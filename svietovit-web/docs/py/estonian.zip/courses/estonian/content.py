"""Treść kursu: estoński dla Polaków."""

PUNCT = {"!", "?", ".", ",", ":"}

TRACKS = {"wymowa": "HÄÄL · WYMOWA", "jezyk": "KEEL · JĘZYK"}

UNITS = [
    {"id": "wymowa", "title": "Wymowa", "icon": "Õ", "track": "wymowa",
     "letters": [
         ("õ", "[ɤ]: nie ma odpowiednika w polskim; coś między y a o, usta niezaokrąglone", "põld (pole)"),
         ("ä", "[æ]: szerokie e, jak w ang. „cat”", "päev (dzień)"),
         ("ö", "[ø]: jak niemieckie ö: o z ustami ułożonymi do e", "töö (praca)"),
         ("ü", "[y]: jak niemieckie ü: u z ustami ułożonymi do i", "tüdruk (dziewczynka)"),
         ("š", "[ʃ]: jak polskie sz (w słowach obcych)", "šokolaad (czekolada)"),
         ("ž", "[ʒ]: jak polskie ż (w słowach obcych)", "žest (gest)"),
         ("h", "[h]: lekkie, wymawiaj zawsze", "hea (dobry)"),
         ("j", "[j]: jak polskie j", "jah (tak)"),
         ("v", "[ʋ]: jak polskie w", "vesi (woda)"),
         ("r", "[r]: toczone, jak polskie", "raamat (książka)"),
         ("aa, ee, ii, oo, uu", "długa samogłoska: wymawiasz ją dwa razy dłużej", "maa (kraj)"),
         ("k, p, t", "[k], [p], [t]: bez dmuchnięcia, jak polskie, czasem brzmią jak g, b, d", "tuba (pokój)"),
         ("pojedyncze i podwójne spółgłoski", "dłuższa spółgłoska zmienia znaczenie słowa", "kala (ryba)"),
     ]},
    {"id": "slowa", "title": "Pierwsze słowa", "icon": "T", "track": "jezyk", "requires": "wymowa",
     "words": [
         ("tere", "cześć", None, None),
         ("nägemist", "do widzenia", None, "Dosł. „do zobaczenia”.", ),
         ("aitäh", "dziękuję", None, None),
         ("palun", "proszę", None, None),
         ("jah", "tak", None, None),
         ("ei", "nie", None, None),
         ("head", "dobre; dobrego", None, None),
         ("ööd", "nocy", None, None),
         ("hommikust", "rano (dzień dobry rano)", None, None),
         ("vabandust", "przepraszam", None, None),
         ("väga", "bardzo", None, None),
         ("ja", "i", None, None),
         ("okei", "dobrze; ok", "okej", None),
     ],
     "sentences": [
         (["tere", "!"], "Cześć!", {"nägemist": "nägemist to „do widzenia”."}),
         (["nägemist", "!"], "Do widzenia!", {"tere": "tere to „cześć”."}),
         (["tere", "hommikust", "!"], "Dzień dobry (rano)!", {"ööd": "ööd to „nocy”."}),
         (["head", "ööd", "!"], "Dobranoc!", {"hommikust": "hommikust to „rano”."}),
         (["aitäh", "!"], "Dziękuję!", {"palun": "palun to „proszę”. Tu dziękujesz."}),
         (["jah", ",", "aitäh"], "Tak, dziękuję.", {"ei": "ei to „nie”."}),
         (["ei", ",", "aitäh"], "Nie, dziękuję.", {"jah": "jah to „tak”."}),
         (["vabandust", "!"], "Przepraszam!", {}),
     ]},
    {"id": "ja", "title": "Ja, ty, on", "icon": "M", "track": "jezyk",
     "words": [
         ("mina", "ja", None, None),
         ("sina", "ty", None, None),
         ("tema", "on; ona", None, "Nie ma rodzaju: „tema” znaczy on i ona."),
         ("olen", "jestem", None, None),
         ("oled", "jesteś", None, None),
         ("on", "jest", None, None),
         ("õpilane", "uczeń; student", None, None),
         ("õpetaja", "nauczyciel", None, None),
         ("poolakas", "Polak", None, None),
         ("poolatar", "Polka", None, None),
         ("pärit", "pochodzący", None, None),
         ("Poolast", "z Polski", None, "Końcówka -st = „z”."),
         ("Eestist", "z Estonii", None, "Końcówka -st = „z”."),
     ],
     "sentences": [
         (["mina", "olen", "õpilane"], "Jestem uczniem.", {"oled": "oled to „jesteś”. O sobie: olen."}),
         (["sina", "oled", "õpetaja"], "Jesteś nauczycielem.", {"olen": "olen to „jestem”. Do „sina”: oled."}),
         (["tema", "on", "poolakas"], "On jest Polakiem.", {"poolatar": "Dla mężczyzny: poolakas."}),
         (["tema", "on", "poolatar"], "Ona jest Polką.", {"poolakas": "Dla kobiety: poolatar."}),
         (["mina", "olen", "pärit", "Poolast"], "Jestem z Polski.", {"Eestist": "Eestist to „z Estonii”."}),
         (["tema", "on", "pärit", "Eestist"], "On jest z Estonii.", {}),
     ]},
    {"id": "ludzie", "title": "Ludzie i rodzina", "icon": "E", "track": "jezyk",
     "words": [
         ("ema", "mama", None, None),
         ("isa", "tata", None, None),
         ("vend", "brat", None, None),
         ("õde", "siostra", None, None),
         ("laps", "dziecko", None, None),
         ("sõber", "przyjaciel", None, None),
         ("naine", "kobieta", None, None),
         ("mees", "mężczyzna", None, None),
         ("minu", "mój; moja", None, "Estoński nie ma rodzaju."),
         ("sinu", "twój; twoja", None, None),
         ("mul", "u mnie (mam)", None, "„Mul on vend” = mam brata."),
         ("sul", "u ciebie (masz)", None, None),
         ("väike", "mały", None, None),
         ("hea", "dobry", None, None),
     ],
     "sentences": [
         (["minu", "vend", "on", "väike"], "Mój brat jest mały.", {"sinu": "sinu to „twój”. O sobie: minu."}),
         (["minu", "õde", "on", "hea"], "Moja siostra jest dobra.", {}),
         (["minu", "ema", "on", "naine"], "Moja mama jest kobietą.", {}),
         (["mul", "on", "vend"], "Mam brata.", {"sul": "sul to „u ciebie”. O sobie: mul."}),
         (["sul", "on", "õde"], "Masz siostrę.", {"mul": "mul to „u mnie”. Do „sina”: sul."}),
         (["isa", "on", "mees"], "Tata jest mężczyzną.", {}),
         (["minu", "sõber", "on", "hea"], "Mój przyjaciel jest dobry.", {}),
     ]},
    {"id": "jedzenie", "title": "Jedzenie i picie", "icon": "K", "track": "jezyk",
     "words": [
         ("vesi", "woda", None, None),
         ("vett", "wodę", None, "Cząstkowy (partitiiv): po „tahan”."),
         ("kohv", "kawa", None, None),
         ("kohvi", "kawę", None, "Partitiiv."),
         ("tee", "herbata", None, None),
         ("teed", "herbatę", None, "Partitiiv."),
         ("leib", "chleb", None, None),
         ("leiba", "chleb (partitiiv)", None, None),
         ("kala", "ryba", None, None),
         ("õun", "jabłko", None, None),
         ("õuna", "jabłko (partitiiv)", None, None),
         ("tahan", "chcę", None, None),
         ("tahad", "chcesz", None, None),
         ("maitsev", "smaczny", None, None),
         ("nüüd", "teraz", None, None),
     ],
     "sentences": [
         (["mina", "tahan", "kohvi"], "Chcę kawę.", {"tahad": "tahad to „chcesz”. O sobie: tahan."}),
         (["sina", "tahad", "teed"], "Chcesz herbatę.", {"tahan": "tahan to „chcę”. Do „sina”: tahad."}),
         (["mina", "tahan", "leiba"], "Chcę chleb.", {}),
         (["sina", "tahad", "õuna"], "Chcesz jabłko.", {}),
         (["kala", "on", "väga", "maitsev"], "Ryba jest bardzo smaczna.", {}),
         (["nüüd", "tahan", "vett"], "Teraz chcę wodę.", {}),
     ]},
    {"id": "liczby", "title": "Liczby i czas", "icon": "1", "track": "jezyk",
     "words": [
         ("kaks", "dwa", None, None),
         ("kolm", "trzy", None, None),
         ("neli", "cztery", None, None),
         ("viis", "pięć", None, None),
         ("kümme", "dziesięć", None, None),
         ("last", "dzieci (partitiiv)", None, "Po liczbie: partitiiv."),
         ("täna", "dziś", None, None),
         ("homme", "jutro", None, None),
         ("eile", "wczoraj", None, None),
         ("kell", "godzina; zegar", None, None),
         ("mis", "co; jaki", None, None),
     ],
     "sentences": [
         (["mul", "on", "kaks", "last"], "Mam dwoje dzieci.", {}),
         (["mina", "tahan", "kolm", "õuna"], "Chcę trzy jabłka.", {"kaks": "kaks to „dwa”. Chcesz trzy: kolm."}),
         (["mis", "kell", "on", "?"], "Która jest godzina?", {}),
         (["kell", "on", "kümme"], "Jest dziesiąta.", {"viis": "viis to „pięć”."}),
         (["täna", "tahan", "kohvi"], "Dziś chcę kawę.", {"homme": "homme to „jutro”. Tu „dziś”: täna."}),
         (["homme", "tahan", "kala"], "Jutro chcę rybę.", {"eile": "eile to „wczoraj”."}),
     ]},
    {"id": "miejsca", "title": "Miejsca i podróż", "icon": "L", "track": "jezyk",
     "words": [
         ("kodu", "dom", None, None),
         ("koju", "do domu", None, None),
         ("linn", "miasto", None, None),
         ("tänav", "ulica", None, None),
         ("kool", "szkoła", None, None),
         ("meri", "morze", None, None),
         ("takso", "taksówka", "taksówka", None),
         ("hotell", "hotel", "hotel", None),
         ("kus", "gdzie", None, None),
         ("siin", "tu", None, None),
         ("seal", "tam", None, None),
         ("lähen", "idę; jadę", None, None),
         ("Tallinna", "do Tallina", None, "Końcówka -sse/-a = „do”."),
         ("paremal", "po prawej", None, None),
         ("vasakul", "po lewej", None, None),
     ],
     "sentences": [
         (["kus", "on", "hotell", "?"], "Gdzie jest hotel?", {"siin": "siin to „tu”. Pytasz „gdzie”: kus."}),
         (["hotell", "on", "seal"], "Hotel jest tam.", {"siin": "siin to „tu”. Tu „tam”: seal."}),
         (["mina", "lähen", "koju"], "Idę do domu.", {}),
         (["mina", "lähen", "Tallinna"], "Jadę do Tallina.", {}),
         (["takso", "on", "paremal"], "Taksówka jest po prawej.", {"vasakul": "vasakul to „po lewej”."}),
         (["kool", "on", "seal"], "Szkoła jest tam.", {}),
     ]},
]

INSIGHTS = {
    "wymowa": [{"title": "Trzy długości", "chain": [],
                "text": "Estoński ma trzy długości głosek: krótką, długą i bardzo długą. Dłuższa głoska zmienia słowo. Samogłoski ä, ö, ü, õ są osobnymi literami, a õ nie ma odpowiednika po polsku."}],
    "ja": [{"title": "Brak rodzaju", "chain": [
                ("On jest Polakiem.", ["tema", "on", "poolakas"], "„tema” = on lub ona."),
                ("Ona jest Polką.", ["tema", "on", "poolatar"], "Ten sam zaimek."),
            ],
            "text": "Po estońsku nie ma rodzaju ani rodzajników. „Tema” znaczy on i ona. Czasownik „być”: olen, oled, on."}],
    "ludzie": [{"title": "Mam = u mnie jest", "chain": [],
                "text": "Nie ma czasownika „mieć”. Mówisz „u mnie jest”: mul on vend (mam brata), sul on õde (masz siostrę)."}],
    "jedzenie": [{"title": "Partitiiv", "chain": [],
                  "text": "Po „chcę” rzeczownik dostaje formę cząstkową (partitiiv): kohv → kohvi, tee → teed, vesi → vett. Uczysz się jej razem ze słowem."}],
}

ENDINGS_INSIGHT = {"title": "Formy osobowe",
                   "text": "Po estońsku czasownik zmienia końcówkę: olen, oled, on; tahan, tahad. Tu to ćwiczysz."}

ENDINGS = [
    ("mina ", "ol", "en", " õpilane", ["en", "ed"], "ja jestem", "Do „mina” pasuje -en.", "ja"),
    ("sina ", "ol", "ed", " õpetaja", ["en", "ed"], "ty jesteś", "Do „sina” pasuje -ed.", "ja"),
    ("mina ", "tah", "an", " kohvi", ["an", "ad"], "ja chcę", "Do „mina” pasuje -an.", "jedzenie"),
    ("sina ", "tah", "ad", " teed", ["an", "ad"], "ty chcesz", "Do „sina” pasuje -ad.", "jedzenie"),
    ("", "", "minu", " vend", ["minu", "sinu"], "mój", "minu to „mój”, sinu to „twój”.", "ludzie"),
    ("", "", "sinu", " õde", ["minu", "sinu"], "twój", "sinu to „twój”.", "ludzie"),
    ("", "", "mul", " on vend", ["mul", "sul"], "u mnie", "mul to „u mnie”.", "ludzie"),
    ("", "", "sul", " on õde", ["mul", "sul"], "u ciebie", "sul to „u ciebie”.", "ludzie"),
    ("mina ", "", "olen", " pärit Poolast", ["olen", "oled"], "ja jestem", "Do „mina” pasuje olen.", "ja"),
]

CHAT_EXTRA = {"Mari": "Mari (imię)", "Jaan": "Jaan (imię)", "taksojuht": "kierowca", "kuhu": "dokąd", "lähed": "idziesz; jedziesz"}

CHATS = [
    {"id": "kohvik", "title": "W kawiarni", "partner": "Mari", "avatar": "M", "requires": "jedzenie",
     "turns": [
         {"bot": ["tere", "hommikust", "!"], "en": "Dzień dobry!",
          "options": [(["tere", "hommikust", "!"], True, None), (["head", "ööd", "!"], False, "head ööd to „dobranoc”. Jest rano.")]},
         {"bot": ["kohvi", "?"], "en": "Kawy?",
          "options": [(["jah", ",", "mina", "tahan", "kohvi"], True, None),
                      (["jah", ",", "sina", "tahad", "kohvi"], False, "tahad jest do „sina”. O sobie: tahan.")]},
         {"bot": ["ja", "leiba", "?"], "en": "I chleba?",
          "options": [(["ei", ",", "aitäh"], True, None),
                      (["palun", "!"], False, "palun to „proszę”. Odmów: ei, aitäh.")]},
         {"bot": ["okei", "!"], "build": (["aitäh", "!"], "Dziękuję!"), "en": "Dobrze!"},
     ]},
    {"id": "tutvus", "title": "Poznajemy się", "partner": "Jaan", "avatar": "J", "requires": "ludzie",
     "turns": [
         {"bot": ["tere", "!"], "en": "Cześć!",
          "options": [(["tere", "!"], True, None), (["vabandust", "!"], False, "vabandust to „przepraszam”. Powitaj: tere.")]},
         {"bot": ["sina", "oled", "pärit", "Eestist", "?"], "en": "Jesteś z Estonii?",
          "options": [(["ei", ",", "mina", "olen", "pärit", "Poolast"], True, None),
                      (["ei", ",", "mina", "oled", "pärit", "Poolast"], False, "oled jest do „sina”. O sobie: olen.")]},
         {"bot": ["sul", "on", "vend", "?"], "en": "Masz brata?",
          "options": [(["jah", ",", "mul", "on", "vend"], True, None),
                      (["jah", ",", "sul", "on", "vend"], False, "sul to „u ciebie”. O sobie: mul.")]},
         {"bot": ["nägemist", "!"], "build": (["nägemist", "!"], "Do widzenia!"), "en": "Do widzenia!"},
     ]},
    {"id": "takso", "title": "W taksówce", "partner": "taksojuht", "avatar": "T", "requires": "miejsca",
     "turns": [
         {"bot": ["tere", "hommikust", "!"], "en": "Dzień dobry!",
          "options": [(["tere", "hommikust", "!"], True, None), (["head", "ööd", "!"], False, "head ööd to „dobranoc”. Jest rano.")]},
         {"bot": ["kuhu", "sina", "lähed", "?"], "en": "Dokąd jedziesz?",
          "options": [(["mina", "lähen", "Tallinna"], True, None),
                      (["mina", "lähed", "Tallinna"], False, "lähed to „idziesz”. O sobie: lähen.")]},
         {"bot": ["hotell", "on", "seal", "."], "en": "Hotel jest tam.",
          "options": [(["paremal", "?"], True, None), (["siin", "?"], False, "Pytasz o kierunek: paremal.")]},
         {"bot": ["jah", "!"], "build": (["aitäh", "!"], "Dziękuję!"), "en": "Tak!"},
     ]},
]


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['mina', 'sina', 'tema', 'meie', 'teie', 'nemad'],
    'przyp': ['nimetav (kto? co?)', 'omastav (czyj?)', 'osastav (kogo? czego?)'],
    'miejsc': ['sisseütlev (do środka)', 'seesütlev (w)', 'seestütlev (ze środka)', 'alaleütlev (na, do)', 'alalütlev (na, u)', 'alaltütlev (z, od)'],
    'im': ['-v (czynny teraźniejszy)', '-nud (czynny przeszły)', '-tav (bierny teraźniejszy)', '-tud (bierny przeszły)'],
    't_osastav': ['raamat (książka)', 'vesi (woda)', 'laps (dziecko)', 'kool (szkoła)', 'käsi (ręka)', 'mees (mężczyzna)'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'elama (żyć, mieszkać)', 'os', 'elan; elad; elab; elame; elate; elavad', 'Końcówki: -n, -d, -b, -me, -te, -vad.'),
    ('conj', 'Wzory koniugacji', 'tahtma (chcieć)', 'os', 'tahan; tahad; tahab; tahame; tahate; tahavad', None),
    ('conj', 'Wzory koniugacji', 'rääkima (mówić)', 'os', 'räägin; räägid; räägib; räägime; räägite; räägivad', 'Wymiana stopnia: kk → g w temacie.'),
    ('conj', 'Czasowniki nieregularne', 'olema (być)', 'os', 'olen; oled; on; oleme; olete; on', '3. osoba ma tę samą formę w obu liczbach: on.'),
    ('conj', 'Czasowniki nieregularne', 'minema (iść)', 'os', 'lähen; lähed; läheb; läheme; lähete; lähevad', 'Temat teraźniejszy jest inny niż bezokolicznik: lähe-.'),
    ('conj', 'Czasowniki nieregularne', 'tulema (przychodzić)', 'os', 'tulen; tuled; tuleb; tuleme; tulete; tulevad', None),
    ('conj', 'Czasowniki nieregularne', 'tegema (robić)', 'os', 'teen; teed; teeb; teeme; teete; teevad', None),
    ('conj', 'Czasowniki nieregularne', 'nägema (widzieć)', 'os', 'näen; näed; näeb; näeme; näete; näevad', None),
    ('conj', 'Czasowniki nieregularne', 'sööma (jeść)', 'os', 'söön; sööd; sööb; sööme; sööte; söövad', None),
    ('decl', 'Trzy główne przypadki', 'raamat (książka)', 'przyp', 'raamat; raamatu; raamatut', 'Te trzy formy trzeba znać dla każdego słowa; reszta przypadków powstaje z dopełniacza.'),
    ('decl', 'Trzy główne przypadki', 'kool (szkoła)', 'przyp', 'kool; kooli; kooli', None),
    ('decl', 'Trzy główne przypadki', 'laps (dziecko)', 'przyp', 'laps; lapse; last', None),
    ('decl', 'Trzy główne przypadki', 'õpilane (uczeń)', 'przyp', 'õpilane; õpilase; õpilast', 'Słowa na -ne: -se, -st.'),
    ('decl', 'Wyjątki', 'vesi (woda)', 'przyp', 'vesi; vee; vett', None),
    ('decl', 'Wyjątki', 'käsi (ręka)', 'przyp', 'käsi; käe; kätt', None),
    ('decl', 'Wyjątki', 'sõber (przyjaciel)', 'przyp', 'sõber; sõbra; sõpra', 'Wymiana stopnia: b → p w osastav.'),
    ('decl', 'Wyjątki', 'mees (mężczyzna)', 'przyp', 'mees; mehe; meest', None),
    ('decl', 'Przypadki miejsca', 'maja (dom): gdzie?', 'miejsc', 'majja; majas; majast; majale; majal; majalt', 'Końcówki dokleja się do dopełniacza: -s, -st, -le, -l, -lt.'),
    ('decl', 'Przypadki miejsca', 'kool (szkoła): gdzie?', 'miejsc', 'kooli; koolis; koolist; koolile; koolil; koolilt', None),
    ('form', 'Imiesłowy', 'lugema (czytać)', 'im', 'lugev; lugenud; loetav; loetud', None),
    ('form', 'Imiesłowy', 'tegema (robić)', 'im', 'tegev; teinud; tehtav; tehtud', None),
    ('form', 'Imiesłowy', 'kirjutama (pisać)', 'im', 'kirjutav; kirjutanud; kirjutatav; kirjutatud', None),
    ('conj', 'Czas przeszły', 'olema: czas przeszły', 'os', 'olin; olid; oli; olime; olite; olid', None),
    ('conj', 'Czas przeszły', 'elama: czas przeszły', 'os', 'elasin; elasid; elas; elasime; elasite; elasid', 'Znak czasu przeszłego: -si-.'),
    ('form', 'Typowe trudności', 'Partitiiv: jaka forma?', 't_osastav', 'raamatut; vett; last; kooli; kätt; meest', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['olen', 'elan', 'tahan', 'lähen', 'teen', 'näen'],
    't_m1': ['üks (1)', 'kaks (2)', 'kolm (3)', 'viis (5)', 'kümme (10)', 'mitu (ile)'],
    't_m2': ['sõber (przyjaciel)', 'tuba (pokój)', 'poeg (syn)', 'jalg (noga)', 'leib (chleb)', 'kapp (szafa)'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Przeczenie: ei + temat', 't_m0', 'ei ole; ei ela; ei taha; ei lähe; ei tee; ei näe', 'W przeczeniu forma jest jedna dla wszystkich osób: mina ei ole, sina ei ole.'),
    ('form', 'Typowe trudności', 'Liczba + rzeczownik', 't_m1', 'üks raamat; kaks raamatut; kolm raamatut; viis raamatut; kümme raamatut; mitu raamatut', 'Po liczbach od 2 w górę stoi partitiiv liczby pojedynczej.'),
    ('form', 'Typowe trudności', 'Wymiana stopni: omastav', 't_m2', 'sõbra; toa; poja; jala; leiva; kapi', 'Temat słabnie w dopełniaczu: b znika lub zmienia się w v, g znika, pp → p.'),
]

# === PRONOUNS (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('decl', 'Zaimki', 'mina (ja)', 'przyp', 'mina; minu; mind', 'Krótkie formy: ma, mu, mind.'),
    ('decl', 'Zaimki', 'sina (ty)', 'przyp', 'sina; sinu; sind', None),
    ('decl', 'Zaimki', 'tema (on, ona)', 'przyp', 'tema; tema; teda', None),
    ('decl', 'Zaimki', 'meie (my)', 'przyp', 'meie; meie; meid', None),
    ('decl', 'Zaimki', 'teie (wy)', 'przyp', 'teie; teie; teid', None),
    ('decl', 'Zaimki', 'nemad (oni)', 'przyp', 'nemad; nende; neid', None),
    ('decl', 'Zaimki', 'see (ten, to)', 'przyp', 'see; selle; seda', None),
    ('decl', 'Zaimki', 'kes (kto)', 'przyp', 'kes; kelle; keda', None),
    ('decl', 'Zaimki', 'mis (co)', 'przyp', 'mis; mille; mida', None),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /PRONOUNS ===

# Pełne tłumaczenia zdań z ćwiczeń „Uzupełnij końcówkę” (gdy nie ma ich wśród zdań kursu)
ENDINGS_PL = {'minu vend': 'mój brat', 'sinu õde': 'twoja siostra'}

# === STOPNIOWANIE (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('form', 'Stopniowanie', 'hea (dobry)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'hea; parem; parim', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'suur (duży)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'suur; suurem; suurim', None),
    ('form', 'Stopniowanie', 'väike (mały)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'väike; väiksem; väikseim', None),
    ('form', 'Stopniowanie', 'vana (stary)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'vana; vanem; vanim', None),
    ('form', 'Stopniowanie', 'ilus (piękny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'ilus; ilusam; kõige ilusam', 'Najczęściej: kõige + stopień wyższy.'),
    ('form', 'Stopniowanie', 'kiire (szybki)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'kiire; kiirem; kõige kiirem', 'Najczęściej: kõige + stopień wyższy.'),
    ('form', 'Stopniowanie', 'pikk (długi)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'pikk; pikem; pikim', None),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /STOPNIOWANIE ===

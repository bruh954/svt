"""Treść kursu: rosyjski dla Polaków.

Wymowa polskimi literami; ś/ć/ń oznaczają miękkie spółgłoski. Akcent wyrazowy jest zaznaczony kreską nad samogłoską (вода́). W zwykłych tekstach się go nie pisze.
"""

PUNCT = {"!", "?", ".", ",", ":"}

TRACKS = {"alfabet": "АЛФАВИТ · ALFABET", "jezyk": "ЯЗЫК · JĘZYK"}

UNITS = [
    {"id": "wymowa", "title": "Litery I", "icon": "А", "track": "alfabet",
     "letters": [
         ("а", "[a]: jak polskie a", "дом (dom)"),
         ("б", "[b]: jak polskie b", "брат (brat)"),
         ("в", "[w]: jak polskie w", "вода́ (woda)"),
         ("г", "[g]: jak polskie g", "год (rok)"),
         ("д", "[d]: jak polskie d", "да (tak)"),
         ("е", "[je] lub [ie]: jak polskie je; zmiękcza poprzednią", "нет (nie)"),
         ("ё", "[jo] lub [io]: jak polskie jo; zawsze akcentowane", "ёлка (choinka)"),
         ("ж", "[ż]: twarde ż, jak w „żaba”", "жена́ (żona)"),
     ]},
    {"id": "wymowa2", "title": "Litery II", "icon": "З", "track": "alfabet",
     "letters": [
         ("з", "[z]: jak polskie z", "зима́ (zima)"),
         ("и", "[i]: jak polskie i", "мир (pokój)"),
         ("й", "[j]: krótkie j po samogłosce", "чай (herbata)"),
         ("к", "[k]: jak polskie k", "кот (kot)"),
         ("л", "[ł] lub [l]: twarde ł; przed i, e miękkie l", "ла́мпа (lampa)"),
         ("м", "[m]: jak polskie m", "ма́ма (mama)"),
         ("н", "[n]: jak polskie n", "нос (nos)"),
         ("о", "[o]: jak polskie o (bez akcentu brzmi jak a)", "молоко́ (mleko)"),
     ]},
    {"id": "wymowa3", "title": "Litery III", "icon": "П", "track": "alfabet",
     "letters": [
         ("п", "[p]: jak polskie p", "па́па (tata)"),
         ("р", "[r]: wibrujące r, jak polskie", "ры́ба (ryba)"),
         ("с", "[s]: jak polskie s", "сыр (ser)"),
         ("т", "[t]: jak polskie t", "там (tam)"),
         ("у", "[u]: jak polskie u", "муж (mąż)"),
         ("ф", "[f]: jak polskie f", "фо́то (zdjęcie)"),
         ("х", "[ch]: jak polskie ch", "хлеб (chleb)"),
         ("ц", "[c]: jak polskie c", "цена́ (cena)"),
     ]},
    {"id": "wymowa4", "title": "Litery IV", "icon": "Ч", "track": "alfabet",
     "letters": [
         ("ч", "[ć]: miękkie cz, jak „ć” w „ćma”", "чай (herbata)"),
         ("ш", "[sz]: twarde sz, jak polskie sz", "шко́ла (szkoła)"),
         ("щ", "[śś]: długie miękkie sz, jak „szcz” bez t", "борщ (barszcz)"),
         ("ъ", "twardy znak: nie jest dźwiękiem, rozdziela", "объе́кт (obiekt)"),
         ("ы", "[y]: jak polskie y", "ты (ty)"),
         ("ь", "miękki znak: zmiękcza poprzednią spółgłoskę", "день (dzień)"),
         ("э", "[e]: twarde e, jak polskie e", "э́то (to)"),
         ("ю", "[ju] lub [iu]: jak polskie ju; zmiękcza", "люблю́ (kocham)"),
         ("я", "[ja] lub [ia]: jak polskie ja; zmiękcza", "я (ja)"),
     ]},
    {"id": "slowa", "title": "Pierwsze słowa", "icon": "П", "track": "jezyk", "requires": "wymowa",
     "words": [
         ("приве́т", "cześć", None, None),
         ("пока́", "pa; na razie", None, None),
         ("спаси́бо", "dziękuję", None, "Z „spasi bog”: niech Bóg zbawi."),
         ("пожа́луйста", "proszę; nie ma za co", None, None),
         ("да", "tak", None, None),
         ("нет", "nie", None, None),
         ("до́брый", "dobry (męski)", None, None),
         ("день", "dzień", None, None),
         ("до́брой", "dobrej (żeński)", None, None),
         ("но́чи", "nocy", None, None),
         ("извини́те", "przepraszam", None, None),
         ("хорошо́", "dobrze", None, None),
         ("о́чень", "bardzo", None, None),
         ("и", "i", None, None),
     ],
     "sentences": [
         (["приве́т", "!"], "Cześć!", {"пока́": "пока́ to „pa”."}),
         (["пока́", "!"], "Pa!", {"приве́т": "приве́т to „cześć”."}),
         (["до́брый", "день", "!"], "Dzień dobry!", {"но́чи": "но́чи to „nocy”."}),
         (["до́брой", "но́чи", "!"], "Dobranoc!", {"день": "день to „dzień”."}),
         (["спаси́бо", "!"], "Dziękuję!", {"пожа́луйста": "пожа́луйста to „proszę”. Tu dziękujesz."}),
         (["да", ",", "спаси́бо"], "Tak, dziękuję.", {"нет": "нет to „nie”."}),
         (["нет", ",", "спаси́бо"], "Nie, dziękuję.", {"да": "да to „tak”."}),
         (["извини́те", "!"], "Przepraszam!", {}),
     ]},
    {"id": "ja", "title": "Ja, ty, on", "icon": "Я", "track": "jezyk",
     "words": [
         ("я", "ja", None, None),
         ("ты", "ty", None, None),
         ("он", "on", None, None),
         ("она́", "ona", None, None),
         ("студе́нт", "student", "student", None),
         ("учи́тель", "nauczyciel", None, None),
         ("поля́к", "Polak", None, None),
         ("по́лька", "Polka", None, None),
         ("из", "z", None, None),
         ("По́льши", "Polski (z Polski)", None, None),
         ("Росси́и", "Rosji (z Rosji)", None, None),
         ("э́то", "to (jest)", None, None),
     ],
     "sentences": [
         (["я", "студе́нт"], "Jestem studentem.", {"ты": "ty to „ты”. O sobie: я."}),
         (["ты", "учи́тель"], "Jesteś nauczycielem.", {"я": "я to „ja”. Do „ты” mówisz o nim."}),
         (["он", "поля́к"], "On jest Polakiem.", {"по́лька": "Dla mężczyzny: поля́к."}),
         (["она́", "по́лька"], "Ona jest Polką.", {"поля́к": "Dla kobiety: по́лька."}),
         (["я", "из", "По́льши"], "Jestem z Polski.", {"Росси́и": "Росси́и to „Rosji”."}),
         (["она́", "из", "Росси́и"], "Ona jest z Rosji.", {}),
         (["э́то", "студе́нт"], "To jest student.", {}),
     ]},
    {"id": "ludzie", "title": "Ludzie i rodzina", "icon": "С", "track": "jezyk",
     "words": [
         ("мой", "mój (męski)", None, None),
         ("моя́", "moja (żeński)", None, None),
         ("ма́ма", "mama", None, None),
         ("па́па", "tata", None, None),
         ("брат", "brat", None, None),
         ("сестра́", "siostra", None, None),
         ("ма́льчик", "chłopiec", None, None),
         ("друг", "przyjaciel", None, None),
         ("же́нщина", "kobieta", None, None),
         ("мужчи́на", "mężczyzna", None, None),
         ("у", "u; przy", None, "„У меня́ есть” = „mam”."),
         ("меня́", "mnie", None, None),
         ("тебя́", "ciebie", None, None),
         ("есть", "jest; ma się", None, None),
         ("ма́ленький", "mały (męski)", None, None),
         ("ма́ленькая", "mała (żeński)", None, None),
         ("до́брая", "dobra (żeński)", None, None),
     ],
     "sentences": [
         (["мой", "брат", "ма́ленький"], "Mój brat jest mały.", {"моя́": "брат jest męski: мой."}),
         (["моя́", "сестра́", "ма́ленькая"], "Moja siostra jest mała.", {"мой": "сестра́ jest żeńska: моя́."}),
         (["моя́", "ма́ма", "до́брая"], "Moja mama jest dobra.", {}),
         (["у", "меня́", "есть", "брат"], "Mam brata.", {"тебя́": "тебя́ to „ciebie”. O sobie: меня́."}),
         (["у", "тебя́", "есть", "сестра́"], "Masz siostrę.", {"меня́": "меня́ to „mnie”. Do „ты”: тебя́."}),
         (["па́па", "мужчи́на"], "Tata jest mężczyzną.", {}),
         (["мой", "друг", "до́брый"], "Mój przyjaciel jest dobry.", {}),
     ]},
    {"id": "jedzenie", "title": "Jedzenie i picie", "icon": "Е", "track": "jezyk",
     "words": [
         ("вода́", "woda", None, None),
         ("во́ду", "wodę", None, "Biernik: -а → -у."),
         ("ко́фе", "kawa", None, None),
         ("чай", "herbata", None, None),
         ("хлеб", "chleb", None, None),
         ("сыр", "ser", None, None),
         ("молоко́", "mleko", None, None),
         ("ры́ба", "ryba", None, None),
         ("ры́бу", "rybę", None, None),
         ("я́блоко", "jabłko", None, None),
         ("хочу́", "chcę", None, None),
         ("хо́чешь", "chcesz", None, None),
         ("вку́сная", "smaczna", None, None),
         ("сейча́с", "teraz", None, None),
     ],
     "sentences": [
         (["я", "хочу́", "ко́фе"], "Chcę kawę.", {"хо́чешь": "хо́чешь to „chcesz”. O sobie: хочу́."}),
         (["ты", "хо́чешь", "чай", "?"], "Chcesz herbatę?", {"хочу́": "хочу́ to „chcę”. Do „ты”: хо́чешь."}),
         (["я", "хочу́", "хлеб"], "Chcę chleb.", {}),
         (["ты", "хо́чешь", "я́блоко", "?"], "Chcesz jabłko?", {}),
         (["ры́ба", "о́чень", "вку́сная"], "Ryba jest bardzo smaczna.", {}),
         (["сейча́с", "я", "хочу́", "во́ду"], "Teraz chcę wodę.", {"вода́": "Po „хочу́” biernik: во́ду."}),
     ]},
    {"id": "liczby", "title": "Liczby i czas", "icon": "1", "track": "jezyk",
     "words": [
         ("два", "dwa", None, None),
         ("три", "trzy", None, None),
         ("четы́ре", "cztery", None, None),
         ("пять", "pięć", None, None),
         ("де́сять", "dziesięć", None, None),
         ("бра́та", "braci (2–4)", None, "Po 2–4: dopełniacz lp."),
         ("де́ти", "dzieci", None, None),
         ("сего́дня", "dziś", None, None),
         ("за́втра", "jutro", None, None),
         ("вчера́", "wczoraj", None, None),
         ("часо́в", "godzin", None, None),
         ("ско́лько", "ile", None, None),
         ("вре́мени", "czasu", None, None),
     ],
     "sentences": [
         (["у", "меня́", "два", "бра́та"], "Mam dwóch braci.", {}),
         (["у", "меня́", "есть", "де́ти"], "Mam dzieci.", {}),
         (["ско́лько", "вре́мени", "?"], "Która jest godzina?", {}),
         (["сейча́с", "де́сять", "часо́в"], "Jest dziesiąta.", {}),
         (["сего́дня", "я", "хочу́", "ко́фе"], "Dziś chcę kawę.", {"за́втра": "за́втра to „jutro”. Tu „dziś”: сего́дня."}),
         (["за́втра", "я", "хочу́", "ры́бу"], "Jutro chcę rybę.", {"вчера́": "вчера́ to „wczoraj”."}),
     ]},
    {"id": "miejsca", "title": "Miejsca i podróż", "icon": "М", "track": "jezyk",
     "words": [
         ("дом", "dom", None, None),
         ("домо́й", "do domu", None, None),
         ("го́род", "miasto", None, None),
         ("у́лица", "ulica", None, None),
         ("шко́ла", "szkoła", None, None),
         ("мо́ре", "morze", None, None),
         ("такси́", "taksówka", "taksówka", None),
         ("гости́ница", "hotel", None, None),
         ("где", "gdzie", None, None),
         ("здесь", "tu", None, None),
         ("там", "tam", None, None),
         ("иду́", "idę (pieszo)", None, None),
         ("е́ду", "jadę (pojazdem)", None, None),
         ("в", "do; w", None, None),
         ("Москву́", "do Moskwy", None, None),
         ("напра́во", "w prawo", None, None),
         ("нале́во", "w lewo", None, None),
     ],
     "sentences": [
         (["где", "гости́ница", "?"], "Gdzie jest hotel?", {"здесь": "здесь to „tu”. Pytasz „gdzie”: где."}),
         (["гости́ница", "там"], "Hotel jest tam.", {"здесь": "здесь to „tu”. Tu „tam”: там."}),
         (["я", "иду́", "домо́й"], "Idę do domu.", {"е́ду": "Pieszo: иду́. Pojazdem: е́ду."}),
         (["я", "е́ду", "в", "Москву́"], "Jadę do Moskwy.", {}),
         (["такси́", "напра́во"], "Taksówka jest w prawo.", {"нале́во": "нале́во to „w lewo”."}),
         (["шко́ла", "там"], "Szkoła jest tam.", {}),
     ]},
]

INSIGHTS = {
    "wymowa": [{"title": "Cyrylica ma tylko 33 litery", "chain": [],
                "text": "Wiele liter znasz: а, к, м, о, т. Zmylić mogą в (czytane [v]), н ([n]), р ([r]), с ([s]), у ([u]). Miękkie samogłoski (е, ё, ю, я) zmiękczają spółgłoskę przed sobą. Kreska nad samogłoską (вода́) pokazuje akcent: w rosyjskim jest ruchomy i trzeba go zapamiętać razem ze słowem. W zwykłych tekstach się go nie pisze."}],
    "ja": [{"title": "Brak „jest”", "chain": [
                ("Jestem studentem.", ["я", "студе́нт"], "Bez „jestem”: po prostu я студе́нт."),
                ("Jesteś nauczycielem.", ["ты", "учи́тель"], "Bez „jesteś”."),
            ],
            "text": "W czasie teraźniejszym nie mówi się „jestem, jest”. Mówisz po prostu: я студе́нт, он поля́к."}],
    "ludzie": [{"title": "Mój i moja", "chain": [],
                "text": "Przymiotniki i „mój” zgadzają się z rodzajem: мой брат (m), моя́ сестра́ (ż). Posiadanie wyrażasz: у меня́ есть… (u mnie jest = mam)."}],
    "jedzenie": [{"title": "Хочу́ i хо́чешь", "chain": [],
                  "text": "Czasownik zmienia końcówkę: я хочу́, ты хо́чешь. Po „хочу́” rzeczownik żeński kończący się na -а przyjmuje -у: вода́ → во́ду."}],
}

ENDINGS_INSIGHT = {"title": "Rodzaj i forma czasownika",
                   "text": "Ćwiczysz rodzaj (мой/моя́) i formy czasownika (хочу́/хо́чешь). Tu to robisz."}

ENDINGS = [
    ("", "", "мой", " брат", ["мой", "моя́"], "mój (męski)", "брат jest męski: мой.", "ludzie"),
    ("", "", "моя́", " сестра́", ["мой", "моя́"], "moja (żeński)", "сестра́ jest żeńska: моя́.", "ludzie"),
    ("", "", "мой", " друг", ["мой", "моя́"], "mój (męski)", "друг jest męski: мой.", "ludzie"),
    ("", "", "моя́", " ма́ма", ["мой", "моя́"], "moja (żeński)", "ма́ма jest żeńska: моя́.", "ludzie"),
    ("у ", "", "меня́", " есть брат", ["меня́", "тебя́"], "u mnie", "O sobie: меня́.", "ludzie"),
    ("у ", "", "тебя́", " есть сестра́", ["меня́", "тебя́"], "u ciebie", "Do „ты”: тебя́.", "ludzie"),
    ("я ", "", "хочу́", " ко́фе", ["хочу́", "хо́чешь"], "ja chcę", "Do „я” pasuje хочу́.", "jedzenie"),
    ("ты ", "", "хо́чешь", " чай", ["хочу́", "хо́чешь"], "ty chcesz", "Do „ты” pasuje хо́чешь.", "jedzenie"),
    ("он ", "", "поля́к", "", ["поля́к", "по́лька"], "Polak (on)", "Mężczyzna: поля́к.", "ja"),
    ("она́ ", "", "по́лька", "", ["поля́к", "по́лька"], "Polka (ona)", "Kobieta: по́лька.", "ja"),
    ("я ", "", "из", " По́льши", ["из", "в"], "z Polski", "из to „z”, в to „do, w”.", "miejsca"),
    ("я е́ду ", "", "в", " Москву́", ["из", "в"], "do Moskwy", "в to „do, w”.", "miejsca"),
]

CHAT_EXTRA = {"А́нна": "Anna (imię)", "Ива́н": "Iwan (imię)", "води́тель": "kierowca", "куда́": "dokąd", "большо́е": "duże"}

CHATS = [
    {"id": "kafe", "title": "W kawiarni", "partner": "А́нна", "avatar": "А", "requires": "jedzenie",
     "turns": [
         {"bot": ["до́брый", "день", "!"], "en": "Dzień dobry!",
          "options": [(["до́брый", "день", "!"], True, None), (["до́брой", "но́чи", "!"], False, "до́брой но́чи to „dobranoc”. Jest dzień.")]},
         {"bot": ["ко́фе", "?"], "en": "Kawę?",
          "options": [(["да", ",", "я", "хочу́", "ко́фе"], True, None),
                      (["да", ",", "ты", "хо́чешь", "ко́фе"], False, "хо́чешь jest do „ты”. O sobie: хочу́.")]},
         {"bot": ["и", "хлеб", "?"], "en": "I chleb?",
          "options": [(["нет", ",", "спаси́бо"], True, None),
                      (["пожа́луйста", "!"], False, "пожа́луйста to „proszę”. Odmów: нет, спаси́бо.")]},
         {"bot": ["хорошо́", "!"], "build": (["спаси́бо", "!"], "Dziękuję!"), "en": "Dobrze!"},
     ]},
    {"id": "znakomstvo", "title": "Poznajemy się", "partner": "Ива́н", "avatar": "И", "requires": "ludzie",
     "turns": [
         {"bot": ["приве́т", "!"], "en": "Cześć!",
          "options": [(["приве́т", "!"], True, None), (["извини́те", "!"], False, "извини́те to „przepraszam”. Powitaj: приве́т.")]},
         {"bot": ["ты", "из", "Росси́и", "?"], "en": "Jesteś z Rosji?",
          "options": [(["нет", ",", "я", "из", "По́льши"], True, None),
                      (["нет", ",", "ты", "из", "По́льши"], False, "ты to „ty”. O sobie: я.")]},
         {"bot": ["у", "тебя́", "есть", "брат", "?"], "en": "Masz brata?",
          "options": [(["да", ",", "у", "меня́", "есть", "брат"], True, None),
                      (["да", ",", "у", "тебя́", "есть", "брат"], False, "тебя́ to „ciebie”. O sobie: меня́.")]},
         {"bot": ["пока́", "!"], "build": (["пока́", "!"], "Pa!"), "en": "Pa!"},
     ]},
    {"id": "taksi", "title": "W taksówce", "partner": "води́тель", "avatar": "В", "requires": "miejsca",
     "turns": [
         {"bot": ["до́брый", "день", "!"], "en": "Dzień dobry!",
          "options": [(["до́брый", "день", "!"], True, None), (["до́брой", "но́чи", "!"], False, "до́брой но́чи to „dobranoc”. Jest dzień.")]},
         {"bot": ["куда́", "?"], "en": "Dokąd?",
          "options": [(["я", "е́ду", "в", "Москву́"], True, None),
                      (["я", "иду́", "в", "Москву́"], False, "иду́ to „idę pieszo”. Taksówką: е́ду.")]},
         {"bot": ["гости́ница", "там", "."], "en": "Hotel jest tam.",
          "options": [(["напра́во", "?"], True, None), (["здесь", "?"], False, "Pytasz o kierunek: напра́во.")]},
         {"bot": ["да", "!"], "build": (["спаси́бо", "!"], "Dziękuję!"), "en": "Tak!"},
     ]},
]


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['я', 'ты', 'он/она́', 'мы', 'вы', 'они́'],
    'przesz': ['он', 'она́', 'оно́', 'они́'],
    'przyp': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'narzędnik', 'miejscownik (о…)'],
    'im': ['czynny teraźniejszy (który robi)', 'czynny przeszły (który robił)', 'bierny teraźniejszy (robiony)', 'bierny przeszły (zrobiony)', 'przysłówkowy współczesny (robiąc)', 'przysłówkowy uprzedni (zrobiwszy)'],
    'krotka': ['on', 'ona', 'ono', 'oni'],
    'rozk': ['чита́ть', 'говори́ть', 'писа́ть', 'идти́', 'есть', 'быть', 'дать', 'пить'],
    'ruch': ['iść (teraz, w jedną stronę)', 'chodzić (wielokrotnie)', 'jechać', 'jeździć', 'lecieć', 'latać', 'nieść', 'nosić'],
    'stopn': ['хоро́ший', 'плохо́й', 'большо́й', 'ма́ленький', 'краси́вый', 'дорого́й', 'молодо́й', 'ста́рый'],
    'setki': ['200', '300', '400', '500', '600', '700', '800', '900'],
    'liczrz': ['1', '2', '3', '4', '5', '11', '21', '22', '100'],
    't_ff': ['дива́н', 'ковёр', 'запо́мнить', 'забы́ть', 'неде́ля', 'у́тро', 'ско́ро', 'кра́сный'],
    't_rekcja': ['благодари́ть (dziękować)', 'поздравля́ть (gratulować)', 'боле́ть (chorować)', 'учи́ться (uczyć się)', 'интересова́ться (interesować się)', 'ждать (czekać)'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'де́лать (robić)', 'os', 'де́лаю; де́лаешь; де́лает; де́лаем; де́лаете; де́лают', 'I koniugacja: -ю, -ешь, -ет, -ем, -ете, -ют.'),
    ('conj', 'Wzory koniugacji', 'чита́ть (czytać)', 'os', 'чита́ю; чита́ешь; чита́ет; чита́ем; чита́ете; чита́ют', None),
    ('conj', 'Wzory koniugacji', 'говори́ть (mówić)', 'os', 'говорю́; говори́шь; говори́т; говори́м; говори́те; говоря́т', 'II koniugacja: -ю, -ишь, -ит, -им, -ите, -ят.'),
    ('conj', 'Wyjątki', 'люби́ть (kochać)', 'os', 'люблю́; лю́бишь; лю́бит; лю́бим; лю́бите; лю́бят', 'W 1. osobie wtrącone л i akcent na końcówce: люблю́.'),
    ('conj', 'Wyjątki', 'жить (żyć)', 'os', 'живу́; живёшь; живёт; живём; живёте; живу́т', 'Temat жив-, końcówki z ё.'),
    ('conj', 'Czasowniki nieregularne', 'хоте́ть (chcieć)', 'os', 'хочу́; хо́чешь; хо́чет; хоти́м; хоти́те; хотя́т', 'Liczba pojedyncza z ч, mnoga z т.'),
    ('conj', 'Czasowniki nieregularne', 'есть (jeść)', 'os', 'ем; ешь; ест; еди́м; еди́те; едя́т', None),
    ('conj', 'Czasowniki nieregularne', 'идти́ (iść)', 'os', 'иду́; идёшь; идёт; идём; идёте; иду́т', None),
    ('conj', 'Czasowniki nieregularne', 'е́хать (jechać)', 'os', 'е́ду; е́дешь; е́дет; е́дем; е́дете; е́дут', None),
    ('conj', 'Czasowniki nieregularne', 'мочь (móc)', 'os', 'могу́; мо́жешь; мо́жет; мо́жем; мо́жете; мо́гут', None),
    ('conj', 'Czasowniki nieregularne', 'быть (być): czas przeszły', 'przesz', 'был; была́; бы́ло; бы́ли', 'Czas przeszły odmienia się przez rodzaj, nie przez osobę.'),
    ('decl', 'Wzory deklinacji', 'брат (brat): męski żywotny', 'przyp', 'брат; бра́та; бра́ту; бра́та; бра́том; бра́те', 'U żywotnych biernik = dopełniacz.'),
    ('decl', 'Wzory deklinacji', 'стол (stół): męski nieżywotny', 'przyp', 'стол; стола́; столу́; стол; столо́м; столе́', 'U nieżywotnych biernik = mianownik.'),
    ('decl', 'Wzory deklinacji', 'ма́ма (mama): żeński na -а', 'przyp', 'ма́ма; ма́мы; ма́ме; ма́му; ма́мой; ма́ме', None),
    ('decl', 'Wzory deklinacji', 'окно́ (okno): nijaki na -о', 'przyp', 'окно́; окна́; окну́; окно́; окно́м; окне́', None),
    ('decl', 'Wzory deklinacji', 'мо́ре (morze): nijaki na -е', 'przyp', 'мо́ре; мо́ря; мо́рю; мо́ре; мо́рем; мо́ре', None),
    ('decl', 'Wyjątki', 'вода́ (woda): ruchomy akcent', 'przyp', 'вода́; воды́; воде́; во́ду; водо́й; воде́', 'W bierniku akcent przeskakuje na temat: во́ду.'),
    ('decl', 'Wyjątki', 'вре́мя (czas)', 'przyp', 'вре́мя; вре́мени; вре́мени; вре́мя; вре́менем; вре́мени', 'Rzeczowniki nijakie na -мя rozszerzają temat o -ен-.'),
    ('decl', 'Wyjątki', 'мать (matka)', 'przyp', 'мать; ма́тери; ма́тери; мать; ма́терью; ма́тери', 'Temat rozszerzony o -ер-.'),
    ('decl', 'Zaimki', 'я (ja)', 'przyp', 'я; меня́; мне; меня́; мной; мне', None),
    ('decl', 'Zaimki', 'ты (ty)', 'przyp', 'ты; тебя́; тебе́; тебя́; тобо́й; тебе́', None),
    ('form', 'Imiesłowy', 'чита́ть / прочита́ть (czytać)', 'im', 'чита́ющий; чита́вший; чита́емый; прочи́танный; чита́я; прочита́в', 'Czynne: -ющий, -вший. Bierne: -емый, -нный. Przysłówkowe: -я, -в. Imiesłów bierny przeszły tworzy się od czasownika dokonanego.'),
    ('form', 'Imiesłowy', 'де́лать / сде́лать (robić)', 'im', 'де́лающий; де́лавший; де́лаемый; сде́ланный; де́лая; сде́лав', None),
    ('form', 'Imiesłowy', 'изуча́ть / изучи́ть (studiować)', 'im', 'изуча́ющий; изуча́вший; изуча́емый; изу́ченный; изуча́я; изучи́в', None),
    ('form', 'Imiesłowy', 'ви́деть / уви́деть (widzieć)', 'im', 'ви́дящий; ви́девший; ви́димый; уви́денный; ви́дя; уви́дев', 'II koniugacja: -ящий, -имый.'),
    ('decl', 'Imiesłowy: odmiana', 'чита́ющий (czytający): rodzaj męski', 'przyp', 'чита́ющий; чита́ющего; чита́ющему; чита́ющий; чита́ющим; чита́ющем', 'Imiesłów odmienia się jak przymiotnik. Po ж, ш, ч, щ pisze się и, nie ы.'),
    ('decl', 'Imiesłowy: odmiana', 'чита́ющая (czytająca): rodzaj żeński', 'przyp', 'чита́ющая; чита́ющей; чита́ющей; чита́ющую; чита́ющей; чита́ющей', None),
    ('form', 'Imiesłowy: forma krótka', 'сде́ланный (zrobiony)', 'krotka', 'сде́лан; сде́лана; сде́лано; сде́ланы', 'W orzeczeniu używa się formy krótkiej, z jednym н: дом сде́лан.'),
    ('form', 'Imiesłowy: forma krótka', 'откры́тый (otwarty)', 'krotka', 'откры́т; откры́та; откры́то; откры́ты', None),
    ('form', 'Tryb rozkazujący', 'Tryb rozkazujący: ty', 'rozk', 'чита́й; говори́; пиши́; иди́; ешь; будь; дай; пей', 'Po samogłosce -й, po spółgłosce -и (pod akcentem) albo -ь. Liczba mnoga i forma grzecznościowa: + -те.'),
    ('form', 'Czasowniki ruchu', 'Pary czasowników ruchu', 'ruch', 'идти́; ходи́ть; е́хать; е́здить; лете́ть; лета́ть; нести́; носи́ть', 'Każdy ruch ma dwa czasowniki: jednokierunkowy (teraz, do celu) i wielokierunkowy (zwykle, tam i z powrotem).'),
    ('conj', 'Czasowniki ruchu', 'ходи́ть (chodzić)', 'os', 'хожу́; хо́дишь; хо́дит; хо́дим; хо́дите; хо́дят', 'W 1. osobie д → ж.'),
    ('conj', 'Czasowniki ruchu', 'е́здить (jeździć)', 'os', 'е́зжу; е́здишь; е́здит; е́здим; е́здите; е́здят', None),
    ('conj', 'Wyjątki', 'пить (pić)', 'os', 'пью; пьёшь; пьёт; пьём; пьёте; пьют', 'Tak samo: бить, лить, шить.'),
    ('conj', 'Wyjątki', 'писа́ть (pisać)', 'os', 'пишу́; пи́шешь; пи́шет; пи́шем; пи́шете; пи́шут', 'Wymiana с → ш we wszystkich osobach.'),
    ('form', 'Stopniowanie', 'Stopień wyższy przymiotników', 'stopn', 'лу́чше; ху́же; бо́льше; ме́ньше; краси́вее; доро́же; моло́же; ста́рше', 'Regularnie: -ее. Częste przymiotniki mają formy nieregularne.'),
    ('decl', 'Zaimki', 'мой (mój)', 'przyp', 'мой; моего́; моему́; мой; мои́м; моём', None),
    ('decl', 'Zaimki', 'э́тот (ten)', 'przyp', 'э́тот; э́того; э́тому; э́тот; э́тим; э́том', None),
    ('decl', 'Zaimki', 'кто (kto)', 'przyp', 'кто; кого́; кому́; кого́; кем; ком', None),
    ('decl', 'Zaimki', 'что (co)', 'przyp', 'что; чего́; чему́; что; чем; чём', None),
    ('form', 'Liczebniki', 'Setki', 'setki', 'две́сти; три́ста; четы́реста; пятьсо́т; шестьсо́т; семьсо́т; восемьсо́т; девятьсо́т', None),
    ('decl', 'Liczebniki', 'оди́н (jeden): rodzaj męski', 'przyp', 'оди́н; одного́; одному́; оди́н; одни́м; одно́м', 'Odmienia się jak zaimek э́тот.'),
    ('decl', 'Liczebniki', 'одна́ (jedna): rodzaj żeński', 'przyp', 'одна́; одно́й; одно́й; одну́; одно́й; одно́й', None),
    ('decl', 'Liczebniki', 'два (dwa)', 'przyp', 'два; двух; двум; два; двумя́; двух', 'Z rzeczownikiem żywotnym biernik = dopełniacz: двух бра́тьев.'),
    ('decl', 'Liczebniki', 'три (trzy)', 'przyp', 'три; трёх; трём; три; тремя́; трёх', None),
    ('decl', 'Liczebniki', 'четы́ре (cztery)', 'przyp', 'четы́ре; четырёх; четырём; четы́ре; четырьмя́; четырёх', None),
    ('decl', 'Liczebniki', 'пять (pięć)', 'przyp', 'пять; пяти́; пяти́; пять; пятью́; пяти́', '5–20 i 30 odmieniają się jak rzeczowniki żeńskie na -ь; akcent pada na końcówkę.'),
    ('decl', 'Liczebniki', 'во́семь (osiem)', 'przyp', 'во́семь; восьми́; восьми́; во́семь; восемью́; восьми́', 'W temacie znika е: восьми́.'),
    ('decl', 'Liczebniki', 'со́рок (czterdzieści)', 'przyp', 'со́рок; сорока́; сорока́; со́рок; сорока́; сорока́', 'Tylko dwie formy: со́рок i сорока́. Tak samo девяно́сто i сто.'),
    ('decl', 'Liczebniki', 'сто (sto)', 'przyp', 'сто; ста; ста; сто; ста; ста', None),
    ('decl', 'Liczebniki', 'пятьдеся́т (pięćdziesiąt)', 'przyp', 'пятьдеся́т; пяти́десяти; пяти́десяти; пятьдеся́т; пятью́десятью; пяти́десяти', '50–80: odmieniają się obie części.'),
    ('decl', 'Liczebniki', 'две́сти (dwieście)', 'przyp', 'две́сти; двухсо́т; двумста́м; две́сти; двумяста́ми; двухста́х', 'W setkach odmieniają się obie części.'),
    ('decl', 'Liczebniki', 'ты́сяча (tysiąc)', 'przyp', 'ты́сяча; ты́сячи; ты́сяче; ты́сячу; ты́сячей; ты́сяче', 'Odmienia się jak rzeczownik żeński.'),
    ('decl', 'Liczebniki', 'дво́е (dwoje): zbiorowy', 'przyp', 'дво́е; двои́х; двои́м; дво́е; двои́ми; двои́х', None),
    ('decl', 'Liczebniki', 'о́ба (obaj)', 'przyp', 'о́ба; обо́их; обо́им; о́ба; обо́ими; обо́их', 'Rodzaj żeński: о́бе, обе́их.'),
    ('form', 'Liczebniki', 'Liczebnik + rzeczownik: год (rok)', 'liczrz', 'оди́н год; два го́да; три го́да; четы́ре го́да; пять лет; оди́ннадцать лет; два́дцать оди́н год; два́дцать два го́да; сто лет', 'Po 1: mianownik lp. Po 2–4: dopełniacz lp. Po 5–20: dopełniacz lm. O formie decyduje ostatnie słowo liczebnika.'),
    ('form', 'Liczebniki', 'Liczebnik + rzeczownik: кни́га (książka)', 'liczrz', 'одна́ кни́га; две кни́ги; три кни́ги; четы́ре кни́ги; пять книг; оди́ннадцать книг; два́дцать одна́ кни́га; два́дцать две кни́ги; сто книг', 'W rodzaju żeńskim: одна́, две.'),
    ('form', 'Typowe trudności', 'Fałszywi przyjaciele: co to znaczy?', 't_ff', 'kanapa; dywan; zapamiętać; zapomnieć; tydzień; rano; wkrótce; czerwony', None),
    ('form', 'Typowe trudności', 'Rekcja: jaki przypadek po czasowniku?', 't_rekcja', 'кого́ (biernik); кого́ с чем; чем (narzędnik); чему́ (celownik); чем (narzędnik); кого́, что (bez przyimka)', 'Po polsku: czekać na kogoś; po rosyjsku bez przyimka: ждать дру́га.'),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['окно́', 'письмо́', 'сестра́', 'го́род', 'дом', 'учи́тель', 'рука́', 'гора́'],
    't_m1': ['я', 'ты', 'он', 'она́', 'мы', 'вы', 'они́'],
    't_m2': ['он у́чи…ся (3. osoba)', 'на́до учи́…ся (bezokolicznik)', 'она́ смеё…ся (3. osoba)', 'хочу́ улыба́…ся (bezokolicznik)', 'они́ верну́…ся (3. osoba)', 'ну́жно верну́…ся (bezokolicznik)'],
    't_m3': ['ж…знь (życie)', 'ш…на (opona)', 'ч…сто (często)', 'щ…ка (szczupak)', 'ч…до (cud)', 'маш…на (samochód)'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Ruchomy akcent: liczba mnoga', 't_m0', 'о́кна; пи́сьма; сёстры; города́; дома́; учителя́; ру́ки; го́ры', 'W liczbie mnogiej akcent często przeskakuje. Część rzeczowników męskich ma w lm. akcentowane -а́, -я́.'),
    ('form', 'Typowe trudności', '„Mam”: у кого́ есть?', 't_m1', 'у меня́; у тебя́; у него́; у неё; у нас; у вас; у них', 'Zamiast „mam” mówi się „u mnie jest”: у меня́ есть брат.'),
    ('form', 'Typowe trudności', 'Pisownia: -тся czy -ться?', 't_m2', '-тся; -ться; -тся; -ться; -тся; -ться', 'Zapytaj: что де́лает? (bez ь) czy что де́лать? (z ь).'),
    ('form', 'Typowe trudności', 'Pisownia po ж, ш, ч, щ', 't_m3', 'и; и; а; у; у; и', 'Po ж, ш, ч, щ pisze się и, а, у, nigdy ы, я, ю.'),
]

# === PRONOUNS (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /PRONOUNS ===

# Pełne tłumaczenia zdań z ćwiczeń „Uzupełnij końcówkę” (gdy nie ma ich wśród zdań kursu)
ENDINGS_PL = {'мой брат': 'mój brat', 'моя́ сестра́': 'moja siostra', 'мой друг': 'mój przyjaciel', 'моя́ ма́ма': 'moja mama'}

# === STOPNIOWANIE (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('form', 'Stopniowanie', 'хоро́ший (dobry)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'хоро́ший; лу́чше; лу́чший', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'большо́й (duży)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'большо́й; бо́льше; са́мый большо́й', None),
    ('form', 'Stopniowanie', 'ма́ленький (mały)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'ма́ленький; ме́ньше; са́мый ма́ленький', None),
    ('form', 'Stopniowanie', 'плохо́й (zły)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'плохо́й; ху́же; ху́дший', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'высо́кий (wysoki)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'высо́кий; вы́ше; са́мый высо́кий', 'Zmiana spółgłoski: к → ш.'),
    ('form', 'Stopniowanie', 'краси́вый (piękny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'краси́вый; краси́вее; са́мый краси́вый', 'Regularne: -ее.'),
    ('form', 'Stopniowanie', 'ста́рый (stary)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'ста́рый; ста́рше; са́мый ста́рый', None),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /STOPNIOWANIE ===

# === GRAMATYKA 1 (generowane) ===
PARADIGMS += [
    ('form', 'Aspekt czasownika', 'aspekt: robić', ['niedokonany', 'dokonany'], 'де́лать; сде́лать', 'Niedokonany: czynność trwa lub się powtarza. Dokonany: czynność zakończona z wynikiem.'),
    ('form', 'Aspekt czasownika', 'aspekt: pisać', ['niedokonany', 'dokonany'], 'писа́ть; написа́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: czytać', ['niedokonany', 'dokonany'], 'чита́ть; прочита́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: mówić', ['niedokonany', 'dokonany'], 'говори́ть; сказа́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: kupować', ['niedokonany', 'dokonany'], 'покупа́ть; купи́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: brać', ['niedokonany', 'dokonany'], 'брать; взять', None),
    ('form', 'Aspekt czasownika', 'aspekt: dawać', ['niedokonany', 'dokonany'], 'дава́ть; дать', None),
    ('form', 'Aspekt czasownika', 'aspekt: widzieć', ['niedokonany', 'dokonany'], 'ви́деть; уви́деть', None),
    ('form', 'Aspekt czasownika', 'aspekt: otwierać', ['niedokonany', 'dokonany'], 'открыва́ть; откры́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: decydować', ['niedokonany', 'dokonany'], 'реша́ть; реши́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: opowiadać', ['niedokonany', 'dokonany'], 'расска́зывать; рассказа́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: zaczynać', ['niedokonany', 'dokonany'], 'начина́ть; нача́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: zapominać', ['niedokonany', 'dokonany'], 'забыва́ть; забы́ть', None),
    ('form', 'Aspekt czasownika', 'aspekt: jeść', ['niedokonany', 'dokonany'], 'есть; съесть', None),
    ('form', 'Aspekt czasownika', 'aspekt: pić', ['niedokonany', 'dokonany'], 'пить; вы́пить', None),
    ('form', 'Aspekt czasownika', 'aspekt: uczyć się', ['niedokonany', 'dokonany'], 'учи́ться; научи́ться', None),
    ('form', 'Aspekt czasownika', 'aspekt: odpowiadać', ['niedokonany', 'dokonany'], 'отвеча́ть; отве́тить', None),
    ('form', 'Aspekt czasownika', 'aspekt: pytać', ['niedokonany', 'dokonany'], 'спра́шивать; спроси́ть', None),
    ('form', 'Czas przeszły', 'czas przeszły: чита́ть (czytać)', ['r. męski', 'r. żeński', 'r. nijaki', 'liczba mnoga'], 'чита́л; чита́ла; чита́ло; чита́ли', None),
    ('form', 'Czas przeszły', 'czas przeszły: идти́ (iść)', ['r. męski', 'r. żeński', 'r. nijaki', 'liczba mnoga'], 'шёл; шла; шло; шли', None),
    ('form', 'Czas przeszły', 'czas przeszły: мочь (móc)', ['r. męski', 'r. żeński', 'r. nijaki', 'liczba mnoga'], 'мог; могла́; могло́; могли́', None),
    ('form', 'Czas przeszły', 'czas przeszły: хоте́ть (chcieć)', ['r. męski', 'r. żeński', 'r. nijaki', 'liczba mnoga'], 'хоте́л; хоте́ла; хоте́ло; хоте́ли', None),
    ('form', 'Czas przeszły', 'czas przeszły: жить (żyć)', ['r. męski', 'r. żeński', 'r. nijaki', 'liczba mnoga'], 'жил; жила́; жи́ло; жи́ли', None),
    ('form', 'Czas przeszły', 'czas przeszły: говори́ть (mówić)', ['r. męski', 'r. żeński', 'r. nijaki', 'liczba mnoga'], 'говори́л; говори́ла; говори́ло; говори́ли', None),
    ('form', 'Czas przeszły', 'czas przeszły: писа́ть (pisać)', ['r. męski', 'r. żeński', 'r. nijaki', 'liczba mnoga'], 'писа́л; писа́ла; писа́ло; писа́ли', None),
    ('conj', 'Czasowniki nieregularne', 'быть: czas przyszły', ['я', 'ты', 'он / она', 'мы', 'вы', 'они'], 'бу́ду; бу́дешь; бу́дет; бу́дем; бу́дете; бу́дут', None),
    ('conj', 'Czasowniki nieregularne', 'учи́ться (uczyć się)', ['я', 'ты', 'он / она', 'мы', 'вы', 'они'], 'учу́сь; у́чишься; у́чится; у́чимся; у́читесь; у́чатся', None),
    ('conj', 'Czasowniki nieregularne', 'дать (dać): dokonany', ['я', 'ты', 'он / она', 'мы', 'вы', 'они'], 'дам; дашь; даст; дади́м; дади́те; даду́т', None),
    ('form', 'Liczba mnoga', 'mnoga: друг (przyjaciel)', ['liczba pojedyncza', 'liczba mnoga'], 'друг; друзья́', 'Nieregularna liczba mnoga.'),
    ('form', 'Liczba mnoga', 'mnoga: ребёнок (dziecko)', ['liczba pojedyncza', 'liczba mnoga'], 'ребёнок; де́ти', 'Nieregularna liczba mnoga.'),
    ('form', 'Liczba mnoga', 'mnoga: челове́к (człowiek)', ['liczba pojedyncza', 'liczba mnoga'], 'челове́к; лю́ди', 'Nieregularna liczba mnoga.'),
    ('form', 'Liczba mnoga', 'mnoga: брат (brat)', ['liczba pojedyncza', 'liczba mnoga'], 'брат; бра́тья', 'Nieregularna liczba mnoga.'),
    ('form', 'Liczba mnoga', 'mnoga: мать (matka)', ['liczba pojedyncza', 'liczba mnoga'], 'мать; ма́тери', 'Nieregularna liczba mnoga.'),
    ('form', 'Liczba mnoga', 'mnoga: сын (syn)', ['liczba pojedyncza', 'liczba mnoga'], 'сын; сыновья́', 'Nieregularna liczba mnoga.'),
    ('form', 'Liczba mnoga', 'mnoga: стул (krzesło)', ['liczba pojedyncza', 'liczba mnoga'], 'стул; сту́лья', 'Nieregularna liczba mnoga.'),
    ('form', 'Liczba mnoga', 'mnoga: дерево (drzewo)', ['liczba pojedyncza', 'liczba mnoga'], 'де́рево; дере́вья', 'Nieregularna liczba mnoga.'),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: кни́га (książka)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'кни́га; книг', 'Używa się go po liczebnikach 5 i więcej oraz po słowach „мно́го”, „ма́ло”.'),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: окно́ (okno)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'окно́; о́кон', None),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: де́вушка (dziewczyna)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'де́вушка; де́вушек', None),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: рубль (rubel)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'рубль; рубле́й', None),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: студе́нт (student)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'студе́нт; студе́нтов', None),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: день (dzień)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'день; дней', None),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: друг (przyjaciel)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'друг; друзе́й', None),
    ('form', 'Dopełniacz liczby mnogiej', 'dop. mnoga: мать (matka)', ['mianownik l. poj.', 'dopełniacz l. mn.'], 'мать; матере́й', None),
    ('form', 'Typowe trudności', 'Przyimek: jaki przypadek?', ['Я иду́ в ___ (шко́ла)', 'Я в ___ (шко́ла)', 'Я иду́ из ___ (шко́ла)', 'Я иду́ к ___ (друг)', 'Я иду́ с ___ (друг)', 'Я ду́маю о ___ (друг)'], 'шко́лу; шко́ле; шко́лы; дру́гу; дру́гом; дру́ге', 'в + biernik (dokąd?), в + miejscownik (gdzie?), из + dopełniacz, к + celownik, с + narzędnik, о + miejscownik.'),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /GRAMATYKA 1 ===

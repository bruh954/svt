"""[en — wygenerowane przez tools/i18n.py, nie edytuj] Treść kursu: łacina klasyczna dla Polaków.

Słowo:     (forma z iloczasem, znaczenie po polsku, polskie słowo z łaciny lub None, skojarzenie lub None)
Wymowa:    (litera lub dwuznak, jak czytać, przykład)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie)

Wymowa (pole „tr”) powstaje automatycznie w engine.py: wymowa klasyczna
zapisana po polsku, np. caelum → kajlum.
"""

UNITS = [
    # ---------------------------------------------------------------- wymowa
    {
        "id": "wymowa", "title": 'Pronunciation', "icon": "I", "track": "wymowa",
        "letters": [
            ("c", '[k]: Cicerō is read “Kikero”', "Cicerō"),
            ("v", '[w], as in English “wine”', "vīta"),
            ("ae", '[ae̯]: Caesar is read “Kaisar”', "Caesar"),
            ("oe", '[oe̯]: poena is read “poina”', "poena"),
            ("qu", '[kʷ]: aqua is read “akwa”', "aqua"),
            ("ph", '[pʰ] (words from Greek; later f)', "philosophia"),
            ("ch", '[kʰ] (words from Greek)', "chorus"),
            ("i", '[i], but before a vowel [j]: iam is read “yam”', "iam"),
            ("ā", '[aː]: the bar only marks length', "māter"),
            ("ti", '[ti], never [ts]: nātiō', "nātiō"),
            ("s", '[s], never [z]: rosa is read “rossa”', "rosa"),
            ("x", '[ks]: rēx is read “rēks”', "rēx"),
        ],
    },
    # ----------------------------------------------------------------- język
    {
        "id": "slowa", "title": 'First words', "icon": "II", "track": "jezyk", "requires": "wymowa",
        "words": [
            ("salvē", 'hello', 'salvo', 'Literally “be well”. A gun salute (salvo) is a greeting too!'),
            ("valē", 'goodbye; farewell', None, 'The Romans said goodbye by wishing good health.'),
            ("ego", 'I', 'ego; egoist', None),
            ("tū", 'you', 'thou', None),
            ("et", 'and', 'et cetera', 'The sign & is a stylised “et”!'),
            ("nōn", 'not; no', 'nonsense', None),
            ("sum", 'I am', None, None),
            ("es", 'you are', None, None),
            ("est", 'is', 'is', 'Close to English “is”: both come from the same Proto-Indo-European word.'),
            ("puer", 'boy', None, None),
            ("puella", 'girl', None, None),
            ("amīcus", 'friend', 'amicable', None),
            ("bonus", 'good (masculine)', 'bonus', 'A bonus is “something good” on top.'),
            ("bona", 'good (feminine)', 'bona fide', None),
            ("magnus", 'great (masculine)', 'magnate', None),
            ("magna", 'great (feminine)', 'Magna Carta', None),
            ("Rōma", 'Rome', 'Romance', None),
        ],
        "sentences": [
            (["ego", "sum", "puer"], 'I am a boy.',
             {"es": 'es means “you are”. About yourself: sum (I am).', "est": 'est means “is”. About yourself: sum.'}),
            (["tū", "es", "puella"], 'You are a girl.', {"sum": 'sum means “I am”. To “you”: es.'}),
            (["amīcus", "bonus", "est"], 'The friend is good.',
             {"bona": 'amīcus is masculine: bonus.'}),
            (["Rōma", "magna", "est"], 'Rome is great.',
             {"magnus": 'Rōma is feminine, so magna.'}),
            (["nōn", "sum", "magnus"], 'I am not great.', {}),
            (["puella", "bona", "est"], 'The girl is good.',
             {"bonus": 'puella is feminine: bona.'}),
        ],
    },
    {
        "id": "rodzina", "title": 'Family', "icon": "III", "track": "jezyk",
        "words": [
            ("pater", 'father', 'paternal', None),
            ("māter", 'mother', 'maternal', None),
            ("fīlius", 'son', 'filial', 'Filial love is the love of a son or daughter.'),
            ("fīlia", 'daughter', 'affiliate', None),
            ("frāter", 'brother', 'fraternity', None),
            ("soror", 'sister', None, None),
            ("vir", 'man; husband', 'virtue', 'From vir comes virtus: manliness, courage. Hence English virtue.'),
            ("fēmina", 'woman', 'feminine', None),
            ("homō", 'human being', 'homo sapiens', None),
            ("dominus", 'master; lord', 'dominate', None),
            ("servus", 'slave; servant', 'servant', '“Servus!” (literally “your servant”) is still a greeting in Central Europe.'),
            ("meus", 'my (masculine)', None, None),
            ("mea", 'my (feminine)', None, None),
            ("tuus", 'your (masculine)', None, None),
            ("tua", 'your (feminine)', None, None),
        ],
        "sentences": [
            (["pater", "meus", "bonus", "est"], 'My father is good.',
             {"mea": 'pater is masculine: meus (my).'}),
            (["māter", "mea", "fēmina", "bona", "est"], 'My mother is a good woman.',
             {"meus": 'māter is feminine: mea (my).'}),
            (["frāter", "meus", "amīcus", "tuus", "est"], 'My brother is your friend.', {}),
            (["fīlia", "tua", "puella", "bona", "est"], 'Your daughter is a good girl.',
             {"tuus": 'fīlia is feminine: tua (your).'}),
        ],
    },
    {
        "id": "liczby", "title": 'Numbers', "icon": "IV", "track": "jezyk",
        "words": [
            ("ūnus", 'one', 'unique; union', None),
            ("duo", 'two', 'duet', None),
            ("trēs", 'three', 'trio', None),
            ("quattuor", 'four', 'quartet', None),
            ("quīnque", 'five', 'quintet', None),
            ("sex", 'six', 'sextet', None),
            ("septem", 'seven', 'September', 'September was the seventh month of the old Roman calendar.'),
            ("octō", 'eight', 'octave', None),
            ("novem", 'nine', 'November', None),
            ("decem", 'ten', 'decimal', None),
            ("sunt", '(they) are', None, None),
            ("puerī", 'boys · nominative pl.', None, None),
        ],
        "sentences": [
            (["ūnus", "et", "ūnus", "sunt", "duo"], 'One and one is two.',
             {"est": 'Plural subject: sunt (are).'}),
            (["septem", "et", "trēs", "sunt", "decem"], 'Seven and three is ten.', {}),
            (["trēs", "puerī", "sunt"], 'There are three boys.',
             {"puer": 'Three: plural, puerī.'}),
        ],
    },
    {
        "id": "swiat", "title": 'The world', "icon": "V", "track": "jezyk",
        "words": [
            ("terra", 'earth; land', 'terrain; territory', None),
            ("terrā", '(on) the earth · ablative', None, 'Ablative: in terrā = on the earth.'),
            ("aqua", 'water', 'aquarium', None),
            ("caelum", 'sky; heaven', None, 'Hence English “celestial”.'),
            ("caelō", '(in) the sky · ablative', None, None),
            ("sōl", 'sun', 'solar', None),
            ("lūna", 'moon', 'lunar', 'A lunatic was thought to be affected by the moon.'),
            ("stella", 'star', 'constellation', None),
            ("via", 'road; way', 'viaduct', None),
            ("urbs", 'city', 'urban', None),
            ("silva", 'forest', 'Sylvia', 'Sylvia means “of the forest”.'),
            ("mare", 'sea', 'marine', None),
            ("vīta", 'life', 'vital', 'Vitamin = “amine of life”.'),
            ("brevis", 'short', 'brief', 'Brief comes from brevis.'),
            ("in", 'in; on', 'in', None),
        ],
        "sentences": [
            (["sōl", "in", "caelō", "est"], 'The sun is in the sky.',
             {"caelum": 'Where? After “in” the ablative: caelō.'}),
            (["aqua", "in", "terrā", "est"], 'Water is on the earth.',
             {"terra": 'Where? Ablative: terrā.'}),
            (["vīta", "brevis", "est"], 'Life is short.', {}),
            (["Rōma", "urbs", "magna", "est"], 'Rome is a great city.', {}),
        ],
    },
    {
        "id": "czas", "title": 'Verbs', "icon": "VI", "track": "jezyk",
        "words": [
            ("amō", 'I love', 'amateur', 'An amateur is someone who “loves” doing something.'),
            ("amat", '(he/she) loves', None, None),
            ("videō", 'I see', 'video', None),
            ("videt", '(he/she) sees', None, None),
            ("legō", 'I read', 'legend', 'Legend = “something to be read”.'),
            ("legit", '(he/she) reads', None, None),
            ("scrībō", 'I write', 'scribe', None),
            ("scrībis", 'you write', None, None),
            ("audiō", 'I hear', 'audio', None),
            ("labōrat", '(he/she) works', 'laboratory', None),
            ("quid", 'what', None, None),
            ("liber", 'book', 'library', None),
            ("librum", 'book · accusative', None, 'Accusative: what do I read? librum.'),
            ("aquam", 'water · accusative', None, None),
            ("Rōmam", 'Rome · accusative', None, None),
        ],
        "sentences": [
            (["ego", "librum", "legō"], 'I am reading a book.',
             {"legit": 'legit means “reads” (he). About yourself: legō.',
              "liber": 'What do I read? Accusative: librum.'}),
            (["quid", "scrībis"], 'What are you writing?', {"scrībō": "You're asking someone: scrībis (-s for “you”)."}),
            (["puella", "aquam", "videt"], 'The girl sees the water.',
             {"aqua": 'What does she see? Accusative: aquam.', "videō": 'videō means “I see”. She: videt.'}),
            (["amō", "Rōmam"], 'I love Rome.', {"Rōma": 'What do I love? Accusative: Rōmam.'}),
            (["pater", "labōrat"], 'Father is working.', {}),
        ],
    },
    {
        "id": "przypadki", "title": 'Cases', "icon": "VII", "track": "jezyk",
        "words": [
            ("grātiās", 'thanks · accusative pl.', 'gratitude', 'Gratis = “for thanks”, so free of charge.'),
            ("agō", 'I give; I do', 'agenda', None),
            ("Deus", 'God', None, None),
            ("Deō", 'to God · dative', None, None),
            ("domine", 'Lord! · vocative', None, 'The vocative of -us is -e: domine!'),
            ("amīce", 'friend! · vocative', None, None),
            ("Rōmae", 'in Rome · locative', None, 'An old locative case, used for cities.'),
            ("domī", 'at home · locative', None, 'Another old locative.'),
        ],
        "sentences": [
            (["grātiās", "agō"], 'Thank you.', {}),
            (["Deō", "grātiās"], 'Thanks be to God.', {"Deus": 'To whom? Dative: Deō.'}),
            (["amīce", ",", "salvē"], 'Hello, friend!',
             {"amīcus": 'Calling someone: vocative amīce.'}),
            (["Rōmae", "sum"], 'I am in Rome.', {"Rōma": 'Where? Rōmae (in Rome).'}),
            (["domī", "sum"], 'I am at home.', {}),
        ],
    },
    {
        "id": "perfekt", "title": 'Past tense', "icon": "VIII", "track": "jezyk",
        "words": [
            ("vēnī", 'I came', None, 'Perfect tense: -ī = “I … -ed”.'),
            ("vīdī", 'I saw', None, None),
            ("vīcī", 'I conquered', 'victory', None),
            ("fuī", 'I was', None, None),
            ("erat", '(he/she) was', None, None),
            ("dīxit", '(he/she) said', 'dictator', 'A dictator is the one who “says” what to do.'),
            ("scrīpsit", '(he/she) wrote', 'script', None),
            ("Caesar", 'Caesar', 'Kaiser; tsar', "Caesar's name became a title: Kaiser, tsar."),
        ],
        "sentences": [
            (["vēnī", ",", "vīdī", ",", "vīcī"], 'I came, I saw, I conquered.', {}),
            (["Caesar", "dīxit"], 'Caesar said.', {}),
            (["Rōma", "magna", "erat"], 'Rome was great.', {"est": 'In the past: erat (was), not est.'}),
            (["puella", "librum", "scrīpsit"], 'The girl wrote a book.', {}),
            (["fuī", "Rōmae"], 'I was in Rome.', {"sum": 'In the past: fuī (I was).'}),
        ],
    },
    # -------------------------------------------------------------- sentencje
    {
        "id": "sent1", "title": 'Sayings I', "icon": "IX", "track": "sentencje", "requires": "czas",
        "words": [
            ("carpe", 'seize; pluck', None, 'Literally “pluck”, like fruit.'),
            ("diem", 'day · accusative', 'diary', 'A diary is a daily record, from diēs (day).'),
            ("errāre", 'to err', 'error', None),
            ("hūmānum", 'human (neuter)', 'humanism', None),
            ("mementō", 'remember', 'memento', None),
            ("morī", 'to die', 'mortal', 'Related to mors (death), hence mortal.'),
            ("cōgitō", 'I think', None, None),
            ("ergō", 'therefore', 'ergo', None),
        ],
        "sentences": [
            (["carpe", "diem"], 'Seize the day.', {}),
            (["errāre", "hūmānum", "est"], 'To err is human.', {}),
            (["mementō", "morī"], 'Remember that you will die.', {}),
            (["cōgitō", ",", "ergō", "sum"], 'I think, therefore I am.', {}),
        ],
    },
    {
        "id": "sent2", "title": 'Sayings II', "icon": "X", "track": "sentencje",
        "words": [
            ("per", 'through', 'per cent', None),
            ("aspera", 'hardships · accusative pl.', None, None),
            ("ad", 'to; towards', 'adapt', None),
            ("astra", 'stars · accusative pl.', 'astronomy', None),
            ("ālea", 'die (for games)', None, None),
            ("iacta", 'cast; thrown', None, None),
            ("vīnō", '(in) wine · ablative', 'wine', None),
            ("vēritās", 'truth', 'verify', None),
            ("tempus", 'time', 'tempo', None),
            ("fugit", 'flees', 'fugitive', 'A fugue is music where voices “flee” one after another.'),
            ("mēns", 'mind', 'mental', None),
            ("sāna", 'healthy (feminine)', 'sanatorium', None),
            ("corpore", '(in) the body · ablative', 'corporal', None),
            ("sānō", 'healthy · ablative', None, None),
        ],
        "sentences": [
            (["per", "aspera", "ad", "astra"], 'Through hardships to the stars.', {}),
            (["ālea", "iacta", "est"], 'The die is cast.', {}),
            (["in", "vīnō", "vēritās"], 'In wine, truth.', {}),
            (["tempus", "fugit"], 'Time flies.', {}),
            (["mēns", "sāna", "in", "corpore", "sānō"], 'A healthy mind in a healthy body.', {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "pater", "title": 'Pater noster', "icon": "XI", "track": "teksty", "requires": "przypadki",
        "words": [
            ("noster", 'our', None, None),
            ("quī", 'who', None, None),
            ("caelīs", 'heavens · ablative', None, None),
            ("sānctificētur", 'hallowed be', 'sanctuary', None),
            ("nōmen", 'name', 'nominate', None),
            ("tuum", 'your · nominative n.', None, None),
            ("adveniat", 'may (it) come', 'advent', 'Advent = “coming”.'),
            ("rēgnum", 'kingdom', 'reign', None),
            ("fīat", 'be done', None, None),
            ("voluntās", 'will', 'voluntary', None),
            ("sīcut", 'as; just as', None, None),
        ],
        "sentences": [
            (["pater", "noster", ",", "quī", "es", "in", "caelīs"], 'Our Father, who art in heaven.', {}),
            (["sānctificētur", "nōmen", "tuum"], 'Hallowed be thy name.', {}),
            (["adveniat", "rēgnum", "tuum"], 'Thy kingdom come.', {}),
            (["fīat", "voluntās", "tua"], 'Thy will be done.', {"tuum": 'voluntās is feminine: tua.'}),
            (["sīcut", "in", "caelō", "et", "in", "terrā"], 'On earth as it is in heaven.', {}),
        ],
    },
    {
        "id": "gallia", "title": 'Caesar: Gaul', "icon": "XII", "track": "teksty",
        "words": [
            ("Gallia", 'Gaul', 'Gallic', None),
            ("Galliā", '(in) Gaul · ablative', None, None),
            ("omnis", 'whole; all', 'omnibus', 'Omnibus = “for everyone”.'),
            ("dīvīsa", 'divided', 'division', None),
            ("partēs", 'parts · accusative pl.', 'part; party', None),
        ],
        "sentences": [
            (["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
             'All Gaul is divided into three parts.', {}),
            (["Caesar", "in", "Galliā", "erat"], 'Caesar was in Gaul.', {"Gallia": 'Where? Ablative: in Galliā.'}),
        ],
    },
]

TRACKS = {
    "wymowa": 'PRONUNCIATION',
    "jezyk": 'LINGVA · LANGUAGE',
    "sentencje": 'SENTENTIAE · SAYINGS',
    "teksty": 'TEXTVS · TEXTS',
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "wymowa": [
        {"title": 'The Romans said “Kikero”',
         "text": "We say “Cicero” and “Caesar”, but the Romans always read c as k: Kikero, Kaisar. That's where German Kaiser comes from. A bar over a vowel (ā) only marks length: you hold it longer, but the sound is the same.",
         "chain": []},
    ],
    "slowa": [
        {"title": 'You already know Latin',
         "text": 'Bonus, video, ego, nonsense: English is full of Latin. Good news number two: Latin has no articles (a, the). You just say “puer” = boy.',
         "chain": [
             ('I am a boy.', ["ego", "sum", "puer"], 'ego = I (as in “ego”), sum = I am.'),
             ('You are a girl.', ["tū", "es", "puella"], 'Change the person: tū, es.'),
         ]},
        {"title": 'The verb likes the end',
         "text": 'Latin word order is free, but Romans liked to put the verb last: “amīcus bonus est” = the friend good is. Adjectives change with gender: bonus (masculine), bona (feminine).',
         "chain": [
             ('The friend is good.', ["amīcus", "bonus", "est"], 'Noun, adjective, and est at the end.'),
             ('Rome is great.', ["Rōma", "magna", "est"], 'Rōma is feminine, so magna.'),
         ]},
    ],
    "rodzina": [
        {"title": 'Gender has to match',
         "text": 'Every Latin noun is masculine, feminine or neuter, and words that go with it must match: pater meus (my father), māter mea (my mother). The possessive often comes after the noun, as in “Pater noster”.',
         "chain": [
             ('My father is good.', ["pater", "meus", "bonus", "est"], 'pater meus, then the adjective and est.'),
             ('My mother is a good woman.', ["māter", "mea", "fēmina", "bona", "est"],
              'All feminine: mea, bona.'),
         ]},
    ],
    "liczby": [
        {"title": 'You know the numbers from music',
         "text": 'Duet, trio, quartet, quintet, octave, decimal. And “they are” is sunt: the ending -nt means “they”.',
         "chain": [('One and one is two.', ["ūnus", "et", "ūnus", "sunt", "duo"], 'Plural subject: sunt.')]},
    ],
    "swiat": [
        {"title": 'The ablative: where and with what',
         "text": "English shows a word's role with prepositions and word order; Latin uses endings, called cases. The ablative answers “where?” and “with what?”: in terrā = on the earth, in caelō = in the sky.",
         "chain": [
             ('The sun is in the sky.', ["sōl", "in", "caelō", "est"], 'Where? Which word shows the place?'),
             ('Water is on the earth.', ["aqua", "in", "terrā", "est"], 'What are we standing on?'),
         ]},
    ],
    "czas": [
        {"title": 'The person is in the ending',
         "text": "You don't need to say “I”: legō = I read. The ending tells you who: -ō (I), -s (you), -t (he/she). legō, legis, legit = I read, you read, he reads.",
         "chain": [
             ('I am reading a book.', ["ego", "librum", "legō"], 'Who or what is affected, and who acts? Think about the endings.'),
             ('The girl sees the water.', ["puella", "aquam", "videt"], 'Who sees and what do they see? Look at the endings.'),
         ]},
    ],
    "przypadki": [
        {"title": 'Calling someone: the vocative',
         "text": 'Latin has a special form for addressing someone: amīcus → amīce! (friend!), dominus → domine! (Lord!). And the dative means “to”: Deō = to God.',
         "chain": [
             ('Hello, friend!', ["amīce", ",", "salvē"], 'Whom am I addressing? Think of calling out: friend!'),
             ('Thanks be to God.', ["Deō", "grātiās"], 'Whom do we thank? Think of “to God”.'),
         ]},
    ],
    "perfekt": [
        {"title": '-ī = “I did”',
         "text": 'The perfect tense in the first person ends in -ī: vēnī = I came, vīdī = I saw. He/she: -it (dīxit, scrīpsit). Caesar summed up a whole war in one sentence.',
         "chain": [('I came, I saw, I conquered.', ["vēnī", ",", "vīdī", ",", "vīcī"], 'Caesar speaks about himself in the past tense. How do the three verbs end?')]},
    ],
    "sent1": [
        {"title": 'Latin you already quote',
         "text": "Carpe diem, memento mori, cogito ergo sum. You know these sayings; now you'll understand every word. diem is the accusative of diēs (day): seize what? the day.",
         "chain": [('Seize the day.', ["carpe", "diem"], 'What do we seize? Link diem with “diary”.')]},
    ],
    "sent2": [
        {"title": 'Literal and free',
         "text": 'Endings show how words fit together, so Latin can put words wherever it wants to stress them: “mens sana in corpore sano” = a healthy mind in a healthy body.',
         "chain": [('Through hardships to the stars.', ["per", "aspera", "ad", "astra"], 'through … to …: two prepositions, each with the nouns you know from “aspera” and “astra”.')]},
    ],
    "pater": [
        {"title": 'A prayer you know',
         "text": 'The English “Our Father” follows the Latin closely: “hallowed be thy name”. sānctificētur = may it be hallowed (related to “sanctuary”).',
         "chain": [('Thy kingdom come.', ["adveniat", "rēgnum", "tuum"],
                    'adveniat (advent!) + rēgnum (reign) + tuum.')]},
    ],
    "gallia": [
        {"title": "Caesar's first sentence",
         "text": "This is how Caesar's “Commentaries on the Gallic War” begin, the book generations of students learned Latin from. Gallia est omnis dīvīsa in partēs trēs. You already know every word!",
         "chain": [('All Gaul is divided into three parts.',
                    ["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
                    'dīvīsa: division. partēs: party, part. The rest you already know.')]},
    ],
}

ENDINGS_INSIGHT = {
    "title": 'The ending says it all',
    "text": 'English says “she sees him”, not “she sees he”: a trace of cases. Latin does this with every noun: puella (the girl does something), puellam (something is done to the girl). When in doubt, ask: who? whom? to whom? where?',
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("puella ", "bon", "a", "", ["us", "a", "um", "ī"], 'good girl', 'Feminine: -a.', "slowa"),
    ("puer ", "bon", "us", "", ["us", "a", "um", "ae"], 'good boy', 'Masculine: -us.', "slowa"),
    ("Rōma ", "magn", "a", " est", ["us", "a", "um", "ī"], 'Rome is great', 'Rōma is feminine: magna.', "slowa"),
    ("māter ", "me", "a", "", ["us", "a", "um", "ae"], 'my mother', 'Mother is feminine: mea.', "rodzina"),
    ("pater ", "me", "us", "", ["us", "a", "um", "ae"], 'my father', 'Father is masculine: meus.', "rodzina"),
    ("fīlia ", "tu", "a", "", ["us", "a", "um", "ī"], 'your daughter', 'Feminine: tua.', "rodzina"),
    ("ūnus et ūnus ", "su", "nt", " duo", ["m", "s", "t", "nt"], 'are two', '“Are” = sunt: -nt means “they”.', "liczby"),
    ("in ", "terr", "ā", "", ["a", "ā", "am", "ae"], 'on the earth', 'Where? Ablative: terrā.', "swiat"),
    ("sōl in ", "cael", "ō", " est", ["um", "ō", "ī", "us"], 'the sun is in the sky', 'Ablative of caelum: caelō.', "swiat"),
    ("ego librum ", "leg", "ō", "", ["ō", "is", "it", "unt"], 'I read', 'I: -ō.', "czas"),
    ("tū librum ", "leg", "is", "", ["ō", "is", "it", "unt"], 'you read', 'You: -is.', "czas"),
    ("puella aquam ", "vid", "et", "", ["eō", "ēs", "et", "ent"], 'she sees', 'He/she: -t.', "czas"),
    ("amō ", "Rōm", "am", "", ["a", "ae", "am", "ā"], 'I love Rome', 'What do I love? Accusative: -am.', "czas"),
    ("ego ", "libr", "um", " legō", ["um", "ī", "ō", "er"], 'I read a book', 'What do I read? Accusative: librum.', "czas"),
    ("", "De", "ō", " grātiās", ["us", "ō", "um", "e"], 'thanks be to God', 'To whom? Dative: Deō.', "przypadki"),
    ("", "amīc", "e", ", salvē!", ["us", "e", "ī", "um"], 'friend, hello!', 'Vocative of -us: -e.', "przypadki"),
    ("", "Rōm", "ae", " sum", ["a", "ae", "am", "ā"], 'I am in Rome', 'Where? Rōmae (old locative).', "przypadki"),
    ("", "vēn", "ī", ", vīdī, vīcī", ["ī", "it", "iō", "imus"], 'I came', 'Perfect, I: -ī.', "perfekt"),
    ("Caesar ", "dīx", "it", "", ["ī", "it", "imus", "ērunt"], 'Caesar said', 'He: -it.', "perfekt"),
    ("errāre ", "hūmān", "um", " est", ["us", "a", "um", "ī"], 'to err is human',
     'An infinitive is neuter: -um.', "sent1"),
    ("mēns ", "sān", "a", "", ["us", "a", "um", "ō"], 'a healthy mind', 'mēns is feminine: sāna.', "sent2"),
    ("sānctificētur nōmen ", "tu", "um", "", ["us", "a", "um", "ae"], 'thy name', 'nōmen is neuter: tuum.', "pater"),
]

# Kolory: długie samogłoski w kolorze brązu, żeby iloczas był widoczny.
LONG_VOWELS = "āēīōūȳĀĒĪŌŪ"

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "forum", "title": 'At the Forum', "partner": "Marek", "avatar": "M", "requires": "slowa",
        "turns": [
            {"bot": ["salvē", "!"], "en": 'Hello!',
             "options": [(["salvē", "!"], True, None),
                         (["valē", "!"], False, "valē means “goodbye”. You've only just met!")]},
            {"bot": ["quis", "es", "?"], "en": 'Who are you?',
             "options": [(["amīcus", "sum"], True, None),
                         (["amīcus", "es"], False, 'es means “you are”. About yourself: sum (I am).'),
                         (["amīcus", "est"], False, 'est means “is”. About yourself: sum.')]},
            {"bot": ["Rōma", "magna", "est", "!"], "en": 'Rome is great!',
             "options": [(["ita", ",", "Rōma", "magna", "est"], True, None),
                         (["ita", ",", "Rōma", "magnus", "est"], False, 'Rōma is feminine: magna, not magnus.')]},
            {"bot": ["valē", "!"], "en": 'Goodbye!', "build": (["valē"], 'Goodbye!')},
        ],
    },
    {
        "id": "dom", "title": 'At home', "partner": "Julia", "avatar": "I", "requires": "rodzina",
        "turns": [
            {"bot": ["estne", "pater", "tuus", "bonus", "?"], "en": 'Is your father good?',
             "options": [(["pater", "meus", "bonus", "est"], True, None),
                         (["pater", "tuus", "bonus", "est"], False, "tuus means “your”. You're talking about your own father: meus."),
                         (["pater", "mea", "bona", "est"], False, 'pater is masculine: meus, bonus.')],
             "note": '-ne at the end of a word turns it into a question.'},
            {"bot": ["et", "māter", "tua", "?"], "en": 'And your mother?',
             "build": (["māter", "mea", "bona", "est"], 'My mother is good.')},
        ],
    },
    {
        "id": "schola", "title": 'At school', "partner": "Magister", "avatar": "G", "requires": "przypadki",
        "turns": [
            {"bot": ["quid", "legis", "?"], "en": 'What are you reading?',
             "options": [(["librum", "legō"], True, None),
                         (["librum", "legit"], False, 'legit means “reads” (he). About yourself: legō.'),
                         (["liber", "legō"], False, 'What are you reading? Accusative: librum.')]},
            {"bot": ["quid", "scrībis", "?"], "en": 'What are you writing?',
             "build": (["librum", "scrībō"], 'I am writing a book.')},
            {"bot": ["bene", "!"], "en": 'Good!',
             "options": [(["grātiās", "agō"], True, None),
                         (["Deō", "grātiās"], False, "That's “thanks be to God”. To a teacher, just say “thank you”.")]},
        ],
    },
    {
        "id": "caesar", "title": "At Caesar's", "partner": "Cezar", "avatar": "C", "requires": "perfekt",
        "turns": [
            {"bot": ["quid", "fēcistī", "?"], "en": 'What did you do?',
             "options": [(["vēnī", ",", "vīdī", ",", "vīcī"], True, None),
                         (["veniō", ",", "videō", ",", "vincō"], False,
                          "That's the present tense. He's asking what you did: perfect vēnī, vīdī, vīcī.")]},
            {"bot": ["ubi", "fuistī", "?"], "en": 'Where were you?',
             "build": (["fuī", "Rōmae"], 'I was in Rome.')},
            {"bot": ["bene", "!", "valē", "!"], "en": 'Good! Farewell!',
             "options": [(["valē", ",", "Caesar"], True, None),
                         (["salvē", ",", "Caesar"], False, "salvē is a greeting. Now you're saying goodbye: valē.")]},
        ],
    },
]

CHAT_EXTRA = {
    "quis": 'who', "ita": 'yes', "estne": 'is (he)?', "legis": 'you read', "bene": 'well',
    "fēcistī": 'you did', "ubi": 'where', "fuistī": 'you were', "veniō": 'I come', "vincō": 'I conquer',
}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Larpy: sceny ze stawką. Węzeł: bot (tokeny), pl (tłumaczenie) oraz
#   options: [(tokeny, "good" | "weak" | "bad", następny węzeł lub None, komentarz)]  albo
#   build: (tokeny, polecenie po polsku), next: następny węzeł
# deadly: True = pytanie „jedna szansa" (zła odpowiedź kończy scenę). Węzeł z end: True kończy scenę.
# ---------------------------------------------------------------------------
LARP_EXTRA = {"agis": "robisz", "esne": "czy jesteś", "amāsne": "czy kochasz", "mīles": "żołnierz"}

LARPS = [
    {"id": "porta", "title": "Brama Rzymu", "partner": "Mīles", "avatar": "M", "requires": "przypadki",
     "fee": 20, "patience": 3,
     "scene": "Stoisz przed bramą Rzymu. Żołnierz przy bramie nie wpuszcza byle kogo.",
     "goal": "Przekonaj strażnika i wejdź do miasta.",
     "start": "a",
     "endings": {
         "win": "Strażnik odsuwa włócznię. Wchodzisz do Rzymu jak przyjaciel.",
         "partial": "Strażnik w końcu cię wpuszcza, ale patrzy podejrzliwie. Wszedłeś, lecz bez nagrody.",
         "fail": "Strażnik traci cierpliwość i przepędza cię spod bramy.",
     },
     "nodes": {
         "a": {"bot": ["salvē", "!", "quis", "es", "?"], "pl": "Witaj! Kim jesteś?",
               "options": [
                   (["salvē", ",", "domine", "!", "amīcus", "sum"], "good", "b", None),
                   (["salvē", "!", "amīcus", "sum"], "weak", "a2", "Poprawnie, ale bez „domine” brzmi to poufale. Strażnik robi się podejrzliwy."),
                   (["valē", "!", "amīcus", "es"], "bad", None, "valē to pożegnanie, a es znaczy „jesteś”. O sobie: sum."),
               ]},
         "a2": {"bot": ["amīcus", "?", "esne", "servus", "?"], "pl": "Przyjaciel? Jesteś niewolnikiem?",
                "build": (["servus", "nōn", "sum"], "Powiedz: Nie jestem niewolnikiem."), "next": "b",
                "why": "„Nie jestem” to nōn sum; przeczenie stoi przed czasownikiem."},
         "b": {"bot": ["quid", "Rōmae", "agis", "?"], "pl": "Co robisz w Rzymie?",
               "options": [
                   (["frāter", "meus", "Rōmae", "est"], "good", "c", None),
                   (["Rōmam", "videō"], "weak", "b2", "Zdanie jest poprawne, ale to żaden powód. Strażnik dopytuje."),
                   (["frāter", "tuus", "Rōmae", "est"], "bad", None, "tuus to „twój”. Mówisz o swoim bracie: meus."),
               ]},
         "b2": {"bot": ["Rōma", "magna", "est", ".", "quis", "Rōmae", "est", "?"], "pl": "Rzym jest wielki. Kto jest w Rzymie?",
                "build": (["frāter", "meus", "Rōmae", "est"], "Powiedz: Mój brat jest w Rzymie."), "next": "c",
                "why": "„W Rzymie” to Rōmae (miejscownik), a „mój” przy bracie to meus."},
         "c": {"bot": ["estne", "frāter", "tuus", "vir", "bonus", "?"], "pl": "Czy twój brat jest dobrym człowiekiem?",
               "build": (["ita", ",", "vir", "bonus", "est"], "Powiedz: Tak, jest dobrym człowiekiem."), "next": "d",
               "why": "„Tak” to ita; „jest dobrym mężem” to vir bonus est."},
         "d": {"bot": ["amāsne", "Rōmam", "?"], "pl": "Czy kochasz Rzym?", "deadly": True,
               "options": [
                   (["Rōmam", "amō", "!"], "good", "e", None),
                   (["Rōmam", "nōn", "amō"], "bad", None, "Gramatycznie dobrze, ale strażnikowi tego się nie mówi."),
                   (["Rōma", "amat"], "bad", None, "To znaczy „Rzym kocha”. „Kocham Rzym” to Rōmam amō."),
               ]},
         "e": {"bot": ["bene", "!", "valē", ",", "amīce", "!"], "pl": "Dobrze! Bywaj, przyjacielu!",
               "build": (["grātiās", "agō", ",", "domine"], "Podziękuj strażnikowi (panie)."), "next": "end",
               "why": "„Dziękuję” to grātiās agō, a do strażnika zwracasz się domine."},
         "end": {"bot": ["valē", "!"], "pl": "Bywaj!", "end": True},
     }},
]


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['ego', 'tū', 'is/ea', 'nōs', 'vōs', 'eī/eae'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'ablatyw lp.', 'wołacz lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.', 'ablatyw lm.'],
    'przyp5': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'ablatyw'],
    'part': ['participium praesentis activi', 'participium perfecti passivi', 'participium futuri activi', 'gerundivum'],
    'inf': ['īnfīnītīvus praesentis activi', 'īnfīnītīvus praesentis passivi', 'īnfīnītīvus perfecti activi', 'īnfīnītīvus perfecti passivi', 'īnfīnītīvus futuri activi'],
    'stopn': ['bonus', 'malus', 'magnus', 'parvus', 'multus'],
    't_dekl': ['rosa, rosae', 'dominus, dominī', 'rēx, rēgis', 'manus, manūs', 'rēs, reī', 'corpus, corporis', 'ager, agrī', 'cornū, cornūs'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'amāre (kochać): I koniugacja', 'os', 'amō; amās; amat; amāmus; amātis; amant', 'Końcówki osobowe: -ō, -s, -t, -mus, -tis, -nt.'),
    ('conj', 'Wzory koniugacji', 'vidēre (widzieć): II koniugacja', 'os', 'videō; vidēs; videt; vidēmus; vidētis; vident', None),
    ('conj', 'Wzory koniugacji', 'legere (czytać): III koniugacja', 'os', 'legō; legis; legit; legimus; legitis; legunt', 'III koniugacja: krótkie -i-, w 3. osobie lm. -unt.'),
    ('conj', 'Wzory koniugacji', 'audīre (słyszeć): IV koniugacja', 'os', 'audiō; audīs; audit; audīmus; audītis; audiunt', None),
    ('conj', 'Wyjątki', 'capere (chwytać): III koniugacja na -iō', 'os', 'capiō; capis; capit; capimus; capitis; capiunt', 'Jak legere, ale z -i- w 1. osobie lp. i 3. osobie lm.'),
    ('conj', 'Czasowniki nieregularne', 'esse (być)', 'os', 'sum; es; est; sumus; estis; sunt', None),
    ('conj', 'Czasowniki nieregularne', 'posse (móc)', 'os', 'possum; potes; potest; possumus; potestis; possunt', 'pot- + esse: przed s powstaje poss-.'),
    ('conj', 'Czasowniki nieregularne', 'velle (chcieć)', 'os', 'volō; vīs; vult; volumus; vultis; volunt', None),
    ('conj', 'Czasowniki nieregularne', 'īre (iść)', 'os', 'eō; īs; it; īmus; ītis; eunt', None),
    ('conj', 'Czasowniki nieregularne', 'ferre (nieść)', 'os', 'ferō; fers; fert; ferimus; fertis; ferunt', None),
    ('conj', 'Czas przeszły', 'amāre: imperfectum', 'os', 'amābam; amābās; amābat; amābāmus; amābātis; amābant', 'Znak czasu -bā- + końcówki -m, -s, -t.'),
    ('conj', 'Czas przeszły', 'amāre: perfectum', 'os', 'amāvī; amāvistī; amāvit; amāvimus; amāvistis; amāvērunt', 'Końcówki perfectum: -ī, -istī, -it, -imus, -istis, -ērunt.'),
    ('conj', 'Czas przeszły', 'esse: perfectum', 'os', 'fuī; fuistī; fuit; fuimus; fuistis; fuērunt', None),
    ('decl', 'Wzory deklinacji', 'puella (dziewczyna): I deklinacja', 'przyp', 'puella; puellae; puellae; puellam; puellā; puella; puellae; puellārum; puellīs; puellās; puellīs', None),
    ('decl', 'Wzory deklinacji', 'amīcus (przyjaciel): II deklinacja', 'przyp', 'amīcus; amīcī; amīcō; amīcum; amīcō; amīce; amīcī; amīcōrum; amīcīs; amīcōs; amīcīs', 'Jedyna deklinacja z osobnym wołaczem: amīce.'),
    ('decl', 'Wzory deklinacji', 'caelum (niebo): II deklinacja, nijaki', 'przyp', 'caelum; caelī; caelō; caelum; caelō; caelum; caela; caelōrum; caelīs; caela; caelīs', 'Nijakie: mianownik = biernik, w lm. na -a.'),
    ('decl', 'Wzory deklinacji', 'homō (człowiek): III deklinacja', 'przyp', 'homō; hominis; hominī; hominem; homine; homō; hominēs; hominum; hominibus; hominēs; hominibus', 'Temat widać dopiero w dopełniaczu: homin-.'),
    ('decl', 'Wzory deklinacji', 'nōmen (imię): III deklinacja, nijaki', 'przyp', 'nōmen; nōminis; nōminī; nōmen; nōmine; nōmen; nōmina; nōminum; nōminibus; nōmina; nōminibus', None),
    ('decl', 'Wzory deklinacji', 'manus (ręka): IV deklinacja', 'przyp', 'manus; manūs; manuī; manum; manū; manus; manūs; manuum; manibus; manūs; manibus', None),
    ('decl', 'Wzory deklinacji', 'diēs (dzień): V deklinacja', 'przyp', 'diēs; diēī; diēī; diem; diē; diēs; diēs; diērum; diēbus; diēs; diēbus', None),
    ('decl', 'Wyjątki', 'puer (chłopiec)', 'przyp', 'puer; puerī; puerō; puerum; puerō; puer; puerī; puerōrum; puerīs; puerōs; puerīs', 'II deklinacja bez -us w mianowniku.'),
    ('decl', 'Wyjątki', 'mare (morze)', 'przyp', 'mare; maris; marī; mare; marī; mare; maria; marium; maribus; maria; maribus', 'Temat na -i: ablatyw -ī, lm. -ia, -ium.'),
    ('decl', 'Wyjątki', 'deus (bóg)', 'przyp', 'deus; deī; deō; deum; deō; deus; dī; deōrum; dīs; deōs; dīs', 'Wołacz = mianownik; w lm. formy ściągnięte dī, dīs.'),
    ('decl', 'Zaimki', 'ego (ja)', 'przyp5', 'ego; meī; mihi; mē; mē', None),
    ('decl', 'Zaimki', 'tū (ty)', 'przyp5', 'tū; tuī; tibi; tē; tē', None),
    ('form', 'Imiesłowy', 'amāre (kochać)', 'part', 'amāns; amātus; amātūrus; amandus', '-ns: kochający; -tus: kochany; -tūrus: mający kochać; -ndus: ten, którego należy kochać.'),
    ('form', 'Imiesłowy', 'vidēre (widzieć)', 'part', 'vidēns; vīsus; vīsūrus; videndus', None),
    ('form', 'Imiesłowy', 'legere (czytać)', 'part', 'legēns; lēctus; lēctūrus; legendus', None),
    ('form', 'Imiesłowy', 'audīre (słyszeć)', 'part', 'audiēns; audītus; audītūrus; audiendus', None),
    ('form', 'Imiesłowy', 'capere (chwytać)', 'part', 'capiēns; captus; captūrus; capiendus', None),
    ('decl', 'Imiesłowy: odmiana', 'amāns (kochający)', 'przyp5', 'amāns; amantis; amantī; amantem; amante', 'Participium praesentis odmienia się według III deklinacji: temat amant-.'),
    ('form', 'Bezokoliczniki', 'amāre', 'inf', 'amāre; amārī; amāvisse; amātus esse; amātūrus esse', 'Bezokoliczniki są potrzebne w składni accusativus cum infinitivo.'),
    ('conj', 'Strona bierna', 'amāre: praesens passivi', 'os', 'amor; amāris; amātur; amāmur; amāminī; amantur', 'Końcówki bierne: -r, -ris, -tur, -mur, -minī, -ntur.'),
    ('conj', 'Czas przyszły', 'amāre: futurum I', 'os', 'amābō; amābis; amābit; amābimus; amābitis; amābunt', 'I i II koniugacja: znak -b-.'),
    ('conj', 'Czas przyszły', 'legere: futurum I', 'os', 'legam; legēs; leget; legēmus; legētis; legent', 'III i IV koniugacja: -am, -ēs, -et.'),
    ('conj', 'Tryb łączący', 'amāre: coniūnctīvus praesentis', 'os', 'amem; amēs; amet; amēmus; amētis; ament', None),
    ('form', 'Stopniowanie nieregularne', 'Stopień wyższy', 'stopn', 'melior; peior; maior; minor; plūs', None),
    ('form', 'Stopniowanie nieregularne', 'Stopień najwyższy', 'stopn', 'optimus; pessimus; maximus; minimus; plūrimus', None),
    ('form', 'Typowe trudności', 'Która deklinacja?', 't_dekl', 'I; II; III; IV; V; III; II; IV', 'Patrz na dopełniacz: -ae (I), -ī (II), -is (III), -ūs (IV), -eī (V).'),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['puella', 'puellam', 'puellārum', 'puellās', 'puellā', 'puellīs'],
    't_m1': ['Puella puerum amat: kto kocha?', 'Puella puerum amat: kogo?', 'Puerum puella amat: kto kocha?', 'Puer puellam amat: kto kocha?', 'Puer puellam amat: kogo?', 'Puellam puer amat: kogo?'],
    't_m2': ['venit', 'vēnit', 'malum', 'mālum', 'liber', 'līber', 'populus', 'pōpulus'],
    't_m3': ['puellae', 'amīcī', 'amīcō', 'amīcīs', 'caelum', 'caela'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Jaki przypadek? (puella)', 't_m0', 'mianownik lp.; biernik lp.; dopełniacz lm.; biernik lm.; ablatyw lp.; celownik lub ablatyw lm.', 'Rolę słowa w zdaniu pokazuje końcówka, nie szyk.'),
    ('form', 'Typowe trudności', 'Kto kogo kocha?', 't_m1', 'puella; puerum; puella; puer; puellam; puellam', 'Szyk jest swobodny. -um i -am to biernik, czyli ten, kogo się kocha.'),
    ('form', 'Typowe trudności', 'Iloczas: co to znaczy?', 't_m2', 'przychodzi; przyszedł; zło; jabłko; książka; wolny; lud; topola', 'Długość samogłoski zmienia znaczenie.'),
    ('form', 'Typowe trudności', 'Ta sama końcówka: ile przypadków?', 't_m3', 'dopełniacz lp., celownik lp., mianownik lm.; dopełniacz lp., mianownik lm.; celownik lp., ablatyw lp.; celownik lm., ablatyw lm.; mianownik lp., biernik lp.; mianownik lm., biernik lm.', None),
]


# Z czego składają się słowa (pokazywane na karcie nowego słowa)
PARTS = {
    "adveniat": 'ad (to) + veniat (let it come; venīre = to come) → “let it come”',
    "sānctificētur": 'sānctus (holy) + -ficāre (to make) + -ētur (passive) → “let it be made holy”',
    "voluntās": 'vol- (to want, as in velle) + -tās (abstract-noun ending) → “will”',
    "rēgnum": 'rēg- (king, to rule; as in rēx) + -num (noun ending) → “kingdom”',
    "vēritās": 'vērus (true) + -tās (abstract-noun ending) → “truth”',
    "amīcus": 'am- (to love; as in amāre) + -īcus (adjective ending) → “someone loved”, a friend',
    "cōgitō": 'co- (together) + agitāre (to stir) → “I stir thoughts together”',
    "mementō": 'meminisse (to remember) + -tō (imperative ending) → “remember!”',
    "hūmānum": 'hūm- (human; as in homō) + -ānum (relating to) → “human”',
    "sīcut": 'sīc (so) + ut (as) → “just as”',
    "grātiās": 'grātus (pleasing, grateful) + -ia → grātia (grace, thanks)',
}

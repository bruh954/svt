"""[en — wygenerowane przez tools/i18n.py, nie edytuj] Treść kursu: łacina klasyczna dla Polaków.

Słowo:     (forma z iloczasem, znaczenie po polsku, polskie słowo z łaciny lub None, skojarzenie lub None)
Wymowa:    (litera lub dwuznak, jak czytać, przykład)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie)

Wymowa (pole „tr”) powstaje automatycznie w engine.py: wymowa klasyczna
zapisana po polsku, np. caelum → kajlum.
"""

UNITS = [
    # ---------------------------------------------------------------- wymowa
    {
        "id": "wymowa", "title": 'Pronunciation', "icon": "I", "track": "wymowa",
        "letters": [
            ("c", '[k]: Cicerō is read “Kikero”', "Cicerō"),
            ("v", '[w], as in English “wine”', "vīta"),
            ("ae", '[ae̯]: Caesar is read “Kaisar”', "Caesar"),
            ("oe", '[oe̯]: poena is read “poina”', "poena"),
            ("qu", '[kʷ]: aqua is read “akwa”', "aqua"),
            ("ph", '[pʰ] (words from Greek; later f)', "philosophia"),
            ("ch", '[kʰ] (words from Greek)', "chorus"),
            ("i", '[i], but before a vowel [j]: iam is read “yam”', "iam"),
            ("ā", '[aː]: the bar only marks length', "māter"),
            ("ti", '[ti], never [ts]: nātiō', "nātiō"),
            ("s", '[s], never [z]: rosa is read “rossa”', "rosa"),
            ("x", '[ks]: rēx is read “rēks”', "rēx"),
        ],
    },
    # ----------------------------------------------------------------- język
    {
        "id": "slowa", "title": 'First words', "icon": "II", "track": "jezyk", "requires": "wymowa",
        "words": [
            ("salvē", 'hello', 'salvo', 'Literally “be well”. A gun salute (salvo) is a greeting too!'),
            ("valē", 'goodbye; farewell', None, 'The Romans said goodbye by wishing good health.'),
            ("ego", 'I', 'ego; egoist', None),
            ("tū", 'you', 'thou', None),
            ("et", 'and', 'et cetera', 'The sign & is a stylised “et”!'),
            ("nōn", 'not; no', 'nonsense', None),
            ("sum", 'I am', None, None),
            ("es", 'you are', None, None),
            ("est", 'is', 'is', 'Close to English “is”: both come from the same Proto-Indo-European word.'),
            ("puer", 'boy', None, None),
            ("puella", 'girl', None, None),
            ("amīcus", 'friend', 'amicable', None),
            ("bonus", 'good (masculine)', 'bonus', 'A bonus is “something good” on top.'),
            ("bona", 'good (feminine)', 'bona fide', None),
            ("magnus", 'great (masculine)', 'magnate', None),
            ("magna", 'great (feminine)', 'Magna Carta', None),
            ("Rōma", 'Rome', 'Romance', None),
        ],
        "sentences": [
            (["ego", "sum", "puer"], 'I am a boy.',
             {"es": 'es means “you are”. About yourself: sum (I am).', "est": 'est means “is”. About yourself: sum.'}),
            (["tū", "es", "puella"], 'You are a girl.', {"sum": 'sum means “I am”. To “you”: es.'}),
            (["amīcus", "bonus", "est"], 'The friend is good.',
             {"bona": 'amīcus is masculine: bonus.'}),
            (["Rōma", "magna", "est"], 'Rome is great.',
             {"magnus": 'Rōma is feminine, so magna.'}),
            (["nōn", "sum", "magnus"], 'I am not great.', {}),
            (["puella", "bona", "est"], 'The girl is good.',
             {"bonus": 'puella is feminine: bona.'}),
        ],
    },
    {
        "id": "rodzina", "title": 'Family', "icon": "III", "track": "jezyk",
        "words": [
            ("pater", 'father', 'paternal', None),
            ("māter", 'mother', 'maternal', None),
            ("fīlius", 'son', 'filial', 'Filial love is the love of a son or daughter.'),
            ("fīlia", 'daughter', 'affiliate', None),
            ("frāter", 'brother', 'fraternity', None),
            ("soror", 'sister', None, None),
            ("vir", 'man; husband', 'virtue', 'From vir comes virtus: manliness, courage. Hence English virtue.'),
            ("fēmina", 'woman', 'feminine', None),
            ("homō", 'human being', 'homo sapiens', None),
            ("dominus", 'master; lord', 'dominate', None),
            ("servus", 'slave; servant', 'servant', '“Servus!” (literally “your servant”) is still a greeting in Central Europe.'),
            ("meus", 'my (masculine)', None, None),
            ("mea", 'my (feminine)', None, None),
            ("tuus", 'your (masculine)', None, None),
            ("tua", 'your (feminine)', None, None),
        ],
        "sentences": [
            (["pater", "meus", "bonus", "est"], 'My father is good.',
             {"mea": 'pater is masculine: meus (my).'}),
            (["māter", "mea", "fēmina", "bona", "est"], 'My mother is a good woman.',
             {"meus": 'māter is feminine: mea (my).'}),
            (["frāter", "meus", "amīcus", "tuus", "est"], 'My brother is your friend.', {}),
            (["fīlia", "tua", "puella", "bona", "est"], 'Your daughter is a good girl.',
             {"tuus": 'fīlia is feminine: tua (your).'}),
        ],
    },
    {
        "id": "liczby", "title": 'Numbers', "icon": "IV", "track": "jezyk",
        "words": [
            ("ūnus", 'one', 'unique; union', None),
            ("duo", 'two', 'duet', None),
            ("trēs", 'three', 'trio', None),
            ("quattuor", 'four', 'quartet', None),
            ("quīnque", 'five', 'quintet', None),
            ("sex", 'six', 'sextet', None),
            ("septem", 'seven', 'September', 'September was the seventh month of the old Roman calendar.'),
            ("octō", 'eight', 'octave', None),
            ("novem", 'nine', 'November', None),
            ("decem", 'ten', 'decimal', None),
            ("sunt", '(they) are', None, None),
            ("puerī", 'boys', None, None),
        ],
        "sentences": [
            (["ūnus", "et", "ūnus", "sunt", "duo"], 'One and one is two.',
             {"est": 'Plural subject: sunt (are).'}),
            (["septem", "et", "trēs", "sunt", "decem"], 'Seven and three is ten.', {}),
            (["trēs", "puerī", "sunt"], 'There are three boys.',
             {"puer": 'Three: plural, puerī.'}),
        ],
    },
    {
        "id": "swiat", "title": 'The world', "icon": "V", "track": "jezyk",
        "words": [
            ("terra", 'earth; land', 'terrain; territory', None),
            ("terrā", '(on) the earth', None, 'Ablative: in terrā = on the earth.'),
            ("aqua", 'water', 'aquarium', None),
            ("caelum", 'sky; heaven', None, 'Hence English “celestial”.'),
            ("caelō", '(in) the sky', None, None),
            ("sōl", 'sun', 'solar', None),
            ("lūna", 'moon', 'lunar', 'A lunatic was thought to be affected by the moon.'),
            ("stella", 'star', 'constellation', None),
            ("via", 'road; way', 'viaduct', None),
            ("urbs", 'city', 'urban', None),
            ("silva", 'forest', 'Sylvia', 'Sylvia means “of the forest”.'),
            ("mare", 'sea', 'marine', None),
            ("vīta", 'life', 'vital', 'Vitamin = “amine of life”.'),
            ("brevis", 'short', 'brief', 'Brief comes from brevis.'),
            ("in", 'in; on', 'in', None),
        ],
        "sentences": [
            (["sōl", "in", "caelō", "est"], 'The sun is in the sky.',
             {"caelum": 'Where? After “in” the ablative: caelō.'}),
            (["aqua", "in", "terrā", "est"], 'Water is on the earth.',
             {"terra": 'Where? Ablative: terrā.'}),
            (["vīta", "brevis", "est"], 'Life is short.', {}),
            (["Rōma", "urbs", "magna", "est"], 'Rome is a great city.', {}),
        ],
    },
    {
        "id": "czas", "title": 'Verbs', "icon": "VI", "track": "jezyk",
        "words": [
            ("amō", 'I love', 'amateur', 'An amateur is someone who “loves” doing something.'),
            ("amat", '(he/she) loves', None, None),
            ("videō", 'I see', 'video', None),
            ("videt", '(he/she) sees', None, None),
            ("legō", 'I read', 'legend', 'Legend = “something to be read”.'),
            ("legit", '(he/she) reads', None, None),
            ("scrībō", 'I write', 'scribe', None),
            ("scrībis", 'you write', None, None),
            ("audiō", 'I hear', 'audio', None),
            ("labōrat", '(he/she) works', 'laboratory', None),
            ("quid", 'what', None, None),
            ("liber", 'book', 'library', None),
            ("librum", 'book (object)', None, 'Accusative: what do I read? librum.'),
            ("aquam", 'water (object)', None, None),
            ("Rōmam", 'Rome (object)', None, None),
        ],
        "sentences": [
            (["ego", "librum", "legō"], 'I am reading a book.',
             {"legit": 'legit means “reads” (he). About yourself: legō.',
              "liber": 'What do I read? Accusative: librum.'}),
            (["quid", "scrībis"], 'What are you writing?', {"scrībō": "You're asking someone: scrībis (-s for “you”)."}),
            (["puella", "aquam", "videt"], 'The girl sees the water.',
             {"aqua": 'What does she see? Accusative: aquam.', "videō": 'videō means “I see”. She: videt.'}),
            (["amō", "Rōmam"], 'I love Rome.', {"Rōma": 'What do I love? Accusative: Rōmam.'}),
            (["pater", "labōrat"], 'Father is working.', {}),
        ],
    },
    {
        "id": "przypadki", "title": 'Cases', "icon": "VII", "track": "jezyk",
        "words": [
            ("grātiās", 'thanks (accusative plural)', 'gratitude', 'Gratis = “for thanks”, so free of charge.'),
            ("agō", 'I give; I do', 'agenda', None),
            ("Deus", 'God', None, None),
            ("Deō", 'to God', None, None),
            ("domine", 'Lord! (vocative)', None, 'The vocative of -us is -e: domine!'),
            ("amīce", 'friend! (vocative)', None, None),
            ("Rōmae", 'in Rome', None, 'An old locative case, used for cities.'),
            ("domī", 'at home', None, 'Another old locative.'),
        ],
        "sentences": [
            (["grātiās", "agō"], 'Thank you.', {}),
            (["Deō", "grātiās"], 'Thanks be to God.', {"Deus": 'To whom? Dative: Deō.'}),
            (["amīce", ",", "salvē"], 'Hello, friend!',
             {"amīcus": 'Calling someone: vocative amīce.'}),
            (["Rōmae", "sum"], 'I am in Rome.', {"Rōma": 'Where? Rōmae (in Rome).'}),
            (["domī", "sum"], 'I am at home.', {}),
        ],
    },
    {
        "id": "perfekt", "title": 'Past tense', "icon": "VIII", "track": "jezyk",
        "words": [
            ("vēnī", 'I came', None, 'Perfect tense: -ī = “I … -ed”.'),
            ("vīdī", 'I saw', None, None),
            ("vīcī", 'I conquered', 'victory', None),
            ("fuī", 'I was', None, None),
            ("erat", '(he/she) was', None, None),
            ("dīxit", '(he/she) said', 'dictator', 'A dictator is the one who “says” what to do.'),
            ("scrīpsit", '(he/she) wrote', 'script', None),
            ("Caesar", 'Caesar', 'Kaiser; tsar', "Caesar's name became a title: Kaiser, tsar."),
        ],
        "sentences": [
            (["vēnī", ",", "vīdī", ",", "vīcī"], 'I came, I saw, I conquered.', {}),
            (["Caesar", "dīxit"], 'Caesar said.', {}),
            (["Rōma", "magna", "erat"], 'Rome was great.', {"est": 'In the past: erat (was), not est.'}),
            (["puella", "librum", "scrīpsit"], 'The girl wrote a book.', {}),
            (["fuī", "Rōmae"], 'I was in Rome.', {"sum": 'In the past: fuī (I was).'}),
        ],
    },
    # -------------------------------------------------------------- sentencje
    {
        "id": "sent1", "title": 'Sayings I', "icon": "IX", "track": "sentencje", "requires": "czas",
        "words": [
            ("carpe", 'seize; pluck', None, 'Literally “pluck”, like fruit.'),
            ("diem", 'day (object)', 'diary', 'A diary is a daily record, from diēs (day).'),
            ("errāre", 'to err', 'error', None),
            ("hūmānum", 'human (neuter)', 'humanism', None),
            ("mementō", 'remember', 'memento', None),
            ("morī", 'to die', 'mortal', 'Related to mors (death), hence mortal.'),
            ("cōgitō", 'I think', None, None),
            ("ergō", 'therefore', 'ergo', None),
        ],
        "sentences": [
            (["carpe", "diem"], 'Seize the day.', {}),
            (["errāre", "hūmānum", "est"], 'To err is human.', {}),
            (["mementō", "morī"], 'Remember that you will die.', {}),
            (["cōgitō", ",", "ergō", "sum"], 'I think, therefore I am.', {}),
        ],
    },
    {
        "id": "sent2", "title": 'Sayings II', "icon": "X", "track": "sentencje",
        "words": [
            ("per", 'through', 'per cent', None),
            ("aspera", 'hardships', None, None),
            ("ad", 'to; towards', 'adapt', None),
            ("astra", 'stars', 'astronomy', None),
            ("ālea", 'die (for games)', None, None),
            ("iacta", 'cast; thrown', None, None),
            ("vīnō", '(in) wine', 'wine', None),
            ("vēritās", 'truth', 'verify', None),
            ("tempus", 'time', 'tempo', None),
            ("fugit", 'flees', 'fugitive', 'A fugue is music where voices “flee” one after another.'),
            ("mēns", 'mind', 'mental', None),
            ("sāna", 'healthy (feminine)', 'sanatorium', None),
            ("corpore", '(in) the body', 'corporal', None),
            ("sānō", 'healthy (ablative)', None, None),
        ],
        "sentences": [
            (["per", "aspera", "ad", "astra"], 'Through hardships to the stars.', {}),
            (["ālea", "iacta", "est"], 'The die is cast.', {}),
            (["in", "vīnō", "vēritās"], 'In wine, truth.', {}),
            (["tempus", "fugit"], 'Time flies.', {}),
            (["mēns", "sāna", "in", "corpore", "sānō"], 'A healthy mind in a healthy body.', {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "pater", "title": 'Pater noster', "icon": "XI", "track": "teksty", "requires": "przypadki",
        "words": [
            ("noster", 'our', None, None),
            ("quī", 'who', None, None),
            ("caelīs", '(the) heavens', None, None),
            ("sānctificētur", 'hallowed be', 'sanctuary', None),
            ("nōmen", 'name', 'nominate', None),
            ("tuum", 'your (neuter)', None, None),
            ("adveniat", 'may (it) come', 'advent', 'Advent = “coming”.'),
            ("rēgnum", 'kingdom', 'reign', None),
            ("fīat", 'be done', None, None),
            ("voluntās", 'will', 'voluntary', None),
            ("sīcut", 'as; just as', None, None),
        ],
        "sentences": [
            (["pater", "noster", ",", "quī", "es", "in", "caelīs"], 'Our Father, who art in heaven.', {}),
            (["sānctificētur", "nōmen", "tuum"], 'Hallowed be thy name.', {}),
            (["adveniat", "rēgnum", "tuum"], 'Thy kingdom come.', {}),
            (["fīat", "voluntās", "tua"], 'Thy will be done.', {"tuum": 'voluntās is feminine: tua.'}),
            (["sīcut", "in", "caelō", "et", "in", "terrā"], 'On earth as it is in heaven.', {}),
        ],
    },
    {
        "id": "gallia", "title": 'Caesar: Gaul', "icon": "XII", "track": "teksty",
        "words": [
            ("Gallia", 'Gaul', 'Gallic', None),
            ("Galliā", '(in) Gaul', None, None),
            ("omnis", 'whole; all', 'omnibus', 'Omnibus = “for everyone”.'),
            ("dīvīsa", 'divided', 'division', None),
            ("partēs", 'parts', 'part; party', None),
        ],
        "sentences": [
            (["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
             'All Gaul is divided into three parts.', {}),
            (["Caesar", "in", "Galliā", "erat"], 'Caesar was in Gaul.', {"Gallia": 'Where? Ablative: in Galliā.'}),
        ],
    },
]

TRACKS = {
    "wymowa": 'PRONUNCIATION',
    "jezyk": 'LINGVA · LANGUAGE',
    "sentencje": 'SENTENTIAE · SAYINGS',
    "teksty": 'TEXTVS · TEXTS',
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "wymowa": [
        {"title": 'The Romans said “Kikero”',
         "text": "We say “Cicero” and “Caesar”, but the Romans always read c as k: Kikero, Kaisar. That's where German Kaiser comes from. A bar over a vowel (ā) only marks length: you hold it longer, but the sound is the same.",
         "chain": []},
    ],
    "slowa": [
        {"title": 'You already know Latin',
         "text": 'Bonus, video, ego, nonsense: English is full of Latin. Good news number two: Latin has no articles (a, the). You just say “puer” = boy.',
         "chain": [
             ('I am a boy.', ["ego", "sum", "puer"], 'ego = I (as in “ego”), sum = I am.'),
             ('You are a girl.', ["tū", "es", "puella"], 'Change the person: tū, es.'),
         ]},
        {"title": 'The verb likes the end',
         "text": 'Latin word order is free, but Romans liked to put the verb last: “amīcus bonus est” = the friend good is. Adjectives change with gender: bonus (masculine), bona (feminine).',
         "chain": [
             ('The friend is good.', ["amīcus", "bonus", "est"], 'Noun, adjective, and est at the end.'),
             ('Rome is great.', ["Rōma", "magna", "est"], 'Rōma is feminine, so magna.'),
         ]},
    ],
    "rodzina": [
        {"title": 'Gender has to match',
         "text": 'Every Latin noun is masculine, feminine or neuter, and words that go with it must match: pater meus (my father), māter mea (my mother). The possessive often comes after the noun, as in “Pater noster”.',
         "chain": [
             ('My father is good.', ["pater", "meus", "bonus", "est"], 'pater meus, then the adjective and est.'),
             ('My mother is a good woman.', ["māter", "mea", "fēmina", "bona", "est"],
              'All feminine: mea, bona.'),
         ]},
    ],
    "liczby": [
        {"title": 'You know the numbers from music',
         "text": 'Duet, trio, quartet, quintet, octave, decimal. And “they are” is sunt: the ending -nt means “they”.',
         "chain": [('One and one is two.', ["ūnus", "et", "ūnus", "sunt", "duo"], 'Plural subject: sunt.')]},
    ],
    "swiat": [
        {"title": 'The ablative: where and with what',
         "text": "English shows a word's role with prepositions and word order; Latin uses endings, called cases. The ablative answers “where?” and “with what?”: in terrā = on the earth, in caelō = in the sky.",
         "chain": [
             ('The sun is in the sky.', ["sōl", "in", "caelō", "est"], 'Where? in + ablative: caelō.'),
             ('Water is on the earth.', ["aqua", "in", "terrā", "est"], 'in terrā.'),
         ]},
    ],
    "czas": [
        {"title": 'The person is in the ending',
         "text": "You don't need to say “I”: legō = I read. The ending tells you who: -ō (I), -s (you), -t (he/she). legō, legis, legit = I read, you read, he reads.",
         "chain": [
             ('I am reading a book.', ["ego", "librum", "legō"], 'What do I read? Accusative librum. I: legō.'),
             ('The girl sees the water.', ["puella", "aquam", "videt"], 'aquam (accusative), videt (she).'),
         ]},
    ],
    "przypadki": [
        {"title": 'Calling someone: the vocative',
         "text": 'Latin has a special form for addressing someone: amīcus → amīce! (friend!), dominus → domine! (Lord!). And the dative means “to”: Deō = to God.',
         "chain": [
             ('Hello, friend!', ["amīce", ",", "salvē"], 'Vocative amīce.'),
             ('Thanks be to God.', ["Deō", "grātiās"], 'To whom? Deō.'),
         ]},
    ],
    "perfekt": [
        {"title": '-ī = “I did”',
         "text": 'The perfect tense in the first person ends in -ī: vēnī = I came, vīdī = I saw. He/she: -it (dīxit, scrīpsit). Caesar summed up a whole war in one sentence.',
         "chain": [('I came, I saw, I conquered.', ["vēnī", ",", "vīdī", ",", "vīcī"], 'Three times -ī.')]},
    ],
    "sent1": [
        {"title": 'Latin you already quote',
         "text": "Carpe diem, memento mori, cogito ergo sum. You know these sayings; now you'll understand every word. diem is the accusative of diēs (day): seize what? the day.",
         "chain": [('Seize the day.', ["carpe", "diem"], 'carpe (seize) + diem (accusative).')]},
    ],
    "sent2": [
        {"title": 'Literal and free',
         "text": 'Endings show how words fit together, so Latin can put words wherever it wants to stress them: “mens sana in corpore sano” = a healthy mind in a healthy body.',
         "chain": [('Through hardships to the stars.', ["per", "aspera", "ad", "astra"], 'per (through) … ad (to) …')]},
    ],
    "pater": [
        {"title": 'A prayer you know',
         "text": 'The English “Our Father” follows the Latin closely: “hallowed be thy name”. sānctificētur = may it be hallowed (related to “sanctuary”).',
         "chain": [('Thy kingdom come.', ["adveniat", "rēgnum", "tuum"],
                    'adveniat (advent!) + rēgnum (reign) + tuum.')]},
    ],
    "gallia": [
        {"title": "Caesar's first sentence",
         "text": "This is how Caesar's “Commentaries on the Gallic War” begin, the book generations of students learned Latin from. Gallia est omnis dīvīsa in partēs trēs. You already know every word!",
         "chain": [('All Gaul is divided into three parts.',
                    ["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
                    'dīvīsa = divided (division), partēs = parts.')]},
    ],
}

ENDINGS_INSIGHT = {
    "title": 'The ending says it all',
    "text": 'English says “she sees him”, not “she sees he”: a trace of cases. Latin does this with every noun: puella (the girl does something), puellam (something is done to the girl). When in doubt, ask: who? whom? to whom? where?',
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("puella ", "bon", "a", "", ["us", "a", "um", "ī"], 'good girl', 'Feminine: -a.', "slowa"),
    ("puer ", "bon", "us", "", ["us", "a", "um", "ae"], 'good boy', 'Masculine: -us.', "slowa"),
    ("Rōma ", "magn", "a", " est", ["us", "a", "um", "ī"], 'Rome is great', 'Rōma is feminine: magna.', "slowa"),
    ("māter ", "me", "a", "", ["us", "a", "um", "ae"], 'my mother', 'Mother is feminine: mea.', "rodzina"),
    ("pater ", "me", "us", "", ["us", "a", "um", "ae"], 'my father', 'Father is masculine: meus.', "rodzina"),
    ("fīlia ", "tu", "a", "", ["us", "a", "um", "ī"], 'your daughter', 'Feminine: tua.', "rodzina"),
    ("ūnus et ūnus ", "su", "nt", " duo", ["m", "s", "t", "nt"], 'are two', '“Are” = sunt: -nt means “they”.', "liczby"),
    ("in ", "terr", "ā", "", ["a", "ā", "am", "ae"], 'on the earth', 'Where? Ablative: terrā.', "swiat"),
    ("sōl in ", "cael", "ō", " est", ["um", "ō", "ī", "us"], 'the sun is in the sky', 'Ablative of caelum: caelō.', "swiat"),
    ("ego librum ", "leg", "ō", "", ["ō", "is", "it", "unt"], 'I read', 'I: -ō.', "czas"),
    ("tū librum ", "leg", "is", "", ["ō", "is", "it", "unt"], 'you read', 'You: -is.', "czas"),
    ("puella aquam ", "vid", "et", "", ["eō", "ēs", "et", "ent"], 'she sees', 'He/she: -t.', "czas"),
    ("amō ", "Rōm", "am", "", ["a", "ae", "am", "ā"], 'I love Rome', 'What do I love? Accusative: -am.', "czas"),
    ("ego ", "libr", "um", " legō", ["um", "ī", "ō", "er"], 'I read a book', 'What do I read? Accusative: librum.', "czas"),
    ("", "De", "ō", " grātiās", ["us", "ō", "um", "e"], 'thanks be to God', 'To whom? Dative: Deō.', "przypadki"),
    ("", "amīc", "e", ", salvē!", ["us", "e", "ī", "um"], 'friend, hello!', 'Vocative of -us: -e.', "przypadki"),
    ("", "Rōm", "ae", " sum", ["a", "ae", "am", "ā"], 'I am in Rome', 'Where? Rōmae (old locative).', "przypadki"),
    ("", "vēn", "ī", ", vīdī, vīcī", ["ī", "it", "iō", "imus"], 'I came', 'Perfect, I: -ī.', "perfekt"),
    ("Caesar ", "dīx", "it", "", ["ī", "it", "imus", "ērunt"], 'Caesar said', 'He: -it.', "perfekt"),
    ("errāre ", "hūmān", "um", " est", ["us", "a", "um", "ī"], 'to err is human',
     'An infinitive is neuter: -um.', "sent1"),
    ("mēns ", "sān", "a", "", ["us", "a", "um", "ō"], 'a healthy mind', 'mēns is feminine: sāna.', "sent2"),
    ("sānctificētur nōmen ", "tu", "um", "", ["us", "a", "um", "ae"], 'thy name', 'nōmen is neuter: tuum.', "pater"),
]

# Kolory: długie samogłoski w kolorze brązu, żeby iloczas był widoczny.
LONG_VOWELS = "āēīōūȳĀĒĪŌŪ"

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "forum", "title": 'At the Forum', "partner": "Marek", "avatar": "M", "requires": "slowa",
        "turns": [
            {"bot": ["salvē", "!"], "en": 'Hello!',
             "options": [(["salvē", "!"], True, None),
                         (["valē", "!"], False, "valē means “goodbye”. You've only just met!")]},
            {"bot": ["quis", "es", "?"], "en": 'Who are you?',
             "options": [(["amīcus", "sum"], True, None),
                         (["amīcus", "es"], False, 'es means “you are”. About yourself: sum (I am).'),
                         (["amīcus", "est"], False, 'est means “is”. About yourself: sum.')]},
            {"bot": ["Rōma", "magna", "est", "!"], "en": 'Rome is great!',
             "options": [(["ita", ",", "Rōma", "magna", "est"], True, None),
                         (["ita", ",", "Rōma", "magnus", "est"], False, 'Rōma is feminine: magna, not magnus.')]},
            {"bot": ["valē", "!"], "en": 'Goodbye!', "build": (["valē"], 'Goodbye!')},
        ],
    },
    {
        "id": "dom", "title": 'At home', "partner": "Julia", "avatar": "I", "requires": "rodzina",
        "turns": [
            {"bot": ["estne", "pater", "tuus", "bonus", "?"], "en": 'Is your father good?',
             "options": [(["pater", "meus", "bonus", "est"], True, None),
                         (["pater", "tuus", "bonus", "est"], False, "tuus means “your”. You're talking about your own father: meus."),
                         (["pater", "mea", "bona", "est"], False, 'pater is masculine: meus, bonus.')],
             "note": '-ne at the end of a word turns it into a question.'},
            {"bot": ["et", "māter", "tua", "?"], "en": 'And your mother?',
             "build": (["māter", "mea", "bona", "est"], 'My mother is good.')},
        ],
    },
    {
        "id": "schola", "title": 'At school', "partner": "Magister", "avatar": "G", "requires": "przypadki",
        "turns": [
            {"bot": ["quid", "legis", "?"], "en": 'What are you reading?',
             "options": [(["librum", "legō"], True, None),
                         (["librum", "legit"], False, 'legit means “reads” (he). About yourself: legō.'),
                         (["liber", "legō"], False, 'What are you reading? Accusative: librum.')]},
            {"bot": ["quid", "scrībis", "?"], "en": 'What are you writing?',
             "build": (["librum", "scrībō"], 'I am writing a book.')},
            {"bot": ["bene", "!"], "en": 'Good!',
             "options": [(["grātiās", "agō"], True, None),
                         (["Deō", "grātiās"], False, "That's “thanks be to God”. To a teacher, just say “thank you”.")]},
        ],
    },
    {
        "id": "caesar", "title": "At Caesar's", "partner": "Cezar", "avatar": "C", "requires": "perfekt",
        "turns": [
            {"bot": ["quid", "fēcistī", "?"], "en": 'What did you do?',
             "options": [(["vēnī", ",", "vīdī", ",", "vīcī"], True, None),
                         (["veniō", ",", "videō", ",", "vincō"], False,
                          "That's the present tense. He's asking what you did: perfect vēnī, vīdī, vīcī.")]},
            {"bot": ["ubi", "fuistī", "?"], "en": 'Where were you?',
             "build": (["fuī", "Rōmae"], 'I was in Rome.')},
            {"bot": ["bene", "!", "valē", "!"], "en": 'Good! Farewell!',
             "options": [(["valē", ",", "Caesar"], True, None),
                         (["salvē", ",", "Caesar"], False, "salvē is a greeting. Now you're saying goodbye: valē.")]},
        ],
    },
]

CHAT_EXTRA = {
    "quis": 'who', "ita": 'yes', "estne": 'is (he)?', "legis": 'you read', "bene": 'well',
    "fēcistī": 'you did', "ubi": 'where', "fuistī": 'you were', "veniō": 'I come', "vincō": 'I conquer',
}
PUNCT = set(",.!?:;")

"""Treść kursu: łacina klasyczna dla Polaków.

Słowo:     (forma z iloczasem, znaczenie po polsku, polskie słowo z łaciny lub None, skojarzenie lub None)
Wymowa:    (litera lub dwuznak, jak czytać, przykład)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie)

Wymowa (pole „tr”) powstaje automatycznie w engine.py: wymowa klasyczna
zapisana po polsku, np. caelum → kajlum.
"""

UNITS = [
    # ---------------------------------------------------------------- wymowa
    {
        "id": "wymowa", "title": "Wymowa", "icon": "I", "track": "wymowa",
        "letters": [
            ("c", "[k]: Cicerō czytaj „Kikero”", "Cicerō"),
            ("v", "[w], jak angielskie w", "vīta"),
            ("ae", "[ae̯]: Caesar czytaj „Kajsar”", "Caesar"),
            ("oe", "[oe̯]: poena czytaj „pojna”", "poena"),
            ("qu", "[kʷ]: aqua czytaj „akwa”", "aqua"),
            ("ph", "[pʰ] (słowa z greki; później f)", "philosophia"),
            ("ch", "[kʰ] (słowa z greki)", "chorus"),
            ("i", "[i], a przed samogłoską [j]: iam czytaj „jam”", "iam"),
            ("ā", "[aː]: kreska oznacza tylko długość", "māter"),
            ("ti", "[ti], nigdy [ts]: nātiō", "nātiō"),
            ("s", "[s], nigdy [z]: rosa czytaj „rosa”", "rosa"),
            ("x", "[ks]: rēx czytaj „rēks”", "rēx"),
        ],
    },
    # ----------------------------------------------------------------- język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "II", "track": "jezyk", "requires": "wymowa",
        "words": [
            ("salvē", "witaj", "salwa", "Dosłownie „bądź zdrów”. Salwa honorowa to też pozdrowienie!"),
            ("valē", "żegnaj; bądź zdrów", None, "Rzymianie żegnali się życzeniem zdrowia."),
            ("ego", "ja", "ego; egoista", None),
            ("tū", "ty", "ty", None),
            ("et", "i", "et cetera", "Znak & to stylizowane „et”!"),
            ("nōn", "nie", "nonsens", None),
            ("sum", "jestem", "suma", None),
            ("es", "jesteś", None, None),
            ("est", "jest", "jest", "Prawie jak polskie „jest”: oba z tego samego praindoeuropejskiego słowa."),
            ("puer", "chłopiec", None, None),
            ("puella", "dziewczyna", None, None),
            ("amīcus", "przyjaciel", "amicus curiae", None),
            ("bonus", "dobry", "bonus", "Bonus to „coś dobrego” na dokładkę."),
            ("bona", "dobra", "bona (dobra, majątek)", None),
            ("magnus", "wielki", "magnat", None),
            ("magna", "wielka", "Magna Carta", None),
            ("Rōma", "Rzym", "romański", None),
        ],
        "sentences": [
            (["ego", "sum", "puer"], "Jestem chłopcem.",
             {"es": "es to „jesteś”. O sobie: sum (jestem).", "est": "est to „jest”. O sobie: sum."}),
            (["tū", "es", "puella"], "Jesteś dziewczyną.", {"sum": "sum to „jestem”. Do „ty”: es."}),
            (["amīcus", "bonus", "est"], "Przyjaciel jest dobry.",
             {"bona": "amīcus jest męski: bonus, jak „dobry”."}),
            (["Rōma", "magna", "est"], "Rzym jest wielki.",
             {"magnus": "Rōma jest rodzaju żeńskiego (jak „Roma”), więc magna."}),
            (["nōn", "sum", "magnus"], "Nie jestem wielki.", {}),
            (["puella", "bona", "est"], "Dziewczyna jest dobra.",
             {"bonus": "puella jest żeńska: bona, jak „dobra”."}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "III", "track": "jezyk",
        "words": [
            ("pater", "ojciec", "patron", None),
            ("māter", "matka", "matrona", None),
            ("fīlius", "syn", "filia (oddział)", "Filia to dosłownie „córka” firmy."),
            ("fīlia", "córka", "filia", None),
            ("frāter", "brat", "fraternizacja", None),
            ("soror", "siostra", None, None),
            ("vir", "mąż; mężczyzna", "wirtuoz", "Od vir pochodzi virtus: męstwo, cnota. Stąd „wirtuoz”."),
            ("fēmina", "kobieta", "feminizm", None),
            ("homō", "człowiek", "homo sapiens", None),
            ("dominus", "pan", "dominować", None),
            ("servus", "niewolnik; sługa", "serwus!", "„Serwus!” to dosłownie „(twój) sługa”."),
            ("meus", "mój", None, None),
            ("mea", "moja", None, None),
            ("tuus", "twój", None, None),
            ("tua", "twoja", None, None),
        ],
        "sentences": [
            (["pater", "meus", "bonus", "est"], "Mój ojciec jest dobry.",
             {"mea": "pater jest męski: meus (mój)."}),
            (["māter", "mea", "fēmina", "bona", "est"], "Moja matka jest dobrą kobietą.",
             {"meus": "māter jest żeńska: mea (moja)."}),
            (["frāter", "meus", "amīcus", "tuus", "est"], "Mój brat jest twoim przyjacielem.", {}),
            (["fīlia", "tua", "puella", "bona", "est"], "Twoja córka jest dobrą dziewczyną.",
             {"tuus": "fīlia jest żeńska: tua (twoja)."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "IV", "track": "jezyk",
        "words": [
            ("ūnus", "jeden", "unikat; unia", None),
            ("duo", "dwa", "duet", None),
            ("trēs", "trzy", "trio", None),
            ("quattuor", "cztery", "kwartet", None),
            ("quīnque", "pięć", "kwintet", None),
            ("sex", "sześć", "sekstet", None),
            ("septem", "siedem", "septyma", "Stąd angielski September: siódmy miesiąc dawnego kalendarza."),
            ("octō", "osiem", "oktawa", None),
            ("novem", "dziewięć", "nowenna", None),
            ("decem", "dziesięć", "decymetr", None),
            ("sunt", "są", None, None),
            ("puerī", "chłopcy", None, None),
        ],
        "sentences": [
            (["ūnus", "et", "ūnus", "sunt", "duo"], "Jeden i jeden to dwa.",
             {"est": "Podmiot w liczbie mnogiej: sunt (są)."}),
            (["septem", "et", "trēs", "sunt", "decem"], "Siedem i trzy to dziesięć.", {}),
            (["trēs", "puerī", "sunt"], "Jest trzech chłopców.",
             {"puer": "Trzech: liczba mnoga, puerī."}),
        ],
    },
    {
        "id": "swiat", "title": "Świat", "icon": "V", "track": "jezyk",
        "words": [
            ("terra", "ziemia", "teren; terytorium", None),
            ("terrā", "(na) ziemi", None, "Ablatyw: in terrā = na ziemi."),
            ("aqua", "woda", "akwarium", None),
            ("caelum", "niebo", None, "Stąd angielskie „celestial”, niebiański."),
            ("caelō", "(w) niebie", None, None),
            ("sōl", "słońce", "solarium", None),
            ("lūna", "księżyc", "lunatyk", "Lunatyk to ktoś, na kogo działa księżyc."),
            ("stella", "gwiazda", "konstelacja", None),
            ("via", "droga", "wiadukt", None),
            ("urbs", "miasto", "urbanistyka", None),
            ("silva", "las", "Sylwia", "Sylwia to „leśna”."),
            ("mare", "morze", "marynarz", None),
            ("vīta", "życie", "witamina", "Witamina = „amina życia”."),
            ("brevis", "krótki", "brewiarz", "Brewiarz to „skrócony” modlitewnik."),
            ("in", "w; na", "in plus", None),
        ],
        "sentences": [
            (["sōl", "in", "caelō", "est"], "Słońce jest na niebie.",
             {"caelum": "Gdzie? Po „in” ablatyw: caelō, jak polskie „na niebie”."}),
            (["aqua", "in", "terrā", "est"], "Woda jest na ziemi.",
             {"terra": "Gdzie? Ablatyw: terrā."}),
            (["vīta", "brevis", "est"], "Życie jest krótkie.", {}),
            (["Rōma", "urbs", "magna", "est"], "Rzym jest wielkim miastem.", {}),
        ],
    },
    {
        "id": "czas", "title": "Czasowniki", "icon": "VI", "track": "jezyk",
        "words": [
            ("amō", "kocham", "amator", "Amator to ten, kto „kocha” coś robić."),
            ("amat", "kocha", None, None),
            ("videō", "widzę", "wideo", None),
            ("videt", "widzi", None, None),
            ("legō", "czytam", "legenda", "Legenda = „to, co trzeba czytać”."),
            ("legit", "czyta", None, None),
            ("scrībō", "piszę", "skryba", None),
            ("scrībis", "piszesz", None, None),
            ("audiō", "słyszę", "audycja", None),
            ("labōrat", "pracuje", "laboratorium", None),
            ("quid", "co", None, None),
            ("liber", "książka", "libretto", None),
            ("librum", "książkę", None, "Biernik: co czytam? librum."),
            ("aquam", "wodę", None, None),
            ("Rōmam", "Rzym (biernik)", None, None),
        ],
        "sentences": [
            (["ego", "librum", "legō"], "Czytam książkę.",
             {"legit": "legit to „czyta” (on). O sobie: legō, -ō jak polskie -ę.",
              "liber": "Co czytam? Biernik: librum."}),
            (["quid", "scrībis"], "Co piszesz?", {"scrībō": "Pytasz kogoś: scrībis (-s jak polskie -sz)."}),
            (["puella", "aquam", "videt"], "Dziewczyna widzi wodę.",
             {"aqua": "Co widzi? Biernik: aquam, jak polskie „wodę”.", "videō": "videō to „widzę”. Ona: videt."}),
            (["amō", "Rōmam"], "Kocham Rzym.", {"Rōma": "Co kocham? Biernik: Rōmam."}),
            (["pater", "labōrat"], "Ojciec pracuje.", {}),
        ],
    },
    {
        "id": "przypadki", "title": "Przypadki", "icon": "VII", "track": "jezyk",
        "words": [
            ("grātiās", "dzięki (biernik l.mn.)", "gratis", "Gratis = „za dzięki”, czyli za darmo."),
            ("agō", "składam; robię", "agenda", None),
            ("Deus", "Bóg", None, None),
            ("Deō", "Bogu", None, None),
            ("domine", "Panie! (wołacz)", None, "Wołacz od -us to -e, jak polskie „Panie!”."),
            ("amīce", "przyjacielu! (wołacz)", None, None),
            ("Rōmae", "w Rzymie", None, "Dawny miejscownik nazw miast."),
            ("domī", "w domu", None, "Też dawny miejscownik."),
        ],
        "sentences": [
            (["grātiās", "agō"], "Dziękuję.", {}),
            (["Deō", "grātiās"], "Bogu dzięki.", {"Deus": "Komu? Celownik: Deō, jak „Bogu”."}),
            (["amīce", ",", "salvē"], "Witaj, przyjacielu!",
             {"amīcus": "Zwracasz się do kogoś: wołacz amīce, jak „przyjacielu!”."}),
            (["Rōmae", "sum"], "Jestem w Rzymie.", {"Rōma": "Gdzie? Rōmae (w Rzymie)."}),
            (["domī", "sum"], "Jestem w domu.", {}),
        ],
    },
    {
        "id": "perfekt", "title": "Czas przeszły", "icon": "VIII", "track": "jezyk",
        "words": [
            ("vēnī", "przyszedłem", None, "Perfekt: -ī = polskie -łem."),
            ("vīdī", "zobaczyłem", None, None),
            ("vīcī", "zwyciężyłem", "wiktoria", None),
            ("fuī", "byłem", None, None),
            ("erat", "był; była", None, None),
            ("dīxit", "powiedział", "dyktator", "Dyktator to ten, kto „mówi”, co robić."),
            ("scrīpsit", "napisał", "skrypt", None),
            ("Caesar", "Cezar", "cesarz", "Od imienia Cezara: cesarz, Kaiser, car."),
        ],
        "sentences": [
            (["vēnī", ",", "vīdī", ",", "vīcī"], "Przyszedłem, zobaczyłem, zwyciężyłem.", {}),
            (["Caesar", "dīxit"], "Cezar powiedział.", {}),
            (["Rōma", "magna", "erat"], "Rzym był wielki.", {"est": "W przeszłości: erat (był), nie est."}),
            (["puella", "librum", "scrīpsit"], "Dziewczyna napisała książkę.", {}),
            (["fuī", "Rōmae"], "Byłem w Rzymie.", {"sum": "W przeszłości: fuī (byłem)."}),
        ],
    },
    # -------------------------------------------------------------- sentencje
    {
        "id": "sent1", "title": "Sentencje I", "icon": "IX", "track": "sentencje", "requires": "czas",
        "words": [
            ("carpe", "chwytaj; zrywaj", None, "Dosłownie „zrywaj”, jak owoc."),
            ("diem", "dzień (biernik)", "diariusz", "Diariusz = dziennik, od diēs (dzień)."),
            ("errāre", "błądzić", "errata", None),
            ("hūmānum", "ludzkie", "humanizm", None),
            ("mementō", "pamiętaj", "memento", None),
            ("morī", "umrzeć", "mór", "Pokrewne z „mors” (śmierć) i polskim „mór”, „umrzeć”."),
            ("cōgitō", "myślę", None, None),
            ("ergō", "więc", "ergo", None),
        ],
        "sentences": [
            (["carpe", "diem"], "Chwytaj dzień.", {}),
            (["errāre", "hūmānum", "est"], "Błądzić jest rzeczą ludzką.", {}),
            (["mementō", "morī"], "Pamiętaj o śmierci.", {}),
            (["cōgitō", ",", "ergō", "sum"], "Myślę, więc jestem.", {}),
        ],
    },
    {
        "id": "sent2", "title": "Sentencje II", "icon": "X", "track": "sentencje",
        "words": [
            ("per", "przez", "per procura", None),
            ("aspera", "trudności", None, None),
            ("ad", "do", "adaptacja", None),
            ("astra", "gwiazdy", "astronomia", None),
            ("ālea", "kostka do gry", None, None),
            ("iacta", "rzucona", None, None),
            ("vīnō", "(w) winie", "wino", None),
            ("vēritās", "prawda", "weryfikacja", None),
            ("tempus", "czas", "tempo", None),
            ("fugit", "ucieka", "fuga", "Fuga w muzyce to głosy, które „uciekają” jeden za drugim."),
            ("mēns", "umysł", "mentalny", None),
            ("sāna", "zdrowa", "sanatorium", None),
            ("corpore", "(w) ciele", "korporacja", None),
            ("sānō", "zdrowym", None, None),
        ],
        "sentences": [
            (["per", "aspera", "ad", "astra"], "Przez trudy do gwiazd.", {}),
            (["ālea", "iacta", "est"], "Kości zostały rzucone.", {}),
            (["in", "vīnō", "vēritās"], "W winie prawda.", {}),
            (["tempus", "fugit"], "Czas ucieka.", {}),
            (["mēns", "sāna", "in", "corpore", "sānō"], "W zdrowym ciele zdrowy duch.", {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "pater", "title": "Pater noster", "icon": "XI", "track": "teksty", "requires": "przypadki",
        "words": [
            ("noster", "nasz", None, None),
            ("quī", "który", None, None),
            ("caelīs", "niebiosach", None, None),
            ("sānctificētur", "niech się święci", "sanktuarium", None),
            ("nōmen", "imię", "nominacja", None),
            ("tuum", "twoje", None, None),
            ("adveniat", "niech przyjdzie", "adwent", "Adwent = „przyjście”."),
            ("rēgnum", "królestwo", "regent", None),
            ("fīat", "niech się stanie", None, None),
            ("voluntās", "wola", "wolontariusz", None),
            ("sīcut", "jak; jako", None, None),
        ],
        "sentences": [
            (["pater", "noster", ",", "quī", "es", "in", "caelīs"], "Ojcze nasz, któryś jest w niebie.", {}),
            (["sānctificētur", "nōmen", "tuum"], "Święć się imię Twoje.", {}),
            (["adveniat", "rēgnum", "tuum"], "Przyjdź królestwo Twoje.", {}),
            (["fīat", "voluntās", "tua"], "Bądź wola Twoja.", {"tuum": "voluntās jest żeńska: tua."}),
            (["sīcut", "in", "caelō", "et", "in", "terrā"], "Jako w niebie, tak i na ziemi.", {}),
        ],
    },
    {
        "id": "gallia", "title": "Cezar: Galia", "icon": "XII", "track": "teksty",
        "words": [
            ("Gallia", "Galia", "galijski", None),
            ("Galliā", "(w) Galii", None, None),
            ("omnis", "cały; każdy", "omnibus", "Omnibus = „dla wszystkich”."),
            ("dīvīsa", "podzielona", "dywizja", None),
            ("partēs", "części", "partia", None),
        ],
        "sentences": [
            (["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
             "Galia cała dzieli się na trzy części.", {}),
            (["Caesar", "in", "Galliā", "erat"], "Cezar był w Galii.", {"Gallia": "Gdzie? Ablatyw: in Galliā."}),
        ],
    },
]

TRACKS = {
    "wymowa": "WYMOWA",
    "jezyk": "LINGVA · JĘZYK",
    "sentencje": "SENTENTIAE · SENTENCJE",
    "teksty": "TEXTVS · TEKSTY",
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "wymowa": [
        {"title": "Rzymianie mówili „Kikero”",
         "text": "W szkole mówi się „Cyceron” i „Cezar”, ale Rzymianie czytali c zawsze jak k: "
                 "Kikero, Kajsar. Stąd niemieckie Kaiser. Kreska nad samogłoską (ā) to tylko "
                 "długość: wymawiasz ją dłużej, ale tak samo.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Znasz już łacinę",
         "text": "Bonus, magnat, ego, nonsens: polski jest pełen łaciny. Dobra wiadomość nr 2: "
                 "łacina, jak polski, nie ma przedimków (a, the). Mówisz po prostu „puer” = chłopiec.",
         "chain": [
             ("Jestem chłopcem.", ["ego", "sum", "puer"], "ego = ja (jak „egoista”), sum = jestem."),
             ("Jesteś dziewczyną.", ["tū", "es", "puella"], "Zmień osobę: tū, es."),
         ]},
        {"title": "Czasownik lubi koniec",
         "text": "Po polsku szyk jest swobodny i w łacinie też. Ale Rzymianie lubili stawiać "
                 "czasownik na końcu: „amīcus bonus est” = przyjaciel dobry jest. Rodzaj działa "
                 "jak w polskim: bonus (dobry), bona (dobra).",
         "chain": [
             ("Przyjaciel jest dobry.", ["amīcus", "bonus", "est"], "Rzecz, cecha, a est na końcu."),
             ("Rzym jest wielki.", ["Rōma", "magna", "est"], "Rōma jest żeńska, więc magna."),
         ]},
    ],
    "rodzina": [
        {"title": "Rodzaj zgadza się jak u nas",
         "text": "Polski i łacina tak samo dopasowują rodzaj: mój ojciec, moja matka = pater meus, "
                 "māter mea. Zaimek często stoi po rzeczowniku, jak w „Ojcze nasz”.",
         "chain": [
             ("Mój ojciec jest dobry.", ["pater", "meus", "bonus", "est"], "pater meus, potem cecha i est."),
             ("Moja matka jest dobrą kobietą.", ["māter", "mea", "fēmina", "bona", "est"],
              "Wszystko żeńskie: mea, bona."),
         ]},
    ],
    "liczby": [
        {"title": "Liczby znasz z muzyki",
         "text": "Duet, trio, kwartet, kwintet, oktawa, nowenna, decymetr. Wystarczy odciąć "
                 "polską końcówkę. A „są” to sunt: końcówka -nt oznacza „oni”.",
         "chain": [("Jeden i jeden to dwa.", ["ūnus", "et", "ūnus", "sunt", "duo"], "Podmiot mnogi: sunt.")]},
    ],
    "swiat": [
        {"title": "Ablatyw = miejscownik + narzędnik",
         "text": "Polski ma 7 przypadków, łacina 6. Prawie te same! Łaciński ablatyw robi to, co nasz "
                 "miejscownik i narzędnik: in terrā = na ziemi, in caelō = w niebie.",
         "chain": [
             ("Słońce jest na niebie.", ["sōl", "in", "caelō", "est"], "Gdzie? in + ablatyw: caelō."),
             ("Woda jest na ziemi.", ["aqua", "in", "terrā", "est"], "in terrā."),
         ]},
    ],
    "czas": [
        {"title": "Osoba siedzi w końcówce",
         "text": "Jak po polsku, nie musisz mówić „ja”: legō = czytam. Końcówki nawet brzmią "
                 "podobnie: -ō (ja), -s (ty, jak -sz), -t (on). legō, legis, legit = czytam, czytasz, czyta.",
         "chain": [
             ("Czytam książkę.", ["ego", "librum", "legō"], "Co czytam? Biernik librum. Ja: legō."),
             ("Dziewczyna widzi wodę.", ["puella", "aquam", "videt"], "aquam (biernik), videt (ona)."),
         ]},
    ],
    "przypadki": [
        {"title": "Wołacz: jak w polskim",
         "text": "Łacina, jak polski, ma wołacz: amīcus → amīce! (przyjacielu!), dominus → domine! "
                 "(Panie!). I celownik jak nasz: Deō = Bogu.",
         "chain": [
             ("Witaj, przyjacielu!", ["amīce", ",", "salvē"], "Wołacz amīce."),
             ("Bogu dzięki.", ["Deō", "grātiās"], "Komu? Deō."),
         ]},
    ],
    "perfekt": [
        {"title": "-ī = -łem",
         "text": "Perfekt w 1. osobie kończy się na -ī: vēnī = przyszedłem, vīdī = zobaczyłem. "
                 "On/ona: -it (dīxit, scrīpsit). Cezar opisał całą wojnę jednym zdaniem.",
         "chain": [("Przyszedłem, zobaczyłem, zwyciężyłem.", ["vēnī", ",", "vīdī", ",", "vīcī"], "Trzy razy -ī.")]},
    ],
    "sent1": [
        {"title": "Sentencje: łacina, którą już cytujesz",
         "text": "Carpe diem, memento mori, cogito ergo sum. Znasz te zdania, teraz zrozumiesz każde "
                 "słowo. diem to biernik od diēs (dzień): chwytaj co? dzień.",
         "chain": [("Chwytaj dzień.", ["carpe", "diem"], "carpe (chwytaj) + diem (biernik).")]},
    ],
    "sent2": [
        {"title": "Dosłownie i swobodnie",
         "text": "„Mens sana in corpore sano” po polsku mówimy na odwrót: w zdrowym ciele zdrowy "
                 "duch. Łacina stawia słowa tam, gdzie chce podkreślić, bo końcówki i tak mówią, co do czego pasuje.",
         "chain": [("Przez trudy do gwiazd.", ["per", "aspera", "ad", "astra"], "per (przez) … ad (do) …")]},
    ],
    "pater": [
        {"title": "Modlitwę już znasz",
         "text": "„Ojcze nasz” po polsku przetłumaczono z łaciny, stąd stary szyk: „święć się imię "
                 "Twoje”. sānctificētur = niech się święci (pokrewne z „sanktuarium”).",
         "chain": [("Przyjdź królestwo Twoje.", ["adveniat", "rēgnum", "tuum"],
                    "adveniat (adwent!) + rēgnum (regent) + tuum.")]},
    ],
    "gallia": [
        {"title": "Pierwsze zdanie Cezara",
         "text": "Tak zaczynają się „Notatki o wojnie galijskiej”, na których uczyły się pokolenia "
                 "uczniów. Gallia est omnis dīvīsa in partēs trēs. Znasz już wszystkie słowa!",
         "chain": [("Galia cała dzieli się na trzy części.",
                    ["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
                    "dīvīsa = podzielona (dywizja), partēs = części (partia).")]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Końcówka mówi wszystko",
    "text": "W polskim „widzę dziewczynę”, a nie „widzę dziewczyna”. W łacinie tak samo: puellam. "
            "Końcówka mówi, kto co robi i komu. Gdy wahasz się, zadaj pytanie jak na lekcji polskiego: "
            "kto? co? komu? gdzie?",
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("puella ", "bon", "a", "", ["us", "a", "um", "ī"], "dobra dziewczyna", "Żeńska: -a, jak „dobra”.", "slowa"),
    ("puer ", "bon", "us", "", ["us", "a", "um", "ae"], "dobry chłopiec", "Męski: -us.", "slowa"),
    ("Rōma ", "magn", "a", " est", ["us", "a", "um", "ī"], "Rzym jest wielki", "Rōma jest żeńska: magna.", "slowa"),
    ("māter ", "me", "a", "", ["us", "a", "um", "ae"], "moja matka", "Matka jest żeńska: mea.", "rodzina"),
    ("pater ", "me", "us", "", ["us", "a", "um", "ae"], "mój ojciec", "Ojciec jest męski: meus.", "rodzina"),
    ("fīlia ", "tu", "a", "", ["us", "a", "um", "ī"], "twoja córka", "Żeńska: tua.", "rodzina"),
    ("ūnus et ūnus ", "su", "nt", " duo", ["m", "s", "t", "nt"], "są dwa", "„Są” = sunt: -nt to „oni”.", "liczby"),
    ("in ", "terr", "ā", "", ["a", "ā", "am", "ae"], "na ziemi", "Gdzie? Ablatyw: terrā.", "swiat"),
    ("sōl in ", "cael", "ō", " est", ["um", "ō", "ī", "us"], "słońce jest na niebie", "Ablatyw od caelum: caelō.", "swiat"),
    ("ego librum ", "leg", "ō", "", ["ō", "is", "it", "unt"], "czytam", "Ja: -ō, jak polskie -ę.", "czas"),
    ("tū librum ", "leg", "is", "", ["ō", "is", "it", "unt"], "czytasz", "Ty: -is, jak polskie -sz.", "czas"),
    ("puella aquam ", "vid", "et", "", ["eō", "ēs", "et", "ent"], "ona widzi", "On/ona: -t.", "czas"),
    ("amō ", "Rōm", "am", "", ["a", "ae", "am", "ā"], "kocham Rzym", "Co kocham? Biernik: -am (jak „Romę”).", "czas"),
    ("ego ", "libr", "um", " legō", ["um", "ī", "ō", "er"], "czytam książkę", "Co czytam? Biernik: librum.", "czas"),
    ("", "De", "ō", " grātiās", ["us", "ō", "um", "e"], "Bogu dzięki", "Komu? Celownik: Deō.", "przypadki"),
    ("", "amīc", "e", ", salvē!", ["us", "e", "ī", "um"], "przyjacielu, witaj!", "Wołacz od -us: -e.", "przypadki"),
    ("", "Rōm", "ae", " sum", ["a", "ae", "am", "ā"], "jestem w Rzymie", "Gdzie? Rōmae (dawny miejscownik).", "przypadki"),
    ("", "vēn", "ī", ", vīdī, vīcī", ["ī", "it", "iō", "imus"], "przyszedłem", "Perfekt, ja: -ī = -łem.", "perfekt"),
    ("Caesar ", "dīx", "it", "", ["ī", "it", "imus", "ērunt"], "Cezar powiedział", "On: -it.", "perfekt"),
    ("errāre ", "hūmān", "um", " est", ["us", "a", "um", "ī"], "błądzić jest rzeczą ludzką",
     "Bezokolicznik jest nijaki: -um.", "sent1"),
    ("mēns ", "sān", "a", "", ["us", "a", "um", "ō"], "zdrowy umysł", "mēns jest żeńska: sāna.", "sent2"),
    ("sānctificētur nōmen ", "tu", "um", "", ["us", "a", "um", "ae"], "imię twoje", "nōmen jest nijakie: tuum.", "pater"),
]

# Kolory: długie samogłoski w kolorze brązu, żeby iloczas był widoczny.
LONG_VOWELS = "āēīōūȳĀĒĪŌŪ"

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "forum", "title": "Na Forum", "partner": "Marek", "avatar": "M", "requires": "slowa",
        "turns": [
            {"bot": ["salvē", "!"], "en": "Witaj!",
             "options": [(["salvē", "!"], True, None),
                         (["valē", "!"], False, "valē to „żegnaj”. Dopiero się spotkaliście!")]},
            {"bot": ["quis", "es", "?"], "en": "Kim jesteś?",
             "options": [(["amīcus", "sum"], True, None),
                         (["amīcus", "es"], False, "es to „jesteś”. O sobie: sum (jestem)."),
                         (["amīcus", "est"], False, "est to „jest”. O sobie: sum.")]},
            {"bot": ["Rōma", "magna", "est", "!"], "en": "Rzym jest wielki!",
             "options": [(["ita", ",", "Rōma", "magna", "est"], True, None),
                         (["ita", ",", "Rōma", "magnus", "est"], False, "Rōma jest żeńska: magna, nie magnus.")]},
            {"bot": ["valē", "!"], "en": "Żegnaj!", "build": (["valē"], "Żegnaj!")},
        ],
    },
    {
        "id": "dom", "title": "W domu", "partner": "Julia", "avatar": "I", "requires": "rodzina",
        "turns": [
            {"bot": ["estne", "pater", "tuus", "bonus", "?"], "en": "Czy twój ojciec jest dobry?",
             "options": [(["pater", "meus", "bonus", "est"], True, None),
                         (["pater", "tuus", "bonus", "est"], False, "tuus to „twój”. Mówisz o swoim ojcu: meus."),
                         (["pater", "mea", "bona", "est"], False, "pater jest męski: meus, bonus.")],
             "note": "-ne na końcu słowa robi z niego pytanie, jak polskie „czy”."},
            {"bot": ["et", "māter", "tua", "?"], "en": "A twoja matka?",
             "build": (["māter", "mea", "bona", "est"], "Moja matka jest dobra.")},
        ],
    },
    {
        "id": "schola", "title": "W szkole", "partner": "Magister", "avatar": "G", "requires": "przypadki",
        "turns": [
            {"bot": ["quid", "legis", "?"], "en": "Co czytasz?",
             "options": [(["librum", "legō"], True, None),
                         (["librum", "legit"], False, "legit to „czyta” (on). O sobie: legō."),
                         (["liber", "legō"], False, "Co czytasz? Biernik: librum.")]},
            {"bot": ["quid", "scrībis", "?"], "en": "Co piszesz?",
             "build": (["librum", "scrībō"], "Piszę książkę.")},
            {"bot": ["bene", "!"], "en": "Dobrze!",
             "options": [(["grātiās", "agō"], True, None),
                         (["Deō", "grātiās"], False, "To „Bogu dzięki”. Nauczycielowi powiedz po prostu „dziękuję”.")]},
        ],
    },
    {
        "id": "caesar", "title": "U Cezara", "partner": "Cezar", "avatar": "C", "requires": "perfekt",
        "turns": [
            {"bot": ["quid", "fēcistī", "?"], "en": "Co zrobiłeś?",
             "options": [(["vēnī", ",", "vīdī", ",", "vīcī"], True, None),
                         (["veniō", ",", "videō", ",", "vincō"], False,
                          "To czas teraźniejszy. Pyta, co zrobiłeś: perfekt vēnī, vīdī, vīcī.")]},
            {"bot": ["ubi", "fuistī", "?"], "en": "Gdzie byłeś?",
             "build": (["fuī", "Rōmae"], "Byłem w Rzymie.")},
            {"bot": ["bene", "!", "valē", "!"], "en": "Dobrze! Żegnaj!",
             "options": [(["valē", ",", "Caesar"], True, None),
                         (["salvē", ",", "Caesar"], False, "salvē to powitanie. Teraz się żegnasz: valē.")]},
        ],
    },
]

CHAT_EXTRA = {
    "quis": "kto", "ita": "tak", "estne": "czy jest", "legis": "czytasz", "bene": "dobrze",
    "fēcistī": "zrobiłeś", "ubi": "gdzie", "fuistī": "byłeś", "veniō": "przychodzę", "vincō": "zwyciężam",
}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Larpy: sceny ze stawką. Węzeł: bot (tokeny), pl (tłumaczenie) oraz
#   options: [(tokeny, "good" | "weak" | "bad", następny węzeł lub None, komentarz)]  albo
#   build: (tokeny, polecenie po polsku), next: następny węzeł
# deadly: True = pytanie „jedna szansa" (zła odpowiedź kończy scenę). Węzeł z end: True kończy scenę.
# ---------------------------------------------------------------------------
LARP_EXTRA = {"agis": "robisz", "esne": "czy jesteś", "amāsne": "czy kochasz", "mīles": "żołnierz"}

LARPS = [
    {"id": "porta", "title": "Brama Rzymu", "partner": "Mīles", "avatar": "M", "requires": "przypadki",
     "fee": 20, "patience": 3,
     "scene": "Stoisz przed bramą Rzymu. Żołnierz przy bramie nie wpuszcza byle kogo.",
     "goal": "Przekonaj strażnika i wejdź do miasta.",
     "start": "a",
     "endings": {
         "win": "Strażnik odsuwa włócznię. Wchodzisz do Rzymu jak przyjaciel.",
         "partial": "Strażnik w końcu cię wpuszcza, ale patrzy podejrzliwie. Wszedłeś, lecz bez nagrody.",
         "fail": "Strażnik traci cierpliwość i przepędza cię spod bramy.",
     },
     "nodes": {
         "a": {"bot": ["salvē", "!", "quis", "es", "?"], "pl": "Witaj! Kim jesteś?",
               "options": [
                   (["salvē", ",", "domine", "!", "amīcus", "sum"], "good", "b", None),
                   (["salvē", "!", "amīcus", "sum"], "weak", "a2", "Poprawnie, ale bez „domine” brzmi to poufale. Strażnik robi się podejrzliwy."),
                   (["valē", "!", "amīcus", "es"], "bad", None, "valē to pożegnanie, a es znaczy „jesteś”. O sobie: sum."),
               ]},
         "a2": {"bot": ["amīcus", "?", "esne", "servus", "?"], "pl": "Przyjaciel? Jesteś niewolnikiem?",
                "build": (["servus", "nōn", "sum"], "Powiedz: Nie jestem niewolnikiem."), "next": "b",
                "why": "„Nie jestem” to nōn sum; przeczenie stoi przed czasownikiem."},
         "b": {"bot": ["quid", "Rōmae", "agis", "?"], "pl": "Co robisz w Rzymie?",
               "options": [
                   (["frāter", "meus", "Rōmae", "est"], "good", "c", None),
                   (["Rōmam", "videō"], "weak", "b2", "Zdanie jest poprawne, ale to żaden powód. Strażnik dopytuje."),
                   (["frāter", "tuus", "Rōmae", "est"], "bad", None, "tuus to „twój”. Mówisz o swoim bracie: meus."),
               ]},
         "b2": {"bot": ["Rōma", "magna", "est", ".", "quis", "Rōmae", "est", "?"], "pl": "Rzym jest wielki. Kto jest w Rzymie?",
                "build": (["frāter", "meus", "Rōmae", "est"], "Powiedz: Mój brat jest w Rzymie."), "next": "c",
                "why": "„W Rzymie” to Rōmae (miejscownik), a „mój” przy bracie to meus."},
         "c": {"bot": ["estne", "frāter", "tuus", "vir", "bonus", "?"], "pl": "Czy twój brat jest dobrym człowiekiem?",
               "build": (["ita", ",", "vir", "bonus", "est"], "Powiedz: Tak, jest dobrym człowiekiem."), "next": "d",
               "why": "„Tak” to ita; „jest dobrym mężem” to vir bonus est."},
         "d": {"bot": ["amāsne", "Rōmam", "?"], "pl": "Czy kochasz Rzym?", "deadly": True,
               "options": [
                   (["Rōmam", "amō", "!"], "good", "e", None),
                   (["Rōmam", "nōn", "amō"], "bad", None, "Gramatycznie dobrze, ale strażnikowi tego się nie mówi."),
                   (["Rōma", "amat"], "bad", None, "To znaczy „Rzym kocha”. „Kocham Rzym” to Rōmam amō."),
               ]},
         "e": {"bot": ["bene", "!", "valē", ",", "amīce", "!"], "pl": "Dobrze! Bywaj, przyjacielu!",
               "build": (["grātiās", "agō", ",", "domine"], "Podziękuj strażnikowi (panie)."), "next": "end",
               "why": "„Dziękuję” to grātiās agō, a do strażnika zwracasz się domine."},
         "end": {"bot": ["valē", "!"], "pl": "Bywaj!", "end": True},
     }},
]


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['ego', 'tū', 'is/ea', 'nōs', 'vōs', 'eī/eae'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'ablatyw lp.', 'wołacz lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.', 'ablatyw lm.'],
    'przyp5': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'ablatyw'],
    'part': ['participium praesentis activi', 'participium perfecti passivi', 'participium futuri activi', 'gerundivum'],
    'inf': ['īnfīnītīvus praesentis activi', 'īnfīnītīvus praesentis passivi', 'īnfīnītīvus perfecti activi', 'īnfīnītīvus perfecti passivi', 'īnfīnītīvus futuri activi'],
    'stopn': ['bonus', 'malus', 'magnus', 'parvus', 'multus'],
    't_dekl': ['rosa, rosae', 'dominus, dominī', 'rēx, rēgis', 'manus, manūs', 'rēs, reī', 'corpus, corporis', 'ager, agrī', 'cornū, cornūs'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'amāre (kochać): I koniugacja', 'os', 'amō; amās; amat; amāmus; amātis; amant', 'Końcówki osobowe: -ō, -s, -t, -mus, -tis, -nt.'),
    ('conj', 'Wzory koniugacji', 'vidēre (widzieć): II koniugacja', 'os', 'videō; vidēs; videt; vidēmus; vidētis; vident', None),
    ('conj', 'Wzory koniugacji', 'legere (czytać): III koniugacja', 'os', 'legō; legis; legit; legimus; legitis; legunt', 'III koniugacja: krótkie -i-, w 3. osobie lm. -unt.'),
    ('conj', 'Wzory koniugacji', 'audīre (słyszeć): IV koniugacja', 'os', 'audiō; audīs; audit; audīmus; audītis; audiunt', None),
    ('conj', 'Wyjątki', 'capere (chwytać): III koniugacja na -iō', 'os', 'capiō; capis; capit; capimus; capitis; capiunt', 'Jak legere, ale z -i- w 1. osobie lp. i 3. osobie lm.'),
    ('conj', 'Czasowniki nieregularne', 'esse (być)', 'os', 'sum; es; est; sumus; estis; sunt', None),
    ('conj', 'Czasowniki nieregularne', 'posse (móc)', 'os', 'possum; potes; potest; possumus; potestis; possunt', 'pot- + esse: przed s powstaje poss-.'),
    ('conj', 'Czasowniki nieregularne', 'velle (chcieć)', 'os', 'volō; vīs; vult; volumus; vultis; volunt', None),
    ('conj', 'Czasowniki nieregularne', 'īre (iść)', 'os', 'eō; īs; it; īmus; ītis; eunt', None),
    ('conj', 'Czasowniki nieregularne', 'ferre (nieść)', 'os', 'ferō; fers; fert; ferimus; fertis; ferunt', None),
    ('conj', 'Czas przeszły', 'amāre: imperfectum', 'os', 'amābam; amābās; amābat; amābāmus; amābātis; amābant', 'Znak czasu -bā- + końcówki -m, -s, -t.'),
    ('conj', 'Czas przeszły', 'amāre: perfectum', 'os', 'amāvī; amāvistī; amāvit; amāvimus; amāvistis; amāvērunt', 'Końcówki perfectum: -ī, -istī, -it, -imus, -istis, -ērunt.'),
    ('conj', 'Czas przeszły', 'esse: perfectum', 'os', 'fuī; fuistī; fuit; fuimus; fuistis; fuērunt', None),
    ('decl', 'Wzory deklinacji', 'puella (dziewczyna): I deklinacja', 'przyp', 'puella; puellae; puellae; puellam; puellā; puella; puellae; puellārum; puellīs; puellās; puellīs', None),
    ('decl', 'Wzory deklinacji', 'amīcus (przyjaciel): II deklinacja', 'przyp', 'amīcus; amīcī; amīcō; amīcum; amīcō; amīce; amīcī; amīcōrum; amīcīs; amīcōs; amīcīs', 'Jedyna deklinacja z osobnym wołaczem: amīce.'),
    ('decl', 'Wzory deklinacji', 'caelum (niebo): II deklinacja, nijaki', 'przyp', 'caelum; caelī; caelō; caelum; caelō; caelum; caela; caelōrum; caelīs; caela; caelīs', 'Nijakie: mianownik = biernik, w lm. na -a.'),
    ('decl', 'Wzory deklinacji', 'homō (człowiek): III deklinacja', 'przyp', 'homō; hominis; hominī; hominem; homine; homō; hominēs; hominum; hominibus; hominēs; hominibus', 'Temat widać dopiero w dopełniaczu: homin-.'),
    ('decl', 'Wzory deklinacji', 'nōmen (imię): III deklinacja, nijaki', 'przyp', 'nōmen; nōminis; nōminī; nōmen; nōmine; nōmen; nōmina; nōminum; nōminibus; nōmina; nōminibus', None),
    ('decl', 'Wzory deklinacji', 'manus (ręka): IV deklinacja', 'przyp', 'manus; manūs; manuī; manum; manū; manus; manūs; manuum; manibus; manūs; manibus', None),
    ('decl', 'Wzory deklinacji', 'diēs (dzień): V deklinacja', 'przyp', 'diēs; diēī; diēī; diem; diē; diēs; diēs; diērum; diēbus; diēs; diēbus', None),
    ('decl', 'Wyjątki', 'puer (chłopiec)', 'przyp', 'puer; puerī; puerō; puerum; puerō; puer; puerī; puerōrum; puerīs; puerōs; puerīs', 'II deklinacja bez -us w mianowniku.'),
    ('decl', 'Wyjątki', 'mare (morze)', 'przyp', 'mare; maris; marī; mare; marī; mare; maria; marium; maribus; maria; maribus', 'Temat na -i: ablatyw -ī, lm. -ia, -ium.'),
    ('decl', 'Wyjątki', 'deus (bóg)', 'przyp', 'deus; deī; deō; deum; deō; deus; dī; deōrum; dīs; deōs; dīs', 'Wołacz = mianownik; w lm. formy ściągnięte dī, dīs.'),
    ('decl', 'Zaimki', 'ego (ja)', 'przyp5', 'ego; meī; mihi; mē; mē', None),
    ('decl', 'Zaimki', 'tū (ty)', 'przyp5', 'tū; tuī; tibi; tē; tē', None),
    ('form', 'Imiesłowy', 'amāre (kochać)', 'part', 'amāns; amātus; amātūrus; amandus', '-ns: kochający; -tus: kochany; -tūrus: mający kochać; -ndus: ten, którego należy kochać.'),
    ('form', 'Imiesłowy', 'vidēre (widzieć)', 'part', 'vidēns; vīsus; vīsūrus; videndus', None),
    ('form', 'Imiesłowy', 'legere (czytać)', 'part', 'legēns; lēctus; lēctūrus; legendus', None),
    ('form', 'Imiesłowy', 'audīre (słyszeć)', 'part', 'audiēns; audītus; audītūrus; audiendus', None),
    ('form', 'Imiesłowy', 'capere (chwytać)', 'part', 'capiēns; captus; captūrus; capiendus', None),
    ('decl', 'Imiesłowy: odmiana', 'amāns (kochający)', 'przyp5', 'amāns; amantis; amantī; amantem; amante', 'Participium praesentis odmienia się według III deklinacji: temat amant-.'),
    ('form', 'Bezokoliczniki', 'amāre', 'inf', 'amāre; amārī; amāvisse; amātus esse; amātūrus esse', 'Bezokoliczniki są potrzebne w składni accusativus cum infinitivo.'),
    ('conj', 'Strona bierna', 'amāre: praesens passivi', 'os', 'amor; amāris; amātur; amāmur; amāminī; amantur', 'Końcówki bierne: -r, -ris, -tur, -mur, -minī, -ntur.'),
    ('conj', 'Czas przyszły', 'amāre: futurum I', 'os', 'amābō; amābis; amābit; amābimus; amābitis; amābunt', 'I i II koniugacja: znak -b-.'),
    ('conj', 'Czas przyszły', 'legere: futurum I', 'os', 'legam; legēs; leget; legēmus; legētis; legent', 'III i IV koniugacja: -am, -ēs, -et.'),
    ('conj', 'Tryb łączący', 'amāre: coniūnctīvus praesentis', 'os', 'amem; amēs; amet; amēmus; amētis; ament', None),
    ('form', 'Stopniowanie nieregularne', 'Stopień wyższy', 'stopn', 'melior; peior; maior; minor; plūs', None),
    ('form', 'Stopniowanie nieregularne', 'Stopień najwyższy', 'stopn', 'optimus; pessimus; maximus; minimus; plūrimus', None),
    ('form', 'Typowe trudności', 'Która deklinacja?', 't_dekl', 'I; II; III; IV; V; III; II; IV', 'Patrz na dopełniacz: -ae (I), -ī (II), -is (III), -ūs (IV), -eī (V).'),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['puella', 'puellam', 'puellārum', 'puellās', 'puellā', 'puellīs'],
    't_m1': ['Puella puerum amat: kto kocha?', 'Puella puerum amat: kogo?', 'Puerum puella amat: kto kocha?', 'Puer puellam amat: kto kocha?', 'Puer puellam amat: kogo?', 'Puellam puer amat: kogo?'],
    't_m2': ['venit', 'vēnit', 'malum', 'mālum', 'liber', 'līber', 'populus', 'pōpulus'],
    't_m3': ['puellae', 'amīcī', 'amīcō', 'amīcīs', 'caelum', 'caela'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Jaki przypadek? (puella)', 't_m0', 'mianownik lp.; biernik lp.; dopełniacz lm.; biernik lm.; ablatyw lp.; celownik lub ablatyw lm.', 'Rolę słowa w zdaniu pokazuje końcówka, nie szyk.'),
    ('form', 'Typowe trudności', 'Kto kogo kocha?', 't_m1', 'puella; puerum; puella; puer; puellam; puellam', 'Szyk jest swobodny. -um i -am to biernik, czyli ten, kogo się kocha.'),
    ('form', 'Typowe trudności', 'Iloczas: co to znaczy?', 't_m2', 'przychodzi; przyszedł; zło; jabłko; książka; wolny; lud; topola', 'Długość samogłoski zmienia znaczenie.'),
    ('form', 'Typowe trudności', 'Ta sama końcówka: ile przypadków?', 't_m3', 'dopełniacz lp., celownik lp., mianownik lm.; dopełniacz lp., mianownik lm.; celownik lp., ablatyw lp.; celownik lm., ablatyw lm.; mianownik lp., biernik lp.; mianownik lm., biernik lm.', None),
]

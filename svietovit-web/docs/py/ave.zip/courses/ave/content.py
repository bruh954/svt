"""Treść kursu: łacina klasyczna dla Polaków.

Słowo:     (forma z iloczasem, znaczenie po polsku, polskie słowo z łaciny lub None, skojarzenie lub None)
Wymowa:    (litera lub dwuznak, jak czytać, przykład)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie)

Wymowa (pole „tr”) powstaje automatycznie w engine.py: wymowa klasyczna
zapisana po polsku, np. caelum → kajlum.
"""

UNITS = [
    # ---------------------------------------------------------------- wymowa
    {
        "id": "wymowa", "title": "Wymowa", "icon": "I", "track": "wymowa",
        "letters": [
            ("c", "[k]: Cicerō czytaj „Kikero”", "Cicerō"),
            ("v", "[w], jak angielskie w", "vīta"),
            ("ae", "[ae̯]: Caesar czytaj „Kajsar”", "Caesar"),
            ("oe", "[oe̯]: poena czytaj „pojna”", "poena"),
            ("qu", "[kʷ]: aqua czytaj „akwa”", "aqua"),
            ("ph", "[pʰ] (słowa z greki; później f)", "philosophia"),
            ("ch", "[kʰ] (słowa z greki)", "chorus"),
            ("i", "[i], a przed samogłoską [j]: iam czytaj „jam”", "iam"),
            ("ā", "[aː]: kreska oznacza tylko długość", "māter"),
            ("ti", "[ti], nigdy [ts]: nātiō", "nātiō"),
            ("s", "[s], nigdy [z]: rosa czytaj „rosa”", "rosa"),
            ("x", "[ks]: rēx czytaj „rēks”", "rēx"),
        ],
    },
    # ----------------------------------------------------------------- język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "II", "track": "jezyk", "requires": "wymowa",
        "words": [
            ("salvē", "witaj", "salwa", "Dosłownie „bądź zdrów”. Salwa honorowa to też pozdrowienie!"),
            ("valē", "żegnaj; bądź zdrów", None, "Rzymianie żegnali się życzeniem zdrowia."),
            ("ego", "ja", "ego; egoista", None),
            ("tū", "ty", "ty", None),
            ("et", "i", "et cetera", "Znak & to stylizowane „et”!"),
            ("nōn", "nie", "nonsens", None),
            ("sum", "jestem", "suma", None),
            ("es", "jesteś", None, None),
            ("est", "jest", "jest", "Prawie jak polskie „jest”: oba z tego samego praindoeuropejskiego słowa."),
            ("puer", "chłopiec", None, None),
            ("puella", "dziewczyna", None, None),
            ("amīcus", "przyjaciel", "amicus curiae", None),
            ("bonus", "dobry", "bonus", "Bonus to „coś dobrego” na dokładkę."),
            ("bona", "dobra", "bona (dobra, majątek)", None),
            ("magnus", "wielki", "magnat", None),
            ("magna", "wielka", "Magna Carta", None),
            ("Rōma", "Rzym", "romański", None),
        ],
        "sentences": [
            (["ego", "sum", "puer"], "Jestem chłopcem.",
             {"es": "es to „jesteś”. O sobie: sum (jestem).", "est": "est to „jest”. O sobie: sum."}),
            (["tū", "es", "puella"], "Jesteś dziewczyną.", {"sum": "sum to „jestem”. Do „ty”: es."}),
            (["amīcus", "bonus", "est"], "Przyjaciel jest dobry.",
             {"bona": "amīcus jest męski: bonus, jak „dobry”."}),
            (["Rōma", "magna", "est"], "Rzym jest wielki.",
             {"magnus": "Rōma jest rodzaju żeńskiego (jak „Roma”), więc magna."}),
            (["nōn", "sum", "magnus"], "Nie jestem wielki.", {}),
            (["puella", "bona", "est"], "Dziewczyna jest dobra.",
             {"bonus": "puella jest żeńska: bona, jak „dobra”."}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "III", "track": "jezyk",
        "words": [
            ("pater", "ojciec", "patron", None),
            ("māter", "matka", "matrona", None),
            ("fīlius", "syn", "filia (oddział)", "Filia to dosłownie „córka” firmy."),
            ("fīlia", "córka", "filia", None),
            ("frāter", "brat", "fraternizacja", None),
            ("soror", "siostra", None, None),
            ("vir", "mąż; mężczyzna", "wirtuoz", "Od vir pochodzi virtus: męstwo, cnota. Stąd „wirtuoz”."),
            ("fēmina", "kobieta", "feminizm", None),
            ("homō", "człowiek", "homo sapiens", None),
            ("dominus", "pan", "dominować", None),
            ("servus", "niewolnik; sługa", "serwus!", "„Serwus!” to dosłownie „(twój) sługa”."),
            ("meus", "mój", None, None),
            ("mea", "moja", None, None),
            ("tuus", "twój", None, None),
            ("tua", "twoja", None, None),
        ],
        "sentences": [
            (["pater", "meus", "bonus", "est"], "Mój ojciec jest dobry.",
             {"mea": "pater jest męski: meus (mój)."}),
            (["māter", "mea", "fēmina", "bona", "est"], "Moja matka jest dobrą kobietą.",
             {"meus": "māter jest żeńska: mea (moja)."}),
            (["frāter", "meus", "amīcus", "tuus", "est"], "Mój brat jest twoim przyjacielem.", {}),
            (["fīlia", "tua", "puella", "bona", "est"], "Twoja córka jest dobrą dziewczyną.",
             {"tuus": "fīlia jest żeńska: tua (twoja)."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "IV", "track": "jezyk",
        "words": [
            ("ūnus", "jeden", "unikat; unia", None),
            ("duo", "dwa", "duet", None),
            ("trēs", "trzy", "trio", None),
            ("quattuor", "cztery", "kwartet", None),
            ("quīnque", "pięć", "kwintet", None),
            ("sex", "sześć", "sekstet", None),
            ("septem", "siedem", "septyma", "Stąd angielski September: siódmy miesiąc dawnego kalendarza."),
            ("octō", "osiem", "oktawa", None),
            ("novem", "dziewięć", "nowenna", None),
            ("decem", "dziesięć", "decymetr", None),
            ("sunt", "są", None, None),
            ("puerī", "chłopcy · mianownik l.mn.", None, None),
        ],
        "sentences": [
            (["ūnus", "et", "ūnus", "sunt", "duo"], "Jeden i jeden to dwa.",
             {"est": "Podmiot w liczbie mnogiej: sunt (są)."}),
            (["septem", "et", "trēs", "sunt", "decem"], "Siedem i trzy to dziesięć.", {}),
            (["trēs", "puerī", "sunt"], "Jest trzech chłopców.",
             {"puer": "Trzech: liczba mnoga, puerī."}),
        ],
    },
    {
        "id": "swiat", "title": "Świat", "icon": "V", "track": "jezyk",
        "words": [
            ("terra", "ziemia", "teren; terytorium", None),
            ("terrā", "(na) ziemi · ablatyw", None, "Ablatyw: in terrā = na ziemi."),
            ("aqua", "woda", "akwarium", None),
            ("caelum", "niebo", None, "Stąd angielskie „celestial”, niebiański."),
            ("caelō", "(w) niebie · ablatyw", None, None),
            ("sōl", "słońce", "solarium", None),
            ("lūna", "księżyc", "lunatyk", "Lunatyk to ktoś, na kogo działa księżyc."),
            ("stella", "gwiazda", "konstelacja", None),
            ("via", "droga", "wiadukt", None),
            ("urbs", "miasto", "urbanistyka", None),
            ("silva", "las", "Sylwia", "Sylwia to „leśna”."),
            ("mare", "morze", "marynarz", None),
            ("vīta", "życie", "witamina", "Witamina = „amina życia”."),
            ("brevis", "krótki", "brewiarz", "Brewiarz to „skrócony” modlitewnik."),
            ("in", "w; na", "in plus", None),
        ],
        "sentences": [
            (["sōl", "in", "caelō", "est"], "Słońce jest na niebie.",
             {"caelum": "Gdzie? Po „in” ablatyw: caelō, jak polskie „na niebie”."}),
            (["aqua", "in", "terrā", "est"], "Woda jest na ziemi.",
             {"terra": "Gdzie? Ablatyw: terrā."}),
            (["vīta", "brevis", "est"], "Życie jest krótkie.", {}),
            (["Rōma", "urbs", "magna", "est"], "Rzym jest wielkim miastem.", {}),
        ],
    },
    {
        "id": "czas", "title": "Czasowniki", "icon": "VI", "track": "jezyk",
        "words": [
            ("amō", "kocham", "amator", "Amator to ten, kto „kocha” coś robić."),
            ("amat", "kocha", None, None),
            ("videō", "widzę", "wideo", None),
            ("videt", "widzi", None, None),
            ("legō", "czytam", "legenda", "Legenda = „to, co trzeba czytać”."),
            ("legit", "czyta", None, None),
            ("scrībō", "piszę", "skryba", None),
            ("scrībis", "piszesz", None, None),
            ("audiō", "słyszę", "audycja", None),
            ("labōrat", "pracuje", "laboratorium", None),
            ("quid", "co", None, None),
            ("liber", "książka", "libretto", None),
            ("librum", "książkę · biernik", None, "Biernik: co czytam? librum."),
            ("aquam", "wodę · biernik", None, None),
            ("Rōmam", "Rzym · biernik", None, None),
        ],
        "sentences": [
            (["ego", "librum", "legō"], "Czytam książkę.",
             {"legit": "legit to „czyta” (on). O sobie: legō, -ō jak polskie -ę.",
              "liber": "Co czytam? Biernik: librum."}),
            (["quid", "scrībis"], "Co piszesz?", {"scrībō": "Pytasz kogoś: scrībis (-s jak polskie -sz)."}),
            (["puella", "aquam", "videt"], "Dziewczyna widzi wodę.",
             {"aqua": "Co widzi? Biernik: aquam, jak polskie „wodę”.", "videō": "videō to „widzę”. Ona: videt."}),
            (["amō", "Rōmam"], "Kocham Rzym.", {"Rōma": "Co kocham? Biernik: Rōmam."}),
            (["pater", "labōrat"], "Ojciec pracuje.", {}),
        ],
    },
    {
        "id": "przypadki", "title": "Przypadki", "icon": "VII", "track": "jezyk",
        "words": [
            ("grātiās", "dzięki · biernik l.mn.", "gratis", "Gratis = „za dzięki”, czyli za darmo."),
            ("agō", "składam; robię", "agenda", None),
            ("Deus", "Bóg", None, None),
            ("Deō", "Bogu · celownik", None, None),
            ("domine", "Panie! · wołacz", None, "Wołacz od -us to -e, jak polskie „Panie!”."),
            ("amīce", "przyjacielu! · wołacz", None, None),
            ("Rōmae", "w Rzymie · miejscownik", None, "Dawny miejscownik nazw miast."),
            ("domī", "w domu · miejscownik", None, "Też dawny miejscownik."),
        ],
        "sentences": [
            (["grātiās", "agō"], "Dziękuję.", {}),
            (["Deō", "grātiās"], "Bogu dzięki.", {"Deus": "Komu? Celownik: Deō, jak „Bogu”."}),
            (["amīce", ",", "salvē"], "Witaj, przyjacielu!",
             {"amīcus": "Zwracasz się do kogoś: wołacz amīce, jak „przyjacielu!”."}),
            (["Rōmae", "sum"], "Jestem w Rzymie.", {"Rōma": "Gdzie? Rōmae (w Rzymie)."}),
            (["domī", "sum"], "Jestem w domu.", {}),
        ],
    },
    {
        "id": "perfekt", "title": "Czas przeszły", "icon": "VIII", "track": "jezyk",
        "words": [
            ("vēnī", "przyszedłem", None, "Perfekt: -ī = polskie -łem."),
            ("vīdī", "zobaczyłem", None, None),
            ("vīcī", "zwyciężyłem", "wiktoria", None),
            ("fuī", "byłem", None, None),
            ("erat", "był; była", None, None),
            ("dīxit", "powiedział", "dyktator", "Dyktator to ten, kto „mówi”, co robić."),
            ("scrīpsit", "napisał", "skrypt", None),
            ("Caesar", "Cezar", "cesarz", "Od imienia Cezara: cesarz, Kaiser, car."),
        ],
        "sentences": [
            (["vēnī", ",", "vīdī", ",", "vīcī"], "Przyszedłem, zobaczyłem, zwyciężyłem.", {}),
            (["Caesar", "dīxit"], "Cezar powiedział.", {}),
            (["Rōma", "magna", "erat"], "Rzym był wielki.", {"est": "W przeszłości: erat (był), nie est."}),
            (["puella", "librum", "scrīpsit"], "Dziewczyna napisała książkę.", {}),
            (["fuī", "Rōmae"], "Byłem w Rzymie.", {"sum": "W przeszłości: fuī (byłem)."}),
        ],
    },
    # -------------------------------------------------------------- sentencje
    {
        "id": "sent1", "title": "Sentencje I", "icon": "IX", "track": "sentencje", "requires": "czas",
        "words": [
            ("carpe", "chwytaj; zrywaj", None, "Dosłownie „zrywaj”, jak owoc."),
            ("diem", "dzień · biernik", "diariusz", "Diariusz = dziennik, od diēs (dzień)."),
            ("errāre", "błądzić", "errata", None),
            ("hūmānum", "ludzkie", "humanizm", None),
            ("mementō", "pamiętaj", "memento", None),
            ("morī", "umrzeć", "mór", "Pokrewne z „mors” (śmierć) i polskim „mór”, „umrzeć”."),
            ("cōgitō", "myślę", None, None),
            ("ergō", "więc", "ergo", None),
        ],
        "sentences": [
            (["carpe", "diem"], "Chwytaj dzień.", {}),
            (["errāre", "hūmānum", "est"], "Błądzić jest rzeczą ludzką.", {}),
            (["mementō", "morī"], "Pamiętaj o śmierci.", {}),
            (["cōgitō", ",", "ergō", "sum"], "Myślę, więc jestem.", {}),
        ],
    },
    {
        "id": "sent2", "title": "Sentencje II", "icon": "X", "track": "sentencje",
        "words": [
            ("per", "przez", "per procura", None),
            ("aspera", "trudności · biernik l.mn.", None, None),
            ("ad", "do", "adaptacja", None),
            ("astra", "gwiazdy · biernik l.mn.", "astronomia", None),
            ("ālea", "kostka do gry", None, None),
            ("iacta", "rzucona", None, None),
            ("vīnō", "(w) winie · ablatyw", "wino", None),
            ("vēritās", "prawda", "weryfikacja", None),
            ("tempus", "czas", "tempo", None),
            ("fugit", "ucieka", "fuga", "Fuga w muzyce to głosy, które „uciekają” jeden za drugim."),
            ("mēns", "umysł", "mentalny", None),
            ("sāna", "zdrowa", "sanatorium", None),
            ("corpore", "(w) ciele · ablatyw", "korporacja", None),
            ("sānō", "zdrowym · ablatyw", None, None),
        ],
        "sentences": [
            (["per", "aspera", "ad", "astra"], "Przez trudy do gwiazd.", {}),
            (["ālea", "iacta", "est"], "Kości zostały rzucone.", {}),
            (["in", "vīnō", "vēritās"], "W winie prawda.", {}),
            (["tempus", "fugit"], "Czas ucieka.", {}),
            (["mēns", "sāna", "in", "corpore", "sānō"], "W zdrowym ciele zdrowy duch.", {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "pater", "title": "Pater noster", "icon": "XI", "track": "teksty", "requires": "przypadki",
        "words": [
            ("noster", "nasz", None, None),
            ("quī", "który", None, None),
            ("caelīs", "niebiosach · ablatyw", None, None),
            ("sānctificētur", "niech się święci", "sanktuarium", None),
            ("nōmen", "imię", "nominacja", None),
            ("tuum", "twoje · mianownik n.", None, None),
            ("adveniat", "niech przyjdzie", "adwent", "Adwent = „przyjście”."),
            ("rēgnum", "królestwo", "regent", None),
            ("fīat", "niech się stanie", None, None),
            ("voluntās", "wola", "wolontariusz", None),
            ("sīcut", "jak; jako", None, None),
        ],
        "sentences": [
            (["pater", "noster", ",", "quī", "es", "in", "caelīs"], "Ojcze nasz, któryś jest w niebie.", {}),
            (["sānctificētur", "nōmen", "tuum"], "Święć się imię Twoje.", {}),
            (["adveniat", "rēgnum", "tuum"], "Przyjdź królestwo Twoje.", {}),
            (["fīat", "voluntās", "tua"], "Bądź wola Twoja.", {"tuum": "voluntās jest żeńska: tua."}),
            (["sīcut", "in", "caelō", "et", "in", "terrā"], "Jako w niebie, tak i na ziemi.", {}),
        ],
    },
    {
        "id": "gallia", "title": "Cezar: Galia", "icon": "XII", "track": "teksty",
        "words": [
            ("Gallia", "Galia", "galijski", None),
            ("Galliā", "(w) Galii · ablatyw", None, None),
            ("omnis", "cały; każdy", "omnibus", "Omnibus = „dla wszystkich”."),
            ("dīvīsa", "podzielona", "dywizja", None),
            ("partēs", "części · biernik l.mn.", "partia", None),
        ],
        "sentences": [
            (["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
             "Galia cała dzieli się na trzy części.", {}),
            (["Caesar", "in", "Galliā", "erat"], "Cezar był w Galii.", {"Gallia": "Gdzie? Ablatyw: in Galliā."}),
        ],
    },
]

TRACKS = {
    "wymowa": "WYMOWA",
    "jezyk": "LINGVA · JĘZYK",
    "sentencje": "SENTENTIAE · SENTENCJE",
    "teksty": "TEXTVS · TEKSTY",
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "wymowa": [
        {"title": "Rzymianie mówili „Kikero”",
         "text": "W szkole mówi się „Cyceron” i „Cezar”, ale Rzymianie czytali c zawsze jak k: "
                 "Kikero, Kajsar. Stąd niemieckie Kaiser. Kreska nad samogłoską (ā) to tylko "
                 "długość: wymawiasz ją dłużej, ale tak samo.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Znasz już łacinę",
         "text": "Bonus, magnat, ego, nonsens: polski jest pełen łaciny. Dobra wiadomość nr 2: "
                 "łacina, jak polski, nie ma przedimków (a, the). Mówisz po prostu „puer” = chłopiec.",
         "chain": [
             ("Jestem chłopcem.", ["ego", "sum", "puer"], "ego = ja (jak „egoista”), sum = jestem."),
             ("Jesteś dziewczyną.", ["tū", "es", "puella"], "Zmień osobę: tū, es."),
         ]},
        {"title": "Czasownik lubi koniec",
         "text": "Po polsku szyk jest swobodny i w łacinie też. Ale Rzymianie lubili stawiać "
                 "czasownik na końcu: „amīcus bonus est” = przyjaciel dobry jest. Rodzaj działa "
                 "jak w polskim: bonus (dobry), bona (dobra).",
         "chain": [
             ("Przyjaciel jest dobry.", ["amīcus", "bonus", "est"], "Rzecz, cecha, a est na końcu."),
             ("Rzym jest wielki.", ["Rōma", "magna", "est"], "Rōma jest żeńska, więc magna."),
         ]},
    ],
    "rodzina": [
        {"title": "Rodzaj zgadza się jak u nas",
         "text": "Polski i łacina tak samo dopasowują rodzaj: mój ojciec, moja matka = pater meus, "
                 "māter mea. Zaimek często stoi po rzeczowniku, jak w „Ojcze nasz”.",
         "chain": [
             ("Mój ojciec jest dobry.", ["pater", "meus", "bonus", "est"], "pater meus, potem cecha i est."),
             ("Moja matka jest dobrą kobietą.", ["māter", "mea", "fēmina", "bona", "est"],
              "Wszystko żeńskie: mea, bona."),
         ]},
    ],
    "liczby": [
        {"title": "Liczby znasz z muzyki",
         "text": "Duet, trio, kwartet, kwintet, oktawa, nowenna, decymetr. Wystarczy odciąć "
                 "polską końcówkę. A „są” to sunt: końcówka -nt oznacza „oni”.",
         "chain": [("Jeden i jeden to dwa.", ["ūnus", "et", "ūnus", "sunt", "duo"], "Podmiot mnogi: sunt.")]},
    ],
    "swiat": [
        {"title": "Ablatyw = miejscownik + narzędnik",
         "text": "Polski ma 7 przypadków, łacina 6. Prawie te same! Łaciński ablatyw robi to, co nasz "
                 "miejscownik i narzędnik: in terrā = na ziemi, in caelō = w niebie.",
         "chain": [
             ("Słońce jest na niebie.", ["sōl", "in", "caelō", "est"], "Gdzie? Które słowo pokazuje miejsce?"),
             ("Woda jest na ziemi.", ["aqua", "in", "terrā", "est"], "Na czym stoimy?"),
         ]},
    ],
    "czas": [
        {"title": "Osoba siedzi w końcówce",
         "text": "Jak po polsku, nie musisz mówić „ja”: legō = czytam. Końcówki nawet brzmią "
                 "podobnie: -ō (ja), -s (ty, jak -sz), -t (on). legō, legis, legit = czytam, czytasz, czyta.",
         "chain": [
             ("Czytam książkę.", ["ego", "librum", "legō"], "Kogo lub co dotyczy czynność, i kto ją wykonuje? Pomyśl o końcówkach."),
             ("Dziewczyna widzi wodę.", ["puella", "aquam", "videt"], "Kto widzi i co widzi? Szukaj końcówek."),
         ]},
    ],
    "przypadki": [
        {"title": "Wołacz: jak w polskim",
         "text": "Łacina, jak polski, ma wołacz: amīcus → amīce! (przyjacielu!), dominus → domine! "
                 "(Panie!). I celownik jak nasz: Deō = Bogu.",
         "chain": [
             ("Witaj, przyjacielu!", ["amīce", ",", "salvē"], "Do kogo mówię? Jak w polskim: przyjacielu!"),
             ("Bogu dzięki.", ["Deō", "grātiās"], "Komu dziękujemy? Jak po polsku: Bogu."),
         ]},
    ],
    "perfekt": [
        {"title": "-ī = -łem",
         "text": "Perfekt w 1. osobie kończy się na -ī: vēnī = przyszedłem, vīdī = zobaczyłem. "
                 "On/ona: -it (dīxit, scrīpsit). Cezar opisał całą wojnę jednym zdaniem.",
         "chain": [("Przyszedłem, zobaczyłem, zwyciężyłem.", ["vēnī", ",", "vīdī", ",", "vīcī"], "Cezar mówi o sobie w czasie przeszłym. Jak kończą się trzy czasowniki?")]},
    ],
    "sent1": [
        {"title": "Sentencje: łacina, którą już cytujesz",
         "text": "Carpe diem, memento mori, cogito ergo sum. Znasz te zdania, teraz zrozumiesz każde "
                 "słowo. diem to biernik od diēs (dzień): chwytaj co? dzień.",
         "chain": [("Chwytaj dzień.", ["carpe", "diem"], "Co chwytamy? Skojarz diem z „dziennik”.")]},
    ],
    "sent2": [
        {"title": "Dosłownie i swobodnie",
         "text": "„Mens sana in corpore sano” po polsku mówimy na odwrót: w zdrowym ciele zdrowy "
                 "duch. Łacina stawia słowa tam, gdzie chce podkreślić, bo końcówki i tak mówią, co do czego pasuje.",
         "chain": [("Przez trudy do gwiazd.", ["per", "aspera", "ad", "astra"], "przez … do …: dwa przyimki, każdy z rzeczownikami, które znasz z „aspera” i „astra”.")]},
    ],
    "pater": [
        {"title": "Modlitwę już znasz",
         "text": "„Ojcze nasz” po polsku przetłumaczono z łaciny, stąd stary szyk: „święć się imię "
                 "Twoje”. sānctificētur = niech się święci (pokrewne z „sanktuarium”).",
         "chain": [("Przyjdź królestwo Twoje.", ["adveniat", "rēgnum", "tuum"],
                    "adveniat (adwent!) + rēgnum (regent) + tuum.")]},
    ],
    "gallia": [
        {"title": "Pierwsze zdanie Cezara",
         "text": "Tak zaczynają się „Notatki o wojnie galijskiej”, na których uczyły się pokolenia "
                 "uczniów. Gallia est omnis dīvīsa in partēs trēs. Znasz już wszystkie słowa!",
         "chain": [("Galia cała dzieli się na trzy części.",
                    ["Gallia", "est", "omnis", "dīvīsa", "in", "partēs", "trēs"],
                    "dīvīsa: dywizja. partēs: partia. Reszta jest już znana.")]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Końcówka mówi wszystko",
    "text": "W polskim „widzę dziewczynę”, a nie „widzę dziewczyna”. W łacinie tak samo: puellam. "
            "Końcówka mówi, kto co robi i komu. Gdy wahasz się, zadaj pytanie jak na lekcji polskiego: "
            "kto? co? komu? gdzie?",
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("puella ", "bon", "a", "", ["us", "a", "um", "ī"], "dobra dziewczyna", "Żeńska: -a, jak „dobra”.", "slowa"),
    ("puer ", "bon", "us", "", ["us", "a", "um", "ae"], "dobry chłopiec", "Męski: -us.", "slowa"),
    ("Rōma ", "magn", "a", " est", ["us", "a", "um", "ī"], "Rzym jest wielki", "Rōma jest żeńska: magna.", "slowa"),
    ("māter ", "me", "a", "", ["us", "a", "um", "ae"], "moja matka", "Matka jest żeńska: mea.", "rodzina"),
    ("pater ", "me", "us", "", ["us", "a", "um", "ae"], "mój ojciec", "Ojciec jest męski: meus.", "rodzina"),
    ("fīlia ", "tu", "a", "", ["us", "a", "um", "ī"], "twoja córka", "Żeńska: tua.", "rodzina"),
    ("ūnus et ūnus ", "su", "nt", " duo", ["m", "s", "t", "nt"], "są dwa", "„Są” = sunt: -nt to „oni”.", "liczby"),
    ("in ", "terr", "ā", "", ["a", "ā", "am", "ae"], "na ziemi", "Gdzie? Ablatyw: terrā.", "swiat"),
    ("sōl in ", "cael", "ō", " est", ["um", "ō", "ī", "us"], "słońce jest na niebie", "Ablatyw od caelum: caelō.", "swiat"),
    ("ego librum ", "leg", "ō", "", ["ō", "is", "it", "unt"], "czytam", "Ja: -ō, jak polskie -ę.", "czas"),
    ("tū librum ", "leg", "is", "", ["ō", "is", "it", "unt"], "czytasz", "Ty: -is, jak polskie -sz.", "czas"),
    ("puella aquam ", "vid", "et", "", ["eō", "ēs", "et", "ent"], "ona widzi", "On/ona: -t.", "czas"),
    ("amō ", "Rōm", "am", "", ["a", "ae", "am", "ā"], "kocham Rzym", "Co kocham? Biernik: -am (jak „Romę”).", "czas"),
    ("ego ", "libr", "um", " legō", ["um", "ī", "ō", "er"], "czytam książkę", "Co czytam? Biernik: librum.", "czas"),
    ("", "De", "ō", " grātiās", ["us", "ō", "um", "e"], "Bogu dzięki", "Komu? Celownik: Deō.", "przypadki"),
    ("", "amīc", "e", ", salvē!", ["us", "e", "ī", "um"], "przyjacielu, witaj!", "Wołacz od -us: -e.", "przypadki"),
    ("", "Rōm", "ae", " sum", ["a", "ae", "am", "ā"], "jestem w Rzymie", "Gdzie? Rōmae (dawny miejscownik).", "przypadki"),
    ("", "vēn", "ī", ", vīdī, vīcī", ["ī", "it", "iō", "imus"], "przyszedłem", "Perfekt, ja: -ī = -łem.", "perfekt"),
    ("Caesar ", "dīx", "it", "", ["ī", "it", "imus", "ērunt"], "Cezar powiedział", "On: -it.", "perfekt"),
    ("errāre ", "hūmān", "um", " est", ["us", "a", "um", "ī"], "błądzić jest rzeczą ludzką",
     "Bezokolicznik jest nijaki: -um.", "sent1"),
    ("mēns ", "sān", "a", "", ["us", "a", "um", "ō"], "zdrowy umysł", "mēns jest żeńska: sāna.", "sent2"),
    ("sānctificētur nōmen ", "tu", "um", "", ["us", "a", "um", "ae"], "imię twoje", "nōmen jest nijakie: tuum.", "pater"),
]

# Kolory: długie samogłoski w kolorze brązu, żeby iloczas był widoczny.
LONG_VOWELS = "āēīōūȳĀĒĪŌŪ"

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "forum", "title": "Na Forum", "partner": "Marek", "avatar": "M", "requires": "slowa",
        "turns": [
            {"bot": ["salvē", "!"], "en": "Witaj!",
             "options": [(["salvē", "!"], True, None),
                         (["valē", "!"], False, "valē to „żegnaj”. Dopiero się spotkaliście!")]},
            {"bot": ["quis", "es", "?"], "en": "Kim jesteś?",
             "options": [(["amīcus", "sum"], True, None),
                         (["amīcus", "es"], False, "es to „jesteś”. O sobie: sum (jestem)."),
                         (["amīcus", "est"], False, "est to „jest”. O sobie: sum.")]},
            {"bot": ["Rōma", "magna", "est", "!"], "en": "Rzym jest wielki!",
             "options": [(["ita", ",", "Rōma", "magna", "est"], True, None),
                         (["ita", ",", "Rōma", "magnus", "est"], False, "Rōma jest żeńska: magna, nie magnus.")]},
            {"bot": ["valē", "!"], "en": "Żegnaj!", "build": (["valē"], "Żegnaj!")},
        ],
    },
    {
        "id": "dom", "title": "W domu", "partner": "Julia", "avatar": "I", "requires": "rodzina",
        "turns": [
            {"bot": ["estne", "pater", "tuus", "bonus", "?"], "en": "Czy twój ojciec jest dobry?",
             "options": [(["pater", "meus", "bonus", "est"], True, None),
                         (["pater", "tuus", "bonus", "est"], False, "tuus to „twój”. Mówisz o swoim ojcu: meus."),
                         (["pater", "mea", "bona", "est"], False, "pater jest męski: meus, bonus.")],
             "note": "-ne na końcu słowa robi z niego pytanie, jak polskie „czy”."},
            {"bot": ["et", "māter", "tua", "?"], "en": "A twoja matka?",
             "build": (["māter", "mea", "bona", "est"], "Moja matka jest dobra.")},
        ],
    },
    {
        "id": "schola", "title": "W szkole", "partner": "Magister", "avatar": "G", "requires": "przypadki",
        "turns": [
            {"bot": ["quid", "legis", "?"], "en": "Co czytasz?",
             "options": [(["librum", "legō"], True, None),
                         (["librum", "legit"], False, "legit to „czyta” (on). O sobie: legō."),
                         (["liber", "legō"], False, "Co czytasz? Biernik: librum.")]},
            {"bot": ["quid", "scrībis", "?"], "en": "Co piszesz?",
             "build": (["librum", "scrībō"], "Piszę książkę.")},
            {"bot": ["bene", "!"], "en": "Dobrze!",
             "options": [(["grātiās", "agō"], True, None),
                         (["Deō", "grātiās"], False, "To „Bogu dzięki”. Nauczycielowi powiedz po prostu „dziękuję”.")]},
        ],
    },
    {
        "id": "caesar", "title": "U Cezara", "partner": "Cezar", "avatar": "C", "requires": "perfekt",
        "turns": [
            {"bot": ["quid", "fēcistī", "?"], "en": "Co zrobiłeś?",
             "options": [(["vēnī", ",", "vīdī", ",", "vīcī"], True, None),
                         (["veniō", ",", "videō", ",", "vincō"], False,
                          "To czas teraźniejszy. Pyta, co zrobiłeś: perfekt vēnī, vīdī, vīcī.")]},
            {"bot": ["ubi", "fuistī", "?"], "en": "Gdzie byłeś?",
             "build": (["fuī", "Rōmae"], "Byłem w Rzymie.")},
            {"bot": ["bene", "!", "valē", "!"], "en": "Dobrze! Żegnaj!",
             "options": [(["valē", ",", "Caesar"], True, None),
                         (["salvē", ",", "Caesar"], False, "salvē to powitanie. Teraz się żegnasz: valē.")]},
        ],
    },
]

CHAT_EXTRA = {
    "quis": "kto", "ita": "tak", "estne": "czy jest", "legis": "czytasz", "bene": "dobrze",
    "fēcistī": "zrobiłeś", "ubi": "gdzie", "fuistī": "byłeś", "veniō": "przychodzę", "vincō": "zwyciężam",
    "quid": "co", "vīs": "chcesz", "volō": "chcę", "habēs": "masz", "habeō": "mam", "habet": "ma", "venīs": "przychodzisz", "quaeris": "szukasz", "quaerō": "szukam", "quem": "kogo", "mercātōrem": "kupca", "dīcunt": "mówią", "mīlitēs": "żołnierze", "fūr": "złodziej", "fūrem": "złodzieja", "audit": "słucha", "prope": "blisko", "ī": "idź", "venit": "przychodzi", "iūdex": "sędzia", "vidēre": "widzieć", "epistulam": "list", "vocat": "woła", "mē": "mnie", "tē": "ciebie", "tibi": "tobie", "mihi": "mi", "gladium": "miecz", "dō": "daję", "nōmen": "imię", "brevis": "krótki", "Mārcī": "Marka", "Mārcum": "Marka", "Mārcus": "Marek", "Lūcius": "Lucjusz", "Lūcī": "Lucjuszu", "peregrīnus": "obcy", "frātrem": "brata", "pecūniam": "pieniądze", "aquam": "wodę", "carcere": "w więzieniu", "carcerem": "do więzienia", "barbam": "brodę", "magnam": "dużą", "parvam": "małą", "festīnā": "spiesz się", "ibi": "tam", "līber": "wolny", "erit": "będzie", "bibit": "pije", "ecce": "oto", "nox": "noc", "amīce": "przyjacielu", "agis": "robisz", "esne": "czy jesteś", "amāsne": "czy kochasz", "mercātor": "kupiec", "mīles": "żołnierz", "tū": "ty", "hīc": "tutaj", "tuus": "twój",
    "bonum": "dobre", "dīc": "mów", "eum": "go", "meam": "moje",
}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Larpy: sceny ze stawką. Węzeł: bot (tokeny), pl (tłumaczenie) oraz
#   options: [(tokeny, "good" | "weak" | "bad", następny węzeł lub None, komentarz)]  albo
#   build: (tokeny, polecenie po polsku), next: następny węzeł
# deadly: True = pytanie „jedna szansa" (zła odpowiedź kończy scenę). Węzeł z end: True kończy scenę.
# ---------------------------------------------------------------------------
LARP_EXTRA = {"agis": "robisz", "esne": "czy jesteś", "amāsne": "czy kochasz", "mīles": "żołnierz"}

LARPS = [
    {'id': 'porta',
     'title': 'Rzym: w poszukiwaniu brata',
     'partner': 'Mīles',
     'avatar': 'M',
     'requires': 'przypadki',
     'fee': 15,
     'patience': 3,
     'story': True,
     'scene': 'List od brata Marka był krótki: „Przyjdź do Rzymu. Mam kłopoty.” Stoisz przed bramą miasta, a żołnierz przy bramie nie wpuszcza '
              'byle kogo.',
     'goal': 'Odnajdź brata i uwolnij go, zanim zapadnie noc.',
     'endings': {'win': 'Strażnik odsuwa włócznię. Wchodzisz do Rzymu jak przyjaciel. Gdzieś w tym mieście Marek czeka na pomoc.',
                 'partial': 'Strażnik w końcu cię wpuszcza, ale patrzy podejrzliwie. Wszedłeś, lecz bez nagrody.',
                 'fail': 'Strażnik traci cierpliwość i przepędza cię spod bramy.'},
     'levels': [{'title': 'Brama Rzymu',
                 'partner': 'Mīles',
                 'avatar': 'M',
                 'desc': 'Strażnik nie wpuszcza byle kogo. Wejdź do miasta.',
                 'scene': 'List od brata Marka był krótki: „Przyjdź do Rzymu. Mam kłopoty.” Stoisz przed bramą miasta, a żołnierz przy bramie '
                          'nie wpuszcza byle kogo.',
                 'goal': 'Przekonaj strażnika i wejdź do Rzymu.',
                 'start': 'a',
                 'patience': 3,
                 'endings': {'win': 'Strażnik odsuwa włócznię. Wchodzisz do Rzymu jak przyjaciel. Gdzieś w tym mieście Marek czeka na pomoc.',
                             'partial': 'Strażnik w końcu cię wpuszcza, ale patrzy podejrzliwie. Wszedłeś, lecz bez nagrody.',
                             'fail': 'Strażnik traci cierpliwość i przepędza cię spod bramy.'},
                 'nodes': {'a': {'bot': ['salvē', '!', 'quis', 'es', '?'],
                                 'pl': 'Witaj! Kim jesteś?',
                                 'options': [(['salvē', ',', 'domine', '!', 'amīcus', 'sum'], 'good', 'b', None),
                                             (['salvē', '!', 'amīcus', 'sum'],
                                              'weak',
                                              'a2',
                                              'Poprawnie, ale bez „domine” brzmi to poufale. Strażnik robi się podejrzliwy.'),
                                             (['valē', '!', 'amīcus', 'es'],
                                              'bad',
                                              None,
                                              'valē to pożegnanie, a es znaczy „jesteś”. O sobie: sum.')]},
                           'a2': {'bot': ['amīcus', '?', 'esne', 'servus', '?'],
                                  'pl': 'Przyjaciel? Jesteś niewolnikiem?',
                                  'build': (['servus', 'nōn', 'sum'], 'Powiedz: Nie jestem niewolnikiem.'),
                                  'next': 'b',
                                  'why': '„Nie jestem” to nōn sum; przeczenie stoi przed czasownikiem.'},
                           'b': {'bot': ['quid', 'Rōmae', 'agis', '?'],
                                 'pl': 'Co robisz w Rzymie?',
                                 'options': [(['frāter', 'meus', 'Rōmae', 'est'], 'good', 'c', None),
                                             (['Rōmam', 'videō'], 'weak', 'b2', 'Zdanie jest poprawne, ale to żaden powód. Strażnik dopytuje.'),
                                             (['frāter', 'tuus', 'Rōmae', 'est'],
                                              'bad',
                                              None,
                                              'tuus to „twój”. Mówisz o swoim bracie: meus.')]},
                           'b2': {'bot': ['Rōma', 'magna', 'est', '.', 'quis', 'Rōmae', 'est', '?'],
                                  'pl': 'Rzym jest wielki. Kto jest w Rzymie?',
                                  'build': (['frāter', 'meus', 'Rōmae', 'est'], 'Powiedz: Mój brat jest w Rzymie.'),
                                  'next': 'c',
                                  'why': '„W Rzymie” to Rōmae (miejscownik), a „mój” przy bracie to meus.'},
                           'c': {'bot': ['estne', 'frāter', 'tuus', 'vir', 'bonus', '?'],
                                 'pl': 'Czy twój brat jest dobrym człowiekiem?',
                                 'build': (['ita', ',', 'vir', 'bonus', 'est'], 'Powiedz: Tak, jest dobrym człowiekiem.'),
                                 'next': 'd',
                                 'why': '„Tak” to ita; „jest dobrym mężem” to vir bonus est.'},
                           'd': {'bot': ['amāsne', 'Rōmam', '?'],
                                 'pl': 'Czy kochasz Rzym?',
                                 'deadly': True,
                                 'options': [(['Rōmam', 'amō', '!'], 'good', 'e', None),
                                             (['Rōmam', 'nōn', 'amō'], 'bad', None, 'Gramatycznie dobrze, ale strażnikowi tego się nie mówi.'),
                                             (['Rōma', 'amat'], 'bad', None, 'To znaczy „Rzym kocha”. „Kocham Rzym” to Rōmam amō.')]},
                           'e': {'bot': ['bene', '!', 'valē', ',', 'amīce', '!'],
                                 'pl': 'Dobrze! Bywaj, przyjacielu!',
                                 'build': (['grātiās', 'agō', ',', 'domine'], 'Podziękuj strażnikowi (panie).'),
                                 'next': 'end',
                                 'why': '„Dziękuję” to grātiās agō, a do strażnika zwracasz się domine.'},
                           'end': {'bot': ['valē', '!'], 'pl': 'Bywaj!', 'end': True}}},
                {'title': 'Taberna',
                 'partner': 'Caupō',
                 'avatar': 'C',
                 'desc': 'W tawernie przy Forum dowiesz się, gdzie jest Marek.',
                 'scene': 'Jesteś głodny, a w tawernie przy Forum siedzi karczmarz, który zna całe miasto. Ktoś tu musi wiedzieć, gdzie jest '
                          'twój brat.',
                 'goal': 'Zamów wino, a potem dowiedz się od karczmarza, gdzie jest Marek.',
                 'start': 'a',
                 'patience': 4,
                 'endings': {'win': 'Karczmarz klepie cię po ramieniu i wskazuje drogę do więzienia. Czas ucieka, a noc coraz bliżej.',
                             'partial': 'Dowiedziałeś się, gdzie jest brat, ale karczmarz patrzył na ciebie krzywo.',
                             'fail': 'Karczmarz traci cierpliwość i wyrzuca cię na ulicę.'},
                 'nodes': {'a': {'bot': ['salvē', ',', 'hospes', '!', 'quid', 'vīs', '?'],
                                 'pl': 'Witaj, gościu! Czego chcesz?',
                                 'options': [(['vīnum', 'et', 'aquam', 'volō'], 'good', 'b', None),
                                             (['vīnum'], 'weak', 'a2', 'Zrozumiałe, ale karczmarz woli pełne zdanie: vīnum volō.'),
                                             (['vīnum', 'vīs'], 'bad', None, 'vīs to „chcesz”. O sobie: volō.')]},
                           'a2': {'bot': ['vīnum', '?', 'quid', 'vīs', '?'],
                                  'pl': 'Wino? Czego chcesz?',
                                  'build': (['vīnum', 'volō'], 'Powiedz: Chcę wino.'),
                                  'next': 'b',
                                  'why': '„Chcę” to volō (vīs znaczy „chcesz”).'},
                           'b': {'bot': ['bene', '!', 'vīnum', 'bonum', 'est', '.', 'habēs', 'pecūniam', '?'],
                                 'pl': 'Dobrze! Wino jest dobre. Masz pieniądze?',
                                 'options': [(['ita', ',', 'pecūniam', 'habeō'], 'good', 'c', None),
                                             (['ita', ',', 'pecūnia', 'habeō'],
                                              'bad',
                                              None,
                                              '„Mam pieniądze”: pieniądze to dopełnienie, więc biernik: pecūniam habeō.'),
                                             (['nōn', 'habeō'],
                                              'bad',
                                              None,
                                              'Bez pieniędzy karczmarz cię wyrzuci. Masz pieniądze: pecūniam habeō.')]},
                           'c': {'bot': ['quis', 'es', '?', 'unde', 'venīs', '?'],
                                 'pl': 'Kim jesteś? Skąd przybywasz?',
                                 'build': (['peregrīnus', 'sum', ',', 'frātrem', 'quaerō'], 'Powiedz: Jestem obcym, szukam brata.'),
                                 'next': 'd',
                                 'why': 'Szukać kogoś: quaerō + biernik, więc frātrem (od frāter).'},
                           'd': {'bot': ['quem', 'quaeris', '?'],
                                 'pl': 'Kogo szukasz?',
                                 'options': [(['Mārcum', 'mercātōrem', 'quaerō'], 'good', 'e', None),
                                             (['frātrem', 'quaerō'],
                                              'weak',
                                              'e',
                                              'Poprawnie, ale karczmarz nie wie, o kogo chodzi. Lepiej podać imię.'),
                                             (['Mārcus', 'mercātor', 'quaerō'],
                                              'bad',
                                              None,
                                              'Szukasz kogoś: dopełnienie w bierniku. Mārcum mercātōrem quaerō.')]},
                           'e': {'bot': ['Mārcum', '?', 'Mārcus', 'in', 'carcere', 'est', '!'],
                                 'pl': 'Marka? Marek jest w więzieniu!',
                                 'options': [(['in', 'carcere', '?', 'cūr', '?'], 'good', 'f', None),
                                             (['in', 'carcerem', '?', 'cūr', '?'],
                                              'bad',
                                              None,
                                              '„W więzieniu” (gdzie?): in + ablatyw, więc in carcere. In carcerem znaczyłoby „do '
                                              'więzienia”.')]},
                           'f': {'bot': ['mīlitēs', 'dīcunt', ':', 'Mārcus', 'fūr', 'est', '.'],
                                 'pl': 'Żołnierze mówią: Marek jest złodziejem.',
                                 'build': (['Mārcus', 'fūr', 'nōn', 'est', '!'], 'Powiedz: Marek nie jest złodziejem!'),
                                 'next': 'g',
                                 'why': '„Nie jest” to nōn est; przeczenie stoi przed czasownikiem.'},
                           'g': {'bot': ['iūdex', 'nōn', 'audit', '.'],
                                 'pl': 'Sędzia nie słucha.',
                                 'build': (['ubi', 'est', 'carcer', '?'], 'Zapytaj: Gdzie jest więzienie?'),
                                 'next': 'h',
                                 'why': '„Gdzie jest” to ubi est.'},
                           'h': {'bot': ['carcer', 'prope', 'forum', 'est', '.', 'ī', 'celeriter', '!', 'nox', 'venit', '.'],
                                 'pl': 'Więzienie jest blisko forum. Idź szybko! Noc nadchodzi.',
                                 'build': (['grātiās', 'agō', ',', 'hospes', '!'], 'Podziękuj karczmarzowi.'),
                                 'next': 'end',
                                 'why': 'Dziękuję: grātiās agō.'},
                           'end': {'bot': ['valē', '!'], 'pl': 'Bywaj!', 'end': True}}},
                {'title': 'Więzienie',
                 'partner': 'Custōs',
                 'avatar': 'K',
                 'desc': 'Strażnik nie wpuści cię do brata za nic. Jeden zły ruch kończy scenę.',
                 'scene': 'Przed więzieniem stoi strażnik. Bez jego zgody nie zobaczysz brata, a on nie lubi nikogo, kto próbuje go przekupić.',
                 'goal': 'Przekonaj strażnika, żeby wpuścił cię do brata.',
                 'start': 'a',
                 'patience': 3,
                 'endings': {'win': 'Strażnik wręcza ci klucz i otwiera furtkę. Idziesz korytarzem do celi brata.',
                             'partial': 'Strażnik wpuszcza cię niechętnie i dyszy ci w kark.',
                             'fail': 'Strażnik woła wartę. Odprowadzają cię spod murów więzienia.'},
                 'nodes': {'a': {'bot': ['quis', 'es', '?', 'quid', 'hīc', 'quaeris', '?'],
                                 'pl': 'Kim jesteś? Czego tu szukasz?',
                                 'options': [(['frāter', 'Mārcī', 'sum', '.', 'eum', 'vidēre', 'volō'], 'good', 'b', None),
                                             (['Mārcum', 'volō'],
                                              'weak',
                                              'a2',
                                              'Zrozumiałe, ale strażnik chce wiedzieć, kim jesteś: frāter Mārcī sum.'),
                                             (['Mārcus', 'sum', '!'],
                                              'bad',
                                              None,
                                              'Mārcus to twój brat, a nie ty. „Brat Marka” to frāter Mārcī.')]},
                           'a2': {'bot': ['quis', 'es', '?'],
                                  'pl': 'Kim jesteś?',
                                  'build': (['frāter', 'Mārcī', 'sum'], 'Powiedz: Jestem bratem Marka.'),
                                  'next': 'b',
                                  'why': '„Brat Marka”: Mārcī to dopełniacz (czyj?).'},
                           'b': {'bot': ['quid', 'habēs', '?'],
                                 'pl': 'Co masz przy sobie?',
                                 'deadly': True,
                                 'options': [(['epistulam', 'habeō', '.', 'Mārcus', 'mē', 'vocat'], 'good', 'c', None),
                                             (['pecūniam', 'tibi', 'dō', '!'],
                                              'bad',
                                              None,
                                              'Przekupstwo strażnika to zły pomysł: zawoła wartę. Pokaż list: epistulam.'),
                                             (['gladium', 'habeō', '!'],
                                              'bad',
                                              None,
                                              'Miecz? Strażnik chwyta za włócznię. Masz list: epistulam.')]},
                           'c': {'bot': ['quod', 'tibi', 'nōmen', 'est', '?'],
                                 'pl': 'Jak masz na imię?',
                                 'build': (['Lūcius', 'mihi', 'nōmen', 'est'], 'Powiedz: Mam na imię Lucjusz.'),
                                 'next': 'd',
                                 'alts': [['nōmen', 'mihi', 'Lūcius', 'est']],
                                 'why': '„Mam na imię” to mihi nōmen est (dosłownie „imię jest mi”).'},
                           'd': {'bot': ['bene', ',', 'Lūcī', '.', 'ecce', 'clāvis', '!', 'hōra', 'brevis', 'est', '.'],
                                 'pl': 'Dobrze, Lucjuszu. Oto klucz! Czas jest krótki.',
                                 'build': (['grātiās', 'agō', ',', 'domine'], 'Podziękuj strażnikowi.'),
                                 'next': 'end',
                                 'why': 'Dziękuję: grātiās agō, a do strażnika: domine.'},
                           'end': {'bot': ['ī', '!'], 'pl': 'Idź!', 'end': True}}},
                {'title': 'Cela',
                 'partner': 'Mārcus',
                 'avatar': 'M',
                 'desc': 'Marek wie, jak wygląda prawdziwy złodziej. Zapamiętaj.',
                 'scene': 'W ciemnej celi siedzi Marek. Masz niewiele czasu, a on zna prawdziwego złodzieja. Zapamiętaj, co powie.',
                 'goal': 'Dowiedz się od brata, jak wygląda prawdziwy złodziej.',
                 'start': 'a',
                 'patience': 3,
                 'endings': {'win': 'Marek ściska cię przez kraty. Wiesz już, kogo szukać na forum.',
                             'partial': 'Marek opowiedział ci wszystko, ale nie jesteś pewny, co zapamiętałeś.',
                             'fail': 'Strażnik wypędza cię z celi, zanim Marek skończył mówić.'},
                 'nodes': {'a': {'bot': ['frāter', '!', 'tū', 'hīc', 'es', '?'],
                                 'pl': 'Bracie! Ty tutaj?',
                                 'options': [(['ita', ',', 'tē', 'quaerō', '!'], 'good', 'b', None),
                                             (['ita', '!'], 'weak', 'a2', 'Za mało. Powiedz, po co przyszedłeś.'),
                                             (['ita', ',', 'tū', 'quaerō', '!'],
                                              'bad',
                                              None,
                                              'Szukasz kogoś: biernik. „Ciebie” to tē, a nie tū.')]},
                           'a2': {'bot': ['quid', 'agis', '?'],
                                  'pl': 'Co tu robisz?',
                                  'build': (['tē', 'quaerō', '!'], 'Powiedz: Szukam ciebie!'),
                                  'next': 'b',
                                  'why': '„Ciebie” w bierniku to tē.'},
                           'b': {'bot': ['fūr',
                                         'nōn',
                                         'sum',
                                         '!',
                                         'fūr',
                                         'pecūniam',
                                         'meam',
                                         'habet',
                                         '.',
                                         'vir',
                                         'est',
                                         '.',
                                         'barbam',
                                         'magnam',
                                         'habet',
                                         '.'],
                                 'pl': 'Nie jestem złodziejem! Złodziej ma moje pieniądze. To mężczyzna. Ma dużą brodę.',
                                 'options': [(['fūr', 'barbam', 'magnam', 'habet'], 'good', 'c', None),
                                             (['fūr', 'barbam', 'parvam', 'habet'],
                                              'bad',
                                              None,
                                              'Marek powiedział: barbam magnam, czyli „dużą brodę”. Parvam to „małą”.')]},
                           'c': {'bot': ['festīnā', 'ad', 'forum', '!', 'iūdex', 'ibi', 'est', '.'],
                                 'pl': 'Spiesz się na forum! Sędzia jest tam.',
                                 'build': (['ad', 'forum', 'veniō', '!'], 'Powiedz: Idę na forum!'),
                                 'next': 'd',
                                 'why': 'Kierunek (dokąd?): ad + biernik, więc ad forum.'},
                           'd': {'bot': ['valē', ',', 'frāter', '!', 'festīnā', '!'],
                                 'pl': 'Bywaj, bracie! Spiesz się!',
                                 'build': (['valē', ',', 'frāter', '!'], 'Pożegnaj brata.'),
                                 'next': 'end',
                                 'why': '„Bywaj” to valē, a „bracie” to frāter (wołacz jest taki sam jak mianownik).'},
                           'end': {'bot': ['bene', '!'], 'pl': 'Dobrze!', 'end': True}}},
                {'title': 'Forum',
                 'partner': 'Iūdex',
                 'avatar': 'I',
                 'desc': 'Jedna szansa: wskaż prawdziwego złodzieja.',
                 'scene': 'Zapada zmierzch. Na Forum czeka sędzia, a on słucha tylko dobrych argumentów. Masz jedną szansę, żeby wskazać '
                          'prawdziwego złodzieja.',
                 'goal': 'Uwolnij brata: wskaż sędziemu prawdziwego złodzieja.',
                 'start': 'a',
                 'patience': 3,
                 'endings': {'win': 'Sędzia wskazuje człowieka z wielką brodą. Marek jest wolny! Razem wychodzicie z Forum w blasku zachodu '
                                    'słońca.',
                             'partial': 'Sędzia uwalnia Marka, choć wciąż ma wątpliwości co do ciebie.',
                             'fail': 'Sędzia wskazuje niewłaściwego człowieka. Marek zostaje w więzieniu. Spróbuj jeszcze raz.'},
                 'nodes': {'a': {'bot': ['quis', 'es', '?', 'cūr', 'hīc', 'es', '?'],
                                 'pl': 'Kim jesteś? Dlaczego tu jesteś?',
                                 'options': [(['frāter', 'Mārcī', 'sum', '.', 'Mārcus', 'fūr', 'nōn', 'est', '!'], 'good', 'b', None),
                                             (['Mārcus', 'fūr', 'nōn', 'est'], 'weak', 'a2', 'Zbyt krótko. Sędzia chce wiedzieć, kim jesteś.'),
                                             (['Mārcus', 'fūr', 'est', '!'],
                                              'bad',
                                              None,
                                              'To znaczy „Marek jest złodziejem”. Broń brata: fūr nōn est.')]},
                           'a2': {'bot': ['quis', 'es', '?'],
                                  'pl': 'Kim jesteś?',
                                  'build': (['frāter', 'Mārcī', 'sum'], 'Powiedz: Jestem bratem Marka.'),
                                  'next': 'b',
                                  'why': '„Brat Marka”: Mārcī to dopełniacz (czyj?).'},
                           'b': {'bot': ['bene', '.', 'quis', 'fūr', 'est', '?', 'dīc', '!'],
                                 'pl': 'Dobrze. Kto jest złodziejem? Mów!',
                                 'deadly': True,
                                 'options': [(['fūr', 'barbam', 'magnam', 'habet'], 'good', 'c', None),
                                             (['fūr', 'barbam', 'parvam', 'habet'],
                                              'bad',
                                              None,
                                              'Marek mówił w celi o dużej brodzie: barbam magnam. Parvam to „małą”.'),
                                             (['fūr', 'barbam', 'nōn', 'habet'],
                                              'bad',
                                              None,
                                              'Złodziej ma brodę, i to dużą: barbam magnam habet.')]},
                           'c': {'bot': ['bene', '!', 'fūr', 'in', 'carcere', 'erit', '.', 'Mārcus', 'līber', 'est', '!'],
                                 'pl': 'Dobrze! Złodziej trafi do więzienia. Marek jest wolny!',
                                 'build': (['grātiās', 'agō', ',', 'iūdex', '!'], 'Podziękuj sędziemu.'),
                                 'next': 'end',
                                 'why': 'Dziękuję: grātiās agō, a do sędziego: iūdex.'},
                           'end': {'bot': ['valē', ',', 'amīce', '!'], 'pl': 'Bywaj, przyjacielu!', 'end': True}}}]}
]


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['ego', 'tū', 'is/ea', 'nōs', 'vōs', 'eī/eae'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'ablatyw lp.', 'wołacz lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.', 'ablatyw lm.'],
    'przyp5': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'ablatyw'],
    'part': ['participium praesentis activi', 'participium perfecti passivi', 'participium futuri activi', 'gerundivum'],
    'inf': ['īnfīnītīvus praesentis activi', 'īnfīnītīvus praesentis passivi', 'īnfīnītīvus perfecti activi', 'īnfīnītīvus perfecti passivi', 'īnfīnītīvus futuri activi'],
    'stopn': ['bonus', 'malus', 'magnus', 'parvus', 'multus'],
    't_dekl': ['rosa, rosae', 'dominus, dominī', 'rēx, rēgis', 'manus, manūs', 'rēs, reī', 'corpus, corporis', 'ager, agrī', 'cornū, cornūs'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'amāre (kochać): I koniugacja', 'os', 'amō; amās; amat; amāmus; amātis; amant', 'Końcówki osobowe: -ō, -s, -t, -mus, -tis, -nt.'),
    ('conj', 'Wzory koniugacji', 'vidēre (widzieć): II koniugacja', 'os', 'videō; vidēs; videt; vidēmus; vidētis; vident', None),
    ('conj', 'Wzory koniugacji', 'legere (czytać): III koniugacja', 'os', 'legō; legis; legit; legimus; legitis; legunt', 'III koniugacja: krótkie -i-, w 3. osobie lm. -unt.'),
    ('conj', 'Wzory koniugacji', 'audīre (słyszeć): IV koniugacja', 'os', 'audiō; audīs; audit; audīmus; audītis; audiunt', None),
    ('conj', 'Wyjątki', 'capere (chwytać): III koniugacja na -iō', 'os', 'capiō; capis; capit; capimus; capitis; capiunt', 'Jak legere, ale z -i- w 1. osobie lp. i 3. osobie lm.'),
    ('conj', 'Czasowniki nieregularne', 'esse (być)', 'os', 'sum; es; est; sumus; estis; sunt', None),
    ('conj', 'Czasowniki nieregularne', 'posse (móc)', 'os', 'possum; potes; potest; possumus; potestis; possunt', 'pot- + esse: przed s powstaje poss-.'),
    ('conj', 'Czasowniki nieregularne', 'velle (chcieć)', 'os', 'volō; vīs; vult; volumus; vultis; volunt', None),
    ('conj', 'Czasowniki nieregularne', 'īre (iść)', 'os', 'eō; īs; it; īmus; ītis; eunt', None),
    ('conj', 'Czasowniki nieregularne', 'ferre (nieść)', 'os', 'ferō; fers; fert; ferimus; fertis; ferunt', None),
    ('conj', 'Czas przeszły', 'amāre: imperfectum', 'os', 'amābam; amābās; amābat; amābāmus; amābātis; amābant', 'Znak czasu -bā- + końcówki -m, -s, -t.'),
    ('conj', 'Czas przeszły', 'amāre: perfectum', 'os', 'amāvī; amāvistī; amāvit; amāvimus; amāvistis; amāvērunt', 'Końcówki perfectum: -ī, -istī, -it, -imus, -istis, -ērunt.'),
    ('conj', 'Czas przeszły', 'esse: perfectum', 'os', 'fuī; fuistī; fuit; fuimus; fuistis; fuērunt', None),
    ('decl', 'Wzory deklinacji', 'puella (dziewczyna): I deklinacja', 'przyp', 'puella; puellae; puellae; puellam; puellā; puella; puellae; puellārum; puellīs; puellās; puellīs', None),
    ('decl', 'Wzory deklinacji', 'amīcus (przyjaciel): II deklinacja', 'przyp', 'amīcus; amīcī; amīcō; amīcum; amīcō; amīce; amīcī; amīcōrum; amīcīs; amīcōs; amīcīs', 'Jedyna deklinacja z osobnym wołaczem: amīce.'),
    ('decl', 'Wzory deklinacji', 'caelum (niebo): II deklinacja, nijaki', 'przyp', 'caelum; caelī; caelō; caelum; caelō; caelum; caela; caelōrum; caelīs; caela; caelīs', 'Nijakie: mianownik = biernik, w lm. na -a.'),
    ('decl', 'Wzory deklinacji', 'homō (człowiek): III deklinacja', 'przyp', 'homō; hominis; hominī; hominem; homine; homō; hominēs; hominum; hominibus; hominēs; hominibus', 'Temat widać dopiero w dopełniaczu: homin-.'),
    ('decl', 'Wzory deklinacji', 'nōmen (imię): III deklinacja, nijaki', 'przyp', 'nōmen; nōminis; nōminī; nōmen; nōmine; nōmen; nōmina; nōminum; nōminibus; nōmina; nōminibus', None),
    ('decl', 'Wzory deklinacji', 'manus (ręka): IV deklinacja', 'przyp', 'manus; manūs; manuī; manum; manū; manus; manūs; manuum; manibus; manūs; manibus', None),
    ('decl', 'Wzory deklinacji', 'diēs (dzień): V deklinacja', 'przyp', 'diēs; diēī; diēī; diem; diē; diēs; diēs; diērum; diēbus; diēs; diēbus', None),
    ('decl', 'Wyjątki', 'puer (chłopiec)', 'przyp', 'puer; puerī; puerō; puerum; puerō; puer; puerī; puerōrum; puerīs; puerōs; puerīs', 'II deklinacja bez -us w mianowniku.'),
    ('decl', 'Wyjątki', 'mare (morze)', 'przyp', 'mare; maris; marī; mare; marī; mare; maria; marium; maribus; maria; maribus', 'Temat na -i: ablatyw -ī, lm. -ia, -ium.'),
    ('decl', 'Wyjątki', 'deus (bóg)', 'przyp', 'deus; deī; deō; deum; deō; deus; dī; deōrum; dīs; deōs; dīs', 'Wołacz = mianownik; w lm. formy ściągnięte dī, dīs.'),
    ('decl', 'Zaimki', 'ego (ja)', 'przyp5', 'ego; meī; mihi; mē; mē', None),
    ('decl', 'Zaimki', 'tū (ty)', 'przyp5', 'tū; tuī; tibi; tē; tē', None),
    ('form', 'Imiesłowy', 'amāre (kochać)', 'part', 'amāns; amātus; amātūrus; amandus', '-ns: kochający; -tus: kochany; -tūrus: mający kochać; -ndus: ten, którego należy kochać.'),
    ('form', 'Imiesłowy', 'vidēre (widzieć)', 'part', 'vidēns; vīsus; vīsūrus; videndus', None),
    ('form', 'Imiesłowy', 'legere (czytać)', 'part', 'legēns; lēctus; lēctūrus; legendus', None),
    ('form', 'Imiesłowy', 'audīre (słyszeć)', 'part', 'audiēns; audītus; audītūrus; audiendus', None),
    ('form', 'Imiesłowy', 'capere (chwytać)', 'part', 'capiēns; captus; captūrus; capiendus', None),
    ('decl', 'Imiesłowy: odmiana', 'amāns (kochający)', 'przyp5', 'amāns; amantis; amantī; amantem; amante', 'Participium praesentis odmienia się według III deklinacji: temat amant-.'),
    ('form', 'Bezokoliczniki', 'amāre', 'inf', 'amāre; amārī; amāvisse; amātus esse; amātūrus esse', 'Bezokoliczniki są potrzebne w składni accusativus cum infinitivo.'),
    ('conj', 'Strona bierna', 'amāre: praesens passivi', 'os', 'amor; amāris; amātur; amāmur; amāminī; amantur', 'Końcówki bierne: -r, -ris, -tur, -mur, -minī, -ntur.'),
    ('conj', 'Czas przyszły', 'amāre: futurum I', 'os', 'amābō; amābis; amābit; amābimus; amābitis; amābunt', 'I i II koniugacja: znak -b-.'),
    ('conj', 'Czas przyszły', 'legere: futurum I', 'os', 'legam; legēs; leget; legēmus; legētis; legent', 'III i IV koniugacja: -am, -ēs, -et.'),
    ('conj', 'Tryb łączący', 'amāre: coniūnctīvus praesentis', 'os', 'amem; amēs; amet; amēmus; amētis; ament', None),
    ('form', 'Stopniowanie nieregularne', 'Stopień wyższy', 'stopn', 'melior; peior; maior; minor; plūs', None),
    ('form', 'Stopniowanie nieregularne', 'Stopień najwyższy', 'stopn', 'optimus; pessimus; maximus; minimus; plūrimus', None),
    ('form', 'Typowe trudności', 'Która deklinacja?', 't_dekl', 'I; II; III; IV; V; III; II; IV', 'Patrz na dopełniacz: -ae (I), -ī (II), -is (III), -ūs (IV), -eī (V).'),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['puella', 'puellam', 'puellārum', 'puellās', 'puellā', 'puellīs'],
    't_m1': ['Puella puerum amat: kto kocha?', 'Puella puerum amat: kogo?', 'Puerum puella amat: kto kocha?', 'Puer puellam amat: kto kocha?', 'Puer puellam amat: kogo?', 'Puellam puer amat: kogo?'],
    't_m2': ['venit', 'vēnit', 'malum', 'mālum', 'liber', 'līber', 'populus', 'pōpulus'],
    't_m3': ['puellae', 'amīcī', 'amīcō', 'amīcīs', 'caelum', 'caela'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Jaki przypadek? (puella)', 't_m0', 'mianownik lp.; biernik lp.; dopełniacz lm.; biernik lm.; ablatyw lp.; celownik lub ablatyw lm.', 'Rolę słowa w zdaniu pokazuje końcówka, nie szyk.'),
    ('form', 'Typowe trudności', 'Kto kogo kocha?', 't_m1', 'puella; puerum; puella; puer; puellam; puellam', 'Szyk jest swobodny. -um i -am to biernik, czyli ten, kogo się kocha.'),
    ('form', 'Typowe trudności', 'Iloczas: co to znaczy?', 't_m2', 'przychodzi; przyszedł; zło; jabłko; książka; wolny; lud; topola', 'Długość samogłoski zmienia znaczenie.'),
    ('form', 'Typowe trudności', 'Ta sama końcówka: ile przypadków?', 't_m3', 'dopełniacz lp., celownik lp., mianownik lm.; dopełniacz lp., mianownik lm.; celownik lp., ablatyw lp.; celownik lm., ablatyw lm.; mianownik lp., biernik lp.; mianownik lm., biernik lm.', None),
]


# Z czego składają się słowa (pokazywane na karcie nowego słowa)
PARTS = {
    "adveniat": "ad (do) + veniat (niech przyjdzie; venīre = iść, przychodzić) → „niech przyjdzie”",
    "sānctificētur": "sānctus (święty) + -ficāre (czynić) + -ētur (strona bierna) → „niech będzie uświęcone”",
    "voluntās": "vol- (chcieć, jak w velle) + -tās (końcówka rzeczowników abstrakcyjnych) → „wola”",
    "rēgnum": "rēg- (król, rządzić; jak w rēx) + -num (końcówka rzeczownika) → „królestwo”",
    "vēritās": "vērus (prawdziwy) + -tās (końcówka rzeczowników abstrakcyjnych) → „prawda”",
    "amīcus": "am- (kochać; jak w amāre) + -īcus (końcówka przymiotników) → „ktoś kochany”, przyjaciel",
    "cōgitō": "co- (razem) + agitāre (poruszać) → „poruszam myśli razem”",
    "mementō": "meminisse (pamiętać) + -tō (końcówka rozkazu) → „pamiętaj!”",
    "hūmānum": "hūm- (człowiek; jak w homō) + -ānum (dotyczący) → „ludzki”",
    "sīcut": "sīc (tak) + ut (jak) → „tak jak”",
    "grātiās": "grātus (miły, wdzięczny) + -ia → grātia (łaska, wdzięczność)",
}

# === PRONOUNS (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /PRONOUNS ===

# === STOPNIOWANIE (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('form', 'Stopniowanie', 'bonus (dobry)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'bonus; melior; optimus', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'magnus (wielki)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'magnus; maior; maximus', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'parvus (mały)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'parvus; minor; minimus', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'malus (zły)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'malus; peior; pessimus', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'multus (liczny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'multus; plus; plurimus', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'altus (wysoki)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'altus; altior; altissimus', 'Regularne: -ior, -issimus.'),
    ('form', 'Stopniowanie', 'longus (długi)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'longus; longior; longissimus', None),
    ('form', 'Stopniowanie', 'pulcher (piękny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'pulcher; pulchrior; pulcherrimus', 'Przymiotniki na -er: -errimus.'),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /STOPNIOWANIE ===

# === SŁOWNICTWO (generowane z langs/vocab, nie edytuj ręcznie) ===
UNITS += [{'id': 'v01a', 'title': 'Ludzie 1', 'icon': 'L', 'track': 'jezyk', 'words': [('mulier', 'kobieta', None, 'rodzaj żeński'), ('īnfāns', 'dziecko', None, 'rodzaj męski'), ('iuvenis', 'chłopiec (młodzieniec)', None, 'rodzaj męski'), ('virgō', 'dziewczynka', None, 'rodzaj żeński'), ('hominēs', 'człowiek (istota)', None, None), ('familia', 'rodzina', None, 'rodzaj żeński'), ('parentēs', 'rodzice', None, None), ('avus', 'dziadek', None, 'rodzaj męski'), ('avia', 'babcia', None, 'rodzaj żeński'), ('nepōs', 'wnuk', None, 'rodzaj męski'), ('avunculus', 'wuj', None, 'rodzaj męski'), ('amita', 'ciotka', None, 'rodzaj żeński'), ('cōnsōbrīnus', 'kuzyn', None, 'rodzaj męski'), ('marītus', 'mąż (małżonek)', None, 'rodzaj męski'), ('uxor', 'żona', None, 'rodzaj żeński'), ('amīca', 'przyjaciel (bliski)', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v01b', 'title': 'Ludzie 2', 'icon': 'L', 'track': 'jezyk', 'words': [('vīcīnus', 'sąsiad', None, 'rodzaj męski'), ('hospes', 'gość', None, 'rodzaj męski'), ('praefectus', 'szef', None, 'rodzaj męski'), ('socius', 'towarzysz', None, 'rodzaj męski'), ('hostis', 'wróg', None, 'rodzaj męski'), ('rēx', 'król', None, 'rodzaj męski'), ('rēgīna', 'królowa', None, 'rodzaj żeński'), ('imperātor', 'władca', None, 'rodzaj męski'), ('cīvis', 'obywatel', None, 'rodzaj męski'), ('dux', 'wódz', None, 'rodzaj męski'), ('hērōs', 'bohater', None, 'rodzaj męski'), ('sacerdōs', 'kapłan', None, 'rodzaj męski'), ('sacerdōtissa', 'kapłanka', None, 'rodzaj żeński'), ('poēta', 'poeta', None, 'rodzaj męski'), ('philosophus', 'filozof', None, 'rodzaj męski'), ('magister', 'nauczyciel', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01c', 'title': 'Ludzie 3', 'icon': 'L', 'track': 'jezyk', 'words': [('discipulus', 'uczeń', None, 'rodzaj męski'), ('medicus', 'lekarz', None, 'rodzaj męski'), ('mīles', 'żołnierz', None, 'rodzaj męski'), ('agricola', 'rolnik', None, 'rodzaj męski'), ('mercātor', 'kupiec', None, 'rodzaj męski'), ('nauta', 'żeglarz', None, 'rodzaj męski'), ('vēnātor', 'myśliwy', None, 'rodzaj męski'), ('artifex', 'rzemieślnik', None, 'rodzaj męski'), ('pāstor', 'pasterz', None, 'rodzaj męski'), ('iūdex', 'sędzia', None, 'rodzaj męski'), ('senātor', 'senator', None, 'rodzaj męski'), ('cōnsul', 'konsul', None, 'rodzaj męski'), ('serva', 'niewolnica', None, 'rodzaj żeński'), ('lībertus', 'wyzwoleniec', None, 'rodzaj męski'), ('herus', 'pan (właściciel)', None, 'rodzaj męski'), ('peregrīnus', 'obcy', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01d', 'title': 'Ludzie 4', 'icon': 'L', 'track': 'jezyk', 'words': [('senex', 'starzec', None, 'rodzaj męski'), ('anus', 'staruszka', None, 'rodzaj żeński'), ('adulēscēns', 'młodzieniec', None, 'rodzaj męski'), ('māterfamiliās', 'matka rodziny', None, 'rodzaj żeński'), ('paterfamiliās', 'ojciec rodziny', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v02a', 'title': 'Ciało 1', 'icon': 'C', 'track': 'jezyk', 'words': [('caput', 'głowa', None, 'rodzaj nijaki'), ('faciēs', 'twarz', None, 'rodzaj żeński'), ('oculus', 'oko', None, 'rodzaj męski'), ('auris', 'ucho', None, 'rodzaj żeński'), ('nāsus', 'nos', None, 'rodzaj męski'), ('ōs', 'usta', None, 'rodzaj nijaki'), ('dēns', 'ząb', None, 'rodzaj męski'), ('lingua', 'język (narząd)', None, 'rodzaj żeński'), ('capillus', 'włosy', None, 'rodzaj męski'), ('collum', 'szyja', None, 'rodzaj nijaki'), ('bracchium', 'ramię', None, 'rodzaj nijaki'), ('manus', 'ręka', None, 'rodzaj żeński'), ('digitus', 'palec', None, 'rodzaj męski'), ('pēs', 'noga', None, 'rodzaj męski'), ('planta', 'stopa', None, 'rodzaj żeński'), ('genū', 'kolano', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v02b', 'title': 'Ciało 2', 'icon': 'C', 'track': 'jezyk', 'words': [('tergum', 'plecy', None, 'rodzaj nijaki'), ('venter', 'brzuch', None, 'rodzaj męski'), ('cor', 'serce', None, 'rodzaj nijaki'), ('sanguis', 'krew', None, 'rodzaj męski'), ('os', 'kość', None, 'rodzaj nijaki'), ('cutis', 'skóra', None, 'rodzaj żeński'), ('vōx', 'głos', None, 'rodzaj żeński'), ('corpus', 'ciało', None, 'rodzaj nijaki'), ('stomachus', 'żołądek', None, 'rodzaj męski'), ('barba', 'broda', None, 'rodzaj żeński'), ('labrum', 'warga', None, 'rodzaj nijaki'), ('unguis', 'paznokieć', None, 'rodzaj męski'), ('pectus', 'pierś', None, 'rodzaj nijaki'), ('cerebrum', 'mózg', None, 'rodzaj nijaki'), ('cubitum', 'łokieć', None, 'rodzaj nijaki'), ('frōns', 'czoło', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v02c', 'title': 'Ciało 3', 'icon': 'C', 'track': 'jezyk', 'words': [('gena', 'policzek', None, 'rodzaj żeński'), ('mentum', 'podbródek', None, 'rodzaj nijaki'), ('calx', 'pięta', None, 'rodzaj żeński'), ('cauda', 'ogon', None, 'rodzaj żeński'), ('āla', 'skrzydło', None, 'rodzaj żeński'), ('cornū', 'róg', None, 'rodzaj nijaki'), ('iecur', 'wątroba', None, 'rodzaj nijaki'), ('pulmō', 'płuco', None, 'rodzaj męski'), ('sūdor', 'pot', None, 'rodzaj męski'), ('lacrima', 'łza', None, 'rodzaj żeński'), ('cervix', 'kark', None, 'rodzaj żeński'), ('sinistra', 'lewa ręka', None, 'rodzaj żeński'), ('dextra', 'prawa ręka', None, 'rodzaj żeński'), ('vēna', 'żyła', None, 'rodzaj żeński'), ('adeps', 'tłuszcz', None, 'rodzaj męski'), ('rēn', 'nerka', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v02d', 'title': 'Ciało 4', 'icon': 'C', 'track': 'jezyk', 'words': [('linguae', 'język (mowa)', None, None)], 'sentences': []}, {'id': 'v03a', 'title': 'Jedzenie 1', 'icon': 'J', 'track': 'jezyk', 'words': [('pānis', 'chleb', None, 'rodzaj męski'), ('būtȳrum', 'masło', None, 'rodzaj nijaki'), ('cāseus', 'ser', None, 'rodzaj męski'), ('lac', 'mleko', None, 'rodzaj nijaki'), ('ōvum', 'jajko', None, 'rodzaj nijaki'), ('carō', 'mięso', None, 'rodzaj żeński'), ('piscis', 'ryba', None, 'rodzaj męski'), ('pullus', 'kurczak', None, 'rodzaj męski'), ('porcīna', 'wieprzowina', None, 'rodzaj żeński'), ('iūs', 'zupa', None, 'rodzaj nijaki'), ('acētāria', 'sałatka', None, 'rodzaj żeński'), ('puls', 'kasza', None, 'rodzaj żeński'), ('farīna', 'mąka', None, 'rodzaj żeński'), ('caepa', 'cebula', None, 'rodzaj żeński'), ('allium', 'czosnek', None, 'rodzaj nijaki'), ('mālum', 'jabłko', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v03b', 'title': 'Jedzenie 2', 'icon': 'J', 'track': 'jezyk', 'words': [('pirum', 'gruszka', None, 'rodzaj nijaki'), ('ūva', 'winogrono', None, 'rodzaj żeński'), ('ficus', 'figa', None, 'rodzaj żeński'), ('oliva', 'oliwka', None, 'rodzaj żeński'), ('nux', 'orzech', None, 'rodzaj żeński'), ('saccharum', 'cukier', None, 'rodzaj nijaki'), ('sāl', 'sól', None, 'rodzaj męski'), ('piper', 'pieprz', None, 'rodzaj nijaki'), ('oleum', 'olej', None, 'rodzaj nijaki'), ('mel', 'miód', None, 'rodzaj nijaki'), ('vīnum', 'wino', None, 'rodzaj nijaki'), ('acētum', 'ocet', None, 'rodzaj nijaki'), ('ientāculum', 'śniadanie', None, 'rodzaj nijaki'), ('prandium', 'obiad', None, 'rodzaj nijaki'), ('cēna', 'kolacja', None, 'rodzaj żeński'), ('convīvium', 'uczta', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v03c', 'title': 'Jedzenie 3', 'icon': 'J', 'track': 'jezyk', 'words': [('famēs', 'głód', None, 'rodzaj żeński'), ('cibus', 'jedzenie', None, 'rodzaj męski'), ('alimentum', 'pożywienie', None, 'rodzaj nijaki'), ('placenta', 'ciasto', None, 'rodzaj żeński'), ('pīsum', 'groch', None, 'rodzaj nijaki'), ('faba', 'bób', None, 'rodzaj żeński'), ('brassica', 'kapusta', None, 'rodzaj żeński'), ('lactūca', 'sałata', None, 'rodzaj żeński'), ('cucumis', 'ogórek', None, 'rodzaj męski'), ('cucurbita', 'dynia', None, 'rodzaj żeński'), ('prūnum', 'śliwka', None, 'rodzaj nijaki'), ('cerasum', 'wiśnia', None, 'rodzaj nijaki'), ('persicum', 'brzoskwinia', None, 'rodzaj nijaki'), ('mālum grānātum', 'granat', None, 'rodzaj nijaki'), ('pinguedō', 'tłuszcz', None, 'rodzaj żeński'), ('botulus', 'kiełbasa', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03d', 'title': 'Jedzenie 4', 'icon': 'J', 'track': 'jezyk', 'words': [('perna', 'szynka', None, 'rodzaj żeński'), ('sanguīnārius', 'krew (potrawa)', None, 'rodzaj męski'), ('pulmentum', 'owsianka', None, 'rodzaj nijaki'), ('cāseus ovillus', 'ser owczy', None, 'rodzaj męski'), ('ōva frixa', 'jajecznica', None, None), ('ferīna', 'dziczyzna', None, 'rodzaj żeński'), ('būbula', 'wołowina', None, 'rodzaj żeński'), ('ovilla', 'baranina', None, 'rodzaj żeński'), ('harenga', 'śledź', None, 'rodzaj żeński'), ('ostrea', 'ostryga', None, 'rodzaj żeński'), ('assum', 'mięso z grilla', None, 'rodzaj nijaki'), ('garum', 'sos rybny', None, 'rodzaj nijaki'), ('mulsum', 'miód pitny', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v04a', 'title': 'Napoje i stół 1', 'icon': 'N', 'track': 'jezyk', 'words': [('aquae', 'woda (czysta)', None, None), ('pōtiō', 'napój', None, 'rodzaj żeński'), ('pōculum', 'szklanka', None, 'rodzaj nijaki'), ('calix', 'kielich', None, 'rodzaj męski'), ('scyphus', 'kubek', None, 'rodzaj męski'), ('patera', 'miska', None, 'rodzaj żeński'), ('catīnus', 'talerz', None, 'rodzaj męski'), ('culter', 'nóż', None, 'rodzaj męski'), ('cochlear', 'łyżka', None, 'rodzaj nijaki'), ('urceus', 'dzban', None, 'rodzaj męski'), ('amphora', 'amfora', None, 'rodzaj żeński'), ('ahēnum', 'kocioł', None, 'rodzaj nijaki'), ('mēnsa', 'stół', None, 'rodzaj żeński'), ('triclīnium', 'łoże biesiadne', None, 'rodzaj nijaki'), ('sitis', 'pragnienie', None, 'rodzaj żeński'), ('sitiēns', 'spragniony', None, None)], 'sentences': []}, {'id': 'v04b', 'title': 'Napoje i stół 2', 'icon': 'N', 'track': 'jezyk', 'words': [('ēsuriēns', 'głodny', None, None), ('ēbrius', 'pijany', None, None), ('sapidus', 'smaczny', None, None), ('vīnum temperātum', 'wino rozcieńczone', None, 'rodzaj nijaki'), ('cervisia', 'piwo', None, 'rodzaj żeński'), ('lac caprīnum', 'mleko kozie', None, 'rodzaj nijaki'), ('prōsit', 'zdrowie (toast)', None, None), ('convīva', 'gospodarz uczty', None, 'rodzaj męski'), ('taberna', 'szynk', None, 'rodzaj żeński'), ('caupōna', 'karczma', None, 'rodzaj żeński'), ('minister', 'kelner', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v05a', 'title': 'Dom 1', 'icon': 'D', 'track': 'jezyk', 'words': [('domus', 'dom', None, 'rodzaj żeński'), ('habitātiō', 'mieszkanie', None, 'rodzaj żeński'), ('cubiculum', 'pokój', None, 'rodzaj nijaki'), ('culīna', 'kuchnia', None, 'rodzaj żeński'), ('balneum', 'łazienka', None, 'rodzaj nijaki'), ('ātrium', 'salon', None, 'rodzaj nijaki'), ('hortus', 'ogród', None, 'rodzaj męski'), ('iānua', 'drzwi', None, 'rodzaj żeński'), ('porta', 'brama', None, 'rodzaj żeński'), ('fenestra', 'okno', None, 'rodzaj żeński'), ('pariēs', 'ściana', None, 'rodzaj męski'), ('mūrus', 'mur', None, 'rodzaj męski'), ('pavīmentum', 'podłoga', None, 'rodzaj nijaki'), ('tēctum', 'dach', None, 'rodzaj nijaki'), ('scālae', 'schody', None, 'rodzaj żeński'), ('clāvis', 'klucz', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v05b', 'title': 'Dom 2', 'icon': 'D', 'track': 'jezyk', 'words': [('sera', 'zamek', None, 'rodzaj żeński'), ('tabula', 'stół', None, 'rodzaj żeński'), ('sella', 'krzesło', None, 'rodzaj żeński'), ('lectus', 'łóżko', None, 'rodzaj męski'), ('armārium', 'szafa', None, 'rodzaj nijaki'), ('lucerna', 'lampa', None, 'rodzaj żeński'), ('tapēte', 'dywan', None, 'rodzaj nijaki'), ('speculum', 'lustro', None, 'rodzaj nijaki'), ('sōlārium', 'zegar słoneczny', None, 'rodzaj nijaki'), ('pulvīnus', 'poduszka', None, 'rodzaj męski'), ('strāgulum', 'koc', None, 'rodzaj nijaki'), ('sapō', 'mydło', None, 'rodzaj męski'), ('fornāx', 'piec', None, 'rodzaj żeński'), ('puteus', 'studnia', None, 'rodzaj męski'), ('focus', 'ogień (ognisko)', None, 'rodzaj męski'), ('lūmen', 'światło', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v05c', 'title': 'Dom 3', 'icon': 'D', 'track': 'jezyk', 'words': [('fūmus', 'dym', None, 'rodzaj męski'), ('cinis', 'popiół', None, 'rodzaj męski'), ('vestibulum', 'wejście', None, 'rodzaj nijaki'), ('columna', 'kolumna', None, 'rodzaj żeński'), ('peristȳlium', 'dziedziniec', None, 'rodzaj nijaki'), ('bibliothēca', 'biblioteka domowa', None, 'rodzaj żeński'), ('hōrreum', 'spichlerz', None, 'rodzaj nijaki'), ('stabulum', 'stajnia', None, 'rodzaj nijaki'), ('bovīle', 'obora', None, 'rodzaj nijaki'), ('villa', 'willa', None, 'rodzaj żeński'), ('fundus', 'farma', None, 'rodzaj męski'), ('saepēs', 'płot', None, 'rodzaj żeński'), ('stillicidium', 'rynna', None, 'rodzaj nijaki'), ('trabs', 'belka', None, 'rodzaj żeński'), ('later', 'cegła', None, 'rodzaj męski'), ('caementum', 'cement', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v05d', 'title': 'Dom 4', 'icon': 'D', 'track': 'jezyk', 'words': [('lapis', 'kamień', None, 'rodzaj męski'), ('marmor', 'marmur', None, 'rodzaj nijaki'), ('candēla', 'świeca', None, 'rodzaj żeński'), ('taeda', 'pochodnia', None, 'rodzaj żeński'), ('situla', 'wiadro', None, 'rodzaj żeński'), ('corbis', 'kosz', None, 'rodzaj męski'), ('arca', 'skrzynia', None, 'rodzaj żeński'), ('cista', 'szkatułka', None, 'rodzaj żeński'), ('supellex', 'mebel', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v06a', 'title': 'Ubrania 1', 'icon': 'U', 'track': 'jezyk', 'words': [('vestis', 'ubranie', None, 'rodzaj żeński'), ('toga', 'toga', None, 'rodzaj żeński'), ('tunica', 'tunika', None, 'rodzaj żeński'), ('pallium', 'płaszcz', None, 'rodzaj nijaki'), ('sagum', 'płaszcz wojskowy', None, 'rodzaj nijaki'), ('solea', 'sandał', None, 'rodzaj żeński'), ('calceus', 'but', None, 'rodzaj męski'), ('pīleus', 'czapka', None, 'rodzaj męski'), ('petasus', 'kapelusz', None, 'rodzaj męski'), ('manicae', 'rękawice', None, 'rodzaj żeński'), ('cingulum', 'pas', None, 'rodzaj nijaki'), ('fībula', 'broszka', None, 'rodzaj żeński'), ('ānulus', 'pierścień', None, 'rodzaj męski'), ('torquēs', 'naszyjnik', None, 'rodzaj męski'), ('armilla', 'bransoleta', None, 'rodzaj żeński'), ('textum', 'tkanina', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v06b', 'title': 'Ubrania 2', 'icon': 'U', 'track': 'jezyk', 'words': [('lāna', 'wełna', None, 'rodzaj żeński'), ('līnum', 'len', None, 'rodzaj nijaki'), ('sērica', 'jedwab', None, 'rodzaj nijaki'), ('corium', 'skóra (wyprawiona)', None, 'rodzaj nijaki'), ('vēlum', 'welon', None, 'rodzaj nijaki'), ('strophium', 'szal', None, 'rodzaj nijaki'), ('subligāculum', 'bielizna', None, 'rodzaj nijaki'), ('camīsia', 'koszula', None, 'rodzaj żeński'), ('collāre', 'kołnierz', None, 'rodzaj nijaki'), ('manica', 'rękaw', None, 'rodzaj żeński'), ('paenula', 'pelerynka', None, 'rodzaj żeński'), ('toga pulla', 'szata żałobna', None, 'rodzaj żeński'), ('purpura', 'purpura', None, 'rodzaj żeński'), ('corōna', 'korona', None, 'rodzaj żeński'), ('serta', 'wieniec', None, 'rodzaj nijaki'), ('fascia', 'zwój (ubraniowy)', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v06c', 'title': 'Ubrania 3', 'icon': 'U', 'track': 'jezyk', 'words': [('stola', 'sukienka', None, 'rodzaj żeński'), ('īnfula', 'szata kapłańska', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v07a', 'title': 'Kolory i kształty 1', 'icon': 'K', 'track': 'jezyk', 'words': [('ruber', 'czerwony', None, None), ('caeruleus', 'niebieski', None, None), ('viridis', 'zielony', None, None), ('flāvus', 'żółty', None, None), ('niger', 'czarny', None, None), ('albus', 'biały', None, None), ('cinereus', 'szary', None, None), ('fuscus', 'brązowy', None, None), ('roseus', 'różowy', None, None), ('violāceus', 'fioletowy', None, None), ('aureus', 'złoty', None, None), ('argenteus', 'srebrny', None, None), ('clārus', 'jasny', None, None), ('obscūrus', 'ciemny', None, None), ('color', 'kolor', None, 'rodzaj męski'), ('rotundus', 'okrągły', None, None)], 'sentences': []}, {'id': 'v07b', 'title': 'Kolory i kształty 2', 'icon': 'K', 'track': 'jezyk', 'words': [('quadrātus', 'kwadratowy', None, None), ('rēctus', 'prosty', None, None), ('curvus', 'krzywy', None, None), ('līnea', 'linia', None, 'rodzaj żeński'), ('pūnctum', 'punkt', None, 'rodzaj nijaki'), ('circulus', 'koło', None, 'rodzaj męski'), ('triangulum', 'trójkąt', None, 'rodzaj nijaki'), ('fōrma', 'kształt', None, 'rodzaj żeński'), ('globus', 'kula', None, 'rodzaj męski'), ('cylindrus', 'walec', None, 'rodzaj męski'), ('angulus', 'kąt', None, 'rodzaj męski'), ('latus', 'bok', None, 'rodzaj nijaki'), ('centrum', 'środek', None, 'rodzaj nijaki'), ('superficiēs', 'powierzchnia', None, 'rodzaj żeński'), ('altitūdō', 'wysokość', None, 'rodzaj żeński'), ('longitūdō', 'długość', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v07c', 'title': 'Kolory i kształty 3', 'icon': 'K', 'track': 'jezyk', 'words': [('lātitūdō', 'szerokość', None, 'rodzaj żeński'), ('profunditās', 'głębokość', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v08a', 'title': 'Liczby i ilości 1', 'icon': 'L', 'track': 'jezyk', 'words': [('nihil', 'zero', None, None), ('ūndecim', 'jedenaście', None, None), ('duodecim', 'dwanaście', None, None), ('tredecim', 'trzynaście', None, None), ('quattuordecim', 'czternaście', None, None), ('quīndecim', 'piętnaście', None, None), ('sēdecim', 'szesnaście', None, None), ('septendecim', 'siedemnaście', None, None), ('duodēvīgintī', 'osiemnaście', None, None), ('ūndēvīgintī', 'dziewiętnaście', None, None), ('vīgintī', 'dwadzieścia', None, None), ('trīgintā', 'trzydzieści', None, None), ('quadrāgintā', 'czterdzieści', None, None), ('quīnquāgintā', 'pięćdziesiąt', None, None), ('sexāgintā', 'sześćdziesiąt', None, None), ('septuāgintā', 'siedemdziesiąt', None, None)], 'sentences': []}, {'id': 'v08b', 'title': 'Liczby i ilości 2', 'icon': 'L', 'track': 'jezyk', 'words': [('octōgintā', 'osiemdziesiąt', None, None), ('nōnāgintā', 'dziewięćdziesiąt', None, None), ('centum', 'sto', None, None), ('ducentī', 'dwieście', None, None), ('trecentī', 'trzysta', None, None), ('mīlle', 'tysiąc', None, None), ('duo mīlia', 'dwa tysiące', None, None), ('prīmus', 'pierwszy', None, None), ('secundus', 'drugi', None, None), ('tertius', 'trzeci', None, None), ('quārtus', 'czwarty', None, None), ('quīntus', 'piąty', None, None), ('sextus', 'szósty', None, None), ('septimus', 'siódmy', None, None), ('octāvus', 'ósmy', None, None), ('nōnus', 'dziewiąty', None, None)], 'sentences': []}, {'id': 'v08c', 'title': 'Liczby i ilości 3', 'icon': 'L', 'track': 'jezyk', 'words': [('decimus', 'dziesiąty', None, None), ('dīmidium', 'połowa', None, 'rodzaj nijaki'), ('par', 'para', None, 'rodzaj nijaki'), ('aliquot', 'kilka', None, None), ('multī', 'wiele', None, None), ('paucī', 'mało', None, None), ('tōtus', 'cały', None, None), ('omnēs', 'wszyscy', None, None), ('omnia', 'wszystko', None, None), ('nūllus', 'żaden', None, None), ('aliquis', 'jakiś', None, None), ('bis', 'dwa razy', None, None), ('ter', 'trzy razy', None, None), ('quater', 'cztery razy', None, None), ('semel', 'raz', None, None), ('tantus', 'tyle', None, None)], 'sentences': []}, {'id': 'v08d', 'title': 'Liczby i ilości 4', 'icon': 'L', 'track': 'jezyk', 'words': [('quantus', 'ile', None, None), ('plūs', 'więcej', None, None), ('plūrimum', 'najwięcej', None, None), ('minus', 'mniej', None, None), ('satis', 'dość', None, None), ('nimis', 'zbyt', None, None), ('duplex', 'podwójny', None, None), ('triplex', 'potrójny', None, None), ('centuria', 'setka', None, 'rodzaj żeński'), ('mīllennium', 'tysiąclecie', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v09a', 'title': 'Czas 1', 'icon': 'C', 'track': 'jezyk', 'words': [('momentum', 'sekunda', None, 'rodzaj nijaki'), ('minūtum', 'minuta', None, 'rodzaj nijaki'), ('hōra', 'godzina', None, 'rodzaj żeński'), ('diēs', 'dzień', None, 'rodzaj męski'), ('nox', 'noc', None, 'rodzaj żeński'), ('hebdomas', 'tydzień', None, 'rodzaj żeński'), ('mēnsis', 'miesiąc', None, 'rodzaj męski'), ('annus', 'rok', None, 'rodzaj męski'), ('vēr', 'wiosna', None, 'rodzaj nijaki'), ('aestās', 'lato', None, 'rodzaj żeński'), ('autumnus', 'jesień', None, 'rodzaj męski'), ('hiems', 'zima', None, 'rodzaj żeński'), ('Iānuārius', 'styczeń', None, 'rodzaj męski'), ('Februārius', 'luty', None, 'rodzaj męski'), ('Mārtius', 'marzec', None, 'rodzaj męski'), ('Aprīlis', 'kwiecień', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v09b', 'title': 'Czas 2', 'icon': 'C', 'track': 'jezyk', 'words': [('Māius', 'maj', None, 'rodzaj męski'), ('Iūnius', 'czerwiec', None, 'rodzaj męski'), ('Iūlius', 'lipiec', None, 'rodzaj męski'), ('Augustus', 'sierpień', None, 'rodzaj męski'), ('September', 'wrzesień', None, 'rodzaj męski'), ('Octōber', 'październik', None, 'rodzaj męski'), ('November', 'listopad', None, 'rodzaj męski'), ('December', 'grudzień', None, 'rodzaj męski'), ('māne', 'rano', None, None), ('merīdiēs', 'południe', None, 'rodzaj męski'), ('vesper', 'wieczór', None, 'rodzaj męski'), ('semper', 'zawsze', None, None), ('numquam', 'nigdy', None, None), ('interdum', 'czasem', None, None), ('saepe', 'często', None, None), ('iam', 'już', None, None)], 'sentences': []}, {'id': 'v09c', 'title': 'Czas 3', 'icon': 'C', 'track': 'jezyk', 'words': [('adhūc', 'jeszcze', None, None), ('mox', 'wkrótce', None, None), ('posteā', 'później', None, None), ('mātūrē', 'wcześnie', None, None), ('sērō', 'późno', None, None), ('quandō', 'kiedy', None, None), ('praeteritum', 'przeszłość', None, 'rodzaj nijaki'), ('futūrum', 'przyszłość', None, 'rodzaj nijaki'), ('praesēns', 'teraźniejszość', None, 'rodzaj nijaki'), ('diēs nātālis', 'urodziny', None, 'rodzaj męski'), ('fēstum', 'święto', None, 'rodzaj nijaki'), ('fēriae', 'wakacje', None, 'rodzaj żeński'), ('hodiē', 'dziś', None, None), ('crās', 'jutro', None, None), ('herī', 'wczoraj', None, None), ('nunc', 'teraz', None, None)], 'sentences': []}, {'id': 'v09d', 'title': 'Czas 4', 'icon': 'C', 'track': 'jezyk', 'words': [('tum', 'wtedy', None, None), ('Kalendae', 'kalendy', None, 'rodzaj żeński'), ('Nōnae', 'nony', None, 'rodzaj żeński'), ('Īdūs', 'idy', None, 'rodzaj żeński'), ('saeculum', 'wiek', None, 'rodzaj nijaki'), ('aetās', 'czas (okres)', None, 'rodzaj żeński'), ('iuventūs', 'młodość', None, 'rodzaj żeński'), ('senectūs', 'starość', None, 'rodzaj żeński'), ('pueritia', 'dzieciństwo', None, 'rodzaj żeński'), ('aurōra', 'świt', None, 'rodzaj żeński'), ('crepusculum', 'zmierzch', None, 'rodzaj nijaki'), ('media nox', 'północ', None, 'rodzaj żeński'), ('nudius tertius', 'przedwczoraj', None, None), ('perendiē', 'pojutrze', None, None), ('dēinceps', 'odtąd', None, None), ('iamdūdum', 'dawno', None, None)], 'sentences': []}, {'id': 'v09e', 'title': 'Czas 5', 'icon': 'C', 'track': 'jezyk', 'words': [('nūper', 'niedawno', None, None), ('statim', 'natychmiast', None, None), ('prōtinus', 'zaraz', None, None), ('intereā', 'tymczasem', None, None), ('anteā', 'przedtem', None, None), ('dēnique', 'wreszcie', None, None), ('prīmum', 'najpierw', None, None), ('deinde', 'potem', None, None)], 'sentences': []}, {'id': 'v10a', 'title': 'Przyroda i pogoda 1', 'icon': 'P', 'track': 'jezyk', 'words': [('astrum', 'gwiazda', None, 'rodzaj nijaki'), ('nūbēs', 'chmura', None, 'rodzaj żeński'), ('imber', 'deszcz', None, 'rodzaj męski'), ('nix', 'śnieg', None, 'rodzaj żeński'), ('ventus', 'wiatr', None, 'rodzaj męski'), ('tempestās', 'burza', None, 'rodzaj żeński'), ('nebula', 'mgła', None, 'rodzaj żeński'), ('glaciēs', 'lód', None, 'rodzaj żeński'), ('ignis', 'ogień', None, 'rodzaj męski'), ('tellūs', 'ziemia', None, 'rodzaj żeński'), ('pontus', 'morze', None, 'rodzaj męski'), ('flūmen', 'rzeka', None, 'rodzaj nijaki'), ('lacus', 'jezioro', None, 'rodzaj męski'), ('mōns', 'góra', None, 'rodzaj męski'), ('nemus', 'las', None, 'rodzaj nijaki'), ('arbor', 'drzewo', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v10b', 'title': 'Przyroda i pogoda 2', 'icon': 'P', 'track': 'jezyk', 'words': [('flōs', 'kwiat', None, 'rodzaj męski'), ('herba', 'trawa', None, 'rodzaj żeński'), ('folium', 'liść', None, 'rodzaj nijaki'), ('ager', 'pole', None, 'rodzaj męski'), ('prātum', 'łąka', None, 'rodzaj nijaki'), ('īnsula', 'wyspa', None, 'rodzaj żeński'), ('lītus', 'plaża', None, 'rodzaj nijaki'), ('dēsertum', 'pustynia', None, 'rodzaj nijaki'), ('saxum', 'skała', None, 'rodzaj nijaki'), ('aestus', 'upał', None, 'rodzaj męski'), ('frīgus', 'zimno', None, 'rodzaj nijaki'), ('calor', 'ciepło', None, 'rodzaj męski'), ('gelū', 'mróz', None, 'rodzaj nijaki'), ('grandō', 'grad', None, 'rodzaj żeński'), ('tonitrus', 'grzmot', None, 'rodzaj męski'), ('fulmen', 'błyskawica', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v10c', 'title': 'Przyroda i pogoda 3', 'icon': 'P', 'track': 'jezyk', 'words': [('arcus caelestis', 'tęcza', None, 'rodzaj męski'), ('lacūna', 'kałuża', None, 'rodzaj żeński'), ('lutum', 'błoto', None, 'rodzaj nijaki'), ('harēna', 'piasek', None, 'rodzaj żeński'), ('vallis', 'dolina', None, 'rodzaj żeński'), ('collis', 'wzgórze', None, 'rodzaj męski'), ('spēlunca', 'jaskinia', None, 'rodzaj żeński'), ('cataracta', 'wodospad', None, 'rodzaj żeński'), ('fōns', 'źródło', None, 'rodzaj męski'), ('sinus', 'zatoka', None, 'rodzaj męski'), ('ōra', 'wybrzeże', None, 'rodzaj żeński'), ('palūs', 'bagno', None, 'rodzaj żeński'), ('stagnum', 'staw', None, 'rodzaj nijaki'), ('frutex', 'krzak', None, 'rodzaj męski'), ('rādix', 'korzeń', None, 'rodzaj żeński'), ('rāmus', 'gałąź', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10d', 'title': 'Przyroda i pogoda 4', 'icon': 'P', 'track': 'jezyk', 'words': [('unda', 'fala', None, 'rodzaj żeński'), ('rōs', 'rosa', None, 'rodzaj męski'), ('inundātiō', 'powódź', None, 'rodzaj żeński'), ('terrae mōtus', 'trzęsienie ziemi', None, 'rodzaj męski'), ('mōns ignifer', 'wulkan', None, 'rodzaj męski'), ('nivis tempestās', 'burza śnieżna', None, 'rodzaj żeński'), ('aquilō', 'wiatr północny', None, 'rodzaj męski'), ('auster', 'wiatr południowy', None, 'rodzaj męski'), ('zephyrus', 'wiatr zachodni', None, 'rodzaj męski'), ('eurus', 'wiatr wschodni', None, 'rodzaj męski'), ('lūx', 'światło dzienne', None, 'rodzaj żeński'), ('tenebrae', 'ciemność', None, 'rodzaj żeński'), ('umbra', 'cień', None, 'rodzaj żeński'), ('axis', 'oś', None, 'rodzaj męski'), ('mundus', 'wszechświat', None, 'rodzaj męski'), ('orbis', 'świat', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10e', 'title': 'Przyroda i pogoda 5', 'icon': 'P', 'track': 'jezyk', 'words': [('nātūra', 'natura', None, 'rodzaj żeński'), ('grānum', 'ziarno', None, 'rodzaj nijaki'), ('sēmen', 'nasienie', None, 'rodzaj nijaki'), ('frūctus', 'owoc', None, 'rodzaj męski'), ('truncus', 'pień', None, 'rodzaj męski'), ('cortex', 'kora', None, 'rodzaj męski'), ('dūmētum', 'zarośla', None, 'rodzaj nijaki'), ('sēmita', 'ścieżka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v11a', 'title': 'Zwierzęta 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('canis', 'pies', None, 'rodzaj męski'), ('fēlēs', 'kot', None, 'rodzaj żeński'), ('equus', 'koń', None, 'rodzaj męski'), ('equa', 'klacz', None, 'rodzaj żeński'), ('vacca', 'krowa', None, 'rodzaj żeński'), ('taurus', 'byk', None, 'rodzaj męski'), ('bōs', 'wół', None, 'rodzaj męski'), ('sūs', 'świnia', None, 'rodzaj żeński'), ('ovis', 'owca', None, 'rodzaj żeński'), ('capra', 'koza', None, 'rodzaj żeński'), ('gallīna', 'kura', None, 'rodzaj żeński'), ('gallus', 'kogut', None, 'rodzaj męski'), ('anas', 'kaczka', None, 'rodzaj żeński'), ('avis', 'ptak', None, 'rodzaj żeński'), ('mūs', 'mysz', None, 'rodzaj męski'), ('rattus', 'szczur', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11b', 'title': 'Zwierzęta 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('serpēns', 'wąż', None, 'rodzaj męski'), ('rāna', 'żaba', None, 'rodzaj żeński'), ('leō', 'lew', None, 'rodzaj męski'), ('tigris', 'tygrys', None, 'rodzaj męski'), ('elephantus', 'słoń', None, 'rodzaj męski'), ('ursus', 'niedźwiedź', None, 'rodzaj męski'), ('lupus', 'wilk', None, 'rodzaj męski'), ('vulpēs', 'lis', None, 'rodzaj żeński'), ('lepus', 'zając', None, 'rodzaj męski'), ('cervus', 'jeleń', None, 'rodzaj męski'), ('sīmia', 'małpa', None, 'rodzaj żeński'), ('papiliō', 'motyl', None, 'rodzaj męski'), ('apis', 'pszczoła', None, 'rodzaj żeński'), ('musca', 'mucha', None, 'rodzaj żeński'), ('arāneus', 'pająk', None, 'rodzaj męski'), ('animal', 'zwierzę', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v11c', 'title': 'Zwierzęta 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('īnsectum', 'owad', None, 'rodzaj nijaki'), ('asinus', 'osioł', None, 'rodzaj męski'), ('mūlus', 'mul', None, 'rodzaj męski'), ('camēlus', 'wielbłąd', None, 'rodzaj męski'), ('crocodīlus', 'krokodyl', None, 'rodzaj męski'), ('delphīnus', 'delfin', None, 'rodzaj męski'), ('bālaena', 'wieloryb', None, 'rodzaj żeński'), ('aquila', 'orzeł', None, 'rodzaj żeński'), ('būbō', 'sowa', None, 'rodzaj męski'), ('columba', 'gołąb', None, 'rodzaj żeński'), ('cornīx', 'wrona', None, 'rodzaj żeński'), ('corvus', 'kruk', None, 'rodzaj męski'), ('olor', 'łabędź', None, 'rodzaj męski'), ('ānser', 'gęś', None, 'rodzaj męski'), ('pāvō', 'paw', None, 'rodzaj męski'), ('luscinia', 'słowik', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v11d', 'title': 'Zwierzęta 4', 'icon': 'Z', 'track': 'jezyk', 'words': [('hirundō', 'jaskółka', None, 'rodzaj żeński'), ('falcō', 'sokół', None, 'rodzaj męski'), ('aper', 'dzik', None, 'rodzaj męski'), ('ūrus', 'tur', None, 'rodzaj męski'), ('panthēra', 'pantera', None, 'rodzaj żeński'), ('hyaena', 'hiena', None, 'rodzaj żeński'), ('testūdō', 'żółw', None, 'rodzaj żeński'), ('cochlea', 'ślimak', None, 'rodzaj żeński'), ('vermis', 'robak', None, 'rodzaj męski'), ('formīca', 'mrówka', None, 'rodzaj żeński'), ('culex', 'komar', None, 'rodzaj męski'), ('vespa', 'osa', None, 'rodzaj żeński'), ('crābrō', 'szerszeń', None, 'rodzaj męski'), ('pūlex', 'pchła', None, 'rodzaj żeński'), ('pēdiculus', 'wesz', None, 'rodzaj męski'), ('scorpiō', 'skorpion', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11e', 'title': 'Zwierzęta 5', 'icon': 'Z', 'track': 'jezyk', 'words': [('cancer', 'kraby', None, 'rodzaj męski'), ('polypus', 'ośmiornica', None, 'rodzaj męski'), ('pecus', 'bydło', None, 'rodzaj nijaki'), ('grex', 'trzoda', None, 'rodzaj męski'), ('armentum', 'stado', None, 'rodzaj nijaki'), ('agnus', 'jagnię', None, 'rodzaj męski'), ('vitulus', 'cielę', None, 'rodzaj męski'), ('pullus equī', 'źrebię', None, 'rodzaj męski'), ('catulus', 'szczeniak', None, 'rodzaj męski'), ('catulus fēlis', 'kocię', None, 'rodzaj męski'), ('nīdus', 'gniazdo', None, 'rodzaj męski'), ('penna', 'pióro', None, 'rodzaj żeński'), ('ungula', 'kopyto', None, 'rodzaj żeński'), ('pellis', 'futro', None, 'rodzaj żeński'), ('ōvum avis', 'jajo (ptasie)', None, 'rodzaj nijaki'), ('cavea', 'klatka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v11f', 'title': 'Zwierzęta 6', 'icon': 'Z', 'track': 'jezyk', 'words': [('alvēus', 'ul', None, 'rodzaj męski'), ('pēs animālis', 'łapa', None, 'rodzaj męski'), ('dēns caninus', 'kieł', None, 'rodzaj męski'), ('unguis animālis', 'pazur', None, 'rodzaj męski'), ('pilus', 'sierść', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v12a', 'title': 'Miasto i budynki 1', 'icon': 'M', 'track': 'jezyk', 'words': [('oppidum', 'miasto', None, 'rodzaj nijaki'), ('vīcus', 'wieś', None, 'rodzaj męski'), ('strāta', 'ulica', None, 'rodzaj żeński'), ('iter', 'droga (wiejska)', None, 'rodzaj nijaki'), ('forum', 'plac', None, 'rodzaj nijaki'), ('pōns', 'most', None, 'rodzaj męski'), ('hortī', 'park', None, 'rodzaj męski'), ('macellum', 'targ', None, 'rodzaj nijaki'), ('mercātus', 'rynek', None, 'rodzaj męski'), ('argentāria', 'bank', None, 'rodzaj żeński'), ('tabellāria', 'poczta', None, 'rodzaj żeński'), ('valētūdinārium', 'szpital', None, 'rodzaj nijaki'), ('schola', 'uniwersytet', None, 'rodzaj żeński'), ('mūsēum', 'muzeum', None, 'rodzaj nijaki'), ('templum', 'świątynia', None, 'rodzaj nijaki'), ('basilica', 'kościół', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v12b', 'title': 'Miasto i budynki 2', 'icon': 'M', 'track': 'jezyk', 'words': [('popīna', 'restauracja', None, 'rodzaj żeński'), ('portus', 'port', None, 'rodzaj męski'), ('statiō', 'dworzec', None, 'rodzaj żeński'), ('theātrum', 'teatr', None, 'rodzaj nijaki'), ('circus', 'cyrk', None, 'rodzaj męski'), ('amphitheātrum', 'amfiteatr', None, 'rodzaj nijaki'), ('thermae', 'łaźnie', None, 'rodzaj żeński'), ('aquaeductus', 'akwedukt', None, 'rodzaj męski'), ('cloāca', 'kanał', None, 'rodzaj żeński'), ('cūria', 'senat', None, 'rodzaj żeński'), ('portae', 'bramy miasta', None, 'rodzaj żeński'), ('moenia', 'mury miejskie', None, 'rodzaj nijaki'), ('turris', 'wieża', None, 'rodzaj żeński'), ('castellum', 'twierdza', None, 'rodzaj nijaki'), ('castra', 'obóz', None, 'rodzaj nijaki'), ('carcer', 'więzienie', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v12c', 'title': 'Miasto i budynki 3', 'icon': 'M', 'track': 'jezyk', 'words': [('sepulcrum', 'grób', None, 'rodzaj nijaki'), ('sepulcrētum', 'cmentarz', None, 'rodzaj nijaki'), ('monumentum', 'pomnik', None, 'rodzaj nijaki'), ('arcus', 'łuk triumfalny', None, 'rodzaj męski'), ('columna triumphālis', 'kolumna triumfalna', None, 'rodzaj żeński'), ('stadium', 'stadion', None, 'rodzaj nijaki'), ('lūdus', 'szkoła', None, 'rodzaj męski'), ('lupānar', 'burdel', None, 'rodzaj nijaki'), ('pistrīnum', 'piekarnia', None, 'rodzaj nijaki'), ('mola', 'młyn', None, 'rodzaj żeński'), ('officīna', 'warsztat', None, 'rodzaj żeński'), ('fabrica', 'fabryka', None, 'rodzaj żeński'), ('fabrica ferrāria', 'kuźnia', None, 'rodzaj żeński'), ('hōrrea', 'spichlerz publiczny', None, 'rodzaj nijaki'), ('Tulliānum', 'więzienie (Tullianum)', None, 'rodzaj nijaki'), ('regiō', 'dzielnica', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v12d', 'title': 'Miasto i budynki 4', 'icon': 'M', 'track': 'jezyk', 'words': [('suburbium', 'przedmieście', None, 'rodzaj nijaki'), ('forum Rōmānum', 'centrum', None, 'rodzaj nijaki'), ('domicilium', 'adres', None, 'rodzaj nijaki'), ('tabula geographica', 'mapa', None, 'rodzaj żeński'), ('palātium', 'pałac', None, 'rodzaj nijaki'), ('sēdēs', 'siedziba', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13a', 'title': 'Podróż i transport 1', 'icon': 'P', 'track': 'jezyk', 'words': [('currus', 'samochód', None, 'rodzaj męski'), ('carrus', 'wóz', None, 'rodzaj męski'), ('raeda', 'powóz', None, 'rodzaj żeński'), ('quadrīga', 'rydwan', None, 'rodzaj żeński'), ('lectīca', 'lektyka', None, 'rodzaj żeński'), ('nāvis', 'statek', None, 'rodzaj żeński'), ('nāvis longa', 'okręt wojenny', None, 'rodzaj żeński'), ('scapha', 'łódź', None, 'rodzaj żeński'), ('rēmus', 'wiosło', None, 'rodzaj męski'), ('mālus', 'maszt', None, 'rodzaj męski'), ('gubernāculum', 'ster', None, 'rodzaj nijaki'), ('ancora', 'kotwica', None, 'rodzaj żeński'), ('excursiō', 'wycieczka', None, 'rodzaj żeński'), ('diplōma', 'paszport', None, 'rodzaj nijaki'), ('sarcina', 'walizka', None, 'rodzaj żeński'), ('bivium', 'skrzyżowanie', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v13b', 'title': 'Podróż i transport 2', 'icon': 'P', 'track': 'jezyk', 'words': [('mīliārium', 'kamień milowy', None, 'rodzaj nijaki'), ('vadum', 'brod', None, 'rodzaj nijaki'), ('fīnis', 'granica', None, 'rodzaj męski'), ('aurīga', 'kierowca', None, 'rodzaj męski'), ('viātor', 'pasażer', None, 'rodzaj męski'), ('tabellārius', 'kurier', None, 'rodzaj męski'), ('nūntius', 'posłaniec', None, 'rodzaj męski'), ('mānsiō', 'gospoda', None, 'rodzaj żeński'), ('peregrīnātor', 'podróżnik', None, 'rodzaj męski'), ('expedītiō', 'wyprawa', None, 'rodzaj żeński'), ('nāvigātiō', 'żeglarstwo', None, 'rodzaj żeński'), ('equitātiō', 'jazda konna', None, 'rodzaj żeński'), ('mīlle passuum', 'mil', None, 'rodzaj nijaki'), ('passus', 'krok', None, 'rodzaj męski'), ('cursus', 'trasa', None, 'rodzaj męski'), ('tempestās maritima', 'sztorm', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13c', 'title': 'Podróż i transport 3', 'icon': 'P', 'track': 'jezyk', 'words': [('nāufragus', 'rozbitek', None, 'rodzaj męski'), ('nāufragium', 'zatonięcie', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v14a', 'title': 'Praca i szkoła 1', 'icon': 'P', 'track': 'jezyk', 'words': [('labor', 'praca', None, 'rodzaj męski'), ('ars', 'zawód', None, 'rodzaj żeński'), ('faber', 'kowal', None, 'rodzaj męski'), ('tignārius', 'stolarz', None, 'rodzaj męski'), ('sūtor', 'szewc', None, 'rodzaj męski'), ('piscātor', 'rybak', None, 'rodzaj męski'), ('pistor', 'piekarz', None, 'rodzaj męski'), ('lanius', 'rzeźnik', None, 'rodzaj męski'), ('coquus', 'kucharz', None, 'rodzaj męski'), ('tōnsor', 'fryzjer', None, 'rodzaj męski'), ('sartor', 'krawiec', None, 'rodzaj męski'), ('architectus', 'architekt', None, 'rodzaj męski'), ('sculptor', 'rzeźbiarz', None, 'rodzaj męski'), ('pictor', 'malarz', None, 'rodzaj męski'), ('mūsicus', 'muzyk', None, 'rodzaj męski'), ('histriō', 'aktor', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v14b', 'title': 'Praca i szkoła 2', 'icon': 'P', 'track': 'jezyk', 'words': [('scrība', 'pisarz', None, 'rodzaj męski'), ('historicus', 'historyk', None, 'rodzaj męski'), ('iūrisconsultus', 'prawnik', None, 'rodzaj męski'), ('advocātus', 'adwokat', None, 'rodzaj męski'), ('nummulārius', 'kasjer', None, 'rodzaj męski'), ('magistrātus', 'urzędnik', None, 'rodzaj męski'), ('societās', 'firma', None, 'rodzaj żeński'), ('pecūnia', 'pieniądze', None, 'rodzaj żeński'), ('salārium', 'pensja', None, 'rodzaj nijaki'), ('foedus', 'umowa', None, 'rodzaj nijaki'), ('conventus', 'spotkanie', None, 'rodzaj męski'), ('lectiō', 'lekcja', None, 'rodzaj żeński'), ('probātiō', 'egzamin', None, 'rodzaj żeński'), ('iūdicium', 'ocena', None, 'rodzaj nijaki'), ('classis', 'klasa', None, 'rodzaj żeński'), ('volūmen', 'zwój', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v14c', 'title': 'Praca i szkoła 3', 'icon': 'P', 'track': 'jezyk', 'words': [('tabula cērāta', 'zeszyt', None, 'rodzaj żeński'), ('calamus', 'pióro', None, 'rodzaj męski'), ('stilus', 'ołówek', None, 'rodzaj męski'), ('charta', 'papier', None, 'rodzaj żeński'), ('membrāna', 'pergamin', None, 'rodzaj żeński'), ('ātrāmentum', 'atrament', None, 'rodzaj nijaki'), ('glossārium', 'słownik', None, 'rodzaj nijaki'), ('quaestiō', 'pytanie', None, 'rodzaj żeński'), ('respōnsum', 'odpowiedź', None, 'rodzaj nijaki'), ('officium', 'zadanie', None, 'rodzaj nijaki'), ('experīmentum', 'test', None, 'rodzaj nijaki'), ('grammatica', 'lekcja gramatyki', None, 'rodzaj żeński'), ('rhētorica', 'retoryka', None, 'rodzaj żeński'), ('ōrātiō', 'mowa', None, 'rodzaj żeński'), ('ōrātor', 'mówca', None, 'rodzaj męski'), ('doctrīna', 'nauka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v14d', 'title': 'Praca i szkoła 4', 'icon': 'P', 'track': 'jezyk', 'words': [('scientia', 'wiedza', None, 'rodzaj żeński'), ('sapientia', 'mądrość', None, 'rodzaj żeński'), ('cōnsilium', 'rada', None, 'rodzaj nijaki'), ('mandātum', 'polecenie', None, 'rodzaj nijaki'), ('imperium', 'rozkaz', None, 'rodzaj nijaki'), ('lēx', 'ustawa', None, 'rodzaj żeński'), ('sententia', 'wyrok', None, 'rodzaj żeński'), ('poena', 'kara', None, 'rodzaj żeński'), ('praemium', 'nagroda', None, 'rodzaj nijaki'), ('cūra', 'odpowiedzialność', None, 'rodzaj żeński'), ('opus', 'praca fizyczna', None, 'rodzaj nijaki'), ('īnstrūmentum', 'narzędzie', None, 'rodzaj nijaki'), ('malleus', 'młot', None, 'rodzaj męski'), ('incūs', 'kowadło', None, 'rodzaj żeński'), ('secūris', 'siekiera', None, 'rodzaj żeński'), ('serra', 'piła', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v14e', 'title': 'Praca i szkoła 5', 'icon': 'P', 'track': 'jezyk', 'words': [('ascia', 'topór', None, 'rodzaj żeński'), ('scalprum', 'dłuto', None, 'rodzaj nijaki'), ('acus', 'igła', None, 'rodzaj żeński'), ('filum', 'nić', None, 'rodzaj nijaki'), ('tēla', 'krosno', None, 'rodzaj żeński'), ('arātrum', 'pług', None, 'rodzaj nijaki'), ('falx', 'sierp', None, 'rodzaj żeński'), ('rastrum', 'grabie', None, 'rodzaj nijaki'), ('pāla', 'łopata', None, 'rodzaj żeński'), ('calathus', 'kosz', None, 'rodzaj męski'), ('fūnis', 'lina', None, 'rodzaj męski'), ('catēna', 'łańcuch', None, 'rodzaj żeński'), ('clāvus', 'gwóźdź', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v15a', 'title': 'Pieniądze i handel 1', 'icon': 'P', 'track': 'jezyk', 'words': [('pretium', 'cena', None, 'rodzaj nijaki'), ('tessera', 'karta', None, 'rodzaj żeński'), ('pecūnia praesēns', 'gotówka', None, 'rodzaj żeński'), ('nummus', 'moneta', None, 'rodzaj męski'), ('dēnārius', 'denar', None, 'rodzaj męski'), ('sēstertius', 'sestercja', None, 'rodzaj męski'), ('reliquum', 'reszta', None, 'rodzaj nijaki'), ('rēmissiō', 'zniżka', None, 'rodzaj żeński'), ('sporta', 'koszyk', None, 'rodzaj żeński'), ('merx', 'towar', None, 'rodzaj żeński'), ('emptiō', 'zakup', None, 'rodzaj żeński'), ('vēnditiō', 'sprzedaż', None, 'rodzaj żeński'), ('valor', 'wartość', None, 'rodzaj męski'), ('crēditum', 'kredyt', None, 'rodzaj nijaki'), ('aes aliēnum', 'dług', None, 'rodzaj nijaki'), ('tribūtum', 'podatek', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v15b', 'title': 'Pieniądze i handel 2', 'icon': 'P', 'track': 'jezyk', 'words': [('dīvitiae', 'bogactwo', None, 'rodzaj żeński'), ('pauper', 'biedny', None, None), ('dīves', 'bogaty', None, None), ('vīlis', 'tani', None, None), ('cārus', 'drogi', None, None), ('commercium', 'handel', None, 'rodzaj nijaki'), ('negōtiātor', 'kupiec (hurtowy)', None, 'rodzaj męski'), ('mēnsa argentāria', 'bank (stół)', None, 'rodzaj żeński'), ('ūsūra', 'lichwa', None, 'rodzaj żeński'), ('lucrum', 'zysk', None, 'rodzaj nijaki'), ('damnum', 'strata', None, 'rodzaj nijaki'), ('thēsaurus', 'skarb', None, 'rodzaj męski'), ('hērēditās', 'spadek', None, 'rodzaj żeński'), ('dōnum', 'dar', None, 'rodzaj nijaki'), ('mūnus', 'podarunek', None, 'rodzaj nijaki'), ('praeda', 'łup', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v15c', 'title': 'Pieniądze i handel 3', 'icon': 'P', 'track': 'jezyk', 'words': [('redēmptiō', 'okup', None, 'rodzaj żeński'), ('emō', 'kupować', None, None), ('vendō', 'sprzedawać', None, None), ('solvō', 'płacić', None, None), ('mūtuor', 'pożyczać', None, None), ('mereor', 'zarabiać', None, None), ('dēbitor', 'dłużnik', None, 'rodzaj męski'), ('crēditor', 'wierzyciel', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v16a', 'title': 'Zdrowie 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('salūs', 'zdrowie', None, 'rodzaj żeński'), ('morbus', 'choroba', None, 'rodzaj męski'), ('dolor', 'ból', None, 'rodzaj męski'), ('febris', 'gorączka', None, 'rodzaj żeński'), ('tussis', 'kaszel', None, 'rodzaj żeński'), ('medicāmentum', 'lekarstwo', None, 'rodzaj nijaki'), ('pilula', 'tabletka', None, 'rodzaj żeński'), ('sectiō', 'operacja', None, 'rodzaj żeński'), ('vulnus', 'rana', None, 'rodzaj nijaki'), ('cāsus', 'wypadek', None, 'rodzaj męski'), ('sānus', 'zdrowy', None, None), ('aeger', 'chory', None, None), ('dēfessus', 'zmęczony', None, None), ('somniculōsus', 'śpiący', None, None), ('fortis', 'silny', None, None), ('īnfirmus', 'słaby', None, None)], 'sentences': []}, {'id': 'v16b', 'title': 'Zdrowie 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('surdus', 'głuchy', None, None), ('caecus', 'ślepy', None, None), ('claudus', 'kulawy', None, None), ('mūtus', 'niemy', None, None), ('īnsānus', 'szalony', None, None), ('venēnum', 'trucizna', None, 'rodzaj nijaki'), ('mors', 'śmierć', None, 'rodzaj żeński'), ('cadāver', 'trup', None, 'rodzaj nijaki'), ('corpus mortuum', 'zwłoki', None, 'rodzaj nijaki'), ('sānātiō', 'uzdrowienie', None, 'rodzaj żeński'), ('auxilium', 'pomoc', None, 'rodzaj nijaki'), ('pestis', 'zaraza', None, 'rodzaj żeński'), ('pestilentia', 'dżuma', None, 'rodzaj żeński'), ('cicātrix', 'blizna', None, 'rodzaj żeński'), ('livor', 'siniak', None, 'rodzaj męski'), ('sanguinis fluxus', 'krwawienie', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v16c', 'title': 'Zdrowie 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('somnus', 'sen', None, 'rodzaj męski'), ('quiēs', 'odpoczynek', None, 'rodzaj żeński'), ('spīritus', 'oddech', None, 'rodzaj męski'), ('victus', 'dieta', None, 'rodzaj męski'), ('herba medicīnālis', 'zioło', None, 'rodzaj żeński'), ('unguentum', 'maść', None, 'rodzaj nijaki'), ('dolor capitis', 'ból głowy', None, 'rodzaj męski'), ('dolor dentium', 'ból zęba', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v17a', 'title': 'Uczucia i charakter 1', 'icon': 'U', 'track': 'jezyk', 'words': [('gaudium', 'radość', None, 'rodzaj nijaki'), ('trīstitia', 'smutek', None, 'rodzaj żeński'), ('timor', 'strach', None, 'rodzaj męski'), ('īra', 'gniew', None, 'rodzaj żeński'), ('amor', 'miłość', None, 'rodzaj męski'), ('ōdium', 'nienawiść', None, 'rodzaj nijaki'), ('spēs', 'nadzieja', None, 'rodzaj żeński'), ('somnium', 'marzenie', None, 'rodzaj nijaki'), ('fēlīcitās', 'szczęście', None, 'rodzaj żeński'), ('pudor', 'wstyd', None, 'rodzaj męski'), ('admīrātiō', 'zdziwienie', None, 'rodzaj żeński'), ('cūriōsitās', 'ciekawość', None, 'rodzaj żeński'), ('patientia', 'cierpliwość', None, 'rodzaj żeński'), ('virtūs', 'odwaga', None, 'rodzaj żeński'), ('sincērus', 'szczery', None, None), ('amābilis', 'miły', None, None)], 'sentences': []}, {'id': 'v17b', 'title': 'Uczucia i charakter 2', 'icon': 'U', 'track': 'jezyk', 'words': [('urbānus', 'grzeczny', None, None), ('stultus', 'głupi', None, None), ('sapiēns', 'mądry', None, None), ('piger', 'leniwy', None, None), ('industrius', 'pracowity', None, None), ('cūriōsus', 'ciekawy', None, None), ('molestus', 'nudny', None, None), ('hilaris', 'wesoły', None, None), ('trīstis', 'smutny', None, None), ('īrātus', 'zły (rozgniewany)', None, None), ('fēlix', 'szczęśliwy', None, None), ('amans', 'zakochany', None, None), ('sōlus', 'samotny', None, None), ('tranquillus', 'spokojny', None, None), ('superbus', 'dumny', None, None), ('invidus', 'zazdrosny', None, None)], 'sentences': []}, {'id': 'v17c', 'title': 'Uczucia i charakter 3', 'icon': 'U', 'track': 'jezyk', 'words': [('grātus', 'wdzięczny', None, None), ('sollicitus', 'zmartwiony', None, None), ('attonitus', 'zaskoczony', None, None), ('dēceptus', 'rozczarowany', None, None), ('dēsīderāns', 'tęskniący', None, None), ('audāx', 'odważny', None, None), ('fidēlis', 'wierny', None, None), ('perfidus', 'zdradziecki', None, None), ('avārus', 'skąpy', None, None), ('līberālis', 'hojny', None, None), ('humilis', 'pokorny', None, None), ('pertināx', 'uparty', None, None), ('misericors', 'litościwy', None, None), ('crūdēlis', 'okrutny', None, None), ('iustus', 'sprawiedliwy', None, None), ('iniūstus', 'niesprawiedliwy', None, None)], 'sentences': []}, {'id': 'v17d', 'title': 'Uczucia i charakter 4', 'icon': 'U', 'track': 'jezyk', 'words': [('probus', 'uczciwy', None, None), ('improbus', 'nikczemny', None, None), ('ignāvus', 'tchórzliwy', None, None), ('vitium', 'wada', None, 'rodzaj nijaki'), ('honor', 'honor', None, 'rodzaj męski'), ('dēdecus', 'hańba', None, 'rodzaj nijaki'), ('glōria', 'sława', None, 'rodzaj żeński'), ('prūdentia', 'rozsądek', None, 'rodzaj żeński'), ('iūstitia', 'sprawiedliwość', None, 'rodzaj żeński'), ('temperantia', 'umiar', None, 'rodzaj żeński'), ('fidēs', 'wierność', None, 'rodzaj żeński'), ('amīcitia', 'przyjaźń', None, 'rodzaj żeński'), ('inimīcitia', 'wrogość', None, 'rodzaj żeński'), ('misericordia', 'litość', None, 'rodzaj żeński'), ('dolor animī', 'żal', None, 'rodzaj męski'), ('dēsīderium', 'tęsknota', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v17e', 'title': 'Uczucia i charakter 5', 'icon': 'U', 'track': 'jezyk', 'words': [('invidia', 'zazdrość', None, 'rodzaj żeński'), ('ultiō', 'zemsta', None, 'rodzaj żeński'), ('iūsiūrandum', 'przysięga', None, 'rodzaj nijaki'), ('fātum', 'los', None, 'rodzaj nijaki'), ('fortūna', 'szczęście (traf)', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v18a', 'title': 'Przymiotniki 1', 'icon': 'P', 'track': 'jezyk', 'words': [('grandis', 'duży', None, None), ('parvus', 'mały', None, None), ('longus', 'długi', None, None), ('altus', 'wysoki', None, None), ('lātus', 'szeroki', None, None), ('angustus', 'wąski', None, None), ('crassus', 'gruby', None, None), ('macer', 'chudy', None, None), ('gravis', 'ciężki', None, None), ('levis', 'lekki', None, None), ('celer', 'szybki', None, None), ('lentus', 'wolny', None, None), ('dūrus', 'twardy', None, None), ('mollis', 'miękki', None, None), ('ūmidus', 'mokry', None, None), ('siccus', 'suchy', None, None)], 'sentences': []}, {'id': 'v18b', 'title': 'Przymiotniki 2', 'icon': 'P', 'track': 'jezyk', 'words': [('pūrus', 'czysty', None, None), ('sordidus', 'brudny', None, None), ('plēnus', 'pełny', None, None), ('vacuus', 'pusty', None, None), ('ācer', 'ostry', None, None), ('sonōrus', 'głośny', None, None), ('tacitus', 'cichy', None, None), ('vetus', 'stary', None, None), ('novus', 'nowy', None, None), ('malus', 'zły (niedobry)', None, None), ('pulcher', 'ładny', None, None), ('turpis', 'brzydki', None, None), ('facilis', 'łatwy', None, None), ('difficilis', 'trudny', None, None), ('possibilis', 'możliwy', None, None), ('vērus', 'prawdziwy', None, None)], 'sentences': []}, {'id': 'v18c', 'title': 'Przymiotniki 3', 'icon': 'P', 'track': 'jezyk', 'words': [('falsus', 'fałszywy', None, None), ('līber', 'wolny (nie niewolnik)', None, None), ('proprius', 'własny', None, None), ('aliēnus', 'obcy', None, None), ('sacer', 'święty', None, None), ('potēns', 'potężny', None, None), ('proximus', 'bliski', None, None), ('longinquus', 'daleki', None, None), ('certus', 'pewny', None, None), ('incertus', 'niepewny', None, None), ('parātus', 'gotowy', None, None), ('similis', 'podobny', None, None), ('dissimilis', 'niepodobny', None, None), ('alius', 'inny', None, None), ('quisque', 'każdy', None, None), ('cūnctus', 'wszelki', None, None)], 'sentences': []}, {'id': 'v18d', 'title': 'Przymiotniki 4', 'icon': 'P', 'track': 'jezyk', 'words': [('profundus', 'głęboki', None, None), ('acūtus', 'wysoki (głos)', None, None), ('dulcis', 'słodki', None, None), ('amārus', 'gorzki', None, None), ('acidus', 'kwaśny', None, None), ('salsus', 'słony', None, None), ('calidus', 'gorący', None, None), ('frīgidus', 'zimny', None, None), ('tepidus', 'ciepły', None, None), ('lūcidus', 'jasny (światło)', None, None), ('tenebrōsus', 'ciemny (ciemność)', None, None), ('speciōsus', 'piękny', None, None), ('nōbilis', 'szlachetny', None, None), ('vulgāris', 'pospolity', None, None), ('rārus', 'rzadki', None, None), ('abundāns', 'bogaty (w)', None, None)], 'sentences': []}, {'id': 'v18e', 'title': 'Przymiotniki 5', 'icon': 'P', 'track': 'jezyk', 'words': [('inops', 'ubogi', None, None), ('tūtus', 'bezpieczny', None, None), ('perīculōsus', 'niebezpieczny', None, None), ('commūnis', 'wspólny', None, None), ('sēparātus', 'osobny', None, None), ('integer', 'cały (nienaruszony)', None, None), ('expers', 'wolny (od)', None, None), ('ultimus', 'ostatni', None, None), ('prior', 'pierwszy (z dwóch)', None, None), ('antīquus', 'dawny', None, None), ('aeternus', 'wieczny', None, None), ('mortālis', 'śmiertelny', None, None), ('immortālis', 'nieśmiertelny', None, None), ('dīvīnus', 'boski', None, None), ('hūmānus', 'ludzki', None, None), ('Rōmānus', 'rzymski', None, None)], 'sentences': []}, {'id': 'v18f', 'title': 'Przymiotniki 6', 'icon': 'P', 'track': 'jezyk', 'words': [('Graecus', 'grecki', None, None), ('Latīnus', 'łaciński', None, None), ('barbarus', 'barbarzyński', None, None)], 'sentences': []}, {'id': 'v19a', 'title': 'Czasowniki podstawowe 1', 'icon': 'C', 'track': 'jezyk', 'words': [('habeō', 'mieć', None, None), ('faciō', 'robić', None, None), ('eō', 'iść', None, None), ('vehor', 'jechać', None, None), ('veniō', 'przyjść', None, None), ('exeō', 'wyjść', None, None), ('intrō', 'wejść', None, None), ('redeō', 'wrócić', None, None), ('currō', 'biec', None, None), ('stō', 'stać', None, None), ('sedeō', 'siedzieć', None, None), ('iaceō', 'leżeć', None, None), ('dormiō', 'spać', None, None), ('surgō', 'wstać', None, None), ('edō', 'jeść', None, None), ('bibō', 'pić', None, None)], 'sentences': []}, {'id': 'v19b', 'title': 'Czasowniki podstawowe 2', 'icon': 'C', 'track': 'jezyk', 'words': [('coquō', 'gotować', None, None), ('lavō', 'myć', None, None), ('vestiō', 'ubierać się', None, None), ('loquor', 'mówić', None, None), ('dīcō', 'powiedzieć', None, None), ('rogō', 'pytać', None, None), ('respondeō', 'odpowiadać', None, None), ('auscultō', 'słuchać', None, None), ('spectō', 'patrzeć', None, None), ('discō', 'uczyć się', None, None), ('doceō', 'uczyć (kogoś)', None, None), ('intellegō', 'rozumieć', None, None), ('sciō', 'wiedzieć', None, None), ('nōscō', 'znać', None, None), ('putō', 'myśleć', None, None), ('meminī', 'pamiętać', None, None)], 'sentences': []}, {'id': 'v19c', 'title': 'Czasowniki podstawowe 3', 'icon': 'C', 'track': 'jezyk', 'words': [('oblīviscor', 'zapominać', None, None), ('volō', 'chcieć', None, None), ('dēlectō', 'lubić', None, None), ('egeō', 'potrzebować', None, None), ('possum', 'móc', None, None), ('dēbeō', 'musieć', None, None), ('dō', 'dawać', None, None), ('capiō', 'brać', None, None), ('pendō', 'płacić', None, None), ('aperiō', 'otwierać', None, None), ('claudō', 'zamykać', None, None), ('incipiō', 'zaczynać', None, None), ('fīniō', 'kończyć', None, None), ('labōrō', 'pracować', None, None), ('lūdō', 'grać', None, None), ('cantō', 'śpiewać', None, None)], 'sentences': []}, {'id': 'v19d', 'title': 'Czasowniki podstawowe 4', 'icon': 'C', 'track': 'jezyk', 'words': [('saltō', 'tańczyć', None, None), ('natō', 'pływać', None, None), ('pōnō', 'kłaść', None, None), ('quaerō', 'szukać', None, None), ('inveniō', 'znajdować', None, None), ('exspectō', 'czekać', None, None), ('iuvō', 'pomagać', None, None), ('ōrō', 'prosić', None, None), ('excūsō', 'przepraszać', None, None), ('sinō', 'pozwalać', None, None), ('temptō', 'próbować', None, None), ('mūtō', 'zmieniać', None, None), ('portō', 'nosić', None, None), ('teneō', 'trzymać', None, None), ('iaciō', 'rzucać', None, None), ('feriō', 'bić', None, None)], 'sentences': []}, {'id': 'v19e', 'title': 'Czasowniki podstawowe 5', 'icon': 'C', 'track': 'jezyk', 'words': [('occīdō', 'zabijać', None, None), ('morior', 'umierać', None, None), ('vīvō', 'żyć', None, None), ('habitō', 'mieszkać', None, None), ('obviam eō', 'spotykać', None, None), ('vocō', 'dzwonić', None, None), ('mittō', 'wysyłać', None, None), ('accipiō', 'dostawać', None, None), ('mōnstrō', 'pokazywać', None, None), ('invītō', 'zapraszać', None, None), ('vīsitō', 'odwiedzać', None, None), ('fleō', 'płakać', None, None), ('rīdeō', 'śmiać się', None, None), ('subrīdeō', 'uśmiechać się', None, None), ('timeō', 'bać się', None, None), ('gaudeō', 'cieszyć się', None, None)], 'sentences': []}, {'id': 'v19f', 'title': 'Czasowniki podstawowe 6', 'icon': 'C', 'track': 'jezyk', 'words': [('crēdō', 'wierzyć', None, None), ('cōnsentiō', 'zgadzać się', None, None), ('ēligō', 'wybierać', None, None), ('dēcernō', 'decydować', None, None), ('numerō', 'liczyć', None, None), ('dīligō', 'kochać (miłością)', None, None), ('ōdī', 'nienawidzić', None, None), ('regō', 'rządzić', None, None), ('dūcō', 'prowadzić', None, None), ('cēdō', 'poddać się', None, None), ('vincō', 'zwyciężać', None, None), ('vincor', 'przegrywać', None, None), ('pugnō', 'walczyć', None, None), ('dēfendō', 'bronić', None, None), ('oppugnō', 'atakować', None, None), ('expugnō', 'zdobywać', None, None)], 'sentences': []}, {'id': 'v19g', 'title': 'Czasowniki podstawowe 7', 'icon': 'C', 'track': 'jezyk', 'words': [('dēleō', 'niszczyć', None, None), ('aedificō', 'budować', None, None), ('dīruō', 'burzyć', None, None), ('ūrō', 'palić', None, None), ('exstinguō', 'gasić', None, None), ('cupiō', 'pragnąć', None, None), ('vereor', 'bać się (obawiać)', None, None), ('pudet', 'wstydzić się', None, None), ('paenitet', 'żałować', None, None), ('licet', 'wolno', None, None), ('oportet', 'trzeba', None, None), ('decet', 'wypada', None, None)], 'sentences': []}, {'id': 'v20a', 'title': 'Czasowniki dnia codziennego 1', 'icon': 'C', 'track': 'jezyk', 'words': [('ambulō', 'chodzić', None, None), ('equitō', 'jeździć', None, None), ('ascendō', 'wsiadać', None, None), ('dēscendō', 'wysiadać', None, None), ('flectō', 'skręcać', None, None), ('cōnsistō', 'zatrzymywać się', None, None), ('morō', 'spóźniać się', None, None), ('festīnō', 'spieszyć się', None, None), ('quiēscō', 'odpoczywać', None, None), ('dēlineō', 'rysować', None, None), ('struō', 'budować (dom)', None, None), ('reficiō', 'naprawiać', None, None), ('secō', 'ciąć', None, None), ('frīgō', 'smażyć', None, None), ('torreō', 'piec', None, None), ('misceō', 'mieszać', None, None)], 'sentences': []}, {'id': 'v20b', 'title': 'Czasowniki dnia codziennego 2', 'icon': 'C', 'track': 'jezyk', 'words': [('fundō', 'nalewać', None, None), ('pūrgō', 'sprzątać', None, None), ('pressō', 'prasować', None, None), ('rādō', 'golić się', None, None), ('pectō', 'czesać', None, None), ('lavor', 'kąpać się', None, None), ('expergiscor', 'budzić się', None, None), ('obdormiscō', 'zasypiać', None, None), ('somniō', 'marzyć', None, None), ('exerceō', 'ćwiczyć', None, None), ('exercitō', 'trenować', None, None), ('perdō', 'przegrywać', None, None), ('moveō', 'ruszać', None, None), ('trahō', 'ciągnąć', None, None), ('pellō', 'pchać', None, None), ('tollō', 'podnosić', None, None)], 'sentences': []}, {'id': 'v20c', 'title': 'Czasowniki dnia codziennego 3', 'icon': 'C', 'track': 'jezyk', 'words': [('cadō', 'spadać', None, None), ('saliō', 'skakać', None, None), ('scandō', 'wspinać się', None, None), ('cēlō', 'ukrywać', None, None), ('fūror', 'kraść', None, None), ('reddō', 'oddawać', None, None), ('mūtuum dō', 'pożyczać', None, None), ('impendō', 'wydawać', None, None), ('parcō', 'oszczędzać', None, None), ('arō', 'orać', None, None), ('serō', 'siać', None, None), ('metō', 'żąć', None, None), ('colligō', 'zbierać', None, None), ('plantō', 'sadzić', None, None), ('rigō', 'podlewać', None, None), ('pascō', 'paść', None, None)], 'sentences': []}, {'id': 'v20d', 'title': 'Czasowniki dnia codziennego 4', 'icon': 'C', 'track': 'jezyk', 'words': [('mulgeō', 'doić', None, None), ('tondeō', 'strzyc', None, None), ('texō', 'tkać', None, None), ('nēō', 'prząść', None, None), ('suō', 'szyć', None, None), ('pinsō', 'piec chleb', None, None), ('molō', 'mleć', None, None), ('fingō', 'wyrabiać', None, None), ('sculpō', 'rzeźbić', None, None), ('pingō', 'malować', None, None), ('cūdō', 'kuć', None, None), ('liquefaciō', 'topić', None, None), ('fodiō', 'kopać', None, None), ('ligō', 'wiązać', None, None), ('obserō', 'zamykać na klucz', None, None), ('reserō', 'odmykać', None, None)], 'sentences': []}, {'id': 'v20e', 'title': 'Czasowniki dnia codziennego 5', 'icon': 'C', 'track': 'jezyk', 'words': [('cubō', 'kłaść się', None, None), ('cōnsīdō', 'siadać', None, None), ('excitor', 'wstawać', None, None), ('colloquor', 'rozmawiać', None, None), ('clāmō', 'krzyczeć', None, None), ('taceō', 'milczeć', None, None), ('susurrō', 'szeptać', None, None), ('canō', 'śpiewać (pieśń)', None, None), ('psallō', 'grać na lirze', None, None), ('imperō', 'rozkazywać', None, None), ('vetō', 'zabraniać', None, None), ('permittō', 'pozwalać (komuś)', None, None), ('prōmittō', 'obiecywać', None, None), ('iūrō', 'przysięgać', None, None), ('mentior', 'kłamać', None, None), ('coniciō', 'zgadywać', None, None)], 'sentences': []}, {'id': 'v20f', 'title': 'Czasowniki dnia codziennego 6', 'icon': 'C', 'track': 'jezyk', 'words': [('commemorō', 'wspominać', None, None), ('narrō', 'opowiadać', None, None), ('dēscrībō', 'opisywać', None, None), ('interpretor', 'tłumaczyć', None, None), ('appellō', 'nazywać', None, None), ('vocor', 'nazywać się', None, None), ('laudō', 'chwalić', None, None), ('reprehendō', 'ganić', None, None), ('accūsō', 'oskarżać', None, None), ('pūniō', 'karać', None, None), ('remūnerō', 'nagradzać', None, None), ('ignōscō', 'wybaczać', None, None), ('grātiās agō', 'dziękować', None, None), ('salūtō', 'pozdrawiać', None, None), ('valedīcō', 'żegnać', None, None), ('salvēre iubeō', 'witać', None, None)], 'sentences': []}, {'id': 'v21a', 'title': 'Słowa funkcyjne 1', 'icon': 'S', 'track': 'jezyk', 'words': [('hic', 'ten', None, None), ('ille', 'tamten', None, None), ('iste', 'ten (ów)', None, None), ('īdem', 'ten sam', None, None), ('ipse', 'ten (sam z siebie)', None, None), ('hīc', 'tutaj', None, None), ('illīc', 'tam', None, None), ('hinc', 'stąd', None, None), ('illinc', 'stamtąd', None, None), ('quō', 'dokąd', None, None), ('unde', 'skąd', None, None), ('ubi', 'gdzie', None, None), ('quōmodo', 'jak', None, None), ('cūr', 'dlaczego', None, None), ('quis', 'kto', None, None), ('quālis', 'jaki', None, None)], 'sentences': []}, {'id': 'v21b', 'title': 'Słowa funkcyjne 2', 'icon': 'S', 'track': 'jezyk', 'words': [('quot', 'ile', None, None), ('sed', 'ale', None, None), ('aut', 'lub', None, None), ('vel', 'albo', None, None), ('nam', 'bo', None, None), ('quia', 'ponieważ', None, None), ('sī', 'jeśli', None, None), ('quod', 'że', None, None), ('itaque', 'więc', None, None), ('quoque', 'też', None, None), ('tantum', 'tylko', None, None), ('paulum', 'trochę', None, None), ('multum', 'dużo', None, None), ('aliquid', 'coś', None, None), ('nēmō', 'nikt', None, None), ('fortasse', 'może', None, None)], 'sentences': []}, {'id': 'v21c', 'title': 'Słowa funkcyjne 3', 'icon': 'S', 'track': 'jezyk', 'words': [('certē', 'na pewno', None, None), ('simul', 'razem', None, None), ('sine', 'bez', None, None), ('cum', 'z', None, None), ('ab', 'od', None, None), ('prō', 'dla', None, None), ('post', 'po', None, None), ('ante', 'przed', None, None), ('suprā', 'nad', None, None), ('sub', 'pod', None, None), ('iuxtā', 'obok', None, None), ('inter', 'między', None, None), ('contrā', 'przeciw', None, None), ('dē', 'o', None, None), ('apud', 'u', None, None), ('circā', 'około', None, None)], 'sentences': []}, {'id': 'v21d', 'title': 'Słowa funkcyjne 4', 'icon': 'S', 'track': 'jezyk', 'words': [('paene', 'prawie', None, None), ('etiam', 'nawet', None, None), ('iterum', 'jeszcze raz', None, None), ('alicubi', 'gdzieś', None, None), ('nusquam', 'nigdzie', None, None), ('ubīque', 'wszędzie', None, None), ('valdē', 'bardzo', None, None), ('ita', 'tak', None, None), ('num', 'czy (pytanie)', None, None), ('nōnne', 'chyba', None, None), ('at', 'lecz', None, None), ('tamen', 'jednak', None, None), ('quamquam', 'chociaż', None, None), ('dum', 'dopóki', None, None), ('dōnec', 'aż', None, None), ('ex quō', 'odkąd', None, None)], 'sentences': []}, {'id': 'v21e', 'title': 'Słowa funkcyjne 5', 'icon': 'S', 'track': 'jezyk', 'words': [('antequam', 'zanim', None, None), ('umquam', 'kiedykolwiek', None, None), ('nec', 'ani', None, None), ('aut...aut', 'albo...albo', None, None), ('et...et', 'zarówno', None, None), ('tam...quam', 'jak...tak', None, None), ('super', 'nad (górą)', None, None), ('intrā', 'wewnątrz', None, None), ('extrā', 'na zewnątrz', None, None), ('praeter', 'poza', None, None), ('secundum', 'wzdłuż', None, None), ('adversus', 'wbrew', None, None), ('ope', 'za pomocą', None, None), ('grātiā', 'dzięki', None, None), ('locō', 'zamiast', None, None), ('sēcundum', 'według', None, None)], 'sentences': []}, {'id': 'v21f', 'title': 'Słowa funkcyjne 6', 'icon': 'S', 'track': 'jezyk', 'words': [('ā', 'od strony', None, None), ('ē', 'z (wyjść)', None, None), ('ut', 'aby', None, None), ('nē', 'żeby nie', None, None), ('utinam', 'niech', None, None), ('ō sī', 'oby', None, None), ('ne', 'czyż', None, None), ('nempe', 'otóż', None, None), ('scīlicet', 'oczywiście', None, None), ('vidēlicet', 'mianowicie', None, None), ('igitur', 'zatem', None, None), ('enim', 'albowiem', None, None), ('autem', 'zaś', None, None), ('vērō', 'natomiast', None, None), ('quidem', 'przecież', None, None), ('ipsum', 'właśnie', None, None)], 'sentences': []}, {'id': 'v21g', 'title': 'Słowa funkcyjne 7', 'icon': 'S', 'track': 'jezyk', 'words': [('nōn iam', 'już nie', None, None), ('nōndum', 'jeszcze nie', None, None), ('numquam iterum', 'nigdy więcej', None, None)], 'sentences': []}, {'id': 'v22a', 'title': 'Świat i społeczeństwo 1', 'icon': 'Ś', 'track': 'jezyk', 'words': [('patria', 'kraj', None, 'rodzaj żeński'), ('cīvitās', 'państwo', None, 'rodzaj żeński'), ('rēs pūblica', 'republika', None, 'rodzaj żeński'), ('verbum', 'słowo', None, 'rodzaj nijaki'), ('cognōmen', 'przydomek', None, 'rodzaj nijaki'), ('historia', 'historia', None, 'rodzaj żeński'), ('cultūra', 'kultura', None, 'rodzaj żeński'), ('religiō', 'religia', None, 'rodzaj żeński'), ('deus', 'bóg', None, 'rodzaj męski'), ('dea', 'bogini', None, 'rodzaj żeński'), ('bellum', 'wojna', None, 'rodzaj nijaki'), ('pāx', 'pokój', None, 'rodzaj żeński'), ('lībertās', 'wolność', None, 'rodzaj żeński'), ('potestās', 'władza', None, 'rodzaj żeński'), ('administrātiō', 'rząd', None, 'rodzaj żeński'), ('comitia', 'wybory', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v22b', 'title': 'Świat i społeczeństwo 2', 'icon': 'Ś', 'track': 'jezyk', 'words': [('causa', 'powód', None, 'rodzaj żeński'), ('ēventus', 'wynik', None, 'rodzaj męski'), ('modus', 'sposób', None, 'rodzaj męski'), ('initium', 'początek', None, 'rodzaj nijaki'), ('pars', 'część', None, 'rodzaj żeński'), ('locus', 'miejsce', None, 'rodzaj męski'), ('rēs', 'rzecz', None, 'rodzaj żeński'), ('negōtium', 'sprawa', None, 'rodzaj nijaki'), ('nūntium', 'wiadomość', None, 'rodzaj nijaki'), ('epistula', 'list', None, 'rodzaj żeński'), ('ācta diurna', 'gazeta', None, 'rodzaj nijaki'), ('mūsica', 'muzyka', None, 'rodzaj żeński'), ('carmen', 'piosenka', None, 'rodzaj nijaki'), ('pictūra', 'obraz', None, 'rodzaj żeński'), ('certāmen', 'sport', None, 'rodzaj nijaki'), ('factiō', 'drużyna', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22c', 'title': 'Świat i społeczeństwo 3', 'icon': 'Ś', 'track': 'jezyk', 'words': [('pila', 'piłka', None, 'rodzaj żeński'), ('iocus', 'zabawa', None, 'rodzaj męski'), ('ēlēctiō', 'wybór', None, 'rodzaj żeński'), ('error', 'błąd', None, 'rodzaj męski'), ('mendācium', 'kłamstwo', None, 'rodzaj nijaki'), ('arcānum', 'tajemnica', None, 'rodzaj nijaki'), ('vīs', 'siła', None, 'rodzaj żeński'), ('vigor', 'energia', None, 'rodzaj męski'), ('sonus', 'dźwięk', None, 'rodzaj męski'), ('silentium', 'cisza', None, 'rodzaj nijaki'), ('mōtus', 'ruch', None, 'rodzaj męski'), ('mūtātiō', 'zmiana', None, 'rodzaj żeński'), ('differentia', 'różnica', None, 'rodzaj żeński'), ('exemplum', 'przykład', None, 'rodzaj nijaki'), ('tōtum', 'całość', None, 'rodzaj nijaki'), ('nātiō', 'naród', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22d', 'title': 'Świat i społeczeństwo 4', 'icon': 'Ś', 'track': 'jezyk', 'words': [('populus', 'lud', None, 'rodzaj męski'), ('turba', 'tłum', None, 'rodzaj żeński'), ('plēbs', 'plebs', None, 'rodzaj żeński'), ('nōbilitās', 'szlachta', None, 'rodzaj żeński'), ('senātus', 'senat (instytucja)', None, 'rodzaj męski'), ('exercitus', 'armia', None, 'rodzaj męski'), ('legiō', 'legion', None, 'rodzaj żeński'), ('cohors', 'kohorta', None, 'rodzaj żeński'), ('proelium', 'bitwa', None, 'rodzaj nijaki'), ('victōria', 'zwycięstwo', None, 'rodzaj żeński'), ('clādēs', 'klęska', None, 'rodzaj żeński'), ('dēbellātiō', 'pokonanie', None, 'rodzaj żeński'), ('obses', 'zakładnik', None, 'rodzaj męski'), ('captīvus', 'jeniec', None, 'rodzaj męski'), ('spolia', 'łup wojenny', None, 'rodzaj nijaki'), ('triumphus', 'triumf', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v22e', 'title': 'Świat i społeczeństwo 5', 'icon': 'Ś', 'track': 'jezyk', 'words': [('gladius', 'miecz', None, 'rodzaj męski'), ('hasta', 'włócznia', None, 'rodzaj żeński'), ('pīlum', 'dzida', None, 'rodzaj nijaki'), ('scūtum', 'tarcza', None, 'rodzaj nijaki'), ('galea', 'hełm', None, 'rodzaj żeński'), ('lōrīca', 'pancerz', None, 'rodzaj żeński'), ('sagitta', 'strzała', None, 'rodzaj żeński'), ('funda', 'proca', None, 'rodzaj żeński'), ('māchina', 'machina oblężnicza', None, 'rodzaj żeński'), ('impetus', 'szturm', None, 'rodzaj męski'), ('obsidiō', 'oblężenie', None, 'rodzaj żeński'), ('fuga', 'ucieczka', None, 'rodzaj żeński'), ('sacrificium', 'ofiara', None, 'rodzaj nijaki'), ('precātiō', 'modlitwa', None, 'rodzaj żeński'), ('āra', 'ołtarz', None, 'rodzaj żeński'), ('aedēs', 'świątynia (budynek)', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22f', 'title': 'Świat i społeczeństwo 6', 'icon': 'Ś', 'track': 'jezyk', 'words': [('numen', 'bożek', None, 'rodzaj nijaki'), ('anima', 'dusza', None, 'rodzaj żeński'), ('mānēs', 'cień zmarłych', None, 'rodzaj męski'), ('Orcus', 'podziemie', None, 'rodzaj męski'), ('Olympus', 'niebo (siedziba)', None, 'rodzaj męski'), ('augurium', 'wróżba', None, 'rodzaj nijaki'), ('ōrāculum', 'wyrocznia', None, 'rodzaj nijaki'), ('signum', 'znak', None, 'rodzaj nijaki'), ('mīrāculum', 'cud', None, 'rodzaj nijaki'), ('exsecrātiō', 'przekleństwo', None, 'rodzaj żeński'), ('benedictiō', 'błogosławieństwo', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v23a', 'title': 'Geografia 1', 'icon': 'G', 'track': 'jezyk', 'words': [('septentriō', 'północ', None, 'rodzaj męski'), ('oriēns', 'wschód', None, 'rodzaj męski'), ('occidēns', 'zachód', None, 'rodzaj męski'), ('Polonia', 'Polska', None, 'rodzaj żeński'), ('Eurōpa', 'Europa', None, 'rodzaj żeński'), ('Germānia', 'Niemcy', None, 'rodzaj żeński'), ('Ītalia', 'Włochy', None, 'rodzaj żeński'), ('Hispānia', 'Hiszpania', None, 'rodzaj żeński'), ('Russia', 'Rosja', None, 'rodzaj żeński'), ('Britannia', 'Anglia', None, 'rodzaj żeński'), ('Americā', 'Ameryka', None, 'rodzaj żeński'), ('Sīnae', 'Chiny', None, 'rodzaj żeński'), ('Iāpōnia', 'Japonia', None, 'rodzaj żeński'), ('Āfrica', 'Afryka', None, 'rodzaj żeński'), ('Asia', 'Azja', None, 'rodzaj żeński'), ('continēns', 'kontynent', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v23b', 'title': 'Geografia 2', 'icon': 'G', 'track': 'jezyk', 'words': [('Graecia', 'Grecja', None, 'rodzaj żeński'), ('Aegyptus', 'Egipt', None, 'rodzaj żeński'), ('Syria', 'Syria', None, 'rodzaj żeński'), ('Iūdaea', 'Judea', None, 'rodzaj żeński'), ('Carthāgō', 'Kartagina', None, 'rodzaj żeński'), ('Athēnae', 'Ateny', None, 'rodzaj żeński'), ('Sparta', 'Sparta', None, 'rodzaj żeński'), ('Troia', 'Troja', None, 'rodzaj żeński'), ('Neāpolis', 'Neapol', None, 'rodzaj żeński'), ('Pompēiī', 'Pompeje', None, 'rodzaj męski'), ('Tiberis', 'Tyber', None, 'rodzaj męski'), ('Rhēnus', 'Ren', None, 'rodzaj męski'), ('Dānuvius', 'Dunaj', None, 'rodzaj męski'), ('Alpēs', 'Alpy', None, 'rodzaj żeński'), ('Appenīnus', 'Apeniny', None, 'rodzaj męski'), ('mare nostrum', 'Morze Śródziemne', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v23c', 'title': 'Geografia 3', 'icon': 'G', 'track': 'jezyk', 'words': [('Ōceanus', 'Ocean Atlantycki', None, 'rodzaj męski'), ('Sicilia', 'Sycylia', None, 'rodzaj żeński'), ('Sardinia', 'Sardynia', None, 'rodzaj żeński'), ('Corsica', 'Korsyka', None, 'rodzaj żeński'), ('Dacia', 'Dacja', None, 'rodzaj żeński'), ('Pannonia', 'Panonia', None, 'rodzaj żeński'), ('Asia Minor', 'Azja Mniejsza', None, 'rodzaj żeński'), ('Persia', 'Persja', None, 'rodzaj żeński'), ('India', 'Indie', None, 'rodzaj żeński'), ('Aethiopia', 'Etiopia', None, 'rodzaj żeński'), ('Libya', 'Libia', None, 'rodzaj żeński'), ('Numidia', 'Numidia', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v24a', 'title': 'Materiały i przedmioty 1', 'icon': 'M', 'track': 'jezyk', 'words': [('frustum', 'kawałek', None, 'rodzaj nijaki'), ('gutta', 'kropla', None, 'rodzaj żeński'), ('capsa', 'pudełko', None, 'rodzaj żeński'), ('saccus', 'worek', None, 'rodzaj męski'), ('filum aeneum', 'drut', None, 'rodzaj nijaki'), ('forfex', 'nożyczki', None, 'rodzaj żeński'), ('bacillum', 'kij', None, 'rodzaj nijaki'), ('restis', 'lina', None, 'rodzaj żeński'), ('glūten', 'klej', None, 'rodzaj nijaki'), ('pigmentum', 'farba', None, 'rodzaj nijaki'), ('vitrum', 'szkło', None, 'rodzaj nijaki'), ('lignum', 'drewno', None, 'rodzaj nijaki'), ('metallum', 'metal', None, 'rodzaj nijaki'), ('aurum', 'złoto', None, 'rodzaj nijaki'), ('argentum', 'srebro', None, 'rodzaj nijaki'), ('ferrum', 'żelazo', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v24b', 'title': 'Materiały i przedmioty 2', 'icon': 'M', 'track': 'jezyk', 'words': [('aes', 'miedź', None, 'rodzaj nijaki'), ('plumbum', 'ołów', None, 'rodzaj nijaki'), ('stannum', 'cyna', None, 'rodzaj nijaki'), ('ēlectrum', 'bursztyn', None, 'rodzaj nijaki'), ('ebur', 'kość słoniowa', None, 'rodzaj nijaki'), ('sabulum', 'piasek', None, 'rodzaj nijaki'), ('pulvis', 'kurz', None, 'rodzaj męski'), ('carbō', 'węgiel', None, 'rodzaj męski'), ('pix', 'smoła', None, 'rodzaj żeński'), ('cēra', 'wosk', None, 'rodzaj żeński'), ('sāl marīnus', 'sól morska', None, 'rodzaj męski'), ('forceps', 'szczypce', None, 'rodzaj męski'), ('bipennis', 'siekiera', None, 'rodzaj żeński'), ('crībrum', 'sito', None, 'rodzaj nijaki'), ('stīpes', 'kłoda', None, 'rodzaj męski'), ('asser', 'deska', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v24c', 'title': 'Materiały i przedmioty 3', 'icon': 'M', 'track': 'jezyk', 'words': [('strāmen', 'słoma', None, 'rodzaj nijaki'), ('faenum', 'siano', None, 'rodzaj nijaki'), ('harundō', 'trzcina', None, 'rodzaj żeński'), ('papȳrus', 'papirus', None, 'rodzaj żeński'), ('tabella', 'tabliczka', None, 'rodzaj żeński'), ('sigillum', 'pieczęć', None, 'rodzaj nijaki'), ('clāvis arcae', 'klucz do skrzyni', None, 'rodzaj żeński'), ('mēnsūra', 'miara', None, 'rodzaj żeński'), ('lībra', 'waga', None, 'rodzaj żeński'), ('pondus', 'ciężar', None, 'rodzaj nijaki'), ('fiscus', 'kosz wiklinowy', None, 'rodzaj męski'), ('olla', 'dzban gliniany', None, 'rodzaj żeński'), ('sartāgō', 'patelnia', None, 'rodzaj żeński'), ('aenum', 'rondel', None, 'rodzaj nijaki'), ('lagoena', 'flaszka', None, 'rodzaj żeński'), ('ampulla', 'fiolka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v24d', 'title': 'Materiały i przedmioty 4', 'icon': 'M', 'track': 'jezyk', 'words': [('vās', 'naczynie', None, 'rodzaj nijaki'), ('ūrna', 'urna', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v25a', 'title': 'Kierunki i miejsca 1', 'icon': 'K', 'track': 'jezyk', 'words': [('sursum', 'góra (kierunek)', None, None), ('deorsum', 'dół', None, None), ('retrō', 'tył', None, None), ('medium', 'środek', None, 'rodzaj nijaki'), ('intus', 'wewnątrz', None, None), ('forīs', 'na zewnątrz', None, None), ('procul', 'daleko', None, None), ('prope', 'blisko', None, None), ('altē', 'wysoko', None, None), ('humiliter', 'nisko', None, None), ('celeriter', 'szybko', None, None), ('lentē', 'wolno', None, None), ('bene', 'dobrze', None, None), ('male', 'źle', None, None), ('facile', 'łatwo', None, None), ('difficile', 'trudno', None, None)], 'sentences': []}, {'id': 'v25b', 'title': 'Kierunki i miejsca 2', 'icon': 'K', 'track': 'jezyk', 'words': [('sēparātim', 'osobno', None, None), ('trānsversē', 'w poprzek', None, None), ('circum', 'dokoła', None, None), ('dextrō', 'na prawo', None, None), ('sinistrō', 'na lewo', None, None), ('rēctā', 'prosto', None, None), ('hūc', 'tutaj (kierunek)', None, None), ('illūc', 'tam (kierunek)', None, None), ('prōrsus', 'w przód', None, None), ('domum', 'do domu', None, None), ('domō', 'z domu', None, None), ('peregrē', 'za granicą', None, None), ('in urbe', 'w mieście', None, None), ('rūrī', 'na wsi', None, None), ('in agrō', 'w polu', None, None), ('in marī', 'na morzu', None, None)], 'sentences': []}, {'id': 'v25c', 'title': 'Kierunki i miejsca 3', 'icon': 'K', 'track': 'jezyk', 'words': [('aliubi', 'wszędzie indziej', None, None), ('nusquam alibi', 'nigdzie indziej', None, None)], 'sentences': []}, {'id': 'v26a', 'title': 'Więcej jedzenia i życia 1', 'icon': 'W', 'track': 'jezyk', 'words': [('passum', 'rodzynek', None, 'rodzaj nijaki'), ('amygdala', 'migdał', None, 'rodzaj żeński'), ('palma', 'daktyl', None, 'rodzaj żeński'), ('mālum Pūnicum', 'granat (owoc)', None, 'rodzaj nijaki'), ('citrum', 'cytryna', None, 'rodzaj nijaki'), ('melō', 'melon', None, 'rodzaj męski'), ('pepō', 'arbuz', None, 'rodzaj męski'), ('castanea', 'kasztan', None, 'rodzaj żeński'), ('glāns', 'żołądź', None, 'rodzaj żeński'), ('fāgus', 'bukiew', None, 'rodzaj żeński'), ('papāver', 'mak', None, 'rodzaj nijaki'), ('cumīnum', 'kminek', None, 'rodzaj nijaki'), ('menta', 'mięta', None, 'rodzaj żeński'), ('rūta', 'ruta', None, 'rodzaj żeński'), ('crocus', 'szafran', None, 'rodzaj męski'), ('cinnamōmum', 'cynamon', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v26b', 'title': 'Więcej jedzenia i życia 2', 'icon': 'W', 'track': 'jezyk', 'words': [('zingiber', 'imbir', None, 'rodzaj nijaki'), ('coriandrum', 'kolendra', None, 'rodzaj nijaki'), ('anēthum', 'koperek', None, 'rodzaj nijaki'), ('petroselīnum', 'pietruszka', None, 'rodzaj nijaki'), ('raphanus', 'rzodkiewka', None, 'rodzaj męski'), ('rāpa', 'rzepa', None, 'rodzaj żeński'), ('bēta', 'burak', None, 'rodzaj żeński'), ('porrum', 'por', None, 'rodzaj nijaki'), ('apium', 'seler', None, 'rodzaj nijaki'), ('asparagus', 'szparagi', None, 'rodzaj męski'), ('cinara', 'karczoch', None, 'rodzaj żeński'), ('fungus', 'grzyb', None, 'rodzaj męski'), ('tūber', 'trufla', None, 'rodzaj nijaki'), ('oleum olīvārium', 'oliwa', None, 'rodzaj nijaki'), ('triticum', 'pszenica', None, 'rodzaj nijaki'), ('hordeum', 'jęczmień', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v26c', 'title': 'Więcej jedzenia i życia 3', 'icon': 'W', 'track': 'jezyk', 'words': [('avēna', 'owies', None, 'rodzaj żeński'), ('secale', 'żyto', None, 'rodzaj nijaki'), ('milium', 'proso', None, 'rodzaj nijaki'), ('ōryza', 'ryż', None, 'rodzaj żeński'), ('pānis siligineus', 'chleb pszenny', None, 'rodzaj męski'), ('pānis parvus', 'bułeczka', None, 'rodzaj męski'), ('lībum', 'placek', None, 'rodzaj nijaki'), ('lac ovillum', 'mleko owcze', None, 'rodzaj nijaki'), ('flōs lactis', 'śmietanka', None, 'rodzaj męski'), ('oxygala', 'jogurt', None, 'rodzaj nijaki'), ('lucānica', 'kiełbasa (rzymska)', None, 'rodzaj żeński'), ('lardum', 'wędzonka', None, 'rodzaj nijaki'), ('lārīdum', 'słonina', None, 'rodzaj nijaki'), ('sēbum', 'łój', None, 'rodzaj nijaki'), ('axungia', 'smalec', None, 'rodzaj żeński'), ('acētum vīnāria', 'ocet winny', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v26d', 'title': 'Więcej jedzenia i życia 4', 'icon': 'W', 'track': 'jezyk', 'words': [('mustum', 'wino młode', None, 'rodzaj nijaki'), ('vīnum vetus', 'wino stare', None, 'rodzaj nijaki'), ('zythum', 'piwo (jęczmienne)', None, 'rodzaj nijaki'), ('hydromeli', 'woda z miodem', None, 'rodzaj nijaki'), ('calda', 'gorąca woda', None, 'rodzaj żeński'), ('aqua frīgida', 'zimna woda', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v27a', 'title': 'Rodzina i obyczaje 1', 'icon': 'R', 'track': 'jezyk', 'words': [('socer', 'teść', None, 'rodzaj męski'), ('socrus', 'teściowa', None, 'rodzaj żeński'), ('gener', 'szwagier', None, 'rodzaj męski'), ('frātris fīlius', 'bratanek', None, 'rodzaj męski'), ('sorōris fīlia', 'siostrzenica', None, 'rodzaj żeński'), ('orbus', 'sierota', None, 'rodzaj męski'), ('vidua', 'wdowa', None, 'rodzaj żeński'), ('sponsus', 'narzeczony', None, 'rodzaj męski'), ('sponsa', 'narzeczona', None, 'rodzaj żeński'), ('nuptiae', 'ślub', None, 'rodzaj żeński'), ('dīvortium', 'rozwód', None, 'rodzaj nijaki'), ('nātīvitās', 'urodzenie', None, 'rodzaj żeński'), ('fūnus', 'pogrzeb', None, 'rodzaj nijaki'), ('crematiō', 'kremacja', None, 'rodzaj żeński'), ('monumentum gentis', 'grób rodzinny', None, 'rodzaj nijaki'), ('gēns', 'imię rodowe', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v27b', 'title': 'Rodzina i obyczaje 2', 'icon': 'R', 'track': 'jezyk', 'words': [('stirps', 'ród', None, 'rodzaj żeński'), ('māior', 'przodek', None, 'rodzaj męski'), ('posterus', 'potomek', None, 'rodzaj męski'), ('cognātus', 'krewny', None, 'rodzaj męski'), ('affīnis', 'powinowaty', None, 'rodzaj męski'), ('tūtor', 'opiekun', None, 'rodzaj męski'), ('adōptīvus', 'adoptowany', None, 'rodzaj męski'), ('spurius', 'bękart', None, 'rodzaj męski'), ('verna', 'niewolnik domowy', None, 'rodzaj męski'), ('paedagōgus', 'wychowawca', None, 'rodzaj męski'), ('nūtrix', 'piastunka', None, 'rodzaj żeński'), ('fētus', 'dziecko (płód)', None, 'rodzaj męski'), ('īnfāns recēns nātus', 'noworodek', None, 'rodzaj męski'), ('mātrimōnium', 'małżeństwo', None, 'rodzaj nijaki'), ('testāmentum', 'testament', None, 'rodzaj nijaki'), ('hērēs', 'spadkobierca', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v27c', 'title': 'Rodzina i obyczaje 3', 'icon': 'R', 'track': 'jezyk', 'words': [('patrimōnium', 'majątek rodzinny', None, 'rodzaj nijaki'), ('dōs', 'posag', None, 'rodzaj żeński'), ('patria potestās', 'władza ojcowska', None, 'rodzaj żeński'), ('māiōrēs', 'przodkowie', None, 'rodzaj męski'), ('Larēs', 'bogowie domowi', None, 'rodzaj męski'), ('genius', 'duch opiekuńczy', None, 'rodzaj męski'), ('hospitium', 'gościnność', None, 'rodzaj nijaki'), ('patrōnus', 'patron', None, 'rodzaj męski'), ('cliēns', 'klient', None, 'rodzaj męski'), ('necessitūdō', 'przyjaźń zawodowa', None, 'rodzaj żeński'), ('pietās', 'miłość ojczyzny', None, 'rodzaj żeński'), ('reverentia', 'szacunek', None, 'rodzaj żeński'), ('auctōritās', 'powaga', None, 'rodzaj żeński'), ('dignitās', 'godność', None, 'rodzaj żeński')], 'sentences': []}]
# === /SŁOWNICTWO ===

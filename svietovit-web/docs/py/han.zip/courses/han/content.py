"""Treść kursu: chińskie znaki (汉字) dla Polaków. Uproszczone, ze znaczkami pinyin.

Kurs uczy samych znaków: zaczyna od jednej kreski i każdy nowy znak opisuje jako złożenie znanych
części. Nie ma tu zdań ani rozmów: te są w kursie 中文 (hanzi_hero), z którym ten kurs się uzupełnia.

Litera:    (znak lub składnik, znaczenie, przykład lub nazwa, uwaga)
Słowo:     (zapis, znaczenie po polsku, polski krewny lub None, z czego złożony)
Końcówka:  (przed, temat, brakujący składnik, po, [opcje], podpowiedź po polsku, wyjaśnienie, dział)

Pinyin każdego znaku jest w pinyin_data.py.
"""

UNITS = [{'id': 'kreski',
  'title': 'Osiem kresek',
  'icon': '一',
  'track': 'kreski',
  'kind': 'stroke',
  'letters': [('一', 'pozioma (héng)', 'héng', 'Z lewej do prawej. Przykłady: 三, 十, 王.'),
              ('丨', 'pionowa (shù)', 'shù', 'Z góry na dół. Przykłady: 十, 中, 山.'),
              ('丿', 'opadająca w lewo (piě)', 'piě', 'Zakrzywiona w dół w lewo, jak piórko. Przykłady: 人, 八, 千.'),
              ('丶', 'kropka (diǎn)', 'diǎn', 'Krótkie pociągnięcie w dół. Przykłady: 火, 小, 主.'),
              ('㇏', 'opadająca w prawo (nà)', 'nà', 'W dół w prawo, z zakończeniem. Przykłady: 人, 大, 八.'),
              ('㇀', 'wznosząca (tí)', 'tí', 'W górę w prawo, krótko. Przykłady: 冰, 地, 打.'),
              ('乛', 'łamana (zhé)', 'zhé', 'Pozioma, potem w dół, z załamaniem. Przykłady: 口, 日, 国.'),
              ('亅', 'haczyk (gōu)', 'gōu', 'Pionowa z haczykiem na końcu. Przykłady: 小, 水, 手.')]},
 {'id': 'klucze',
  'title': 'Klucze: wąskie formy',
  'icon': '氵',
  'track': 'kreski',
  'letters': [('亻', 'człowiek (klucz)', '休', 'Wąska wersja 人, gdy stoi po lewej stronie znaku.'),
              ('扌', 'ręka (klucz)', '打', 'Wąska wersja 手. Czynności ręką: 打 uderzać, 拿 brać.'),
              ('忄', 'serce (klucz)', '情', 'Wąska wersja 心: uczucia, np. 情 uczucie.'),
              ('氵', 'woda (klucz: trzy kropki)', '河', 'Wąska wersja 水. Znaki rzek, mórz i cieczy: 河 rzeka, 海 morze.'),
              ('灬', 'ogień (cztery kropki na dole)', '热', 'Wersja 火 na dole znaku: 热 gorący.'),
              ('艹', 'trawa (na górze)', '花', 'Znaki roślin: 花 kwiat, 茶 herbata.'),
              ('讠', 'mowa (klucz)', '说', 'Uproszczona 言. Znaki mowy: 说 mówić, 请 prosić.'),
              ('钅', 'metal (klucz)', '钱', 'Uproszczona 金. Metale i pieniądze: 钱 pieniądz.'),
              ('饣', 'jedzenie (klucz)', '饭', 'Uproszczona 食. 饭 posiłek, ryż.'),
              ('宀', 'dach', '家', 'Dach nad głową. 家 jiā: dom (świnia pod dachem).'),
              ('辶', 'chód; droga (klucz)', '这', 'Znaki ruchu: 这 to, 过 przejść.'),
              ('刂', 'nóż (po prawej)', '到', 'Wąska wersja 刀. Cięcie: 到 dotrzeć (po prawej).'),
              ('门', 'drzwi; brama', '问', 'Dwoje drzwi. 问 wèn: pytać (usta w drzwiach).'),
              ('车', 'wóz; pojazd', '轮', 'Uproszczony wóz, widziany z góry.')]},
 {'id': 'z1',
  'title': 'Od jednej kreski',
  'icon': '一',
  'track': 'znaki',
  'requires': 'kreski',
  'words': [('一', 'jeden', None, 'Jedna kreska to jeden.'),
            ('二', 'dwa', None, 'Dwie kreski 一, więc logicznie: dwa.'),
            ('三', 'trzy', None, 'Trzy kreski 一, więc trzy.'),
            ('十', 'dziesięć', None, '一 + 丨: kreski się krzyżują. Dziesięć zamyka rachunek na palcach.'),
            ('千', 'tysiąc', None, '丿 + 十: dziesiątka z kreską na górze.'),
            ('土', 'ziemia', None, '十 + 一: krzyż wbity w linię gruntu.'),
            ('王', 'król', None, '三 + 丨: pionowa kreska łączy niebo, ludzi i ziemię.'),
            ('工', 'praca; rzemiosło', None, '二 + 丨: belka między dwiema poziomymi, kątownik cieśli.'),
            ('上', 'góra; nad', None, 'Kreska nad linią 一: to, co wyżej.'),
            ('下', 'dół; pod', None, 'Kreska pod linią 一: to, co niżej.')]},
 {'id': 'z2',
  'title': 'Człowiek i drzewo',
  'icon': '人',
  'track': 'znaki',
  'words': [('人', 'człowiek', None, '丿 + ㇏: dwie kreski oparte o siebie, idący człowiek.'),
            ('八', 'osiem', None, 'Te same kreski co w 人, ale rozsunięte: pierwotnie „dzielić”.'),
            ('个', 'sztuka (klasyfikator)', None, '人 + 丨.'),
            ('大', 'duży', None, '人 + 一: człowiek z rozłożonymi rękami.'),
            ('天', 'niebo; dzień', None, '一 + 大: to, co nad dużym człowiekiem.'),
            ('太', 'zbyt; bardzo', None, '大 + 丶: jeszcze większe niż duże.'),
            ('木', 'drzewo', None, '十 + 八: pień z gałęziami i korzenie.'),
            ('本', 'korzeń; podstawa', None, '木 + 一: kreska zaznacza korzeń drzewa.'),
            ('林', 'gaj', None, '木 + 木: dwa drzewa.'),
            ('森', 'las', None, '木 + 木 + 木: trzy drzewa.'),
            ('从', 'z; od', None, '人 + 人: jeden idzie za drugim.'),
            ('众', 'tłum', None, '人 + 人 + 人: tłum ludzi.')]},
 {'id': 'z3',
  'title': 'Ramka 口',
  'icon': '口',
  'track': 'znaki',
  'words': [('口', 'usta', None, '丨 + 乛 + 一: ramka z trzech kresek, otwarte usta.'),
            ('日', 'słońce; dzień', None, '口 + 一: ramka z kreską w środku, dawniej koło z kropką.'),
            ('目', 'oko', None, '日 + 一: jeszcze jedna kreska. Oko postawione pionowo.'),
            ('田', 'pole', None, '口 + 十: pole podzielone groblami.'),
            ('中', 'środek; w', None, '口 + 丨: kreska przez środek ramki.'),
            ('回', 'wracać', None, '口 w 口: koło w kole, obrót.'),
            ('白', 'biały', None, '丿 + 日: promień nad słońcem.'),
            ('百', 'sto', None, '一 + 白: jedynka nad białym.'),
            ('早', 'wcześnie; rano', None, '日 + 十: słońce wschodzi nad krzyżem.'),
            ('古', 'dawny', None, '十 + 口: opowieść powtórzona przez dziesięć ust.'),
            ('叶', 'liść', None, '口 + 十.'),
            ('品', 'towar; jakość', None, '口 + 口 + 口: trzy ramki, sterta rzeczy.')]},
 {'id': 'z4',
  'title': 'Pozostałe liczby',
  'icon': '五',
  'track': 'znaki',
  'words': [('四', 'cztery', None, '口 + 儿: ramka z dwiema nóżkami w środku.'),
            ('五', 'pięć', None, '二 połączone łamaną kreską w środku.'),
            ('六', 'sześć', None, '亠 (daszek) + 八.'),
            ('七', 'siedem', None, '一 przecięte kreską z haczykiem.'),
            ('九', 'dziewięć', None, '丿 + kreska z haczykiem.'),
            ('万', 'dziesięć tysięcy', None, '一 nad łamaną i 丿. Chińczycy liczą w jednostkach 10 000.')]},
 {'id': 'z5',
  'title': 'Natura',
  'icon': '山',
  'track': 'znaki',
  'words': [('山', 'góra', None, 'Trzy 丨 na jednej linii: trzy szczyty.'),
            ('川', 'rzeka; nurt', None, 'Trzy kreski płyną obok siebie.'),
            ('水', 'woda', None, '亅 w środku i krople po bokach: płynąca woda.'),
            ('火', 'ogień', None, '人 + dwie iskry 丶: płomień.'),
            ('炎', 'płomień; upał', None, '火 + 火: ogień na ogniu.'),
            ('月', 'księżyc; miesiąc', None, 'Ramka z dwiema 一 w środku: sierp księżyca.'),
            ('明', 'jasny', None, '日 + 月: słońce i księżyc razem.'),
            ('石', 'kamień', None, '一 + 丿 + 口: skała pod klifem.'),
            ('小', 'mały', None, '亅 + 八: środek i dwa drobne ziarna po bokach.'),
            ('少', 'mało', None, '小 + 丿: z małego jeszcze ubywa.'),
            ('尖', 'ostry; szpiczasty', None, '小 + 大: małe na dużym, zwęża się ku górze.'),
            ('生', 'żyć; rodzić się', None, '丿 + 一 + 土: roślina wyrasta z ziemi.'),
            ('雨', 'deszcz', None, '一 + ramka + cztery 丶: krople pod chmurą.')]},
 {'id': 'z6',
  'title': 'Ciało i rodzina',
  'icon': '好',
  'track': 'znaki',
  'requires': 'klucze',
  'words': [('手', 'ręka', None, '丿 + 二 + 亅: dłoń z palcami.'),
            ('看', 'patrzeć', None, '手 + 目: ręka nad okiem, osłaniasz oczy.'),
            ('心', 'serce', None, 'Zakrzywiona kreska i trzy 丶: serce z komorami.'),
            ('耳', 'ucho', None, '目 z wydłużonymi kreskami: małżowina ucha.'),
            ('足', 'stopa', None, '口 + 止: kolano nad stopą.'),
            ('女', 'kobieta', None, 'Trzy kreski: klęcząca kobieta.'),
            ('子', 'dziecko', None, '了 + 一: dziecko owinięte w kocyk, z rozłożonymi rączkami.'),
            ('好', 'dobry', None, '女 + 子: kobieta z dzieckiem, dobrze jest.'),
            ('力', 'siła', None, 'Dwie kreski: napięte ramię.'),
            ('男', 'mężczyzna', None, '田 + 力: siła na polu.'),
            ('休', 'odpoczywać', None, '亻 + 木: człowiek pod drzewem.')]},
 {'id': 'z7',
  'title': 'Znaczenie i dźwięk',
  'icon': '请',
  'track': 'znaki',
  'requires': 'klucze',
  'words': [('青', 'zielony; niebieski', None, 'Wspólna część fonetyczna rodziny: qīng, qíng, qǐng.'),
            ('清', 'czysty', None, '氵 (woda) + 青: czysta woda. Czytanie: qīng.'),
            ('请', 'proszę; prosić', None, '讠 (mowa) + 青: prośba słowami. Czytanie: qǐng.'),
            ('情', 'uczucie', None, '忄 (serce) + 青: uczucie. Czytanie: qíng.'),
            ('晴', 'pogodny; bezchmurny', None, '日 (słońce) + 青: słoneczna pogoda. Czytanie: qíng.'),
            ('马', 'koń', None, 'Uproszczony obraz konia z grzywą. Czytanie: mǎ.'),
            ('妈', 'mama', None, '女 (kobieta) + 马: znaczenie „kobieta”, dźwięk mǎ → mā.'),
            ('吗', '(partykuła pytająca)', None, '口 (usta) + 马: dźwięk ma, znaczenie „mówić”. Robi pytanie.'),
            ('可', 'móc; można', None, 'Część fonetyczna kě, np. w 河 hé.'),
            ('河', 'rzeka', None, '氵 (woda) + 可: znaczenie „woda”, dźwięk kě → hé.')]},
 {'id': 'z8',
  'title': 'Częste znaki',
  'icon': '我',
  'track': 'znaki',
  'words': [('我', 'ja', None, '手 + 戈: ręka z włócznią, „ja sam”.'),
            ('你', 'ty', None, '亻 + 尔.'),
            ('他', 'on', None, '亻 + 也.'),
            ('她', 'ona', None, '女 + 也: ta sama wymowa co 他.'),
            ('们', '(liczba mnoga)', None, '亻 + 门; po zaimku daje liczbę mnogą: 我们.'),
            ('的', '(partykuła przynależności)', None, '白 + 勺. Jak polski dopełniacz: 我的 = mój.'),
            ('是', 'być; to jest', None, '日 + 正: słońce nad tym, co prawe.'),
            ('不', 'nie', None, '一 + 丿 + 丨 + 丶. Stawia się przed czasownikiem: 不是 = nie jest.'),
            ('有', 'mieć; jest', None, 'Ręka nad 月: trzymać coś w ręce.'),
            ('在', 'być w; w', None, 'Kreski 一 丿 丨 + 土: stać na ziemi.')]},
 {'id': 'z9',
  'title': 'Więcej znaków',
  'icon': '国',
  'track': 'znaki',
  'words': [('国', 'kraj', None, 'Duża ramka 囗 + 玉 (王 + 丶, jadeit): klejnot w granicach.'),
            ('学', 'uczyć się', None, 'Trzy kreski + daszek 冖 + 子: dziecko pod dachem szkoły.'),
            ('老', 'stary; doświadczony', None, '土 + 丿 + 匕: zgarbiony człowiek z laską.'),
            ('师', 'mistrz; nauczyciel', None, 'Dwie kreski + 一 + 巾.'),
            ('爱', 'kochać', None, 'Ręka u góry + 冖 + 友 (przyjaciel).'),
            ('家', 'dom; rodzina', None, '宀 + 豕: świnia pod dachem.'),
            ('吃', 'jeść', None, '口 + 乞. Czytanie: chī.'),
            ('喝', 'pić', None, '口 + 曷. Czytanie: hē.'),
            ('去', 'iść; jechać', None, '土 + 厶.'),
            ('来', 'przychodzić', None, '一 + 米: kłos zboża, dar, który przyszedł.')]},
 {'id': 'z10',
  'title': 'Słowa ze znanych znaków',
  'icon': '明',
  'track': 'znaki',
  'words': [('大人', 'dorosły', None, '大 + 人: duży człowiek.'),
            ('人口', 'ludność', None, '人 + 口: ludzie liczeni na usta.'),
            ('火山', 'wulkan', None, '火 + 山: ognista góra.'),
            ('明天', 'jutro', None, '明 + 天: jasny dzień, który nadejdzie.'),
            ('日本', 'Japonia', None, '日 + 本: korzeń słońca, kraj wschodzącego słońca.'),
            ('中国', 'Chiny', None, '中 + 国: państwo środka.'),
            ('木工', 'stolarz', None, '木 + 工: praca w drewnie.'),
            ('小心', 'ostrożnie; uważaj', None, '小 + 心: małe serce, czyli uwaga.'),
            ('好看', 'ładny', None, '好 + 看: dobrze się patrzy.'),
            ('女王', 'królowa', None, '女 + 王: kobieta król.'),
            ('学生', 'uczeń; student', None, '学 + 生: ten, kto rodzi się do nauki.'),
            ('老师', 'nauczyciel', None, '老 + 师: stary mistrz.'),
            ('我们', 'my', None, '我 + 们 (liczba mnoga).'),
            ('你好', 'cześć; dzień dobry', None, '你 + 好: dosłownie „ty dobry”.')]}]

TRACKS = {'kreski': '笔画 · KRESKI I KLUCZE', 'znaki': '汉字 · ZNAKI'}

INSIGHTS = {'kreski': [{'title': 'Kolejność kresek',
             'text': 'Pisze się od lewej do prawej i od góry do dołu. Przy skrzyżowaniu pozioma przed pionową: 十 zaczyna się od 一. Środek przed bokami: 小 (najpierw '
                     'środkowa, potem boczne). Ramkę 口 zamyka się od dołu na końcu. Kolejność nie jest ozdobą, dzięki niej znaki wychodzą równe i szybciej się pisze.',
             'chain': []}],
 'klucze': [{'title': 'Jeden składnik, dwie postaci',
             'text': 'Wiele znaków zmienia kształt, gdy staje się kluczem innego znaku: 人 → 亻, 手 → 扌, 心 → 忄, 水 → 氵. Znaczą to samo, tylko są węższe, żeby zmieścić się '
                     'obok. Klucz podpowiada kategorię: 氵 to ciecze (河 rzeka), 讠 to mowa (说 mówić), 饣 to jedzenie (饭 posiłek).',
             'chain': []}],
 'z1': [{'title': 'Znaki rosną z kresek',
         'text': 'Jedna kreska to 一 (jeden). Dwie to 二, trzy to 三. Dodaj pionową 丨 i masz 十 (dziesięć); postaw 十 na linii i wychodzi 土 (ziemia). Każdy nowy znak w tym '
                 'kursie składa się z kresek i znaków, które już znasz, więc zamiast zapamiętywać obrazek, czytasz przepis.',
         'chain': []}],
 'z2': [{'title': 'Powtórzenie wzmacnia',
         'text': 'Ten sam znak powtórzony daje „więcej tego samego”: 木 drzewo, 林 gaj, 森 las; 人 człowiek, 从 iść za kimś, 众 tłum. Jedna dodana kreska też zmienia '
                 'znaczenie: 大 duży, 天 niebo, 太 zbyt.',
         'chain': []}],
 'z3': [{'title': 'Jedna ramka, wiele znaków',
         'text': 'Ramka 口 to usta, ale też cegiełka. Z kreską w środku to 日 (słońce), z dwiema 目 (oko), z krzyżem 田 (pole), z kreską na wylot 中 (środek). Policz kreski '
                 'w środku, a odróżnisz je bez trudu.',
         'chain': []}],
 'z7': [{'title': 'Znaczenie plus dźwięk',
         'text': 'Większość znaków to składniki znaczeniowy i fonetyczny. Rodzina 青 qīng: 清 qīng (czysty), 请 qǐng (proszę), 情 qíng (uczucie), 晴 qíng (pogodny). Dźwięk '
                 'wskazuje 青, znaczenie wybiera składnik obok: woda, mowa, serce, słońce. Podobnie 马 mǎ: 妈 mā (mama), 吗 ma (pytanie).',
         'chain': []}],
 'z10': [{'title': 'Słowa to też złożenia',
          'text': 'Większość chińskich słów ma dwa znaki, a ich znaczenia się sumują: 火 + 山 = 火山 (wulkan), 大 + 人 = 大人 (dorosły), 小 + 心 = 小心 (ostrożnie). Znając znaki, '
                  'często zgadniesz słowo, którego nigdy nie widziałeś. Zdania z tymi słowami ćwiczysz w kursie 中文.',
          'chain': []}]}

ENDINGS_INSIGHT = {'text': 'Wiele znaków składa się z dwóch części: znaczeniowej i fonetycznej albo z dwóch znaczeniowych. Gdy znasz jedną część, reszta wynika ze znaczenia znaku. Ćwicz '
         'to jak łamigłówkę.',
 'title': 'Zgadnij brakujący składnik'}

ENDINGS = [('', '一 ＋ ', '一', ' ＝ 二', ['一', '丨', '人', '口'], 'dwa: jedna kreska + ?', '二 = 一 + 一.', 'z1'),
 ('', '一 ＋ ', '丨', ' ＝ 十', ['丨', '一', '丿', '丶'], 'dziesięć: pozioma + ?', '十 = 一 + 丨.', 'z1'),
 ('', '十 ＋ ', '一', ' ＝ 土', ['一', '丨', '口', '人'], 'ziemia: krzyż + ?', '土 = 十 + 一.', 'z1'),
 ('', '三 ＋ ', '丨', ' ＝ 王', ['丨', '一', '人', '丶'], 'król: trzy kreski + ?', '王 = 三 + 丨.', 'z1'),
 ('', '人 ＋ ', '一', ' ＝ 大', ['一', '丨', '丶', '八'], 'duży: człowiek + ?', '大 = 人 + 一.', 'z2'),
 ('', '一 ＋ ', '大', ' ＝ 天', ['大', '人', '木', '十'], 'niebo: kreska nad ?', '天 = 一 + 大.', 'z2'),
 ('', '大 ＋ ', '丶', ' ＝ 太', ['丶', '一', '丨', '人'], 'zbyt: duży + ?', '太 = 大 + 丶.', 'z2'),
 ('', '木 ＋ ', '一', ' ＝ 本', ['一', '丶', '人', '木'], 'korzeń: drzewo + ?', '本 = 木 + 一.', 'z2'),
 ('', '木 ＋ ', '木', ' ＝ 林', ['木', '人', '大', '十'], 'gaj: drzewo + ?', '林 = 木 + 木.', 'z2'),
 ('', '口 ＋ ', '一', ' ＝ 日', ['一', '十', '丨', '人'], 'słońce: ramka + ?', '日 = 口 + 一.', 'z3'),
 ('', '口 ＋ ', '十', ' ＝ 田', ['十', '一', '丨', '木'], 'pole: ramka + ?', '田 = 口 + 十.', 'z3'),
 ('', '口 ＋ ', '丨', ' ＝ 中', ['丨', '一', '十', '人'], 'środek: ramka + ?', '中 = 口 + 丨.', 'z3'),
 ('', '一 ＋ ', '白', ' ＝ 百', ['白', '日', '口', '田'], 'sto: jeden + ?', '百 = 一 + 白.', 'z3'),
 ('', '日 ＋ ', '月', ' ＝ 明', ['月', '木', '日', '山'], 'jasny: słońce + ?', '明 = 日 (słońce) + 月 (księżyc).', 'z5'),
 ('', '小 ＋ ', '大', ' ＝ 尖', ['大', '人', '木', '山'], 'ostry: mały na ?', '尖 = 小 + 大.', 'z5'),
 ('', '火 ＋ ', '火', ' ＝ 炎', ['火', '山', '水', '人'], 'płomień: ogień + ?', '炎 = 火 + 火.', 'z5'),
 ('', '女 ＋ ', '子', ' ＝ 好', ['子', '马', '日', '口'], 'dobry: kobieta + ?', '好 = 女 (kobieta) + 子 (dziecko).', 'z6'),
 ('', '田 ＋ ', '力', ' ＝ 男', ['力', '人', '大', '十'], 'mężczyzna: pole + ?', '男 = 田 (pole) + 力 (siła).', 'z6'),
 ('', '手 ＋ ', '目', ' ＝ 看', ['目', '口', '耳', '心'], 'patrzeć: ręka nad ?', '看 = 手 (ręka) + 目 (oko).', 'z6'),
 ('', '亻 ＋ ', '木', ' ＝ 休', ['木', '日', '口', '水'], 'odpoczynek: człowiek + ?', '休 = 亻 (człowiek) + 木 (drzewo).', 'z6'),
 ('', '氵 ＋ ', '青', ' ＝ 清', ['青', '马', '可', '月'], 'czysty: woda + ?', '清 qīng: 氵 (woda) + część fonetyczna 青 qīng.', 'z7'),
 ('', '讠 ＋ ', '青', ' ＝ 请', ['青', '马', '可', '月'], 'proszę: mowa + ?', '请 qǐng: 讠 (mowa) + 青.', 'z7'),
 ('', '忄 ＋ ', '青', ' ＝ 情', ['青', '马', '可', '日'], 'uczucie: serce + ?', '情 qíng: 忄 (serce) + 青.', 'z7'),
 ('', '日 ＋ ', '青', ' ＝ 晴', ['青', '马', '可', '月'], 'pogodny: słońce + ?', '晴 qíng: 日 (słońce) + 青.', 'z7'),
 ('', '女 ＋ ', '马', ' ＝ 妈', ['马', '可', '青', '子'], 'mama: kobieta + ?', '妈 mā: 女 (kobieta) + 马 mǎ.', 'z7'),
 ('', '口 ＋ ', '马', ' ＝ 吗', ['马', '可', '青', '木'], 'pytanie: usta + ?', '吗 ma: 口 (usta) + 马.', 'z7'),
 ('', '氵 ＋ ', '可', ' ＝ 河', ['可', '青', '马', '口'], 'rzeka: woda + ?', '河 hé: 氵 (woda) + 可 kě.', 'z7')]

CHATS = []

CHAT_EXTRA = {}

PUNCT = set("。，？！")


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    't_pod': ['człowiek', 'wchodzić', 'ziemia', 'uczony', 'duży', 'zbyt', 'pies', 'słońce'],
}

PARADIGMS = [
    ('form', 'Typowe trudności', 'Podobne znaki', 't_pod', '人; 入; 土; 士; 大; 太; 犬; 日', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['słońce', 'oko', 'biały', 'sto', 'drzewo', 'korzeń', 'król', 'jadeit'],
    't_m1': ['氵', '讠', '饣', '钅', '忄', '扌', '艹', '宀'],
    't_m2': ['十: pozioma czy pionowa?', '人: lewa czy prawa?', '小: środek czy boki?', '口: lewa pionowa czy dolna pozioma?', '三: górna czy dolna?', '国: zamknięcie ramki czy środek?'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Podobne znaki: druga seria', 't_m0', '日; 目; 白; 百; 木; 本; 王; 玉', 'Jedna kreska zmienia znak.'),
    ('form', 'Typowe trudności', 'Klucz: jaka kategoria?', 't_m1', 'ciecze; mowa; jedzenie; metal; uczucia; czynności ręką; rośliny; dom, dach', 'Klucz podpowiada kategorię znaczenia, nie całe znaczenie.'),
    ('form', 'Typowe trudności', 'Kolejność kresek: co najpierw?', 't_m2', 'pozioma; lewa; środek; lewa pionowa; górna; środek', 'Od góry do dołu, od lewej do prawej, pozioma przed pionową, ramkę zamyka się na końcu.'),
]

# Klasyfikatory i liczba mnoga
PARADIGM_LABELS.update({
    't_k0': ['książki', 'płaskie: kartki, stoły', 'długie i giętkie: ryby, drogi', 'małe zwierzęta, ptaki', 'pojazdy', 'ubrania, sprawy', 'filiżanki, szklanki', 'ludzie i rzeczy ogólnie'],
})
PARADIGMS += [
    ('form', 'Klasyfikatory', 'Klasyfikatory: który znak?', 't_k0', '本; 张; 条; 只; 辆; 件; 杯; 个', 'Między liczbą a rzeczownikiem po chińsku zawsze stoi klasyfikator: 三本书 (trzy książki).'),
]

"""[pl — wygenerowane przez tools/i18n.py, nie edytuj] Course logic: words, exercise generation, progress, streaks, XP.

Pure Python with no Kivy imports, so it can be tested on its own.
"""
import json

from courses import config
import os
import random
import time
import datetime as dt

from .content_pl import UNITS, INSIGHTS, HOOKS, TONE_HINTS, TONE_INSIGHT, CHATS, CHAT_EXTRA, PUNCT

# ---------------------------------------------------------------------------
# Pinyin helpers
# ---------------------------------------------------------------------------
_MARKS = {
    "a": "āáǎà", "e": "ēéěè", "i": "īíǐì", "o": "ōóǒò", "u": "ūúǔù", "ü": "ǖǘǚǜ",
}
_UNMARK = {}
for _base, _marked in _MARKS.items():
    for _i, _ch in enumerate(_marked):
        _UNMARK[_ch] = (_base, _i + 1)
_VOWELS = "aeiouü"


def split_syllable(syl):
    """'hao3' -> ('hao', 3). Neutral tone is 5."""
    syl = syl.replace("u:", "ü").replace("v", "ü").replace("V", "Ü")
    if syl and syl[-1].isdigit():
        return syl[:-1], int(syl[-1])
    return syl, 5


def mark_syllable(syl):
    base, tone = split_syllable(syl)
    if tone == 5 or tone == 0:
        return base
    low = base.lower()
    if "a" in low:
        i = low.index("a")
    elif "e" in low:
        i = low.index("e")
    elif "ou" in low:
        i = low.index("o")
    else:
        i = max(j for j, c in enumerate(low) if c in _VOWELS)
    ch = base[i]
    m = _MARKS[ch.lower()][tone - 1]
    if ch.isupper():
        m = m.upper()
    return base[:i] + m + base[i + 1:]


def to_marked(pinyin_num):
    """'nv3 er2' -> 'nǚ'ér' (word written as one unit)."""
    out = ""
    for k, syl in enumerate(pinyin_num.split()):
        m = mark_syllable(syl)
        if k > 0 and m[:1].lower() in "aeoāáǎàēéěèōóǒò":
            out += "'"
        out += m
    return out


def toneless(pinyin_num):
    return "".join(split_syllable(s)[0] for s in pinyin_num.split())


def tones_of(pinyin_num):
    return [split_syllable(s)[1] for s in pinyin_num.split()]


def parse_typed_pinyin(text):
    """Turn user typing ('ni3hao3', 'nǐ hǎo', 'Ni3 Hao3') into (letters, [tones])."""
    letters, tones = "", []
    text = text.strip().lower().replace("u:", "ü").replace("v", "ü")
    for ch in text:
        if ch in _UNMARK:
            base, t = _UNMARK[ch]
            letters += base
            tones.append(t)
        elif ch.isdigit():
            t = int(ch)
            if 1 <= t <= 4:
                tones.append(t)
        elif ch.isalpha():
            letters += ch
    return letters, tones


def check_typed_pinyin(text, pinyin_num):
    """Returns 'correct', 'tones' (right letters, wrong/missing tones) or 'wrong'."""
    letters, tones = parse_typed_pinyin(text)
    want_letters = toneless(pinyin_num).lower()
    want_tones = [t for t in tones_of(pinyin_num) if t != 5]
    if letters != want_letters:
        return "wrong"
    return "correct" if tones == want_tones else "tones"


# ---------------------------------------------------------------------------
# Word table
# ---------------------------------------------------------------------------
WORDS = {}
for _ui, _u in enumerate(UNITS):
    for _h, _p, _e in _u["words"]:
        if _h in WORDS:
            raise ValueError("Duplicate word in content: " + _h)
        WORDS[_h] = {
            "hanzi": _h, "num": _p, "pinyin": to_marked(_p), "english": _e,
            "unit": _ui, "hook": HOOKS.get(_h),
            "syllables": [split_syllable(s) for s in _p.split()],
        }


def token_num(t):
    """Numbered pinyin for a word or chat-only token, or None for punctuation."""
    if t in WORDS:
        return WORDS[t]["num"]
    if t in CHAT_EXTRA:
        return CHAT_EXTRA[t][0]
    return None


def sentence_pinyin(tokens):
    return " ".join(to_marked(token_num(t)) for t in tokens if token_num(t))


def prev_in_track(idx):
    tr = UNITS[idx]["track"]
    for j in range(idx - 1, -1, -1):
        if UNITS[j]["track"] == tr:
            return j
    return None


def unit_index(uid):
    for i, u in enumerate(UNITS):
        if u["id"] == uid:
            return i
    raise KeyError(uid)


def is_idiom(h):
    return len(h) == 4 and h in WORDS and UNITS[WORDS[h]["unit"]]["track"] == "chengyu"


def is_single_tone_word(w):
    return len(w["syllables"]) == 1 and w["syllables"][0][1] in (1, 2, 3, 4)


def is_tone_pair_word(w):
    s = w["syllables"]
    if len(s) != 2 or any(t == 5 for _, t in s):
        return False
    if s[0][1] == 3 and s[1][1] == 3:  # 3-3 changes in speech, skip
        return False
    if "不" in w["hanzi"] or "一" in w["hanzi"]:
        return False
    return True


def unit_groups(unit_idx, n=3):
    """Split a unit's words into n roughly equal groups for the first lessons."""
    words = [w[0] for w in UNITS[unit_idx]["words"]]
    size = -(-len(words) // n)
    return [words[i:i + size] for i in range(0, len(words), size)]


# ---------------------------------------------------------------------------
# Language Transfer: explain mistakes caused by English habits
# ---------------------------------------------------------------------------
ADJECTIVES = {"好", "大", "小", "多", "少", "热", "冷", "漂亮", "高兴", "好吃"}
QUESTION_WORDS = {"什么", "谁", "哪儿", "几", "怎么", "多少", "为什么"}
TIME_WORDS = {"今天", "明天", "昨天", "现在", "上午", "下午"}


def explain_mistake(given, answer):
    """Compare token lists and return an English-transfer explanation or None."""
    if not given:
        return None
    g, a = list(given), list(answer)
    if "是" in g and "是" not in a and any(t in ADJECTIVES for t in a):
        return 'Po polsku mówisz „jest/jestem”, po chińsku nie: cechy działają jak czasowniki, więc bez 是.'
    if "是" in g and "是" not in a and "在" in a:
        return '在 już znaczy „być w”, więc bez 是.'
    if "吗" in a and "吗" not in g:
        return 'Żeby zapytać „czy…?”, zostaw zdanie bez zmian i dodaj 吗 na końcu.'
    if "吗" in g and "吗" not in a and any(t in QUESTION_WORDS for t in a):
        return 'Zdanie ze słowem pytającym (什么, 谁, 几…) już jest pytaniem, więc bez 吗.'
    if "个" in a and "个" not in g:
        return 'Kiedy coś liczysz, wstaw klasyfikator (个) między liczbę a rzeczownik.'
    if sorted(g) == sorted(a):
        for qw in QUESTION_WORDS:
            if qw in a and qw in g and a.index(qw) != g.index(qw) and g.index(qw) == 0:
                return 'Słowa pytające nie skaczą na początek jak po polsku. Stoją tam, gdzie będzie odpowiedź.'
        for tw in TIME_WORDS:
            if tw in a and tw in g and g.index(tw) > a.index(tw) and g.index(tw) == len(g) - 1:
                return 'Po chińsku „kiedy” zawsze stoi przed czynnością, nigdy na końcu.'
        if "在" in a and "在" in g and g.index("在") > a.index("在"):
            return 'Najpierw scena: 在 + miejsce idzie przed czynność.'
        if "不" in a and "不" in g:
            return '不 stoi tuż przed słowem, któremu przeczy.'
        return 'Dobre słowa, ale inna kolejność. Przeczytaj rozwiązanie i zauważ wzór.'
    return None


# ---------------------------------------------------------------------------
# Exercise generation
# ---------------------------------------------------------------------------
class Gen:
    def __init__(self, known, rng=None, audio=False):
        """known: list of hanzi the learner has met (used for distractors)."""
        self.rng = rng or random.Random()
        self.known = [h for h in known if h in WORDS]
        self.audio = audio

    # -- distractors -------------------------------------------------------
    def _pool(self, target, prefer=None, key=None):
        r = self.rng
        prefer = [h for h in (prefer or []) if h != target]
        rest = [h for h in self.known if h != target and h not in prefer]
        everything = [h for h in WORDS if h != target and h not in prefer and h not in rest]
        r.shuffle(prefer)
        r.shuffle(rest)
        r.shuffle(everything)
        return prefer + rest + everything

    def _distract(self, target, n, key, prefer=None, avoid=()):
        seen = {key(WORDS[target])} | set(avoid)
        out = []
        for h in self._pool(target, prefer):
            k = key(WORDS[h])
            if k in seen:
                continue
            seen.add(k)
            out.append(h)
            if len(out) == n:
                break
        return out

    def _options(self, correct, others):
        opts = [correct] + others
        self.rng.shuffle(opts)
        return opts

    # -- single-word exercises --------------------------------------------
    def intro(self, h):
        w = WORDS[h]
        return {"type": "intro", "word": h, "hanzi": h, "pinyin": w["pinyin"],
                "english": w["english"], "hook": w["hook"], "audio": h}

    def meaning(self, h, pool=None, show_pinyin=True):
        w = WORDS[h]
        others = self._distract(h, 3, lambda x: x["english"], pool)
        return {"type": "choice", "mode": "meaning", "word": h,
                "title": 'Co to znaczy?',
                "prompt": h, "prompt_sub": w["pinyin"] if show_pinyin else None,
                "options": self._options(w["english"], [WORDS[o]["english"] for o in others]),
                "answer": w["english"], "audio": h, "solution": w["english"]}

    def hanzi(self, h, pool=None, show_pinyin=True):
        w = WORDS[h]
        others = self._distract(h, 3, lambda x: x["hanzi"], pool,
                                avoid=())
        opts = self._options(h, others)
        return {"type": "choice", "mode": "hanzi", "word": h,
                "title": 'Wybierz właściwe znaki',
                "prompt": w["english"], "options": opts,
                "option_subs": [WORDS[o]["pinyin"] for o in opts] if show_pinyin else None,
                "answer": h, "audio": h, "solution": h + "  " + w["pinyin"]}

    def pinyin(self, h, pool=None):
        """Choose the right pinyin. Distractors include the same syllables with wrong tones."""
        w = WORDS[h]
        r = self.rng
        right = w["pinyin"]
        variants = set()
        sylls = w["syllables"]
        for _ in range(30):
            new = []
            for base, t in sylls:
                if t != 5 and r.random() < 0.7:
                    t = r.choice([x for x in (1, 2, 3, 4) if x != t])
                new.append(base + str(t))
            m = to_marked(" ".join(new))
            if m != right:
                variants.add(m)
        variants = list(variants)
        r.shuffle(variants)
        opts = variants[:2]
        for o in self._distract(h, 3, lambda x: x["pinyin"], pool, avoid=set(opts) | {right}):
            if len(opts) == 3:
                break
            opts.append(WORDS[o]["pinyin"])
        return {"type": "choice", "mode": "pinyin", "word": h,
                "title": 'Jak to się wymawia?',
                "prompt": h, "options": self._options(right, opts[:3]),
                "answer": right, "audio": h, "solution": right}

    def listen(self, h, pool=None):
        w = WORDS[h]
        others = self._distract(h, 3, lambda x: toneless(x["num"]).lower(), pool)
        opts = self._options(h, others)
        return {"type": "choice", "mode": "listen", "word": h,
                "title": 'Co słyszysz?', "prompt": None,
                "options": opts, "answer": h, "audio": h, "autoplay": True,
                "solution": h + "  " + w["pinyin"]}

    def tone(self, h):
        w = WORDS[h]
        base, t = w["syllables"][0]
        return {"type": "tone", "word": h, "title": 'Który to ton?',
                "prompt": h, "prompt_sub": base, "answer": t, "audio": h,
                "solution": '%s  %s: ton %d, %s' % (h, w["pinyin"], t, TONE_HINTS[t])}

    def tone_ear(self, t=None):
        t = t or self.rng.randint(1, 4)
        return {"type": "tone", "word": None, "title": 'Posłuchaj wysokości. Który to ton?',
                "prompt": None, "hum": t, "answer": t, "autoplay": True,
                "solution": 'Ton %d: %s' % (t, TONE_HINTS[t])}

    def tone_pair(self, h):
        w = WORDS[h]
        right = tuple(t for _, t in w["syllables"])
        opts = {right}
        while len(opts) < 4:
            opts.add((self.rng.randint(1, 4), self.rng.randint(1, 4)))
        opts = list(opts)
        self.rng.shuffle(opts)
        return {"type": "tone_pair", "word": h, "title": 'Wybierz układ tonów',
                "prompt": h, "prompt_sub": " ".join(b for b, _ in w["syllables"]),
                "options": opts, "answer": right, "audio": h,
                "solution": '%s  %s: tony %d + %d' % (h, w["pinyin"], right[0], right[1])}

    def match(self, words, mode="english"):
        words = list(words)[:5]
        # keep the right column unambiguous
        seen, uniq = set(), []
        for h in words:
            k = WORDS[h][mode]
            if k not in seen:
                seen.add(k)
                uniq.append(h)
        pairs = [(h, WORDS[h][mode]) for h in uniq]
        return {"type": "match", "title": 'Dopasuj pary', "pairs": pairs,
                "words": uniq}

    def draw(self, h):
        w = WORDS[h]
        return {"type": "draw", "word": h, "title": 'Napisz ten znak',
                "prompt": w["english"], "prompt_sub": w["pinyin"], "answer": h,
                "hook": w["hook"], "audio": h, "solution": h}

    def typing(self, h):
        w = WORDS[h]
        return {"type": "type", "word": h, "title": 'Wpisz pinyin',
                "prompt": h, "prompt_sub": w["english"], "answer": w["num"],
                "audio": h, "solution": w["pinyin"] + "   (" + w["num"] + ")"}

    # -- sentence exercises -----------------------------------------------
    def build(self, tokens, english, hint=None, trap=True, title=None, insight=None):
        r = self.rng
        extra = []
        if trap and "是" not in tokens:
            extra.append("是")  # the classic English-transfer trap
        cands = [h for h in self.known if h not in tokens and h not in extra
                 and len(h) <= 2]
        r.shuffle(cands)
        while len(extra) < 3 and cands:
            extra.append(cands.pop())
        bank = list(tokens) + extra
        r.shuffle(bank)
        return {"type": "build", "title": title or 'Ułóż zdanie po chińsku',
                "prompt": english, "bank": bank, "answer": list(tokens), "think": hint,
                "insight": insight, "audio": "".join(tokens), "words": list(tokens),
                "solution": "".join(tokens) + "\n" + sentence_pinyin(tokens)}

    def sentence_meaning(self, tokens, english, other_english):
        others = [e for e in other_english if e != english]
        self.rng.shuffle(others)
        return {"type": "choice", "mode": "sentence", "title": 'Co to znaczy?',
                "prompt": "".join(tokens), "prompt_sub": sentence_pinyin(tokens),
                "options": self._options(english, others[:3]), "answer": english,
                "audio": "".join(tokens), "words": list(tokens), "solution": english}

    def cloze(self, h):
        """Complete the idiom: one character is missing."""
        w = WORDS[h]
        r = self.rng
        pos = r.randrange(4)
        right = h[pos]
        idioms = [x for x in WORDS if is_idiom(x) and x != h]
        r.shuffle(idioms)
        opts = []
        for x in idioms:
            c = x[pos]
            if c != right and c not in opts:
                opts.append(c)
            if len(opts) == 3:
                break
        prompt = h[:pos] + "＿" + h[pos + 1:]
        return {"type": "choice", "mode": "cloze", "word": h, "title": 'Dokończ idiom',
                "prompt": prompt, "prompt_sub": w["english"], "options": self._options(right, opts),
                "answer": right, "audio": h, "solution": h + "  " + w["pinyin"]}

    def insight_card(self, ins):
        return {"type": "insight", "title": ins["title"], "text": ins["text"]}


def available_sentences(unit_idx, known_set):
    out = []
    for ui in range(unit_idx + 1):
        for tokens, eng in UNITS[ui]["sentences"]:
            if all(t in known_set for t in tokens):
                out.append((tokens, eng, ui))
    return out


def all_english_sentences():
    return [e for u in UNITS for _, e in u["sentences"]]


def insight_ready(ins, known_set):
    return all(t in known_set for _, toks, _ in ins["chain"] for t in toks)


def think_chain(gen, ins):
    """An insight card followed by guided construction steps."""
    out = [gen.insight_card(ins)]
    for k, (eng, toks, hint) in enumerate(ins["chain"]):
        out.append(gen.build(toks, eng, hint=hint, title='Pomyśl (%d/%d)' % (k + 1, len(ins["chain"])),
                             insight=ins["title"]))
    return out


LESSON_LEN = 12
LESSONS_PER_LEVEL = 3
MAX_CROWNS = 5


def make_lesson(state, unit_idx, audio=False, rng=None):
    rng = rng or random.Random()
    unit = UNITS[unit_idx]
    uid = unit["id"]
    level = state.crowns(uid)
    known_before = [h for h in WORDS if WORDS[h]["unit"] < unit_idx]
    unit_words = [w[0] for w in unit["words"]]
    exercises = []

    if level == 0:
        k = state.lessons(uid)
        groups = unit_groups(unit_idx)
        k = min(k, len(groups) - 1)
        new = groups[k]
        pool = [h for g in groups[:k + 1] for h in g]
        known = known_before + pool
        gen = Gen(known, rng, audio)
        # 1. meet the new words, each followed by a quick check
        for h in new:
            exercises.append(gen.intro(h))
            exercises.append(gen.meaning(h, pool) if rng.random() < 0.5 else gen.hanzi(h, pool))
        # 2. Language Transfer insights whose words are all known now
        known_set = set(known)
        for ins in INSIGHTS.get(uid, []):
            key = uid + ":" + ins["title"]
            if key in state.data["insights_seen"]:
                continue
            if not ins["chain"] or insight_ready(ins, known_set):
                exercises.extend(think_chain(gen, ins))
        # 3. mixed practice on everything learned in this unit so far
        filler = _mixed(gen, pool, known_set, unit_idx, level, rng, audio,
                        max(4, LESSON_LEN - len(exercises)))
        exercises.extend(filler)
    else:
        known = known_before + unit_words
        gen = Gen(known, rng, audio)
        # one guided-construction step to revisit an insight
        chains = [i for i in INSIGHTS.get(uid, []) if i["chain"]]
        if chains:
            ins = rng.choice(chains)
            eng, toks, hint = rng.choice(ins["chain"])
            exercises.append(gen.build(toks, eng, hint=hint if level < 3 else None,
                                       title='Pomyśl', insight=ins["title"]))
        exercises.extend(_mixed(gen, unit_words, set(known), unit_idx, level, rng, audio,
                                LESSON_LEN - len(exercises)))
    return exercises


def _mixed(gen, pool, known_set, unit_idx, level, rng, audio, n):
    """A mix of exercise types that gets more productive (less recognition) at higher crowns."""
    words = list(pool)
    rng.shuffle(words)
    singles = [h for h in pool if is_single_tone_word(WORDS[h])]
    pairs = [h for h in pool if is_tone_pair_word(WORDS[h])]
    idioms = [h for h in pool if is_idiom(h)]
    sentences = available_sentences(unit_idx, known_set)
    sentences = [s for s in sentences if s[2] == unit_idx] or sentences
    other_eng = all_english_sentences()

    weights = {
        "meaning": 3 if level < 2 else 1,
        "hanzi": 3 if level < 2 else 1,
        "pinyin": 2,
        "tone": 2 if singles else 0,
        "tone_pair": 1 if pairs else 0,
        "listen": 2 if audio else 0,
        "build": (2 + level) if sentences else 0,
        "sentence": 2 if sentences else 0,
        "draw": (1 + level // 2) if (level >= 1 and singles) else 0,
        "type": level if level >= 2 else 0,
        "cloze": 4 if idioms else 0,
    }
    kinds = [k for k, v in weights.items() for _ in range(v)]
    out = []
    if len(words) >= 4:
        out.append(gen.match(words[:5], "english" if level < 2 else "pinyin"))
    i = 0
    last = None
    while len(out) < n and kinds:
        kind = rng.choice(kinds)
        if kind == last and len(set(kinds)) > 1:
            continue
        last = kind
        h = words[i % len(words)]
        i += 1
        show = level < 2
        if kind == "meaning":
            out.append(gen.meaning(h, pool, show))
        elif kind == "hanzi":
            out.append(gen.hanzi(h, pool, show))
        elif kind == "pinyin":
            out.append(gen.pinyin(h, pool))
        elif kind == "listen":
            out.append(gen.listen(h, pool))
        elif kind == "tone":
            out.append(gen.tone(rng.choice(singles)))
        elif kind == "tone_pair":
            out.append(gen.tone_pair(rng.choice(pairs)))
        elif kind == "draw":
            out.append(gen.draw(rng.choice(singles)))
        elif kind == "type":
            out.append(gen.typing(h))
        elif kind == "cloze":
            out.append(gen.cloze(rng.choice(idioms)))
        elif kind in ("build", "sentence"):
            toks, eng, _ = rng.choice(sentences)
            if kind == "build":
                out.append(gen.build(toks, eng))
            else:
                out.append(gen.sentence_meaning(toks, eng, other_eng))
    rng.shuffle(out)
    return out


def make_practice(state, audio=False, rng=None, n=LESSON_LEN):
    """Strengthen the weakest learned words."""
    rng = rng or random.Random()
    learned = state.learned_words()
    if not learned:
        return []
    learned.sort(key=lambda h: (state.strength(h), rng.random()))
    weak = learned[:max(6, n // 2)]
    gen = Gen(learned, rng, audio)
    top_unit = max(WORDS[h]["unit"] for h in learned)
    level = 2
    out = _mixed(gen, weak, set(learned), top_unit, level, rng, audio, n)
    return out[:n]


def make_tone_training(state, audio=False, rng=None, n=15):
    rng = rng or random.Random()
    learned = state.learned_words() or [w[0] for w in UNITS[0]["words"]]
    singles = [h for h in learned if is_single_tone_word(WORDS[h])]
    pairs = [h for h in learned if is_tone_pair_word(WORDS[h])]
    gen = Gen(learned, rng, audio)
    out = [{"type": "insight", "title": TONE_INSIGHT["title"], "text": TONE_INSIGHT["text"]}]
    # warm up the ear with pure pitch contours, one of each tone
    ears = [1, 2, 3, 4]
    rng.shuffle(ears)
    out += [gen.tone_ear(t) for t in ears]
    while len(out) < n:
        r = rng.random()
        if pairs and r < 0.3:
            out.append(gen.tone_pair(rng.choice(pairs)))
        elif singles and r < 0.8:
            out.append(gen.tone(rng.choice(singles)))
        elif singles:
            out.append(gen.pinyin(rng.choice(singles), learned))
        else:
            out.append(gen.tone_ear())
    return out


# ---------------------------------------------------------------------------
# Lesson session
# ---------------------------------------------------------------------------
class Session:
    def __init__(self, exercises, kind="lesson", unit_idx=None, hearts=True):
        self.queue = list(exercises)
        self.kind = kind
        self.unit_idx = unit_idx
        self.use_hearts = hearts
        self.total = len(self.queue)
        self.done = 0
        self.graded = 0
        self.first_try_correct = 0
        self.mistakes = 0
        self.combo = 0
        self.max_combo = 0
        self.insights = set()
        self.word_results = []  # (hanzi, correct)

    @property
    def current(self):
        return self.queue[0] if self.queue else None

    @property
    def progress(self):
        return self.done / max(1, self.total)

    @property
    def finished(self):
        return not self.queue

    def answer(self, correct):
        """correct: True/False, or None for ungraded cards. Returns combo milestone or 0."""
        ex = self.queue.pop(0)
        retry = ex.get("_retry", False)
        if ex["type"] == "insight":
            self.insights.add(ex["title"])
        for h in self._words(ex):
            if correct is not None:
                self.word_results.append((h, bool(correct)))
        if correct is None or correct:
            self.done += 1
            if correct:
                if not retry:
                    self.graded += 1
                    self.first_try_correct += 1
                self.combo += 1
                self.max_combo = max(self.max_combo, self.combo)
                if self.combo in (5, 10, 15, 20):
                    return self.combo
            return 0
        # wrong: try again at the end (Duolingo-style)
        if not retry:
            self.graded += 1
        self.mistakes += 1
        self.combo = 0
        again = dict(ex)
        again["_retry"] = True
        self.queue.append(again)
        return 0

    @staticmethod
    def _words(ex):
        if ex["type"] == "match":
            return ex["words"]
        if ex.get("word"):
            return [ex["word"]]
        return ex.get("words", [])

    @property
    def accuracy(self):
        return self.first_try_correct / max(1, self.graded)

    def xp(self):
        base = 10
        bonus = min(3, self.max_combo // 5)
        perfect = 2 if self.mistakes == 0 else 0
        return base + bonus + perfect, bonus, perfect


# ---------------------------------------------------------------------------
# Persistent state
# ---------------------------------------------------------------------------
HEART_MAX = 5
HEART_REGEN_S = 30 * 60
SRS_DAYS = [0, 1, 2, 4, 8, 16, 32]
GOALS = [('Na luzie', 10), ('Regularnie', 20), ('Poważnie', 30), ('Szaleńczo', 50)]
FREEZE_COST = 30
REFILL_COST = 40
MAX_FREEZES = 2


def _default():
    return {
        "version": 1, "onboarded": False,
        "xp_total": 0, "xp_by_day": {}, "daily_goal": 20,
        "streak": 0, "last_goal_day": None, "longest_streak": 0,
        "freezes": 0, "gems": 20,
        "hearts": HEART_MAX, "hearts_ts": 0,
        "units": {}, "words": {}, "insights_seen": [],
        "settings": {"sound": True, "slow_audio": False}, "chats": {},
        "lessons_completed": 0,
    }


class State:
    def __init__(self, path=None, now=None):
        self.path = path
        self._now = now  # for tests
        self.data = _default()
        if path and os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    loaded = json.load(f)
                d = _default()
                d.update(loaded)
                d["settings"] = {**_default()["settings"], **loaded.get("settings", {})}
                self.data = d
            except (ValueError, OSError):
                pass

    # -- time ----------------------------------------------------------------
    def now(self):
        return self._now() if self._now else time.time()

    def today(self):
        return dt.date.fromtimestamp(self.now())

    def save(self):
        if not self.path:
            return
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False)
        os.replace(tmp, self.path)

    # -- units ---------------------------------------------------------------
    def _unit(self, uid):
        return self.data["units"].setdefault(uid, {"crowns": 0, "lessons": 0})

    def crowns(self, uid):
        return self._unit(uid)["crowns"]

    def lessons(self, uid):
        return self._unit(uid)["lessons"]

    def unlocked(self, unit_idx):
        if config.UNLOCK_ALL:
            return True
        if unit_idx == 0:
            return True
        prev = prev_in_track(unit_idx)
        if prev is not None:
            return self.crowns(UNITS[prev]["id"]) >= 1
        req = UNITS[unit_idx].get("requires")
        return req is None or self.crowns(req) >= 1

    def unlock_reason(self, unit_idx):
        prev = prev_in_track(unit_idx)
        if prev is None:
            prev = unit_index(UNITS[unit_idx]["requires"])
        return UNITS[prev]["title"]

    # -- chats -----------------------------------------------------------------
    def chat_unlocked(self, chat):
        if config.UNLOCK_ALL:
            return True
        return self.crowns(chat["requires"]) >= 1

    def chat_stars(self, chat_id):
        return self.data["chats"].get(chat_id, 0)

    def finish_chat(self, chat, mistakes):
        stars = 3 if mistakes == 0 else (2 if mistakes <= 2 else 1)
        d = self.data
        d["chats"][chat["id"]] = max(stars, d["chats"].get(chat["id"], 0))
        for turn in chat["turns"]:
            for t in turn["bot"]:
                if t in WORDS and t in d["words"]:
                    self.record_word(t, True)
        xp = 10 + (5 if mistakes == 0 else 0)
        gems = 3 if mistakes == 0 else 1
        d["gems"] += gems
        if self.hearts() < HEART_MAX:
            self.gain_heart()
        ext = self.add_xp(xp)
        self.save()
        return {"xp": xp, "gems": gems, "stars": stars, "streak_extended": ext, "streak": d["streak"]}

    def unit_strength(self, unit_idx):
        words = [w[0] for w in UNITS[unit_idx]["words"]]
        seen = [h for h in words if h in self.data["words"]]
        if not seen:
            return 1.0
        return sum(self.strength(h) for h in seen) / len(seen)

    def cracked(self, unit_idx):
        return self.crowns(UNITS[unit_idx]["id"]) >= 1 and self.unit_strength(unit_idx) < 0.5

    # -- words / spaced repetition ----------------------------------------------
    def learned_words(self):
        return [h for h in self.data["words"] if h in WORDS]

    def record_word(self, h, correct):
        w = self.data["words"].setdefault(h, {"box": 0, "last": self.now(), "right": 0, "wrong": 0})
        if correct:
            w["box"] = min(len(SRS_DAYS) - 1, w["box"] + 1)
            w["right"] += 1
        else:
            w["box"] = max(0, w["box"] - 2)
            w["wrong"] += 1
        w["last"] = self.now()

    def strength(self, h):
        """1.0 = fresh, 0 = badly overdue / never got right."""
        w = self.data["words"].get(h)
        if not w:
            return 0.0
        interval = SRS_DAYS[w["box"]] or 0.5
        age_days = (self.now() - w["last"]) / 86400.0
        base = min(1.0, 0.6 + 0.08 * w["box"]) if w["box"] else 0.45
        if age_days <= interval:
            return base
        overdue = (age_days - interval) / (interval + 1)
        return max(0.0, base - 0.5 * overdue)

    # -- hearts ------------------------------------------------------------------
    def hearts(self):
        d = self.data
        if d["hearts"] < HEART_MAX:
            now = self.now()
            gained = int((now - d["hearts_ts"]) // HEART_REGEN_S)
            if gained > 0:
                d["hearts"] = min(HEART_MAX, d["hearts"] + gained)
                d["hearts_ts"] += gained * HEART_REGEN_S
        return d["hearts"]

    def lose_heart(self):
        self.hearts()
        if self.data["hearts"] == HEART_MAX:
            self.data["hearts_ts"] = self.now()
        self.data["hearts"] = max(0, self.data["hearts"] - 1)

    def gain_heart(self):
        self.hearts()
        self.data["hearts"] = min(HEART_MAX, self.data["hearts"] + 1)

    def seconds_to_next_heart(self):
        if self.hearts() >= HEART_MAX:
            return 0
        return int(HEART_REGEN_S - (self.now() - self.data["hearts_ts"]))

    # -- XP / streak ------------------------------------------------------------
    def xp_today(self):
        return self.data["xp_by_day"].get(self.today().isoformat(), 0)

    def check_streak(self):
        """Call on app start. Uses a streak freeze for a single missed day."""
        d = self.data
        last = d["last_goal_day"]
        if not last or d["streak"] == 0:
            return None
        gap = (self.today() - dt.date.fromisoformat(last)).days
        if gap <= 1:
            return None
        missed = gap - 1
        if d["freezes"] >= missed:
            d["freezes"] -= missed
            d["last_goal_day"] = (self.today() - dt.timedelta(days=1)).isoformat()
            return "frozen"
        d["streak"] = 0
        return "lost"

    def add_xp(self, n):
        """Returns True if this XP completed today's goal (streak extended)."""
        d = self.data
        today = self.today().isoformat()
        d["xp_total"] += n
        d["xp_by_day"][today] = d["xp_by_day"].get(today, 0) + n
        if d["xp_by_day"][today] >= d["daily_goal"] and d["last_goal_day"] != today:
            yesterday = (self.today() - dt.timedelta(days=1)).isoformat()
            d["streak"] = d["streak"] + 1 if d["last_goal_day"] == yesterday else 1
            d["last_goal_day"] = today
            d["longest_streak"] = max(d["longest_streak"], d["streak"])
            return True
        return False

    def level(self):
        """Player level from total XP (gets slower as you go)."""
        xp, lvl, need = self.data["xp_total"], 1, 60
        while xp >= need:
            xp -= need
            lvl += 1
            need = int(need * 1.35)
        return lvl, xp, need

    def week_xp(self):
        t = self.today()
        days = [t - dt.timedelta(days=i) for i in range(6, -1, -1)]
        names = ['Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd']
        return [(names[d.weekday()], self.data["xp_by_day"].get(d.isoformat(), 0)) for d in days]

    # -- shop ------------------------------------------------------------------
    def buy_freeze(self):
        d = self.data
        if d["gems"] >= FREEZE_COST and d["freezes"] < MAX_FREEZES:
            d["gems"] -= FREEZE_COST
            d["freezes"] += 1
            return True
        return False

    def buy_refill(self):
        d = self.data
        if d["gems"] >= REFILL_COST and self.hearts() < HEART_MAX:
            d["gems"] -= REFILL_COST
            d["hearts"] = HEART_MAX
            return True
        return False

    # -- finishing --------------------------------------------------------------
    def finish(self, session):
        """Apply a completed session. Returns a summary dict for the results screen."""
        d = self.data
        for h, ok in session.word_results:
            self.record_word(h, ok)
        xp, combo_bonus, perfect = session.xp()
        gems = 2 + (3 if perfect else 0)
        events = {"xp": xp, "combo_bonus": combo_bonus, "perfect": bool(perfect),
                  "accuracy": session.accuracy, "crown_up": None, "unlocked": None,
                  "heart_back": False}
        if session.kind == "lesson" and session.unit_idx is not None:
            before = [self.unlocked(i) for i in range(len(UNITS))]
            uid = UNITS[session.unit_idx]["id"]
            u = self._unit(uid)
            if u["crowns"] < MAX_CROWNS:
                u["lessons"] += 1
                if u["lessons"] >= LESSONS_PER_LEVEL:
                    u["crowns"] += 1
                    u["lessons"] = 0
                    gems += 10
                    events["crown_up"] = u["crowns"]
                    new = [i for i in range(len(UNITS)) if self.unlocked(i) and not before[i]]
                    if new:
                        events["unlocked"] = new
                    chats = [c["title"] for c in CHATS if c["requires"] == uid and u["crowns"] == 1]
                    if chats:
                        events["chats"] = chats
            for t in session.insights:
                key = uid + ":" + t
                if key not in d["insights_seen"]:
                    d["insights_seen"].append(key)
        else:
            if self.hearts() < HEART_MAX:
                self.gain_heart()
                events["heart_back"] = True
        d["gems"] += gems
        events["gems"] = gems
        d["lessons_completed"] += 1
        events["streak_extended"] = self.add_xp(xp)
        events["streak"] = d["streak"]
        self.save()
        return events

    def reset(self):
        self.data = _default()
        self.data["onboarded"] = True
        self.save()

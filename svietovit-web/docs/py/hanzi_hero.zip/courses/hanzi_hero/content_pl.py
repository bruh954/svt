"""[pl — wygenerowane przez tools/i18n.py, nie edytuj] Course content: Simplified Chinese, roughly HSK 1 level.

Each word is (hanzi, numbered pinyin, English).
  - Syllables are separated by spaces, tone number at the end (5 = neutral tone).
  - Write ü as "v" (nv3 -> nǚ).
  - Capitalise proper nouns (Bei3 jing1 -> Běijīng).
Each sentence is (list of word tokens, English). Every token must be a word
somewhere in the course so the app can show its pinyin.

To add a unit, append a dict to UNITS. The app picks it up automatically.
"""

UNITS = [
    {
        "id": "greetings", "title": 'Powitania', "icon": "你", "color": "#12B886",
        "words": [
            ("你", "ni3", 'ty'),
            ("我", "wo3", 'ja; mnie'),
            ("好", "hao3", 'dobry; dobrze'),
            ("你好", "ni3 hao3", 'cześć; dzień dobry'),
            ("是", "shi4", 'być (łączy rzeczowniki)'),
            ("不", "bu4", 'nie'),
            ("很", "hen3", 'bardzo'),
            ("吗", "ma5", '(partykuła pytająca, jak „czy”)'),
            ("谢谢", "xie4 xie5", 'dziękuję'),
            ("再见", "zai4 jian4", 'do widzenia'),
            ("对不起", "dui4 bu5 qi3", 'przepraszam'),
            ("没关系", "mei2 guan1 xi5", 'nic nie szkodzi'),
            ("不客气", "bu2 ke4 qi5", 'nie ma za co'),
        ],
        "sentences": [
            (["你", "好", "吗"], 'Jak się masz?'),
            (["我", "很", "好"], 'Mam się bardzo dobrze.'),
            (["我", "不", "好"], 'Nie czuję się dobrze.'),
            (["谢谢", "你"], 'Dziękuję.'),
        ],
    },
    {
        "id": "people", "title": 'Ludzie', "icon": "人", "color": "#4DABF7",
        "words": [
            ("他", "ta1", 'on; jego'),
            ("她", "ta1", 'ona; ją'),
            ("我们", "wo3 men5", 'my; nas'),
            ("你们", "ni3 men5", 'wy'),
            ("人", "ren2", 'człowiek; osoba'),
            ("中国", "Zhong1 guo2", 'Chiny'),
            ("老师", "lao3 shi1", 'nauczyciel'),
            ("学生", "xue2 sheng5", 'uczeń; student'),
            ("朋友", "peng2 you5", 'przyjaciel'),
            ("叫", "jiao4", 'nazywać się'),
            ("什么", "shen2 me5", 'co'),
            ("名字", "ming2 zi5", 'imię'),
        ],
        "sentences": [
            (["我", "是", "学生"], 'Jestem studentem.'),
            (["他", "是", "老师"], 'On jest nauczycielem.'),
            (["你", "叫", "什么", "名字"], 'Jak masz na imię?'),
            (["她", "是", "我", "朋友"], 'Ona jest moją przyjaciółką.'),
            (["我们", "是", "中国", "人"], 'Jesteśmy Chińczykami.'),
            (["你", "是", "学生", "吗"], 'Czy jesteś studentem?'),
        ],
    },
    {
        "id": "numbers", "title": 'Liczby', "icon": "三", "color": "#FF922B",
        "words": [
            ("一", "yi1", 'jeden'),
            ("二", "er4", 'dwa'),
            ("三", "san1", 'trzy'),
            ("四", "si4", 'cztery'),
            ("五", "wu3", 'pięć'),
            ("六", "liu4", 'sześć'),
            ("七", "qi1", 'siedem'),
            ("八", "ba1", 'osiem'),
            ("九", "jiu3", 'dziewięć'),
            ("十", "shi2", 'dziesięć'),
            ("几", "ji3", 'ile (o małej liczbie)'),
            ("岁", "sui4", 'lat (o wieku)'),
        ],
        "sentences": [
            (["你", "几", "岁"], 'Ile masz lat?'),
            (["我", "十", "岁"], 'Mam dziesięć lat.'),
            (["他", "八", "岁"], 'On ma osiem lat.'),
            (["她", "是", "九", "岁", "吗"], 'Czy ona ma dziewięć lat?'),
        ],
    },
    {
        "id": "family", "title": 'Rodzina', "icon": "家", "color": "#CC5DE8",
        "words": [
            ("家", "jia1", 'dom; rodzina'),
            ("爸爸", "ba4 ba5", 'tata'),
            ("妈妈", "ma1 ma5", 'mama'),
            ("儿子", "er2 zi5", 'syn'),
            ("女儿", "nv3 er2", 'córka'),
            ("有", "you3", 'mieć'),
            ("没有", "mei2 you3", 'nie mieć'),
            ("个", "ge4", '(ogólny klasyfikator, „sztuka”)'),
            ("狗", "gou3", 'pies'),
            ("猫", "mao1", 'kot'),
            ("和", "he2", 'i (łączy rzeczowniki)'),
            ("的", "de5", '(partykuła dzierżawcza, jak „-ego”)'),
        ],
        "sentences": [
            (["我", "有", "一", "个", "儿子"], 'Mam syna.'),
            (["你", "有", "狗", "吗"], 'Czy masz psa?'),
            (["我", "没有", "猫"], 'Nie mam kota.'),
            (["我", "家", "有", "四", "个", "人"], 'W mojej rodzinie są cztery osoby.'),
            (["我", "的", "朋友", "有", "三", "个", "女儿"], 'Mój przyjaciel ma trzy córki.'),
        ],
    },
    {
        "id": "food", "title": 'Jedzenie i picie', "icon": "吃", "color": "#F25F5C",
        "words": [
            ("吃", "chi1", 'jeść'),
            ("喝", "he1", 'pić'),
            ("水", "shui3", 'woda'),
            ("茶", "cha2", 'herbata'),
            ("米饭", "mi3 fan4", 'ryż (gotowany)'),
            ("菜", "cai4", 'danie; warzywa'),
            ("苹果", "ping2 guo3", 'jabłko'),
            ("想", "xiang3", 'chcieć; myśleć'),
            ("爱", "ai4", 'kochać; uwielbiać'),
            ("面条", "mian4 tiao2", 'makaron'),
            ("饭店", "fan4 dian4", 'restauracja'),
            ("杯子", "bei1 zi5", 'kubek; filiżanka'),
        ],
        "sentences": [
            (["我", "想", "喝", "茶"], 'Chcę napić się herbaty.'),
            (["你", "吃", "米饭", "吗"], 'Czy jesz ryż?'),
            (["我", "爱", "吃", "苹果"], 'Uwielbiam jeść jabłka.'),
            (["他", "不", "喝", "水"], 'On nie pije wody.'),
            (["我", "想", "吃", "面条"], 'Chcę zjeść makaron.'),
        ],
    },
    {
        "id": "time", "title": 'Czas', "icon": "天", "color": "#FAB005",
        "words": [
            ("今天", "jin1 tian1", 'dzisiaj'),
            ("明天", "ming2 tian1", 'jutro'),
            ("昨天", "zuo2 tian1", 'wczoraj'),
            ("现在", "xian4 zai4", 'teraz'),
            ("点", "dian3", 'godzina (która?)'),
            ("年", "nian2", 'rok'),
            ("月", "yue4", 'miesiąc'),
            ("号", "hao4", 'dzień miesiąca'),
            ("星期", "xing1 qi1", 'tydzień'),
            ("上午", "shang4 wu3", 'rano'),
            ("下午", "xia4 wu3", 'po południu'),
            ("时候", "shi2 hou5", '(chwila; moment) czasu'),
        ],
        "sentences": [
            (["今天", "星期", "几"], 'Jaki dziś dzień tygodnia?'),
            (["现在", "几", "点"], 'Która jest teraz godzina?'),
            (["明天", "是", "几", "月", "几", "号"], 'Którego jest jutro?'),
            (["我", "今天", "很", "好"], 'Dziś mam się bardzo dobrze.'),
            (["现在", "是", "下午", "三", "点"], 'Jest teraz trzecia po południu.'),
        ],
    },
    {
        "id": "places", "title": 'Miejsca', "icon": "去", "color": "#20C997",
        "words": [
            ("在", "zai4", 'w; na (być w)'),
            ("哪儿", "nar3", 'gdzie'),
            ("这", "zhe4", 'to (ten)'),
            ("那", "na4", 'tamto (tamten)'),
            ("学校", "xue2 xiao4", 'szkoła'),
            ("医院", "yi1 yuan4", 'szpital'),
            ("商店", "shang1 dian4", 'sklep'),
            ("去", "qu4", 'iść; jechać'),
            ("来", "lai2", 'przychodzić'),
            ("北京", "Bei3 jing1", 'Pekin'),
            ("里", "li3", 'w środku'),
            ("回", "hui2", 'wracać'),
        ],
        "sentences": [
            (["你", "在", "哪儿"], 'Gdzie jesteś?'),
            (["我", "去", "学校"], 'Idę do szkoły.'),
            (["他", "在", "医院"], 'On jest w szpitalu.'),
            (["这", "是", "什么"], 'Co to jest?'),
            (["我", "明天", "回", "北京"], 'Jutro wracam do Pekinu.'),
            (["那", "是", "我", "家"], 'To jest mój dom.'),
        ],
    },
    {
        "id": "actions", "title": 'Czynności', "icon": "看", "color": "#5C7CFA",
        "words": [
            ("看", "kan4", 'patrzeć; oglądać'),
            ("听", "ting1", 'słuchać'),
            ("说", "shuo1", 'mówić'),
            ("读", "du2", 'czytać (na głos)'),
            ("写", "xie3", 'pisać'),
            ("做", "zuo4", 'robić'),
            ("买", "mai3", 'kupować'),
            ("开", "kai1", 'otwierać; prowadzić (auto)'),
            ("坐", "zuo4", 'siedzieć'),
            ("睡觉", "shui4 jiao4", 'spać'),
            ("工作", "gong1 zuo4", 'pracować; praca'),
            ("学习", "xue2 xi2", 'uczyć się'),
            ("书", "shu1", 'książka'),
        ],
        "sentences": [
            (["我", "在", "学校", "学习"], 'Uczę się w szkole.'),
            (["他", "在", "看", "书"], 'On czyta książkę.'),
            (["我", "想", "买", "苹果"], 'Chcę kupić jabłka.'),
            (["妈妈", "在", "工作"], 'Mama pracuje.'),
            (["你", "想", "做", "什么"], 'Co chcesz robić?'),
        ],
    },
    {
        "id": "describing", "title": 'Opisywanie', "icon": "大", "color": "#E64980",
        "words": [
            ("大", "da4", 'duży'),
            ("小", "xiao3", 'mały'),
            ("多", "duo1", 'dużo; wiele'),
            ("少", "shao3", 'mało'),
            ("热", "re4", 'gorący'),
            ("冷", "leng3", 'zimny'),
            ("漂亮", "piao4 liang5", 'ładny'),
            ("高兴", "gao1 xing4", 'szczęśliwy; wesoły'),
            ("太", "tai4", 'za (bardzo)'),
            ("好吃", "hao3 chi1", 'smaczny'),
            ("天气", "tian1 qi4", 'pogoda'),
            ("钱", "qian2", 'pieniądze'),
        ],
        "sentences": [
            (["今天", "天气", "很", "好"], 'Dziś jest bardzo dobra pogoda.'),
            (["今天", "很", "热"], 'Dziś jest gorąco.'),
            (["这", "个", "菜", "很", "好吃"], 'To danie jest bardzo smaczne.'),
            (["她", "很", "漂亮"], 'Ona jest bardzo ładna.'),
            (["我", "没有", "钱"], 'Nie mam pieniędzy.'),
        ],
    },
    {
        "id": "questions", "title": 'Pytania', "icon": "谁", "color": "#7950F2",
        "words": [
            ("呢", "ne5", '(partykuła pytania zwrotnego: „a ty?”)'),
            ("谁", "shei2", 'kto'),
            ("怎么", "zen3 me5", 'jak'),
            ("多少", "duo1 shao5", 'ile'),
            ("为什么", "wei4 shen2 me5", 'dlaczego'),
            ("会", "hui4", 'umieć (wyuczona umiejętność)'),
            ("能", "neng2", 'móc; potrafić'),
            ("喜欢", "xi3 huan5", 'lubić'),
            ("认识", "ren4 shi5", 'znać (kogoś)'),
            ("汉语", "Han4 yu3", 'język chiński'),
            ("字", "zi4", 'znak (pisma)'),
            ("电话", "dian4 hua4", 'telefon'),
        ],
        "sentences": [
            (["你", "会", "说", "汉语", "吗"], 'Czy umiesz mówić po chińsku?'),
            (["他", "是", "谁"], 'Kim on jest?'),
            (["你", "喜欢", "喝", "茶", "吗"], 'Czy lubisz pić herbatę?'),
            (["我", "认识", "你"], 'Znam cię.'),
            (["这", "个", "字", "怎么", "读"], 'Jak się czyta ten znak?'),
            (["我", "很", "好", "你", "呢"], 'Dobrze, a ty?'),
        ],
    },
]


# ---------------------------------------------------------------------------
# Language Transfer-style insights.
# Each insight is a short "why" explanation that builds on what an English
# speaker already knows, followed by a chain of guided construction steps:
# (English prompt, tokens, a "think it through" hint).
# Insights appear in a unit's first lessons once all their words are known.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "greetings": [
        {
            "title": 'Pinyin czyta się prawie po polsku',
            "text": 'Pinyin to chińskie słowa zapisane łacinką. Polakom idzie łatwiej niż Anglikom, bo mamy te same dźwięki: x to prawie nasze ś (xiè ≈ „sie”), q to ć (qǐ ≈ „ci”), j to dź, z to dz, c to c, zh to dż, ch to cz, sh to sz, h to ch. Tylko zh, ch, sh wymawia się z językiem zawiniętym do tyłu.',
            "chain": [],
        },
        {
            "title": '„Jestem” nie jest potrzebne',
            "text": 'Po polsku mówimy „jestem zmęczony”. Chiński pomija „jestem”: 我很好 to dosłownie „ja bardzo dobrze”. 很 jest tu głównie łącznikiem, nie mocnym „bardzo”. I czasowniki nigdy się nie odmieniają: żadnych -m, -sz, -my.',
            "chain": [
                ('Mam się dobrze.', ["我", "很", "好"], 'Zacznij od 我, potem 很 + dobrze. Bez „jestem”.'),
                ('Masz się dobrze.', ["你", "很", "好"], 'Zmień tylko osobę. Nic innego się nie zmienia.'),
                ('Nie czuję się dobrze.', ["我", "不", "好"], '不 stoi tuż przed tym, co zaprzecza, w miejscu 很.'),
            ],
        },
        {
            "title": 'Pytanie: dodaj 吗',
            "text": 'Po polsku pytanie robi się słówkiem „czy” na początku, a szyk zostaje: „czy masz się dobrze?”. Po chińsku tak samo, tylko „czy” stoi na końcu: zdanie oznajmujące + 吗.',
            "chain": [
                ('Czy masz się dobrze?', ["你", "好", "吗"], 'Zdanie 你好, a na końcu 吗.'),
                ('Czy masz się bardzo dobrze?', ["你", "很", "好", "吗"], 'To samo zdanie co „masz się dobrze”, plus 吗.'),
            ],
        },
    ],
    "people": [
        {
            "title": '是 łączy dwie rzeczy',
            "text": '是 łączy dwa rzeczowniki: „jestem studentem” to 我是学生. Chiński, jak polski, nie ma rodzajników (a, the), a do tego nie ma przypadków: bez „studentem”, po prostu „student”.',
            "chain": [
                ('Jestem nauczycielem.', ["我", "是", "老师"], '我 + 是 + nauczyciel. Bez końcówki narzędnika.'),
                ('On jest nauczycielem.', ["他", "是", "老师"], 'Zamień 我 na 他. 是 się nie zmienia.'),
                ('Czy on jest nauczycielem?', ["他", "是", "老师", "吗"], 'To już znasz: dodaj 吗.'),
                ('On nie jest nauczycielem.', ["他", "不", "是", "老师"], '不 stoi tuż przed 是.'),
            ],
        },
        {
            "title": 'Słowo pytające stoi tam, gdzie odpowiedź',
            "text": 'Po polsku „co” skacze na początek zdania. Po chińsku stoi dokładnie tam, gdzie będzie odpowiedź. Pomyśl o luce do uzupełnienia: 你叫 ___ ? to 你叫什么?',
            "chain": [
                ('Jak się nazywasz?', ["你", "叫", "什么"], '„Nazywasz się ___”, a w luce 什么.'),
                ('Jak masz na imię?', ["你", "叫", "什么", "名字"], 'Dosłownie „nazywasz się jakim imieniem?”'),
            ],
        },
    ],
    "numbers": [
        {
            "title": 'Liczby składa się jak klocki',
            "text": 'Chińskie liczby to czysta logika: 11 to 十一 (dziesięć-jeden), 20 to 二十 (dwa-dziesięć), 35 to 三十五. Wiek: osoba, liczba i 岁. Bez „mam”, jak przy cechach.',
            "chain": [
                ('Mam osiem lat.', ["我", "八", "岁"], 'Ja + osiem + lat. Bez 是.'),
                ('Ile masz lat?', ["你", "几", "岁"], 'Wstaw słowo pytające 几 w lukę 你 ___ 岁.'),
                ('Czy on ma dziesięć lat?', ["他", "十", "岁", "吗"], 'Najpierw zdanie, potem 吗.'),
            ],
        },
    ],
    "family": [
        {
            "title": 'Liczenie wymaga klasyfikatora',
            "text": 'Po polsku czasem liczymy z pomocnikiem: „trzy sztuki”, „dwie kromki chleba”, „szklanka herbaty”. Po chińsku zawsze: liczba + klasyfikator + rzeczownik. 个 to klasyfikator uniwersalny.',
            "chain": [
                ('jedna osoba', ["一", "个", "人"], 'jeden + 个 + osoba.'),
                ('cztery osoby', ["四", "个", "人"], 'Zmień tylko liczbę. Chiński nie ma liczby mnogiej.'),
                ('Mam syna.', ["我", "有", "一", "个", "儿子"], '„syn” to „jeden 个 syn”.'),
            ],
        },
        {
            "title": '的 działa jak dopełniacz',
            "text": '我的 to „mój”, 你的 to „twój”, 朋友的 to „przyjaciela”. Uwaga na szyk: właściciel idzie pierwszy, odwrotnie niż po polsku: 朋友的狗 to „przyjaciela pies”.',
            "chain": [
                ('mój kot', ["我", "的", "猫"], 'ja + 的 + kot.'),
                ('pies mojego przyjaciela', ["我", "朋友", "的", "狗"], 'Przy bliskich osobach, jak „mój przyjaciel”, pierwsze 的 może odpaść.'),
            ],
        },
    ],
    "food": [
        {
            "title": 'Szyk jak po polsku',
            "text": 'Dobra wiadomość: podstawowy szyk jest taki sam jak w polskim. „Jem ryż” to 我吃米饭. 想 działa jak „chcę”: stawiasz je tuż przed czynnością.',
            "chain": [
                ('Jem ryż.', ["我", "吃", "米饭"], 'Ten sam szyk co po polsku.'),
                ('Chcę zjeść ryż.', ["我", "想", "吃", "米饭"], '想 idzie przed czynność, jak „chcę”.'),
                ('Czy chcesz napić się herbaty?', ["你", "想", "喝", "茶", "吗"], 'Zbuduj zdanie, potem dodaj 吗.'),
                ('Nie chcę pić wody.', ["我", "不", "想", "喝", "水"], '不 idzie przed 想, słowo, któremu przeczy.'),
            ],
        },
    ],
    "time": [
        {
            "title": '„Kiedy” idzie na początek',
            "text": 'Po polsku czas może stać w różnych miejscach. Po chińsku stoi przed czynnością lub cechą albo na samym początku: „ja dziś bardzo dobrze”.',
            "chain": [
                ('Dziś mam się bardzo dobrze.', ["我", "今天", "很", "好"], 'Kto, potem kiedy, potem cecha.'),
                ('Dziś nie czuję się dobrze.', ["今天", "我", "不", "好"], 'Czas może też otwierać zdanie.'),
                ('Która jest teraz godzina?', ["现在", "几", "点"], 'teraz + ile + godzina.'),
            ],
        },
    ],
    "places": [
        {
            "title": '在 znaczy „być w”',
            "text": '在 zawiera już „być”: 他在学校 to „on jest w szkole”. Nie dodawaj 是. A „gdzie” stoi w miejscu odpowiedzi, jak każde słowo pytające.',
            "chain": [
                ('On jest w szkole.', ["他", "在", "学校"], 'Tu 在 jest czasownikiem. Bez 是.'),
                ('Gdzie on jest?', ["他", "在", "哪儿"], '„On jest w ___”, a w luce 哪儿.'),
                ('Jutro jadę do Pekinu.', ["我", "明天", "去", "北京"], 'Kiedy przed czasownikiem, dokąd po 去.'),
            ],
        },
    ],
    "actions": [
        {
            "title": 'Najpierw gdzie, potem co',
            "text": 'Po polsku „uczę się w szkole”. Po chińsku najpierw scena: „ja w szkole uczę się”. 在 + miejsce idzie przed czynność. 在 tuż przed czasownikiem znaczy „właśnie robić”.',
            "chain": [
                ('Uczę się w szkole.', ["我", "在", "学校", "学习"], 'Najpierw scena (在 + szkoła), potem czynność.'),
                ('Tata pracuje w szpitalu.', ["爸爸", "在", "医院", "工作"], 'Ten sam wzór: kto, 在 + gdzie, co.'),
                ('On (właśnie) czyta książkę.', ["他", "在", "看", "书"], '在 + czasownik = właśnie to robi.'),
            ],
        },
    ],
    "describing": [
        {
            "title": 'Cechy działają jak czasowniki',
            "text": 'Ten sam trik co w 我很好: 今天很热 to „dziś bardzo gorąco”. Słowo opisujące działa jak czasownik, więc nie potrzebuje 是. Po polsku też mówimy po prostu „dziś gorąco”.',
            "chain": [
                ('Dziś jest gorąco.', ["今天", "很", "热"], 'Bez „jest”: dziś bardzo gorąco.'),
                ('Dziś nie jest zimno.', ["今天", "不", "冷"], '不 zastępuje 很.'),
                ('To danie jest smaczne.', ["这", "个", "菜", "很", "好吃"], '这 + 个 + rzeczownik = „ten ___”.'),
            ],
        },
    ],
    "questions": [
        {
            "title": 'Odbij pytanie: 呢',
            "text": 'Gdy odpowiesz, odbij pytanie krótkim 你呢? („a ty?”). Pozostałe słowa pytające stoją w miejscu odpowiedzi, jak już wiesz.',
            "chain": [
                ('Dobrze, a ty?', ["我", "很", "好", "你", "呢"], 'Twoja odpowiedź, potem 你呢.'),
                ('Kim on jest?', ["他", "是", "谁"], '„On jest ___”, a w luce 谁.'),
                ('Dlaczego nie pijesz herbaty?', ["你", "为什么", "不", "喝", "茶"], '为什么 stoi po osobie, przed czynnością.'),
            ],
        },
    ],
}

# Memory hooks: build new characters out of parts you've already met.
# These are learning aids, not strict etymology.
HOOKS = {
    "好": '女 (kobieta) + 子 (dziecko) obok siebie: coś dobrego.',
    "你": '亻 to klucz „człowiek”, więc 你 to człowiek: ty.',
    "他": '亻 (człowiek) + 也. Zamień 亻 na 女 (kobieta), a dostaniesz 她, „ona”. Ten sam dźwięk.',
    "她": '女 (kobieta) + 也. Porównaj z 他: ten sam dźwięk, inna osoba.',
    "我们": '们 to 亻 (człowiek) + 门 (mén, drzwi) dla dźwięku. Dodaj 们 do osób, a powstanie liczba mnoga.',
    "你们": '你 + 们: końcówka liczby mnogiej dla ludzi. Porównaj 我们.',
    "吗": '口 (usta) + 马 (mǎ, koń) dla dźwięku. Słowo, które tylko się mówi, bez znaczenia.',
    "妈妈": '女 (kobieta) + 马 (mǎ) dla dźwięku. Ten sam koń co w 吗.',
    "爸爸": '父 (ojciec) nad 巴 (bā) dla dźwięku.',
    "谢谢": '讠 to klucz „mowa”. Podziękowania się wypowiada.',
    "叫": '口 (usta) po lewej: wołanie kogoś po imieniu.',
    "吃": '口 (usta) po lewej: jedzenie.',
    "喝": '口 (usta) po lewej: picie.',
    "听": '口 (usta) po lewej. Słuchanie tego, co mówią usta.',
    "说": '讠 (mowa) po lewej: mówienie.',
    "读": '讠 (mowa) po lewej: czytanie na głos.',
    "茶": '艹 (trawa) na górze: herbata to roślina.',
    "菜": '艹 (trawa) na górze: warzywa.',
    "热": 'Cztery kropki na dole to ogień (灬): gorąco.',
    "冷": '冫 to lód: zimno. Porównaj 热 z ogniem na dole.',
    "字": '宀 (dach) nad 子 (dziecko): dziecko w domu uczy się znaków.',
    "家": '宀 (dach) nad 豕 (świnia): dom z inwentarzem to dom rodzinny.',
    "明天": '明 to 日 (słońce) + 月 (księżyc): jasny. Jasny dzień po dzisiejszym.',
    "朋友": '朋 to dwa 月 obok siebie, jak dwaj przyjaciele.',
    "人": 'Dwie idące nogi.',
    "大": 'Człowiek (人) z szeroko rozłożonymi rękami: duży.',
    "太": '大 (duży) i dodatkowa kropka: za duży, za bardzo.',
    "小": 'Coś podzielone na drobne kawałki.',
    "少": '小 (mały) z dodatkową kreską, która jeszcze przycina: mało.',
    "看": 'Dłoń (手) nad okiem (目), osłaniająca je, by spojrzeć w dal.',
    "坐": 'Dwie osoby (人人) siedzące na ziemi (土).',
    "回": 'Pudełko w pudełku: obejść dookoła i wrócić.',
    "一": 'Jedna kreska to jeden.',
    "二": 'Dwie kreski to dwa.',
    "三": 'Trzy kreski to trzy.',
    "钱": '钅 to metal: pieniądze były kiedyś metalowymi monetami.',
    "米饭": '饭 ma 饣, klucz „jedzenie”.',
    "饭店": '饭 (jedzenie, z 饣) + 店 (sklep): sklep z jedzeniem, czyli restauracja.',
    "想": '心 (serce) na dole: myślenie i chęci rodzą się w sercu.',
    "怎么": '怎 też ma 心 (serce) na dole, jak 想.',
    "时候": '时 ma 日 (słońce) po lewej: słońce wyznacza czas.',
    "睡觉": '睡 ma 目 (oko) po lewej: zamykasz oczy.',
    "学生": '学 ma 子 (dziecko) na dole, pod dachem: dziecko się uczy.',
    "学习": '学 to samo co w 学生: dziecko pod dachem, które się uczy.',
    "学校": '学 (uczyć się) + 校 (budynek szkoły).',
    "中国": '中 to kreska przez środek pudełka: Państwo Środka.',
}

# Tones anchored to intonation an English speaker already uses.
TONE_HINTS = {
    1: 'wysoki i równy, jak śpiewana nuta',
    2: 'wznoszący, jak zdziwione „Hę?”',
    3: 'nisko opadający, jak niepewne „Nooo…”',
    4: 'ostro opadający, jak stanowcze „Nie!”',
}

TONE_INSIGHT = {
    "title": 'Te melodie już znasz',
    "text": 'Po polsku melodią wyrażasz nastrój: „Hę?” idzie w górę, „Nie!” w dół. Chiński używa tych samych melodii, ale zmieniają one znaczenie słowa. Ton 1 to śpiewana nuta, ton 2 to „Hę?”, ton 3 to niepewne „Nooo…”, ton 4 to stanowcze „Nie!”. Powiedz każdy z polskim uczuciem i masz większość pracy za sobą.',
}


# ---------------------------------------------------------------------------
# Extra tracks. "track" groups units on the home path; "requires" is the
# unit that must reach level 1 before the track's first unit unlocks.
# ---------------------------------------------------------------------------
for _u in UNITS:
    _u.setdefault("track", "modern")

UNITS.extend([
    {
        "id": 'rad1', "title": 'Obrazki: przyroda', "icon": '山', "color": '#2F9E44', "track": "radicals",
        "words": [
            ('山', 'shan1', 'góra'),
            ('火', 'huo3', 'ogień'),
            ('木', 'mu4', 'drzewo; drewno'),
            ('土', 'tu3', 'ziemia; gleba'),
            ('田', 'tian2', 'pole'),
            ('石', 'shi2', 'kamień'),
            ('雨', 'yu3', 'deszcz'),
            ('云', 'yun2', 'chmura'),
            ('风', 'feng1', 'wiatr'),
            ('花', 'hua1', 'kwiat'),
            ('草', 'cao3', 'trawa'),
            ('河', 'he2', 'rzeka'),
        ],
        "sentences": [
            (['山', '很', '大'], 'Góra jest duża.'),
            (['火', '很', '热'], 'Ogień jest bardzo gorący.'),
            (['河', '里', '有', '水'], 'W rzece jest woda.'),
            (['我', '看', '山'], 'Patrzę na górę.'),
            (['花', '很', '漂亮'], 'Kwiat jest bardzo ładny.'),
        ],
    },
    {
        "id": 'rad2', "title": 'Obrazki: ciało', "icon": '口', "color": '#E8590C', "track": "radicals",
        "words": [
            ('口', 'kou3', 'usta'),
            ('手', 'shou3', 'ręka'),
            ('心', 'xin1', 'serce'),
            ('目', 'mu4', 'oko'),
            ('耳', 'er3', 'ucho'),
            ('足', 'zu2', 'stopa'),
            ('头', 'tou2', 'głowa'),
            ('力', 'li4', 'siła'),
            ('女', 'nv3', 'kobieta'),
            ('自', 'zi4', 'samo; własne ja'),
            ('牙', 'ya2', 'ząb'),
            ('毛', 'mao2', 'włosy; sierść'),
        ],
        "sentences": [
            (['她', '的', '手', '很', '小'], 'Jej ręka jest mała.'),
            (['我', '的', '头', '很', '大'], 'Moja głowa jest duża.'),
            (['这', '是', '我', '的', '手'], 'To jest moja ręka.'),
            (['他', '的', '女儿', '很', '漂亮'], 'Jego córka jest bardzo ładna.'),
            (['我', '心', '里', '很', '高兴'], 'Jest mi bardzo radośnie w środku.'),
        ],
    },
    {
        "id": 'rad3', "title": 'Obrazki: rzeczy', "icon": '门', "color": '#1C7ED6', "track": "radicals",
        "words": [
            ('门', 'men2', 'drzwi; brama'),
            ('车', 'che1', 'pojazd; samochód'),
            ('刀', 'dao1', 'nóż'),
            ('工', 'gong1', 'praca; rzemiosło'),
            ('马', 'ma3', 'koń'),
            ('鸟', 'niao3', 'ptak'),
            ('鱼', 'yu2', 'ryba'),
            ('虫', 'chong2', 'owad'),
            ('米', 'mi3', 'ryż (surowy)'),
            ('竹', 'zhu2', 'bambus'),
            ('金', 'jin1', 'złoto; metal'),
            ('言', 'yan2', 'mowa; słowa'),
        ],
        "sentences": [
            (['我', '有', '一', '个', '车'], 'Mam samochód.'),
            (['我', '看', '鱼'], 'Patrzę na rybę.'),
            (['门', '很', '大'], 'Drzwi są duże.'),
            (['我', '爱', '吃', '鱼'], 'Uwielbiam jeść ryby.'),
        ],
    },
    {
        "id": 'rad4', "title": 'Kierunki', "icon": '上', "color": '#845EF7', "track": "radicals",
        "words": [
            ('上', 'shang4', 'góra; nad'),
            ('下', 'xia4', 'dół; pod'),
            ('中', 'zhong1', 'środek; w'),
            ('左', 'zuo3', 'lewy'),
            ('右', 'you4', 'prawy'),
            ('前', 'qian2', 'przód; przed'),
            ('后', 'hou4', 'tył; po'),
            ('外', 'wai4', 'na zewnątrz'),
            ('东', 'dong1', 'wschód'),
            ('西', 'xi1', 'zachód'),
            ('南', 'nan2', 'południe'),
            ('北', 'bei3', 'północ'),
        ],
        "sentences": [
            (['我', '在', '中国'], 'Jestem w Chinach.'),
            (['北京', '在', '中国', '的', '北'], 'Pekin leży na północy Chin.'),
            (['他', '在', '门', '外'], 'On jest za drzwiami.'),
            (['书', '在', '这', '里'], 'Książka jest tutaj.'),
            (['我', '去', '学校'], 'Idę do szkoły.'),
        ],
    },
    {
        "id": 'rad5', "title": 'Kolory i rozmiary', "icon": '红', "color": '#C2255C', "track": "radicals",
        "words": [
            ('红', 'hong2', 'czerwony'),
            ('白', 'bai2', 'biały'),
            ('黑', 'hei1', 'czarny'),
            ('黄', 'huang2', 'żółty'),
            ('绿', 'lv4', 'zielony'),
            ('蓝', 'lan2', 'niebieski'),
            ('色', 'se4', 'kolor'),
            ('光', 'guang1', 'światło; promień'),
            ('明', 'ming2', 'jasny'),
            ('高', 'gao1', 'wysoki'),
            ('长', 'chang2', 'długi'),
            ('短', 'duan3', 'krótki'),
        ],
        "sentences": [
            (['这', '个', '是', '红', '色'], 'To jest czerwone.'),
            (['我', '的', '书', '是', '黑', '色', '的'], 'Moja książka jest czarna.'),
            (['她', '的', '花', '是', '黄', '色', '的'], 'Jej kwiat jest żółty.'),
            (['山', '很', '高'], 'Góra jest wysoka.'),
            (['河', '很', '长'], 'Rzeka jest długa.'),
        ],
    },
    {
        "id": "chengyu1", "title": 'Idiomy I', "icon": "成", "color": "#F76707",
        "track": "chengyu", "requires": "people",
        "words": [
            ("马马虎虎", "ma3 ma3 hu1 hu1", 'tak sobie; byle jak'),
            ("一心一意", "yi1 xin1 yi2 yi4", 'z całego serca'),
            ("人山人海", "ren2 shan1 ren2 hai3", 'tłumy ludzi'),
            ("自言自语", "zi4 yan2 zi4 yu3", 'mówić do siebie'),
            ("一路平安", "yi2 lu4 ping2 an1", 'szczęśliwej podróży'),
            ("好久不见", "hao3 jiu3 bu2 jian4", 'kopę lat'),
            ("不三不四", "bu4 san1 bu2 si4", 'podejrzany; nie wiadomo jaki'),
            ("半途而废", "ban4 tu2 er2 fei4", 'rzucić w połowie drogi'),
            ("对牛弹琴", "dui4 niu2 tan2 qin2", 'mówić do kogoś, kto i tak nie zrozumie'),
            ("画蛇添足", "hua4 she2 tian1 zu2", 'zepsuć coś przesadą'),
        ],
        "sentences": [
            (["我", "马马虎虎"], 'Tak sobie.'),
            (["好久不见", "你", "好", "吗"], 'Kopę lat! Jak się masz?'),
            (["他", "是", "不三不四", "的", "人"], 'To podejrzany człowiek.'),
        ],
    },
    {
        "id": "chengyu2", "title": 'Idiomy II', "icon": "语", "color": "#D9480F",
        "track": "chengyu",
        "words": [
            ("守株待兔", "shou3 zhu1 dai4 tu4", 'czekać na szczęście zamiast pracować'),
            ("井底之蛙", "jing3 di3 zhi1 wa1", 'ktoś o wąskich horyzontach'),
            ("亡羊补牢", "wang2 yang2 bu3 lao2", 'lepiej późno niż wcale'),
            ("塞翁失马", "sai4 weng1 shi1 ma3", 'nie ma tego złego, co by na dobre nie wyszło'),
            ("一石二鸟", "yi4 shi2 er4 niao3", 'upiec dwie pieczenie na jednym ogniu'),
            ("入乡随俗", "ru4 xiang1 sui2 su2", 'kiedy wejdziesz między wrony, musisz krakać jak i one'),
            ("熟能生巧", "shu2 neng2 sheng1 qiao3", 'praktyka czyni mistrza'),
            ("三心二意", "san1 xin1 er4 yi4", 'bez przekonania'),
            ("学以致用", "xue2 yi3 zhi4 yong4", 'uczyć się, żeby korzystać z wiedzy'),
            ("九牛一毛", "jiu3 niu2 yi4 mao2", 'kropla w morzu'),
        ],
        "sentences": [
            (["我", "不", "是", "井底之蛙"], 'Nie jestem żabą w studni.'),
            (["你", "三心二意"], 'Robisz to bez przekonania.'),
        ],
    },
    {
        "id": "classical1", "title": 'Klasyczny I', "icon": "文", "color": "#495057",
        "track": "classical", "requires": "numbers",
        "words": [
            ("吾", "wu2", 'ja (klasyczne 我)'),
            ("汝", "ru3", 'ty (klasyczne 你)'),
            ("之", "zhi1", 'to; go (po czasowniku) / jak 的'),
            ("乎", "hu1", '(klasyczna partykuła pytająca, jak 吗)'),
            ("也", "ye3", '(partykuła końcowa: „tak właśnie jest”)'),
            ("曰", "yue1", 'rzec; mówić'),
            ("子", "zi3", 'Mistrz (Konfucjusz)'),
            ("而", "er2", 'i; a jednak'),
            ("学", "xue2", 'uczyć się (poznawać)'),
            ("习", "xi2", 'ćwiczyć; powtarzać'),
            ("时", "shi2", 'we właściwym czasie'),
            ("知", "zhi1", 'wiedzieć; znać'),
            ("为", "wei2", 'być; uchodzić za'),
            ("其", "qi2", 'jego; jej'),
        ],
        "sentences": [
            (["子", "曰"], 'Mistrz rzekł…'),
            (["吾", "知", "之"], 'Wiem to.'),
            (["汝", "知", "之", "乎"], 'Czy to wiesz?'),
            (["学", "而", "时", "习", "之"], 'Ucz się i we właściwym czasie to ćwicz.'),
            (["知", "之", "为", "知", "之"], 'Gdy coś wiesz, mów, że wiesz.'),
        ],
    },
    {
        "id": "classical2", "title": 'Klasyczny II', "icon": "古", "color": "#343A40",
        "track": "classical",
        "words": [
            ("行", "xing2", 'chodzić; iść'),
            ("必", "bi4", 'na pewno; musieć'),
            ("师", "shi1", 'nauczyciel (klasyczne 老师)'),
            ("温", "wen1", 'powtarzać (dosł. ogrzewać)'),
            ("故", "gu4", 'stare'),
            ("新", "xin1", 'nowe'),
            ("日", "ri4", 'dzień; codziennie'),
            ("省", "xing3", 'badać; rozważać'),
            ("身", "shen1", 'siebie (dosł. ciało)'),
            ("己", "ji3", 'samemu sobie'),
            ("所", "suo3", 'to, co'),
            ("欲", "yu4", 'chcieć; pragnąć'),
            ("勿", "wu4", 'nie (rób)! (klasyczne 别)'),
            ("施", "shi1", 'narzucać; czynić komuś'),
            ("于", "yu2", 'do; na; w'),
        ],
        "sentences": [
            (["三", "人", "行", "必", "有", "我", "师"],
             'Gdy idą we trzech, jeden z nich może być moim nauczycielem.'),
            (["温", "故", "而", "知", "新"], 'Powtarzaj stare, by zrozumieć nowe.'),
            (["吾", "日", "三", "省", "吾", "身"], 'Codziennie trzy razy badam samego siebie.'),
            (["己", "所", "不", "欲", "勿", "施", "于", "人"],
             'Nie czyń drugiemu, co tobie niemiłe.'),
        ],
    },
])

TRACKS = {
    "modern": 'Współczesny chiński',
    "radicals": '部首  Obrazki i rdzenie',
    "chengyu": '成语  Chengyu: idiomy z czterech znaków',
    "classical": '文言  Chiński klasyczny',
}

HOOKS.update({
    '山': 'Trzy szczyty obok siebie: góra.',
    '火': 'Płomienie wznoszą się w górę: ogień. Na dole znaku zmienia się w 灬, jak w 热.',
    '木': 'Drzewo: pień, gałęzie u góry, korzenie na dole. Dwa drzewa to 林 (gaj), trzy to 森 (las).',
    '土': 'Kopiec ziemi z pędem nad linią gruntu.',
    '田': 'Pole podzielone ścieżkami na działki.',
    '石': 'Skała 厂 z kamieniem 口 pod nią: kamień.',
    '云': 'Chmura. Z 雨 (deszczem) na górze to 雲, forma tradycyjna.',
    '风': 'Wiatr. Tradycyjna forma 風 ma w środku owada 虫.',
    '花': '艹 (roślina) nad 化 (zmiana): roślina, która zmienia się w kwiat.',
    '草': '艹 (roślina) nad 早 (wcześnie): trawa.',
    '河': '氵 (woda) po lewej, 可 podpowiada dźwięk: rzeka.',
    '口': 'Otwarte usta narysowane jako kwadrat. Spotkałeś je w 吃, 喝 i 叫.',
    '手': 'Dłoń z palcami. Po lewej stronie kurczy się do 扌, jak w 打 (bić).',
    '心': 'Serce. Po lewej stronie zmienia się w 忄, jak w 快 (szybki) i 忙 (zajęty).',
    '目': 'Oko obrócone na bok. 看 (patrzeć) to 手 nad 目: dłoń osłaniająca oko.',
    '耳': 'Ucho narysowane jako zwój. Tradycyjne 聽 (słuchać) ma w środku ucho.',
    '足': 'Noga ze stopą na dole. To rdzeń „stopy” w 跑 (biec) i 路 (droga).',
    '头': 'Dwie kropki nad 大 (duży): duża rzecz na twoich barkach.',
    '力': 'Napięte ramię: siła. 男 (mężczyzna) to 田 (pole) + 力: ten, kto ma siłę na polu.',
    '女': 'Klęcząca kobieta ze skrzyżowanymi rękami. Widziałeś ją w 她, 好 i 妈.',
    '自': 'Nos widziany z przodu. Mówiąc „ja”, ludzie wskazują na nos.',
    '牙': 'Dwa zazębione zęby, górny i dolny.',
    '门': 'Dwa skrzydła drzwi. Tradycyjna forma 門 pokazuje je wyraźniej.',
    '车': 'Wóz widziany z góry. Tradycyjna forma 車 pokazuje dwa koła na osi.',
    '刀': 'Nóż z zakrzywionym ostrzem i rękojeścią.',
    '工': 'Kątownik stolarza między dwiema liniami: praca, rzemiosło. Zobacz 工作.',
    '马': 'Koń z grzywą i czterema nogami. Tradycyjna forma 馬 pokazuje je wyraźnie.',
    '鸟': 'Ptak z dziobem, tułowiem i nogami. Tradycyjna forma 鳥 ma oko.',
    '鱼': 'Ryba: głowa, łuskowate ciało 田, ogon. Tradycyjna forma 魚 pokazuje ogon jako cztery kropki.',
    '虫': 'Robak lub owad. To rdzeń małych stworzeń.',
    '米': 'Cztery ziarna ryżu wokół krzyża. 米饭 to ugotowany ryż.',
    '竹': 'Dwie łodygi bambusa z liśćmi. Na górze znaku zmienia się w ⺮, jak w 筷 (pałeczki).',
    '金': 'Dach nad ziemią i błyszczącymi bryłkami: metal, złoto. Po lewej zmienia się w 钅, jak w 钱 (pieniądze).',
    '言': 'Usta 口 z liniami mowy: słowa. Po lewej zmienia się w 讠, jak w 说 (mówić) i 谢 (dziękować).',
    '上': 'Kreska nad linią podstawy: góra.',
    '下': 'Kreska pod linią podstawy: dół.',
    '中': 'Strzała przez środek tarczy: środek. 中国 to Państwo Środka.',
    '左': '左 i 右 zaczynają się od kreski dłoni. 左 ma pod sobą 工 (narzędzie): pomocna dłoń.',
    '右': '右 ma pod kreską dłoni 口 (usta): ręka, którą jesz.',
    '东': 'Tradycyjna forma 東 pokazuje słońce 日 wschodzące za drzewem 木: wschód.',
    '西': 'Ptak siadający na gnieździe o zachodzie słońca: zachód.',
    '北': 'Dwie osoby siedzące plecami do siebie: północ, w stronę której odwracasz się plecami.',
    '红': '纟 (jedwab) + 工: czerwony jedwab. 纟 to rdzeń jedwabiu, jak w 绿.',
    '白': 'Słońce 日 z promieniem światła na górze: biały, jasny.',
    '黑': 'Sadza nad ogniem 灬: czarny.',
    '绿': '纟 (jedwab) + 录: zielony jedwab.',
    '蓝': '艹 (roślina) + 监: indygo, niebieski.',
    '光': 'Ogień nad klęczącym człowiekiem: światło.',
    '明': '日 (słońce) + 月 (księżyc): jasny. Znasz 明天.',
    '高': 'Wysoka wieża z dachem: wysoki.',
    '短': 'Mierzone strzałą 矢: krótki.',
})

INSIGHTS.update({
    'rad1': [{'title': 'Obrazki, które stały się literami', 'text': 'Wiele znaków zaczynało jako rysunki: 山 to trzy szczyty, 火 to płomienie, 木 to drzewo. Przez wieki rysunki wyprostowano w kreski, ale obraz wciąż tam jest. Dwadzieścia takich obrazków pomaga zgadywać setki innych znaków.', 'chain': []}],
    'rad2': [{'title': 'Części ciała, które się kurczą', 'text': 'Znaki ciała często ściskają się po lewej stronie innych znaków i podpowiadają znaczenie: 口 w 吃, 喝, 叫 (czynności ustami), 扌 (ręka) w 打, 忄 (serce) w 快. Gdy poznajesz nowy znak, patrz najpierw na jego lewą stronę.', 'chain': []}],
    'rad3': [{'title': 'Znaczenie plus dźwięk', 'text': 'Większość znaków łączy część znaczeniową z częścią dźwiękową. 妈 mā to 女 (kobieta) dla znaczenia i 马 mǎ (koń) dla dźwięku. Obie połówki już znasz. Rdzeń mówi, jaka to dziedzina, a druga połowa podpowiada dźwięk.', 'chain': []}],
    'rad4': [{'title': 'Wschód-zachód to rzecz', 'text': 'Chiński wymienia strony świata jako 东南西北 (wschód, południe, zachód, północ). A 东西 (wschód-zachód) znaczy też „rzecz”: 买东西 to kupować rzeczy. 上 i 下 to nie tylko góra i dół, ale też „poprzedni” i „następny”: 上午 to przedpołudnie, 下午 popołudnie.', 'chain': []}],
    'rad5': [{'title': 'Kolory idą z 色', 'text': 'Po kolorze zwykle stoi 色 (sè): 红色 to kolor czerwony. Wiele znaków kolorów ma rdzeń jedwabiu 纟 (红, 绿), bo kolory najpierw farbowano na jedwabiu. Porównaj 明, słońce i księżyc razem: najjaśniejsze słowo.', 'chain': []}],
})

INSIGHTS.update({
    "chengyu1": [
        {
            "title": 'Idiomy to małe opowieści',
            "text": 'Polski ma „upiec dwie pieczenie na jednym ogniu” i „kropla w morzu”. Chiński ma 成语 (chéngyǔ): cztery znaki, w których mieści się cała historia. Najpierw przeczytaj dosłownie, potem przejdź do znaczenia: 人山人海 to „ludzi góra, ludzi morze”, czyli tłumy. Słowa, które już znasz, pomogą je rozszyfrować.',
            "chain": [
                ('Tak sobie.', ["我", "马马虎虎"],
                 '马马虎虎 to „koń koń tygrys tygrys”: ani to, ani tamto. Jak 很好, bez 是.'),
                ('Kopę lat! Jak się masz?', ["好久不见", "你", "好", "吗"],
                 'Najpierw powitanie, potem pytanie, które już znasz.'),
            ],
        },
    ],
    "chengyu2": [
        {
            "title": 'Rozszyfruj znakami, które znasz',
            "text": 'Znasz 三 (trzy), 九 (dziewięć), 一 (jeden), 学 i 心. Użyj ich jako kotwic: 三心二意 to „trzy serca, dwa umysły”: bez przekonania. 九牛一毛 to „jeden włos z dziewięciu krów”: kropla w morzu. Najpierw zgadnij obrazek, potem znaczenie.',
            "chain": [
                ('Robisz to bez przekonania.', ["你", "三心二意"],
                 'Idiomy opisują jak przymiotniki, więc bez 是. Ta sama zasada co w 你很好.'),
                ('Nie jestem żabą w studni.', ["我", "不", "是", "井底之蛙"],
                 'Tu idiom działa jak rzeczownik (żaba), więc 是 jest potrzebne, z 不 przed nim.'),
            ],
        },
    ],
    "classical1": [
        {
            "title": 'Klasyczny to współczesny w skrócie',
            "text": 'Chińskiego klasycznego nie zaczynasz od zera. Większość przekłada się na słowa, które znasz: 吾 = 我, 汝 = 你, 乎 = 吗. Główna różnica: klasyczny używa jednego znaku tam, gdzie współczesny dwóch. 学习 (nauka) rozpada się z powrotem na 学 (uczyć się) i 习 (ćwiczyć).',
            "chain": [
                ('Wiem to.', ["吾", "知", "之"],
                 '吾 to klasyczne 我. 知 = wiedzieć. 之 znaczy „to” i stoi po czasowniku.'),
                ('Czy to wiesz?', ["汝", "知", "之", "乎"],
                 'Ten sam trik co we współczesnym: zdanie zostaje, na końcu partykuła pytająca. 汝 = 你, 乎 = 吗.'),
            ],
        },
        {
            "title": 'Czytamy Konfucjusza',
            "text": '„Dialogi konfucjańskie” (论语) zaczynają się od 子曰, „Mistrz rzekł”. Potem: 学而时习之, „ucz się i we właściwym czasie to ćwicz”. Każdy element już znasz. 而 łączy dwie czynności, jak „i”.',
            "chain": [
                ('Mistrz rzekł…', ["子", "曰"], '子 to Mistrz (Konfucjusz), 曰 = rzec.'),
                ('Ucz się i we właściwym czasie to ćwicz.', ["学", "而", "时", "习", "之"],
                 'ucz się + i + we-właściwym-czasie + ćwicz + to. Czas przed czynnością, jak we współczesnym.'),
            ],
        },
    ],
    "classical2": [
        {
            "title": 'Współczesne słowa wyrosły z tych',
            "text": 'Zajrzyj do słów, które znasz: 老师 zawiera 师 (nauczyciel), 时候 zawiera 时, a 学习 to 学 + 习. Współczesny chiński często skleił dwa klasyczne słowa w jedno. Każde słowo klasyczne rozjaśnia więc słowa współczesne.',
            "chain": [
                ('Powtarzaj stare, by zrozumieć nowe.', ["温", "故", "而", "知", "新"],
                 '温 powtarzaj + 故 stare, 而 i, 知 poznaj + 新 nowe.'),
                ('Gdy idą we trzech, jeden z nich może być moim nauczycielem.',
                 ["三", "人", "行", "必", "有", "我", "师"],
                 'trzech ludzi idzie, na pewno jest-tam mój nauczyciel. 有 działa jak we współczesnym.'),
            ],
        },
        {
            "title": '勿 to „nie rób”',
            "text": 'Współczesny mówi 别 albo 不要 na „nie rób”. Klasyczny mówi 勿. Chińska złota reguła: 己所不欲, 勿施于人, dosłownie „czego sam nie chcesz, nie narzucaj ludziom”.',
            "chain": [
                ('Nie czyń drugiemu, co tobie niemiłe.',
                 ["己", "所", "不", "欲", "勿", "施", "于", "人"],
                 'Zacznij od tego, czego nie chcesz: 己所不欲. Potem polecenie: 勿施于人.'),
            ],
        },
    ],
})

HOOKS.update({
    "马马虎虎": 'Legenda: malarz namalował głowę tygrysa na ciele konia i nazwał to „koniotygrysem”. Ani to, ani tamto: tak sobie.',
    "人山人海": 'Ludzi jak góra, ludzi jak morze.',
    "一心一意": 'Jedno serce, jedna myśl: cały poświęcasz się jednej rzeczy.',
    "自言自语": 'Sam mówi, sam gada.',
    "一路平安": 'Cała droga spokojna i bezpieczna. Mówi się to komuś, kto wyrusza w podróż.',
    "好久不见": 'Dobrze (bardzo) długo nie widzieć. Angielskie „long time no see” może pochodzić właśnie stąd.',
    "不三不四": 'Ani trzy, ani cztery: nigdzie nie pasuje, czyli podejrzany.',
    "半途而废": 'W połowie drogi porzucić.',
    "对牛弹琴": 'Muzyk grał krowie piękną muzykę. Krowa dalej żuła trawę.',
    "画蛇添足": 'Ludzie ścigali się, kto szybciej narysuje węża. Najszybszy skończył, potem dorysował nogi i przegrał: węże nie mają nóg.',
    "守株待兔": 'Rolnik zobaczył, jak zając rozbił się o pień. Przestał uprawiać pole i czekał przy pniu na następne.',
    "井底之蛙": 'Żaba na dnie studni myśli, że niebo jest wielkości wylotu studni. Zauważ 之 = 的.',
    "亡羊补牢": 'Pasterz stracił owce, potem naprawił zagrodę. Za późno, ale uratował resztę.',
    "塞翁失马": 'Staruszkowi z pogranicza uciekł koń. Wrócił z drugim koniem. Pech może okazać się szczęściem.',
    "一石二鸟": 'Jeden kamień, dwa ptaki. Ten sam obraz co w angielskim idiomie.',
    "入乡随俗": 'Wejdziesz do wioski, przestrzegaj jej zwyczajów.',
    "熟能生巧": 'Obycie rodzi wprawę.',
    "三心二意": 'Trzy serca, dwa umysły: nigdy w pełni przy jednej rzeczy.',
    "学以致用": 'Ucz się, żeby z tego korzystać. 学 to samo co w 学习.',
    "九牛一毛": 'Jeden włos z dziewięciu krów: odrobina.',
    "吾": 'Klasyczne 我. Wciąż spotkasz je w imionach i w piśmie oficjalnym.',
    "汝": 'Klasyczne 你. 氵 to woda, ale tu tylko podpowiada dźwięk.',
    "之": 'Dwie funkcje: „to/go” po czasowniku (知之 = wiedzieć to) albo jak 的 między rzeczownikami (井底之蛙).',
    "乎": 'Klasyczne 吗: postaw je na końcu, a powstanie pytanie.',
    "曰": 'Jak 日 (słońce), ale szersze: usta, z których wychodzi oddech. Mówienie.',
    "学": 'Pierwsza połowa 学习 i 学生.',
    "习": 'Druga połowa 学习: ćwiczenie w kółko.',
    "时": 'Pierwsza połowa 时候. 日 (słońce) po lewej wyznacza czas.',
    "师": 'Druga połowa 老师.',
    "新": 'Ukryte w wielu współczesnych słowach, np. 新年 (Nowy Rok).',
    "日": 'Obrazek słońca. 日 znaczy też dzień.',
    "身": 'Obrazek ciała. W klasycznym: „siebie”.',
    "勿": 'Klasyczne „nie rób”. Jak współczesne 别.',
    "知": 'Od tego zaczyna się współczesne 知道 (wiedzieć).',
})

# ---------------------------------------------------------------------------
# Practice chats. Bot lines and replies are token lists like sentences
# (punctuation tokens are allowed). Each turn has either "options"
# [(tokens, correct, explanation)] or "build" (tokens, English).
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "hello", "title": 'Przywitaj się', "partner": "Lili", "avatar": "丽",
        "requires": "greetings",
        "turns": [
            {"bot": ["你好", "！"], "en": 'Cześć!',
             "options": [(["你好", "！"], True, None),
                         (["再见", "！"], False, '再见 znaczy „do widzenia”. Dopiero się poznajecie!'),
                         (["对不起"], False, '对不起 to „przepraszam”. Na razie nie ma za co przepraszać.')]},
            {"bot": ["你", "好", "吗", "？"], "en": 'Jak się masz?',
             "options": [(["我", "很", "好", "，", "谢谢"], True, None),
                         (["我", "是", "好"], False, 'Po polsku mówisz „mam się”, po chińsku po prostu 我很好, bez 是.'),
                         (["我", "很", "好", "吗"], False, '吗 robi z tego pytanie. Odpowiadasz, a nie pytasz.')]},
            {"bot": ["谢谢", "你"], "en": 'Dziękuję.',
             "options": [(["不客气"], True, None),
                         (["没关系"], False, '没关系 odpowiada na „przepraszam”. Na „dziękuję” powiedz 不客气.'),
                         (["谢谢"], False, 'Podziękowała ci, więc odpowiedz „nie ma za co”: 不客气.')]},
            {"bot": ["再见", "！"], "en": 'Do widzenia!',
             "build": (["再见"], 'Do widzenia!')},
        ],
    },
    {
        "id": "classroom", "title": 'Pierwszy dzień zajęć', "partner": "Teacher Wang", "avatar": "王",
        "requires": "people",
        "turns": [
            {"bot": ["你好", "！", "你", "叫", "什么", "名字", "？"], "en": 'Cześć! Jak masz na imię?',
             "options": [(["我", "叫", "大明"], True, None),
                         (["什么", "名字", "我", "叫"], False, 'Odpowiedz w tym samym szyku co pytanie: 我叫 + imię.'),
                         (["我", "是", "叫", "大明"], False, '叫 już znaczy „nazywać się”. 是 nie jest potrzebne.')],
             "note": 'Udawaj, że masz na imię 大明 (Dà Míng).'},
            {"bot": ["你", "是", "老师", "吗", "？"], "en": 'Czy jesteś nauczycielem?',
             "options": [(["我", "不", "是", "老师", "，", "我", "是", "学生"], True, None),
                         (["我", "不", "老师"], False, 'Przy rzeczownikach 是 jest potrzebne: 我不是老师.'),
                         (["我", "是", "不", "老师"], False, '不 stoi tuż przed słowem, któremu przeczy: 不是.')]},
            {"bot": ["他", "是", "谁", "？"], "en": 'Kim on jest?',
             "build": (["他", "是", "我", "朋友"], 'On jest moim przyjacielem.')},
            {"bot": ["好", "！", "我们", "是", "朋友", "！"], "en": 'Super! Jesteśmy przyjaciółmi!',
             "options": [(["谢谢", "老师"], True, None),
                         (["对不起", "老师"], False, '对不起 to „przepraszam”. Spróbuj jej podziękować.')]},
        ],
    },
    {
        "id": "family", "title": 'Zdjęcia rodzinne', "partner": "Xiaoyu", "avatar": "雨",
        "requires": "family",
        "turns": [
            {"bot": ["你", "家", "有", "几", "个", "人", "？"], "en": 'Ile osób jest w twojej rodzinie?',
             "options": [(["我", "家", "有", "四", "个", "人"], True, None),
                         (["我", "家", "有", "四", "人"], False, 'Liczenie wymaga klasyfikatora: 四个人.'),
                         (["我", "家", "四", "个", "人", "有"], False, '有 stoi przed tym, co masz, jak polskie „mam”.')]},
            {"bot": ["你", "有", "狗", "吗", "？"], "en": 'Czy masz psa?',
             "options": [(["我", "没有", "狗"], True, None),
                         (["我", "不", "有", "狗"], False, '有 nigdy nie łączy się z 不. Zawsze 没有.'),
                         (["我", "有", "不", "狗"], False, 'Przeczenie od 有 to jedno słowo: 没有.')]},
            {"bot": ["我", "有", "一", "个", "女儿", "！"], "en": 'Mam córkę!',
             "build": (["她", "几", "岁"], 'Ile ona ma lat?')},
            {"bot": ["她", "八", "岁", "。", "你", "有", "儿子", "吗", "？"], "en": 'Ma osiem. A ty masz syna?',
             "options": [(["我", "有", "一", "个", "儿子"], True, None),
                         (["我", "有", "一", "儿子"], False, 'Liczenie wymaga klasyfikatora: 一个儿子.'),
                         (["我", "不", "有", "儿子"], False, 'Odpowiadasz „tak”? To 我有一个儿子. (I nigdy 不有, tylko 没有.)')]},
        ],
    },
    {
        "id": "restaurant", "title": 'W restauracji', "partner": "Waiter", "avatar": "店",
        "requires": "food",
        "turns": [
            {"bot": ["你好", "！", "你", "想", "吃", "什么", "？"], "en": 'Dzień dobry! Co chce pan zjeść?',
             "options": [(["我", "想", "吃", "面条"], True, None),
                         (["我", "想", "面条", "吃"], False, 'Ten sam szyk co po polsku: chcę, zjeść, makaron.'),
                         (["我", "吃", "想", "面条"], False, '想 (chcę) stoi przed czynnością.')]},
            {"bot": ["你", "想", "喝", "什么", "？"], "en": 'Co chce pan wypić?',
             "build": (["我", "想", "喝", "茶"], 'Chciałbym napić się herbaty.')},
            {"bot": ["好", "！", "面条", "和", "茶", "。"], "en": 'Dobrze! Makaron i herbata.',
             "options": [(["谢谢"], True, None),
                         (["没关系"], False, '没关系 odpowiada na przeprosiny. Po prostu podziękuj.')]},
            {"bot": ["好吃", "吗", "？"], "en": 'Smaczne?',
             "options": [(["很", "好吃", "！"], True, None),
                         (["是", "好吃"], False, 'Cechy nie potrzebują 是: 很好吃.')]},
        ],
    },
    {
        "id": "plans", "title": 'Plany na weekend', "partner": "Tom", "avatar": "汤",
        "requires": "places",
        "turns": [
            {"bot": ["你", "明天", "去", "哪儿", "？"], "en": 'Dokąd jedziesz jutro?',
             "options": [(["我", "明天", "去", "北京"], True, None),
                         (["我", "去", "北京", "明天"], False, 'Czas idzie przed czynnością: 我明天去北京.'),
                         (["我", "明天", "去", "哪儿", "北京"], False, 'Zastąp 哪儿 odpowiedzią. Nie zostaje w zdaniu.')]},
            {"bot": ["你", "去", "北京", "做", "什么", "？"], "en": 'Co będziesz robić w Pekinie?',
             "build": (["我", "去", "北京", "学习", "汉语"], 'Jadę do Pekinu uczyć się chińskiego.')},
            {"bot": ["太", "好", "了", "！"], "en": 'Świetnie!',
             "options": [(["一路平安"], False, 'To nie on wyjeżdża, tylko ty! Spróbuj mu podziękować.'),
                         (["谢谢", "！", "再见"], True, None)]},
            {"bot": ["一路平安", "！"], "en": 'Szczęśliwej podróży!',
             "options": [(["谢谢"], True, None),
                         (["好久不见"], False, 'To „kopę lat”, mówi się przy ponownym spotkaniu.')]},
        ],
    },
    {
        "id": "oldfriend", "title": 'Stara znajoma', "partner": "Lili", "avatar": "丽",
        "requires": "chengyu1",
        "turns": [
            {"bot": ["好久不见", "！", "你", "好", "吗", "？"], "en": 'Kopę lat! Jak się masz?',
             "options": [(["马马虎虎"], True, None),
                         (["人山人海"], False, '人山人海 to tłumy ludzi. Chodzi ci o „tak sobie”.'),
                         (["对牛弹琴"], False, 'To „mówić do krowy”. Spróbuj „tak sobie”.')]},
            {"bot": ["你", "还", "学", "汉语", "吗", "？"], "en": 'Dalej uczysz się chińskiego?',
             "options": [(["我", "一心一意", "学习", "汉语"], True, None),
                         (["我", "半途而废"], False, 'To znaczy, że rzuciłeś naukę w połowie! Nie przestawaj teraz.')]},
            {"bot": ["熟能生巧", "！"], "en": 'Praktyka czyni mistrza!',
             "build": (["谢谢", "你"], 'Dziękuję.')},
        ],
    },
    {
        "id": "master", "title": 'Zapytaj Mistrza', "partner": "Old Scholar", "avatar": "子",
        "requires": "classical1",
        "turns": [
            {"bot": ["子", "曰", "：", "学", "而", "时", "习", "之"], "en": 'Mistrz rzekł: ucz się i we właściwym czasie to ćwicz.',
             "options": [(["吾", "知", "之"], True, None),
                         (["我", "知", "之"], False, 'W stylu klasycznym użyj 吾, a nie współczesnego 我.'),
                         (["吾", "之", "知"], False, '之 (to) stoi po czasowniku: 知之.')]},
            {"bot": ["汝", "知", "之", "乎", "？"], "en": 'Czy (naprawdę) to wiesz?',
             "build": (["知", "之", "为", "知", "之"], 'Gdy coś wiesz, mów, że wiesz.')},
            {"bot": ["善", "！"], "en": 'Doskonale!',
             "options": [(["谢谢", "老师"], True, None),
                         (["再见"], False, 'Podziękuj nauczycielowi przed odejściem!')]},
        ],
    },
]

# Pinyin for tokens that appear in chats but aren't course words.
CHAT_EXTRA = {
    "大明": ("Da4 Ming2", 'Daming (imię)'),
    "还": ("hai2", 'wciąż; jeszcze'),
    "了": ("le5", '(partykuła zmiany / dokonania)'),
    "善": ("shan4", 'dobry; doskonały (klasyczne)'),
}
PUNCT = set("，。！？：、")


# ---------------------------------------------------------------------------
# Grammar tab: common difficulties and targeted drills, per interface language.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {'en': {'t_mw': ['书 (book)', '人 (person)', '茶 (tea, a cup)', '猫 (cat)', '纸 (paper, a sheet)', '车 (car)', '衣服 (clothes)', '鱼 (fish)'], 't_neg': ["我明天 ___ 去。(I'm not going tomorrow)", "我昨天 ___ 去。(I didn't go yesterday)", '我 ___ 有钱。(I have no money)', "他 ___ 是老师。(he isn't a teacher)", "我还 ___ 吃。(I haven't eaten yet)", "我 ___ 喜欢。(I don't like it)"], 't_szyk': ['who', 'when', 'where', 'does what', 'what (object)']},
                   'pl': {'t_mw': ['书 (książka)', '人 (człowiek)', '茶 (herbata, filiżanka)', '猫 (kot)', '纸 (papier, kartka)', '车 (samochód)', '衣服 (ubranie)', '鱼 (ryba)'], 't_neg': ['我明天 ___ 去。(jutro nie idę)', '我昨天 ___ 去。(wczoraj nie poszedłem)', '我 ___ 有钱。(nie mam pieniędzy)', '他 ___ 是老师。(nie jest nauczycielem)', '我还 ___ 吃。(jeszcze nie jadłem)', '我 ___ 喜欢。(nie lubię)'], 't_szyk': ['kto', 'kiedy', 'gdzie', 'co robi', 'co (dopełnienie)']}}

PARADIGMS = {'en': [('form', 'Common difficulties', 'Measure word: which one fits?', 't_mw', '本; 个; 杯; 只; 张; 辆; 件; 条', '本 books, 个 people and things in general, 杯 cups, 只 animals, 张 flat things, 辆 vehicles, 件 clothes, 条 long flexible things.'), ('form', 'Common difficulties', '不 or 没?', 't_neg', '不; 没; 没; 不; 没; 不', None), ('form', 'Common difficulties', 'Word order: 我明天在家吃饭', 't_szyk', '我; 明天; 在家; 吃; 饭', 'Who, when, where, does what, what.')],
             'pl': [('form', 'Typowe trudności', 'Klasyfikator: który pasuje?', 't_mw', '本; 个; 杯; 只; 张; 辆; 件; 条', '本 książki, 个 ludzie i rzeczy ogólnie, 杯 filiżanki, 只 zwierzęta, 张 płaskie, 辆 pojazdy, 件 ubrania, 条 długie i giętkie.'), ('form', 'Typowe trudności', '不 czy 没?', 't_neg', '不; 没; 没; 不; 没; 不', None), ('form', 'Typowe trudności', 'Szyk zdania: 我明天在家吃饭', 't_szyk', '我; 明天; 在家; 吃; 饭', 'Kto, kiedy, gdzie, co robi, co.')]}

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS['pl'].update({
    't_m0': ['她 ___ 漂亮。(jest ładna)', '他 ___ 老师。(jest nauczycielem)', '我 ___ 忙。(jestem zajęty)', '这 ___ 书。(to jest książka)', '今天 ___ 冷。(jest zimno)', '我 ___ 学生。(jestem studentem)'],
    't_m1': ['妈 mā', '麻 má', '马 mǎ', '骂 mà', '吗 ma', '好 hǎo', '是 shì', '人 rén'],
    't_m2': ['你好 ___？(jak się masz)', '你是学生 ___？(czy jesteś studentem)', '你去哪儿 ___？(dokąd idziesz)', '他来 ___？(czy on przyjdzie)', '这是什么 ___？(co to jest)', '你喝茶 ___？(czy pijesz herbatę)'],
    't_m3': ['mój nauczyciel', 'moja mama (bliska osoba)', 'twoja książka', 'jego samochód', 'nasza szkoła', 'mój przyjaciel'],
})
PARADIGMS['pl'] += [
    ('form', 'Typowe trudności', '很 czy 是?', 't_m0', '很; 是; 很; 是; 很; 是', 'Przed przymiotnikiem stoi 很, nie 是. 是 łączy dwa rzeczowniki.'),
    ('form', 'Typowe trudności', 'Tony: który ton?', 't_m1', '1; 2; 3; 4; neutralny; 3; 4; 2', 'Ta sama sylaba w innym tonie to inne słowo.'),
    ('form', 'Typowe trudności', 'Pytanie: 吗 czy bez?', 't_m2', '吗; 吗; (bez 吗); 吗; (bez 吗); 吗', '吗 robi pytanie tak/nie. W pytaniu ze słowem pytającym (哪儿, 什么) 吗 się nie dodaje.'),
    ('form', 'Typowe trudności', '的: mój, twój', 't_m3', '我的老师; 我妈妈; 你的书; 他的车; 我们的学校; 我的朋友', 'Przynależność wyraża 的. Przy bliskich krewnych zwykle się je pomija: 我妈妈.'),
]
PARADIGM_LABELS['en'].update({
    't_m0': ['她 ___ 漂亮。(she is pretty)', '他 ___ 老师。(he is a teacher)', '我 ___ 忙。(I am busy)', '这 ___ 书。(this is a book)', '今天 ___ 冷。(it is cold)', '我 ___ 学生。(I am a student)'],
    't_m1': ['妈 mā', '麻 má', '马 mǎ', '骂 mà', '吗 ma', '好 hǎo', '是 shì', '人 rén'],
    't_m2': ['你好 ___？(how are you)', '你是学生 ___？(are you a student)', '你去哪儿 ___？(where are you going)', '他来 ___？(is he coming)', '这是什么 ___？(what is this)', '你喝茶 ___？(do you drink tea)'],
    't_m3': ['my teacher', 'my mum (close person)', 'your book', 'his car', 'our school', 'my friend'],
})
PARADIGMS['en'] += [
    ('form', 'Common difficulties', '很 or 是?', 't_m0', '很; 是; 很; 是; 很; 是', '很 stands before an adjective, not 是. 是 links two nouns.'),
    ('form', 'Common difficulties', 'Tones: which tone?', 't_m1', '1; 2; 3; 4; neutral; 3; 4; 2', 'The same syllable in another tone is another word.'),
    ('form', 'Common difficulties', 'Question: 吗 or not?', 't_m2', '吗; 吗; (no 吗); 吗; (no 吗); 吗', '吗 makes a yes/no question. With a question word (哪儿, 什么) no 吗 is added.'),
    ('form', 'Common difficulties', '的: my, your', 't_m3', '我的老师; 我妈妈; 你的书; 他的车; 我们的学校; 我的朋友', '的 marks possession. With close relatives it is usually dropped: 我妈妈.'),
]

# Klasyfikatory i liczba mnoga
PARADIGM_LABELS['pl'].update({
    't_k0': ['一___人 (jedna osoba)', '一___老师 (nauczyciel, z szacunkiem)', '我家有四___人 (w rodzinie są cztery osoby)', '两___朋友 (dwoje przyjaciół)', '这___先生 (ten pan, z szacunkiem)', '三___学生 (trzech uczniów)', '几___客人 (ilu gości, z szacunkiem)', '你家有几___人 (ile osób jest w twojej rodzinie)'],
    't_k1': ['一___猫 (kot)', '一___鸟 (ptak)', '一___鱼 (ryba)', '一___蛇 (wąż)', '一___马 (koń)', '一___牛 (krowa)', '一___猪 (świnia)', '一___鸡 (kura)'],
    't_k2': ['一___桌子 (stół)', '一___纸 (kartka)', '一___床 (łóżko)', '一___路 (droga)', '一___裤子 (spodnie)', '一___椅子 (krzesło)', '一___伞 (parasol)', '一___笔 (długopis)'],
    't_k3': ['一___茶 (filiżanka herbaty)', '一___水 (butelka wody)', '一___米饭 (miska ryżu)', '一___蛋糕 (kawałek ciasta)', '一___筷子 (para pałeczek)', '一___鞋 (para butów)', '一___啤酒 (butelka piwa)', '一___咖啡 (filiżanka kawy)'],
    't_k4': ['一___书 (książka)', '一___词典 (słownik)', '一___衣服 (ubranie)', '一___事 (sprawa)', '一___车 (samochód)', '一___饭店 (restauracja)', '一___公司 (firma)', '一___山 (góra)'],
    't_k5': ['___个人 (dwie osoby)', '十___ (dwanaście)', '___十 (dwadzieścia)', '第___ (drugi)', '___点 (godzina druga)', '___月 (luty)', '___个月 (dwa miesiące)', '___本书 (dwie książki)'],
    't_k6': ['trzy książki', 'ta książka', 'tamten człowiek', 'ile osób?', 'która książka?', 'dwa miesiące', 'dwa dni', 'dwa lata'],
    't_k7': ['本', '张', '条', '只', '辆', '件', '位', '双'],
    't_k8': ['一___票 (bilet)', '一___照片 (zdjęcie)', '一___面包 (kromka chleba)', '一___树叶 (liść)', '一___星星 (gwiazda)', '一___牙 (ząb)', '一___硬币 (moneta)', '一___米 (ziarenko ryżu)'],
    't_k9': ['一___树 (drzewo)', '一___草 (źdźbło trawy)', '一___花 (kwiat (sam kwiat))', '一___云 (chmura)', '一___香蕉 (banan)', '一___头发 (włos)', '一___黄瓜 (ogórek)', '一___筷子 (jedna pałeczka)'],
    't_k10': ['一___电影 (film)', '一___电话 (telefon)', '一___歌 (piosenka)', '一___诗 (wiersz)', '一___信 (list)', '一___文章 (artykuł)', '一___画 (obraz)', '一___电子邮件 (e-mail)'],
    't_k11': ['一___商店 (sklep)', '一___银行 (bank)', '一___房间 (pokój)', '一___教室 (sala lekcyjna)', '一___学校 (szkoła)', '一___医院 (szpital)', '一___桥 (most)', '一___楼 (budynek)'],
    't_k12': ['一___电脑 (komputer)', '一___电视 (telewizor)', '一___洗衣机 (pralka)', '一___刀 (nóż)', '一___钥匙 (klucz)', '一___牙刷 (szczoteczka)', '一___眼镜 (okulary)', '一___手套 (rękawiczki)'],
    't_k13': ['一___饭 (posiłek)', '一___早饭 (śniadanie)', '一___报纸 (gazeta)', '一___工作 (praca)', '一___面条 (miska makaronu)', '一___饺子 (talerz pierogów)', '一___菜 (danie)', '一___汤 (zupa (danie))'],
    't_k14': ['去一___ (pójść raz)', '看一___电影 (obejrzeć film)', '下一___雨 (popada deszcz)', '去一___北京 (jazda do Pekinu i z powrotem)', '再读一___ (przeczytać jeszcze raz od początku do końca)', '一___事 (jedna sprawa)', '来一___ (przyjść raz)', '踢一___球 (mecz piłki)'],
    't_k15': ['条', '张', '只', '本', '辆', '件', '杯', '把'],
    't_k16': ['家', '间', '部', '首', '封', '台', '棵', '朵'],
})
PARADIGMS['pl'] += [
    ('form', 'Klasyfikatory', 'Ludzie: 个, 位 czy 口?', 't_k0', '个; 位; 口; 个; 位; 个; 位; 口', '个 jest zwykły, 位 grzeczny, 口 liczy domowników.'),
    ('form', 'Klasyfikatory', 'Zwierzęta: 只, 条, 匹 czy 头?', 't_k1', '只; 只; 条; 条; 匹; 头; 头; 只', '只 małe zwierzęta i ptaki, 条 długie i giętkie, 匹 konie, 头 duże zwierzęta gospodarskie.'),
    ('form', 'Klasyfikatory', 'Kształt: 张, 条, 把 czy 支?', 't_k2', '张; 张; 张; 条; 条; 把; 把; 支', '张 płaskie powierzchnie, 条 długie i giętkie, 把 rzeczy z uchwytem, 支 cienkie pałeczki.'),
    ('form', 'Klasyfikatory', 'Porcje i pary: 杯, 瓶, 碗, 块 czy 双?', 't_k3', '杯; 瓶; 碗; 块; 双; 双; 瓶; 杯', 'Naczynie samo jest klasyfikatorem. 块 to kawałek (i potocznie juan), 双 to para.'),
    ('form', 'Klasyfikatory', 'Rzeczy: 本, 件, 辆, 家 czy 座?', 't_k4', '本; 本; 件; 件; 辆; 家; 家; 座', '本 rzeczy oprawione, 件 ubrania i sprawy, 辆 pojazdy, 家 firmy i lokale, 座 góry i budowle.'),
    ('form', 'Klasyfikatory', '二 czy 两?', 't_k5', '两; 二; 二; 二; 两; 二; 两; 两', 'Przed klasyfikatorem „dwa” to 两. W liczeniu, liczbach złożonych i porządkowych: 二.'),
    ('form', 'Klasyfikatory', 'Gdzie stoi klasyfikator?', 't_k6', '三本书|三书|书三本; 这本书|这书本|本这书; 那个人|那人个|个那人; 几个人|几人个|个几人; 哪本书|哪书本|书哪本; 两个月|两月|二月; 两天|两个天|二个天; 两年|两个年|二个年', 'Liczba lub 这, 那, 哪, 几 + klasyfikator + rzeczownik. 天 i 年 same są miarami i nie biorą 个.'),
    ('form', 'Klasyfikatory', 'Co liczy ten klasyfikator?', 't_k7', 'książki, zeszyty; płaskie: kartki, stoły, łóżka; długie i giętkie: ryby, drogi, spodnie; małe zwierzęta, ptaki; pojazdy; ubrania, sprawy; osoby, z szacunkiem; pary: buty, pałeczki', 'x'),
    ('form', 'Klasyfikatory', 'Rzeczy płaskie i okrągłe: 张, 片, 颗, 枚, 粒', 't_k8', '张; 张; 片; 片; 颗; 颗; 枚; 粒', '张 płaskie i rozpostarte, 片 cienkie kawałki, 颗 małe okrągłe, 枚 monety i odznaki, 粒 ziarna.'),
    ('form', 'Klasyfikatory', 'Rośliny: 棵, 朵, 根, 株', 't_k9', '棵; 棵; 朵; 朵; 根; 根; 根; 根', '棵 całe rośliny, 朵 kwiaty i chmury, 根 cienkie i długie, sztywne rzeczy.'),
    ('form', 'Klasyfikatory', 'Media i sztuka: 部, 首, 封, 篇, 幅', 't_k10', '部; 部; 首; 首; 封; 篇; 幅; 封', '部 filmy i telefony, 首 piosenki i wiersze, 封 listy, 篇 teksty, 幅 obrazy.'),
    ('form', 'Klasyfikatory', 'Miejsca i budynki: 家, 间, 所, 座, 栋', 't_k11', '家; 家; 间; 间; 所; 所; 座; 栋', '家 firmy i lokale, 间 pomieszczenia, 所 instytucje, 座 duże nieruchome (mosty, góry), 栋 budynki.'),
    ('form', 'Klasyfikatory', 'Urządzenia i narzędzia: 台, 部, 把, 支, 副', 't_k12', '台; 台; 台; 把; 把; 把; 副; 副', '台 maszyny i sprzęt, 把 rzeczy z rączką, 副 zestawy parzyste (okulary, rękawiczki).'),
    ('form', 'Klasyfikatory', 'Jedzenie i posiłki: 顿, 份, 碗, 盘, 道', 't_k13', '顿; 顿; 份; 份; 碗; 盘; 道; 道', '顿 posiłki, 份 porcje i egzemplarze (gazeta, praca), 盘 talerz, 道 dania i pytania.'),
    ('form', 'Klasyfikatory', 'Zdarzenia i czas: 次, 场, 趟, 遍, 回', 't_k14', '次; 场; 场; 趟; 遍; 回; 次; 场', '次 ogólne „raz”, 场 zdarzenia (mecze, deszcz, film), 趟 kurs tam i z powrotem, 遍 od początku do końca.'),
    ('form', 'Klasyfikatory', 'Co się z czym liczy? Część 1', 't_k15', '鱼、路、裤子、河|桌子、纸、床、票|书、词典、杂志、本子|衣服、事、礼物、行李; 桌子、纸、床、票|猫、鸟、鸡、兔子|车、自行车、公共汽车|茶、咖啡、水、啤酒; 猫、鸟、鸡、兔子|书、词典、杂志、本子|衣服、事、礼物、行李|椅子、伞、刀、钥匙; 书、词典、杂志、本子|车、自行车、公共汽车|茶、咖啡、水、啤酒|鱼、路、裤子、河; 车、自行车、公共汽车|衣服、事、礼物、行李|椅子、伞、刀、钥匙|桌子、纸、床、票; 衣服、事、礼物、行李|茶、咖啡、水、啤酒|鱼、路、裤子、河|猫、鸟、鸡、兔子; 茶、咖啡、水、啤酒|椅子、伞、刀、钥匙|桌子、纸、床、票|书、词典、杂志、本子; 椅子、伞、刀、钥匙|鱼、路、裤子、河|猫、鸟、鸡、兔子|车、自行车、公共汽车', 'Klasyfikator trzeba znać razem z rzeczownikiem. Tu odwrotnie: do jakich rzeczy należy.'),
    ('form', 'Klasyfikatory', 'Co się z czym liczy? Część 2', 't_k16', '商店、银行、饭店、公司|房间、教室、卧室|歌、诗|电脑、电视、洗衣机; 房间、教室、卧室|电影、手机、电视剧|信、电子邮件|树、草、白菜; 电影、手机、电视剧|歌、诗|电脑、电视、洗衣机|花、云; 歌、诗|信、电子邮件|树、草、白菜|商店、银行、饭店、公司; 信、电子邮件|电脑、电视、洗衣机|花、云|房间、教室、卧室; 电脑、电视、洗衣机|树、草、白菜|商店、银行、饭店、公司|电影、手机、电视剧; 树、草、白菜|花、云|房间、教室、卧室|歌、诗; 花、云|商店、银行、饭店、公司|电影、手机、电视剧|信、电子邮件', 'Klasyfikator trzeba znać razem z rzeczownikiem. Tu odwrotnie: do jakich rzeczy należy.'),
]
PARADIGM_LABELS['en'].update({
    't_k0': ['一___人 (one person)', '一___老师 (a teacher, respectfully)', '我家有四___人 (four people in my family)', '两___朋友 (two friends)', '这___先生 (this gentleman, respectfully)', '三___学生 (three students)', '几___客人 (how many guests, respectfully)', '你家有几___人 (how many people in your family)'],
    't_k1': ['一___猫 (cat)', '一___鸟 (bird)', '一___鱼 (fish)', '一___蛇 (snake)', '一___马 (horse)', '一___牛 (cow)', '一___猪 (pig)', '一___鸡 (chicken)'],
    't_k2': ['一___桌子 (table)', '一___纸 (sheet of paper)', '一___床 (bed)', '一___路 (road)', '一___裤子 (trousers)', '一___椅子 (chair)', '一___伞 (umbrella)', '一___笔 (pen)'],
    't_k3': ['一___茶 (a cup of tea)', '一___水 (a bottle of water)', '一___米饭 (a bowl of rice)', '一___蛋糕 (a piece of cake)', '一___筷子 (a pair of chopsticks)', '一___鞋 (a pair of shoes)', '一___啤酒 (a bottle of beer)', '一___咖啡 (a cup of coffee)'],
    't_k4': ['一___书 (book)', '一___词典 (dictionary)', '一___衣服 (piece of clothing)', '一___事 (matter)', '一___车 (car)', '一___饭店 (restaurant)', '一___公司 (company)', '一___山 (mountain)'],
    't_k5': ['___个人 (two people)', '十___ (twelve)', '___十 (twenty)', '第___ (second)', "___点 (two o'clock)", '___月 (February)', '___个月 (two months)', '___本书 (two books)'],
    't_k6': ['three books', 'this book', 'that person', 'how many people?', 'which book?', 'two months', 'two days', 'two years'],
    't_k7': ['本', '张', '条', '只', '辆', '件', '位', '双'],
    't_k8': ['一___票 (ticket)', '一___照片 (photo)', '一___面包 (slice of bread)', '一___树叶 (leaf)', '一___星星 (star)', '一___牙 (tooth)', '一___硬币 (coin)', '一___米 (grain of rice)'],
    't_k9': ['一___树 (tree)', '一___草 (blade of grass)', '一___花 (flower (the bloom))', '一___云 (cloud)', '一___香蕉 (banana)', '一___头发 (hair)', '一___黄瓜 (cucumber)', '一___筷子 (one chopstick)'],
    't_k10': ['一___电影 (film)', '一___电话 (phone)', '一___歌 (song)', '一___诗 (poem)', '一___信 (letter)', '一___文章 (article)', '一___画 (painting)', '一___电子邮件 (email)'],
    't_k11': ['一___商店 (shop)', '一___银行 (bank)', '一___房间 (room)', '一___教室 (classroom)', '一___学校 (school)', '一___医院 (hospital)', '一___桥 (bridge)', '一___楼 (building)'],
    't_k12': ['一___电脑 (computer)', '一___电视 (TV)', '一___洗衣机 (washing machine)', '一___刀 (knife)', '一___钥匙 (key)', '一___牙刷 (toothbrush)', '一___眼镜 (glasses)', '一___手套 (gloves)'],
    't_k13': ['一___饭 (meal)', '一___早饭 (breakfast)', '一___报纸 (newspaper)', '一___工作 (job)', '一___面条 (bowl of noodles)', '一___饺子 (plate of dumplings)', '一___菜 (dish)', '一___汤 (soup (a course))'],
    't_k14': ['去一___ (go once)', '看一___电影 (watch a film)', '下一___雨 (a spell of rain)', '去一___北京 (a trip to Beijing)', '再读一___ (read it once more, start to finish)', '一___事 (one matter)', '来一___ (come once)', '踢一___球 (a ball game)'],
    't_k15': ['条', '张', '只', '本', '辆', '件', '杯', '把'],
    't_k16': ['家', '间', '部', '首', '封', '台', '棵', '朵'],
})
PARADIGMS['en'] += [
    ('form', 'Measure words', 'People: 个, 位 or 口?', 't_k0', '个; 位; 口; 个; 位; 个; 位; 口', '个 is the plain one, 位 is polite, 口 counts household members.'),
    ('form', 'Measure words', 'Animals: 只, 条, 匹 or 头?', 't_k1', '只; 只; 条; 条; 匹; 头; 头; 只', '只 small animals and birds, 条 long flexible ones, 匹 horses, 头 large livestock.'),
    ('form', 'Measure words', 'Shape: 张, 条, 把 or 支?', 't_k2', '张; 张; 张; 条; 条; 把; 把; 支', '张 flat surfaces, 条 long flexible things, 把 things with a handle, 支 thin sticks.'),
    ('form', 'Measure words', 'Portions and pairs: 杯, 瓶, 碗, 块 or 双?', 't_k3', '杯; 瓶; 碗; 块; 双; 双; 瓶; 杯', 'The container itself is the measure word. 块 is a piece (and colloquially a yuan), 双 is a pair.'),
    ('form', 'Measure words', 'Things: 本, 件, 辆, 家 or 座?', 't_k4', '本; 本; 件; 件; 辆; 家; 家; 座', '本 bound things, 件 clothes and matters, 辆 vehicles, 家 businesses, 座 mountains and large buildings.'),
    ('form', 'Measure words', '二 or 两?', 't_k5', '两; 二; 二; 二; 两; 二; 两; 两', "Before a measure word 'two' is 两. In counting, compound and ordinal numbers: 二."),
    ('form', 'Measure words', 'Where does the measure word go?', 't_k6', '三本书|三书|书三本; 这本书|这书本|本这书; 那个人|那人个|个那人; 几个人|几人个|个几人; 哪本书|哪书本|书哪本; 两个月|两月|二月; 两天|两个天|二个天; 两年|两个年|二个年', 'Number or 这, 那, 哪, 几 + measure word + noun. 天 and 年 are measures themselves and take no 个.'),
    ('form', 'Measure words', 'What does this measure word count?', 't_k7', 'books, notebooks; flat things: sheets, tables, beds; long flexible things: fish, roads, trousers; small animals, birds; vehicles; clothes, matters; people, respectfully; pairs: shoes, chopsticks', 'x'),
    ('form', 'Measure words', 'Flat and round things: 张, 片, 颗, 枚, 粒', 't_k8', '张; 张; 片; 片; 颗; 颗; 枚; 粒', '张 flat and spread out, 片 thin pieces, 颗 small round things, 枚 coins and badges, 粒 grains.'),
    ('form', 'Measure words', 'Plants: 棵, 朵, 根, 株', 't_k9', '棵; 棵; 朵; 朵; 根; 根; 根; 根', '棵 whole plants, 朵 blooms and clouds, 根 thin, long, stiff things.'),
    ('form', 'Measure words', 'Media and art: 部, 首, 封, 篇, 幅', 't_k10', '部; 部; 首; 首; 封; 篇; 幅; 封', '部 films and phones, 首 songs and poems, 封 letters, 篇 texts, 幅 paintings.'),
    ('form', 'Measure words', 'Places and buildings: 家, 间, 所, 座, 栋', 't_k11', '家; 家; 间; 间; 所; 所; 座; 栋', '家 businesses, 间 rooms, 所 institutions, 座 large fixed things (bridges, mountains), 栋 buildings.'),
    ('form', 'Measure words', 'Devices and tools: 台, 部, 把, 支, 副', 't_k12', '台; 台; 台; 把; 把; 把; 副; 副', '台 machines and equipment, 把 things with a handle, 副 paired sets (glasses, gloves).'),
    ('form', 'Measure words', 'Food and meals: 顿, 份, 碗, 盘, 道', 't_k13', '顿; 顿; 份; 份; 碗; 盘; 道; 道', '顿 meals, 份 portions and copies (newspaper, job), 盘 plate, 道 courses and questions.'),
    ('form', 'Measure words', 'Events and times: 次, 场, 趟, 遍, 回', 't_k14', '次; 场; 场; 趟; 遍; 回; 次; 场', "次 general 'time', 场 events (matches, rain, shows), 趟 a round trip, 遍 start to finish."),
    ('form', 'Measure words', 'What goes with what? Part 1', 't_k15', '鱼、路、裤子、河|桌子、纸、床、票|书、词典、杂志、本子|衣服、事、礼物、行李; 桌子、纸、床、票|猫、鸟、鸡、兔子|车、自行车、公共汽车|茶、咖啡、水、啤酒; 猫、鸟、鸡、兔子|书、词典、杂志、本子|衣服、事、礼物、行李|椅子、伞、刀、钥匙; 书、词典、杂志、本子|车、自行车、公共汽车|茶、咖啡、水、啤酒|鱼、路、裤子、河; 车、自行车、公共汽车|衣服、事、礼物、行李|椅子、伞、刀、钥匙|桌子、纸、床、票; 衣服、事、礼物、行李|茶、咖啡、水、啤酒|鱼、路、裤子、河|猫、鸟、鸡、兔子; 茶、咖啡、水、啤酒|椅子、伞、刀、钥匙|桌子、纸、床、票|书、词典、杂志、本子; 椅子、伞、刀、钥匙|鱼、路、裤子、河|猫、鸟、鸡、兔子|车、自行车、公共汽车', 'Learn the measure word with the noun. Here the other way round: what it goes with.'),
    ('form', 'Measure words', 'What goes with what? Part 2', 't_k16', '商店、银行、饭店、公司|房间、教室、卧室|歌、诗|电脑、电视、洗衣机; 房间、教室、卧室|电影、手机、电视剧|信、电子邮件|树、草、白菜; 电影、手机、电视剧|歌、诗|电脑、电视、洗衣机|花、云; 歌、诗|信、电子邮件|树、草、白菜|商店、银行、饭店、公司; 信、电子邮件|电脑、电视、洗衣机|花、云|房间、教室、卧室; 电脑、电视、洗衣机|树、草、白菜|商店、银行、饭店、公司|电影、手机、电视剧; 树、草、白菜|花、云|房间、教室、卧室|歌、诗; 花、云|商店、银行、饭店、公司|电影、手机、电视剧|信、电子邮件', 'Learn the measure word with the noun. Here the other way round: what it goes with.'),
]

# Szyk zdania
PARADIGM_LABELS['pl'].update({
    't_s0': ['Jem chleb.', 'Ona jest nauczycielką.', 'Czy jesteś studentem?'],
    't_s1': ['Dziś idę do szkoły.', 'On codziennie pije herbatę.', 'Mieszkam w Pekinie.'],
})
PARADIGMS['pl'] += [
    ('form', 'Szyk zdania', 'Szyk: podmiot, orzeczenie, dopełnienie', 't_s0', '我吃面包。|我面包吃。|吃我面包。|面包吃我。; 她是老师。|她老师是。|是她老师。|老师她是。; 你是学生吗？|你是吗学生？|你吗是学生？|吗你是学生？', 'Szyk jak w polskim: podmiot, czasownik, dopełnienie. Zmiana miejsc zmienia sens: 面包吃我 to „chleb zjada mnie”. 吗 stoi na końcu zdania.'),
    ('form', 'Szyk zdania', 'Szyk: czas i miejsce przed czasownikiem', 't_s1', '我今天去学校。|我去今天学校。|我去学校今天。|去我今天学校。; 他每天喝茶。|他喝茶每天。|每天喝他茶。|他喝每天茶。; 我住在北京。|我北京在住。|住我在北京。|我在住北京。', 'Czas i miejsce stoją przed czasownikiem, nie po nim jak w polskim.'),
]
PARADIGM_LABELS['en'].update({
    't_s0': ['I eat bread.', 'She is a teacher.', 'Are you a student?'],
    't_s1': ['I go to school today.', 'He drinks tea every day.', 'I live in Beijing.'],
})
PARADIGMS['en'] += [
    ('form', 'Word order', 'Word order: subject, verb, object', 't_s0', '我吃面包。|我面包吃。|吃我面包。|面包吃我。; 她是老师。|她老师是。|是她老师。|老师她是。; 你是学生吗？|你是吗学生？|你吗是学生？|吗你是学生？', 'Order as in English: subject, verb, object. Swapping them changes the meaning: 面包吃我 is “the bread eats me”. 吗 goes at the end.'),
    ('form', 'Word order', 'Word order: time and place before the verb', 't_s1', '我今天去学校。|我去今天学校。|我去学校今天。|去我今天学校。; 他每天喝茶。|他喝茶每天。|每天喝他茶。|他喝每天茶。; 我住在北京。|我北京在住。|住我在北京。|我在住北京。', 'Time and place come before the verb, not after it as in English.'),
]

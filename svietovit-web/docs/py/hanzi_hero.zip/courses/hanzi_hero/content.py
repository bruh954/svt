"""Course content: Simplified Chinese, roughly HSK 1 level.

Each word is (hanzi, numbered pinyin, English).
  - Syllables are separated by spaces, tone number at the end (5 = neutral tone).
  - Write ü as "v" (nv3 -> nǚ).
  - Capitalise proper nouns (Bei3 jing1 -> Běijīng).
Each sentence is (list of word tokens, English). Every token must be a word
somewhere in the course so the app can show its pinyin.

To add a unit, append a dict to UNITS. The app picks it up automatically.
"""

UNITS = [
    {
        "id": "greetings", "title": "Greetings", "icon": "你", "color": "#12B886",
        "words": [
            ("你", "ni3", "you"),
            ("我", "wo3", "I; me"),
            ("好", "hao3", "good"),
            ("你好", "ni3 hao3", "hello"),
            ("是", "shi4", "to be"),
            ("不", "bu4", "not; no"),
            ("很", "hen3", "very"),
            ("吗", "ma5", "(yes/no question particle)"),
            ("谢谢", "xie4 xie5", "thank you"),
            ("再见", "zai4 jian4", "goodbye"),
            ("对不起", "dui4 bu5 qi3", "sorry"),
            ("没关系", "mei2 guan1 xi5", "it's okay; never mind"),
            ("不客气", "bu2 ke4 qi5", "you're welcome"),
        ],
        "sentences": [
            (["你", "好", "吗"], "How are you?"),
            (["我", "很", "好"], "I am very well."),
            (["我", "不", "好"], "I am not well."),
            (["谢谢", "你"], "Thank you."),
        ],
    },
    {
        "id": "people", "title": "People", "icon": "人", "color": "#4DABF7",
        "words": [
            ("他", "ta1", "he; him"),
            ("她", "ta1", "she; her"),
            ("我们", "wo3 men5", "we; us"),
            ("你们", "ni3 men5", "you (plural)"),
            ("人", "ren2", "person"),
            ("中国", "Zhong1 guo2", "China"),
            ("老师", "lao3 shi1", "teacher"),
            ("学生", "xue2 sheng5", "student"),
            ("朋友", "peng2 you5", "friend"),
            ("叫", "jiao4", "to be called"),
            ("什么", "shen2 me5", "what"),
            ("名字", "ming2 zi5", "name"),
        ],
        "sentences": [
            (["我", "是", "学生"], "I am a student."),
            (["他", "是", "老师"], "He is a teacher."),
            (["你", "叫", "什么", "名字"], "What is your name?"),
            (["她", "是", "我", "朋友"], "She is my friend."),
            (["我们", "是", "中国", "人"], "We are Chinese."),
            (["你", "是", "学生", "吗"], "Are you a student?"),
        ],
    },
    {
        "id": "numbers", "title": "Numbers", "icon": "三", "color": "#FF922B",
        "words": [
            ("一", "yi1", "one"),
            ("二", "er4", "two"),
            ("三", "san1", "three"),
            ("四", "si4", "four"),
            ("五", "wu3", "five"),
            ("六", "liu4", "six"),
            ("七", "qi1", "seven"),
            ("八", "ba1", "eight"),
            ("九", "jiu3", "nine"),
            ("十", "shi2", "ten"),
            ("几", "ji3", "how many (small number)"),
            ("岁", "sui4", "years old"),
        ],
        "sentences": [
            (["你", "几", "岁"], "How old are you?"),
            (["我", "十", "岁"], "I am ten years old."),
            (["他", "八", "岁"], "He is eight years old."),
            (["她", "是", "九", "岁", "吗"], "Is she nine years old?"),
        ],
    },
    {
        "id": "family", "title": "Family", "icon": "家", "color": "#CC5DE8",
        "words": [
            ("家", "jia1", "home; family"),
            ("爸爸", "ba4 ba5", "dad"),
            ("妈妈", "ma1 ma5", "mom"),
            ("儿子", "er2 zi5", "son"),
            ("女儿", "nv3 er2", "daughter"),
            ("有", "you3", "to have"),
            ("没有", "mei2 you3", "to not have"),
            ("个", "ge4", "(general measure word)"),
            ("狗", "gou3", "dog"),
            ("猫", "mao1", "cat"),
            ("和", "he2", "and"),
            ("的", "de5", "(possessive particle)"),
        ],
        "sentences": [
            (["我", "有", "一", "个", "儿子"], "I have a son."),
            (["你", "有", "狗", "吗"], "Do you have a dog?"),
            (["我", "没有", "猫"], "I don't have a cat."),
            (["我", "家", "有", "四", "个", "人"], "There are four people in my family."),
            (["我", "的", "朋友", "有", "三", "个", "女儿"], "My friend has three daughters."),
        ],
    },
    {
        "id": "food", "title": "Food & Drink", "icon": "吃", "color": "#F25F5C",
        "words": [
            ("吃", "chi1", "to eat"),
            ("喝", "he1", "to drink"),
            ("水", "shui3", "water"),
            ("茶", "cha2", "tea"),
            ("米饭", "mi3 fan4", "rice (cooked)"),
            ("菜", "cai4", "dish; vegetables"),
            ("苹果", "ping2 guo3", "apple"),
            ("想", "xiang3", "to want; to think"),
            ("爱", "ai4", "to love"),
            ("面条", "mian4 tiao2", "noodles"),
            ("饭店", "fan4 dian4", "restaurant"),
            ("杯子", "bei1 zi5", "cup"),
        ],
        "sentences": [
            (["我", "想", "喝", "茶"], "I want to drink tea."),
            (["你", "吃", "米饭", "吗"], "Do you eat rice?"),
            (["我", "爱", "吃", "苹果"], "I love eating apples."),
            (["他", "不", "喝", "水"], "He doesn't drink water."),
            (["我", "想", "吃", "面条"], "I want to eat noodles."),
        ],
    },
    {
        "id": "time", "title": "Time", "icon": "天", "color": "#FAB005",
        "words": [
            ("今天", "jin1 tian1", "today"),
            ("明天", "ming2 tian1", "tomorrow"),
            ("昨天", "zuo2 tian1", "yesterday"),
            ("现在", "xian4 zai4", "now"),
            ("点", "dian3", "o'clock"),
            ("年", "nian2", "year"),
            ("月", "yue4", "month"),
            ("号", "hao4", "day of the month"),
            ("星期", "xing1 qi1", "week"),
            ("上午", "shang4 wu3", "morning"),
            ("下午", "xia4 wu3", "afternoon"),
            ("时候", "shi2 hou5", "(point in) time"),
        ],
        "sentences": [
            (["今天", "星期", "几"], "What day of the week is it today?"),
            (["现在", "几", "点"], "What time is it now?"),
            (["明天", "是", "几", "月", "几", "号"], "What is the date tomorrow?"),
            (["我", "今天", "很", "好"], "I am very well today."),
            (["现在", "是", "下午", "三", "点"], "It is three in the afternoon now."),
        ],
    },
    {
        "id": "places", "title": "Places", "icon": "去", "color": "#20C997",
        "words": [
            ("在", "zai4", "at; in"),
            ("哪儿", "nar3", "where"),
            ("这", "zhe4", "this"),
            ("那", "na4", "that"),
            ("学校", "xue2 xiao4", "school"),
            ("医院", "yi1 yuan4", "hospital"),
            ("商店", "shang1 dian4", "shop"),
            ("去", "qu4", "to go"),
            ("来", "lai2", "to come"),
            ("北京", "Bei3 jing1", "Beijing"),
            ("里", "li3", "inside"),
            ("回", "hui2", "to return"),
        ],
        "sentences": [
            (["你", "在", "哪儿"], "Where are you?"),
            (["我", "去", "学校"], "I am going to school."),
            (["他", "在", "医院"], "He is at the hospital."),
            (["这", "是", "什么"], "What is this?"),
            (["我", "明天", "回", "北京"], "I am going back to Beijing tomorrow."),
            (["那", "是", "我", "家"], "That is my home."),
        ],
    },
    {
        "id": "actions", "title": "Actions", "icon": "看", "color": "#5C7CFA",
        "words": [
            ("看", "kan4", "to look; to watch"),
            ("听", "ting1", "to listen"),
            ("说", "shuo1", "to speak"),
            ("读", "du2", "to read (aloud)"),
            ("写", "xie3", "to write"),
            ("做", "zuo4", "to do; to make"),
            ("买", "mai3", "to buy"),
            ("开", "kai1", "to open; to drive"),
            ("坐", "zuo4", "to sit"),
            ("睡觉", "shui4 jiao4", "to sleep"),
            ("工作", "gong1 zuo4", "to work; job"),
            ("学习", "xue2 xi2", "to study"),
            ("书", "shu1", "book"),
        ],
        "sentences": [
            (["我", "在", "学校", "学习"], "I study at school."),
            (["他", "在", "看", "书"], "He is reading a book."),
            (["我", "想", "买", "苹果"], "I want to buy apples."),
            (["妈妈", "在", "工作"], "Mom is working."),
            (["你", "想", "做", "什么"], "What do you want to do?"),
        ],
    },
    {
        "id": "describing", "title": "Describing", "icon": "大", "color": "#E64980",
        "words": [
            ("大", "da4", "big"),
            ("小", "xiao3", "small"),
            ("多", "duo1", "many; much"),
            ("少", "shao3", "few; little"),
            ("热", "re4", "hot"),
            ("冷", "leng3", "cold"),
            ("漂亮", "piao4 liang5", "pretty"),
            ("高兴", "gao1 xing4", "happy"),
            ("太", "tai4", "too (much)"),
            ("好吃", "hao3 chi1", "tasty"),
            ("天气", "tian1 qi4", "weather"),
            ("钱", "qian2", "money"),
        ],
        "sentences": [
            (["今天", "天气", "很", "好"], "The weather is very good today."),
            (["今天", "很", "热"], "It is hot today."),
            (["这", "个", "菜", "很", "好吃"], "This dish is very tasty."),
            (["她", "很", "漂亮"], "She is very pretty."),
            (["我", "没有", "钱"], "I don't have money."),
        ],
    },
    {
        "id": "questions", "title": "Questions", "icon": "谁", "color": "#7950F2",
        "words": [
            ("呢", "ne5", "(follow-up question particle)"),
            ("谁", "shei2", "who"),
            ("怎么", "zen3 me5", "how"),
            ("多少", "duo1 shao5", "how many; how much"),
            ("为什么", "wei4 shen2 me5", "why"),
            ("会", "hui4", "can (a learned skill)"),
            ("能", "neng2", "can; to be able to"),
            ("喜欢", "xi3 huan5", "to like"),
            ("认识", "ren4 shi5", "to know (a person)"),
            ("汉语", "Han4 yu3", "Chinese (language)"),
            ("字", "zi4", "character; written word"),
            ("电话", "dian4 hua4", "phone"),
        ],
        "sentences": [
            (["你", "会", "说", "汉语", "吗"], "Can you speak Chinese?"),
            (["他", "是", "谁"], "Who is he?"),
            (["你", "喜欢", "喝", "茶", "吗"], "Do you like drinking tea?"),
            (["我", "认识", "你"], "I know you."),
            (["这", "个", "字", "怎么", "读"], "How do you read this character?"),
            (["我", "很", "好", "你", "呢"], "I'm fine, and you?"),
        ],
    },
]


# ---------------------------------------------------------------------------
# Language Transfer-style insights.
# Each insight is a short "why" explanation that builds on what an English
# speaker already knows, followed by a chain of guided construction steps:
# (English prompt, tokens, a "think it through" hint).
# Insights appear in a unit's first lessons once all their words are known.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "greetings": [
        {
            "title": "Pinyin is not English spelling",
            "text": "You already read Latin letters, so pinyin feels familiar. A few letters "
                    "trick English speakers: x sounds close to \"sh\" (xiè), q close to \"ch\" (qǐ), "
                    "z like \"ds\" in \"kids\", c like \"ts\" in \"cats\". zh, ch, sh are said with "
                    "the tongue curled back.",
            "chain": [],
        },
        {
            "title": "No \"am\" with describing words",
            "text": "English says \"I am well\". Chinese skips the \"am\": 我很好 is literally "
                    "\"I very good\". Here 很 is mostly a link word, not a strong \"very\". "
                    "And verbs never change: no am/is/are, no -s endings.",
            "chain": [
                ("I am well.", ["我", "很", "好"], "Start with 我, then 很 + good. No word for \"am\"."),
                ("You are well.", ["你", "很", "好"], "Just swap the person. Nothing else changes."),
                ("I am not well.", ["我", "不", "好"], "不 sits right before what it negates, taking 很's place."),
            ],
        },
        {
            "title": "Questions: just add 吗",
            "text": "English flips words to ask a question (\"you are\" becomes \"are you\"). "
                    "Chinese never flips. Take the statement as it is and put 吗 on the end.",
            "chain": [
                ("Are you well?", ["你", "好", "吗"], "Statement 你好, then 吗."),
                ("Are you very well?", ["你", "很", "好", "吗"], "Same statement as \"you are well\", plus 吗."),
            ],
        },
    ],
    "people": [
        {
            "title": "是 joins two things",
            "text": "Use 是 when \"to be\" links two nouns: \"I am a student\" becomes 我是学生. "
                    "Chinese has no \"a\" or \"the\", so you simply leave them out.",
            "chain": [
                ("I am a teacher.", ["我", "是", "老师"], "我 + 是 + teacher. Drop the \"a\"."),
                ("He is a teacher.", ["他", "是", "老师"], "Swap 我 for 他. 是 stays exactly the same."),
                ("Is he a teacher?", ["他", "是", "老师", "吗"], "You already know this: add 吗."),
                ("He is not a teacher.", ["他", "不", "是", "老师"], "不 goes right before 是."),
            ],
        },
        {
            "title": "Question words stay where the answer goes",
            "text": "In English \"what\" jumps to the front. In Chinese it sits exactly where the "
                    "answer will be. Think of a fill-in-the-blank: 你叫 ___ ? becomes 你叫什么?",
            "chain": [
                ("What are you called?", ["你", "叫", "什么"], "\"You are called ___\" with 什么 in the blank."),
                ("What is your name?", ["你", "叫", "什么", "名字"], "Literally \"you are called what name?\""),
            ],
        },
    ],
    "numbers": [
        {
            "title": "Numbers click together",
            "text": "Chinese numbers are pure logic: 11 is 十一 (ten-one), 20 is 二十 (two-ten), "
                    "35 is 三十五. For age, say the person, the number and 岁. No \"am\", same as "
                    "with describing words.",
            "chain": [
                ("I am eight years old.", ["我", "八", "岁"], "I + eight + years-old. No 是 needed."),
                ("How old are you?", ["你", "几", "岁"], "Fill the blank in 你 ___ 岁 with the question word 几."),
                ("Is he ten years old?", ["他", "十", "岁", "吗"], "Statement first, then 吗."),
            ],
        },
    ],
    "family": [
        {
            "title": "Counting needs a measure word",
            "text": "English sometimes counts with a helper: \"a cup of tea\", \"a piece of paper\". "
                    "Chinese always does: number + measure word + noun. 个 is the all-purpose one.",
            "chain": [
                ("one person", ["一", "个", "人"], "one + 个 + person."),
                ("four people", ["四", "个", "人"], "Change only the number. No plural ending in Chinese."),
                ("I have a son.", ["我", "有", "一", "个", "儿子"], "\"a son\" is \"one 个 son\"."),
            ],
        },
        {
            "title": "的 works like 's",
            "text": "我的 is \"my\", 你的 is \"your\", 朋友的 is \"friend's\". It works just like "
                    "English 's, and the owner comes first as in English.",
            "chain": [
                ("my cat", ["我", "的", "猫"], "me + 's + cat."),
                ("my friend's dog", ["我", "朋友", "的", "狗"], "For close people like \"my friend\", the first 的 can drop."),
            ],
        },
    ],
    "food": [
        {
            "title": "Same order as English",
            "text": "Good news: the core order is the same as English. \"I eat rice\" is 我吃米饭. "
                    "想 works like \"want to\": put it right before the action.",
            "chain": [
                ("I eat rice.", ["我", "吃", "米饭"], "Same order as English."),
                ("I want to eat rice.", ["我", "想", "吃", "米饭"], "想 goes before the action, like \"want to\"."),
                ("Do you want to drink tea?", ["你", "想", "喝", "茶", "吗"], "Build the statement, then add 吗."),
                ("I don't want to drink water.", ["我", "不", "想", "喝", "水"], "不 goes before 想, the word it negates."),
            ],
        },
    ],
    "time": [
        {
            "title": "\"When\" comes early",
            "text": "English often puts time at the end (\"I'm well today\"). Chinese puts it "
                    "before the action or description, or at the very start: \"I today very good\".",
            "chain": [
                ("I am very well today.", ["我", "今天", "很", "好"], "Who, then when, then the description."),
                ("Today I am not well.", ["今天", "我", "不", "好"], "Time can also open the sentence."),
                ("What time is it now?", ["现在", "几", "点"], "now + how-many + o'clock."),
            ],
        },
    ],
    "places": [
        {
            "title": "在 means \"to be at\"",
            "text": "在 already contains the \"to be\": 他在学校 is \"he is at school\". "
                    "Don't add 是. And \"where\" goes in the answer's slot, like every question word.",
            "chain": [
                ("He is at school.", ["他", "在", "学校"], "在 is the verb here. No 是."),
                ("Where is he?", ["他", "在", "哪儿"], "\"He is at ___\" with 哪儿 in the blank."),
                ("I am going to Beijing tomorrow.", ["我", "明天", "去", "北京"], "When comes before the verb; where follows 去."),
            ],
        },
    ],
    "actions": [
        {
            "title": "Where before what",
            "text": "English says \"I study at school\". Chinese sets the scene first: "
                    "\"I at school study\". 在 + place goes before the action. "
                    "在 right before a verb means \"in the middle of doing\", like English -ing.",
            "chain": [
                ("I study at school.", ["我", "在", "学校", "学习"], "Set the scene (在 + school) before the action."),
                ("Dad works at the hospital.", ["爸爸", "在", "医院", "工作"], "Same pattern: who, 在 + where, what."),
                ("He is reading a book.", ["他", "在", "看", "书"], "在 + verb = -ing."),
            ],
        },
    ],
    "describing": [
        {
            "title": "Describing words act like verbs",
            "text": "Same trick as 我很好: 今天很热 is \"today very hot\". The describing word "
                    "does the job of a verb, so you never need 是 in front of it.",
            "chain": [
                ("It is hot today.", ["今天", "很", "热"], "No \"it\", no \"is\": today very hot."),
                ("It is not cold today.", ["今天", "不", "冷"], "不 replaces 很."),
                ("This dish is tasty.", ["这", "个", "菜", "很", "好吃"], "这 + 个 + noun = \"this ___\"."),
            ],
        },
    ],
    "questions": [
        {
            "title": "Bounce questions back with 呢",
            "text": "After you answer, toss the question back with just 你呢? (\"and you?\"). "
                    "Every other question word follows the fill-in-the-blank rule you already know.",
            "chain": [
                ("I'm fine, and you?", ["我", "很", "好", "你", "呢"], "Your answer, then 你呢."),
                ("Who is he?", ["他", "是", "谁"], "\"He is ___\" with 谁 in the blank."),
                ("Why don't you drink tea?", ["你", "为什么", "不", "喝", "茶"], "为什么 goes after the person, before the action."),
            ],
        },
    ],
}

# Memory hooks: build new characters out of parts you've already met.
# These are learning aids, not strict etymology.
HOOKS = {
    "好": "女 (woman) + 子 (child) side by side: something good.",
    "你": "亻 is the \"person\" side, so 你 is a person: you.",
    "他": "亻 (person) + 也. Swap 亻 for 女 (woman) and you get 她, \"she\". Same sound.",
    "她": "女 (woman) + 也. Compare 他: same sound, different person.",
    "我们": "们 is 亻 (person) + 门 (mén, door) giving the sound. Add 们 to people to make plurals.",
    "你们": "你 + 们: the plural ending for people. Compare 我们.",
    "吗": "口 (mouth) + 马 (mǎ, horse) for the sound. A word you only say, never mean.",
    "妈妈": "女 (woman) + 马 (mǎ) for the sound. Same horse as in 吗.",
    "爸爸": "父 (father) on top of 巴 (bā) for the sound.",
    "谢谢": "讠 is the speech side. Thanks are spoken.",
    "叫": "口 (mouth) on the left: calling out a name.",
    "吃": "口 (mouth) on the left: eating.",
    "喝": "口 (mouth) on the left: drinking.",
    "听": "口 (mouth) on the left. Hearing what a mouth says.",
    "说": "讠 (speech) on the left: speaking.",
    "读": "讠 (speech) on the left: reading aloud.",
    "茶": "艹 (grass) on top: tea is a plant.",
    "菜": "艹 (grass) on top: vegetables.",
    "热": "The four dots at the bottom are fire (灬): hot.",
    "冷": "冫 is ice: cold. Compare 热 with fire at the bottom.",
    "字": "宀 (roof) over 子 (child): a child at home learning characters.",
    "家": "宀 (roof) over 豕 (pig): a house with livestock was a family home.",
    "明天": "明 is 日 (sun) + 月 (moon): bright. The bright day after this one.",
    "朋友": "朋 is two 月 side by side, like two friends.",
    "人": "Two legs walking.",
    "大": "A person (人) stretching their arms wide: big.",
    "太": "大 (big) plus an extra dot: too big, too much.",
    "小": "Something split into tiny bits.",
    "少": "小 (small) with an extra stroke trimming it down: few.",
    "看": "A hand (手) over an eye (目), shading it to look into the distance.",
    "坐": "Two people (人人) sitting on the ground (土).",
    "回": "A box within a box: going around and coming back.",
    "一": "One stroke for one.",
    "二": "Two strokes for two.",
    "三": "Three strokes for three.",
    "钱": "钅 is metal: money used to be metal coins.",
    "米饭": "饭 has 饣, the food side.",
    "饭店": "饭 (food, with 饣) + 店 (shop): a food shop, a restaurant.",
    "想": "心 (heart) at the bottom: thinking and wanting happen in the heart.",
    "怎么": "怎 also has 心 (heart) at the bottom, like 想.",
    "时候": "时 has 日 (sun) on the left: the sun tells the time.",
    "睡觉": "睡 has 目 (eye) on the left: closing your eyes.",
    "学生": "学 has 子 (child) at the bottom, under a roof: a child learning.",
    "学习": "学 is the same as in 学生: a child under a roof, learning.",
    "学校": "学 (learn) + 校 (school building).",
    "中国": "中 is a line through the middle of a box: the middle kingdom.",
}

# Tones anchored to intonation an English speaker already uses.
TONE_HINTS = {
    1: "high & flat, like singing a note",
    2: "rising, like a surprised \"Huh?\"",
    3: "low dip, like a doubtful \"Well...\"",
    4: "sharp fall, like a firm \"No!\"",
}

TONE_INSIGHT = {
    "title": "You already use these pitches",
    "text": "English uses pitch for mood: \"Huh?\" rises, \"No!\" falls. Chinese uses the same "
            "pitches, but they change the meaning of the word. Tone 1 is a sung note, tone 2 "
            "is \"Huh?\", tone 3 is a doubtful \"Well...\", tone 4 is a firm \"No!\". "
            "Say each one with the English feeling and you're most of the way there.",
}


# ---------------------------------------------------------------------------
# Extra tracks. "track" groups units on the home path; "requires" is the
# unit that must reach level 1 before the track's first unit unlocks.
# ---------------------------------------------------------------------------
for _u in UNITS:
    _u.setdefault("track", "modern")

UNITS.extend([
    {
        "id": 'rad1', "title": 'Pictures: Nature', "icon": '山', "color": '#2F9E44', "track": "radicals",
        "words": [
            ('山', 'shan1', 'mountain'),
            ('火', 'huo3', 'fire'),
            ('木', 'mu4', 'tree; wood'),
            ('土', 'tu3', 'earth; soil'),
            ('田', 'tian2', 'field'),
            ('石', 'shi2', 'stone'),
            ('雨', 'yu3', 'rain'),
            ('云', 'yun2', 'cloud'),
            ('风', 'feng1', 'wind'),
            ('花', 'hua1', 'flower'),
            ('草', 'cao3', 'grass'),
            ('河', 'he2', 'river'),
        ],
        "sentences": [
            (['山', '很', '大'], 'The mountain is big.'),
            (['火', '很', '热'], 'The fire is very hot.'),
            (['河', '里', '有', '水'], 'There is water in the river.'),
            (['我', '看', '山'], 'I look at the mountain.'),
            (['花', '很', '漂亮'], 'The flower is very pretty.'),
        ],
    },
    {
        "id": 'rad2', "title": 'Pictures: Body', "icon": '口', "color": '#E8590C', "track": "radicals",
        "words": [
            ('口', 'kou3', 'mouth'),
            ('手', 'shou3', 'hand'),
            ('心', 'xin1', 'heart'),
            ('目', 'mu4', 'eye'),
            ('耳', 'er3', 'ear'),
            ('足', 'zu2', 'foot'),
            ('头', 'tou2', 'head'),
            ('力', 'li4', 'strength'),
            ('女', 'nv3', 'woman'),
            ('自', 'zi4', 'oneself'),
            ('牙', 'ya2', 'tooth'),
            ('毛', 'mao2', 'hair; fur'),
        ],
        "sentences": [
            (['她', '的', '手', '很', '小'], 'Her hand is small.'),
            (['我', '的', '头', '很', '大'], 'My head is big.'),
            (['这', '是', '我', '的', '手'], 'This is my hand.'),
            (['他', '的', '女儿', '很', '漂亮'], 'His daughter is very pretty.'),
            (['我', '心', '里', '很', '高兴'], 'I am very happy inside.'),
        ],
    },
    {
        "id": 'rad3', "title": 'Pictures: Things', "icon": '门', "color": '#1C7ED6', "track": "radicals",
        "words": [
            ('门', 'men2', 'door; gate'),
            ('车', 'che1', 'vehicle; car'),
            ('刀', 'dao1', 'knife'),
            ('工', 'gong1', 'work; craft'),
            ('马', 'ma3', 'horse'),
            ('鸟', 'niao3', 'bird'),
            ('鱼', 'yu2', 'fish'),
            ('虫', 'chong2', 'insect'),
            ('米', 'mi3', 'rice (uncooked)'),
            ('竹', 'zhu2', 'bamboo'),
            ('金', 'jin1', 'gold; metal'),
            ('言', 'yan2', 'speech; words'),
        ],
        "sentences": [
            (['我', '有', '一', '个', '车'], 'I have a car.'),
            (['我', '看', '鱼'], 'I look at the fish.'),
            (['门', '很', '大'], 'The door is big.'),
            (['我', '爱', '吃', '鱼'], 'I love eating fish.'),
        ],
    },
    {
        "id": 'rad4', "title": 'Directions', "icon": '上', "color": '#845EF7', "track": "radicals",
        "words": [
            ('上', 'shang4', 'up; above'),
            ('下', 'xia4', 'down; below'),
            ('中', 'zhong1', 'middle; in'),
            ('左', 'zuo3', 'left'),
            ('右', 'you4', 'right'),
            ('前', 'qian2', 'front; before'),
            ('后', 'hou4', 'behind; after'),
            ('外', 'wai4', 'outside'),
            ('东', 'dong1', 'east'),
            ('西', 'xi1', 'west'),
            ('南', 'nan2', 'south'),
            ('北', 'bei3', 'north'),
        ],
        "sentences": [
            (['我', '在', '中国'], 'I am in China.'),
            (['北京', '在', '中国', '的', '北'], 'Beijing is in the north of China.'),
            (['他', '在', '门', '外'], 'He is outside the door.'),
            (['书', '在', '这', '里'], 'The book is here.'),
            (['我', '去', '学校'], 'I go to school.'),
        ],
    },
    {
        "id": 'rad5', "title": 'Colors & Sizes', "icon": '红', "color": '#C2255C', "track": "radicals",
        "words": [
            ('红', 'hong2', 'red'),
            ('白', 'bai2', 'white'),
            ('黑', 'hei1', 'black'),
            ('黄', 'huang2', 'yellow'),
            ('绿', 'lv4', 'green'),
            ('蓝', 'lan2', 'blue'),
            ('色', 'se4', 'color'),
            ('光', 'guang1', 'light; ray'),
            ('明', 'ming2', 'bright'),
            ('高', 'gao1', 'tall; high'),
            ('长', 'chang2', 'long'),
            ('短', 'duan3', 'short'),
        ],
        "sentences": [
            (['这', '个', '是', '红', '色'], 'This is red.'),
            (['我', '的', '书', '是', '黑', '色', '的'], 'My book is black.'),
            (['她', '的', '花', '是', '黄', '色', '的'], 'Her flower is yellow.'),
            (['山', '很', '高'], 'The mountain is tall.'),
            (['河', '很', '长'], 'The river is long.'),
        ],
    },
    {
        "id": "chengyu1", "title": "Idioms I", "icon": "成", "color": "#F76707",
        "track": "chengyu", "requires": "people",
        "words": [
            ("马马虎虎", "ma3 ma3 hu1 hu1", "so-so; careless"),
            ("一心一意", "yi1 xin1 yi2 yi4", "wholeheartedly"),
            ("人山人海", "ren2 shan1 ren2 hai3", "huge crowds"),
            ("自言自语", "zi4 yan2 zi4 yu3", "to talk to oneself"),
            ("一路平安", "yi2 lu4 ping2 an1", "have a safe trip"),
            ("好久不见", "hao3 jiu3 bu2 jian4", "long time no see"),
            ("不三不四", "bu4 san1 bu2 si4", "shady; dubious"),
            ("半途而废", "ban4 tu2 er2 fei4", "to give up halfway"),
            ("对牛弹琴", "dui4 niu2 tan2 qin2", "to talk to someone who won't get it"),
            ("画蛇添足", "hua4 she2 tian1 zu2", "to ruin something by overdoing it"),
        ],
        "sentences": [
            (["我", "马马虎虎"], "I'm so-so."),
            (["好久不见", "你", "好", "吗"], "Long time no see! How are you?"),
            (["他", "是", "不三不四", "的", "人"], "He is a shady person."),
        ],
    },
    {
        "id": "chengyu2", "title": "Idioms II", "icon": "语", "color": "#D9480F",
        "track": "chengyu",
        "words": [
            ("守株待兔", "shou3 zhu1 dai4 tu4", "to wait for luck instead of working"),
            ("井底之蛙", "jing3 di3 zhi1 wa1", "someone with a narrow view"),
            ("亡羊补牢", "wang2 yang2 bu3 lao2", "better late than never"),
            ("塞翁失马", "sai4 weng1 shi1 ma3", "a blessing in disguise"),
            ("一石二鸟", "yi4 shi2 er4 niao3", "to kill two birds with one stone"),
            ("入乡随俗", "ru4 xiang1 sui2 su2", "when in Rome, do as the Romans do"),
            ("熟能生巧", "shu2 neng2 sheng1 qiao3", "practice makes perfect"),
            ("三心二意", "san1 xin1 er4 yi4", "half-hearted"),
            ("学以致用", "xue2 yi3 zhi4 yong4", "to learn in order to use it"),
            ("九牛一毛", "jiu3 niu2 yi4 mao2", "a drop in the ocean"),
        ],
        "sentences": [
            (["我", "不", "是", "井底之蛙"], "I am not a frog in a well."),
            (["你", "三心二意"], "You're being half-hearted."),
        ],
    },
    {
        "id": "classical1", "title": "Classical I", "icon": "文", "color": "#495057",
        "track": "classical", "requires": "numbers",
        "words": [
            ("吾", "wu2", "I; me (classical 我)"),
            ("汝", "ru3", "you (classical 你)"),
            ("之", "zhi1", "it; him (after a verb) / 's (like 的)"),
            ("乎", "hu1", "(classical question particle, like 吗)"),
            ("也", "ye3", "(final particle: \"it is so\")"),
            ("曰", "yue1", "to say"),
            ("子", "zi3", "Master (Confucius)"),
            ("而", "er2", "and; and yet"),
            ("学", "xue2", "to learn"),
            ("习", "xi2", "to practise"),
            ("时", "shi2", "at the right time"),
            ("知", "zhi1", "to know"),
            ("为", "wei2", "to be; to count as"),
            ("其", "qi2", "his; her; its"),
        ],
        "sentences": [
            (["子", "曰"], "The Master said..."),
            (["吾", "知", "之"], "I know it."),
            (["汝", "知", "之", "乎"], "Do you know it?"),
            (["学", "而", "时", "习", "之"], "Learn, and practise it at the right times."),
            (["知", "之", "为", "知", "之"], "When you know it, say you know it."),
        ],
    },
    {
        "id": "classical2", "title": "Classical II", "icon": "古", "color": "#343A40",
        "track": "classical",
        "words": [
            ("行", "xing2", "to walk; to go"),
            ("必", "bi4", "certainly; must"),
            ("师", "shi1", "teacher (classical 老师)"),
            ("温", "wen1", "to review (lit. warm up)"),
            ("故", "gu4", "the old"),
            ("新", "xin1", "the new"),
            ("日", "ri4", "day; daily"),
            ("省", "xing3", "to examine"),
            ("身", "shen1", "oneself (lit. body)"),
            ("己", "ji3", "oneself"),
            ("所", "suo3", "that which; what"),
            ("欲", "yu4", "to want"),
            ("勿", "wu4", "do not (classical 别)"),
            ("施", "shi1", "to impose; to do to"),
            ("于", "yu2", "to; on; at"),
        ],
        "sentences": [
            (["三", "人", "行", "必", "有", "我", "师"],
             "When three walk together, one of them can be my teacher."),
            (["温", "故", "而", "知", "新"], "Review the old to understand the new."),
            (["吾", "日", "三", "省", "吾", "身"], "Every day I examine myself three times."),
            (["己", "所", "不", "欲", "勿", "施", "于", "人"],
             "Don't do to others what you don't want done to yourself."),
        ],
    },
])

TRACKS = {
    "modern": "Modern Chinese",
    "radicals": "部首  Pictures and radicals",
    "chengyu": "成语  Chengyu: four-character idioms",
    "classical": "文言  Classical Chinese",
}

HOOKS.update({
    '山': 'Three peaks side by side: a mountain.',
    '火': 'Flames rising: fire. At the bottom of a character it becomes 灬, as in 热.',
    '木': 'A tree: trunk, branches above, roots below. Two trees make 林 (grove), three make 森 (forest).',
    '土': 'A mound of earth with a sprout above the ground line.',
    '田': 'A field divided into plots by paths.',
    '石': 'A cliff 厂 with a rock 口 beneath it: stone.',
    '云': 'The cloud. With 雨 (rain) on top it becomes 雲, the traditional form.',
    '风': 'Wind. The traditional form 風 holds an insect 虫 inside.',
    '花': '艹 (plant) above 化 (change): a plant that changes into a bloom.',
    '草': '艹 (plant) above 早 (early): grass.',
    '河': '氵 (water) on the left, 可 gives the sound: a river.',
    '口': 'An open mouth, drawn as a square. You met it in 吃, 喝 and 叫.',
    '手': 'A hand with fingers. On the left side it shrinks to 扌, as in 打 (hit).',
    '心': 'A heart. On the left side it becomes 忄, as in 快 (fast) and 忙 (busy).',
    '目': 'An eye turned on its side. 看 (look) is 手 over 目: a hand shading the eye.',
    '耳': 'An ear, drawn as a curl. The traditional 聽 (listen) has an ear inside.',
    '足': 'A leg with a foot below. It is the foot radical in 跑 (run) and 路 (road).',
    '头': 'Two dots over 大 (big): the big thing on your shoulders.',
    '力': 'A flexing arm: strength. 男 (man) is 田 (field) + 力: the one with strength in the field.',
    '女': 'A kneeling woman with crossed arms. You saw it in 她, 好 and 妈.',
    '自': 'A nose seen from the front. People point to the nose for "myself".',
    '牙': 'Two interlocking teeth, one above and one below.',
    '门': 'Two swinging doors. The traditional form 門 shows them more clearly.',
    '车': 'A cart seen from above. The traditional form 車 shows two wheels on an axle.',
    '刀': 'A knife with a curved blade and a handle.',
    '工': "A carpenter's square between two lines: work, craft. See 工作.",
    '马': 'A horse with its mane and four legs. The traditional form 馬 shows them clearly.',
    '鸟': 'A bird with beak, body and feet. The traditional form 鳥 has an eye.',
    '鱼': 'A fish: head, scaly body 田, tail. The traditional form 魚 shows the tail as four dots.',
    '虫': 'A worm or insect. It is the radical of small creatures.',
    '米': 'Four grains of rice around a cross. 米饭 is cooked rice.',
    '竹': 'Two bamboo stalks with leaves. On top of a character it becomes ⺮, as in 筷 (chopsticks).',
    '金': 'A roof over earth and sparkling nuggets: metal, gold. On the left it becomes 钅, as in 钱 (money).',
    '言': 'A mouth 口 with speech lines: words. On the left it becomes 讠, as in 说 (say) and 谢 (thank).',
    '上': 'A stroke above the base line: up.',
    '下': 'A stroke below the base line: down.',
    '中': 'An arrow through the middle of a target: the middle. 中国 is the Middle Kingdom.',
    '左': '左 and 右 both start with a hand stroke. 左 has 工 (a tool) under it: the helping hand.',
    '右': '右 has 口 (mouth) under the hand stroke: the hand you eat with.',
    '东': 'The traditional form 東 shows the sun 日 rising behind a tree 木: east.',
    '西': 'A bird settling on its nest at sunset: west.',
    '北': 'Two people sitting back to back: north, where you turn your back.',
    '红': '纟 (silk) + 工: red silk. 纟 is the silk radical, as in 绿.',
    '白': 'The sun 日 with a ray of light on top: white, bright.',
    '黑': 'Soot above a fire 灬: black.',
    '绿': '纟 (silk) + 录: green silk.',
    '蓝': '艹 (plant) + 监: the indigo plant, blue.',
    '光': 'Fire above a kneeling person: light.',
    '明': '日 (sun) + 月 (moon): bright. You know 明天.',
    '高': 'A tall tower with a roof: tall.',
    '短': 'Measured against an arrow 矢: short.',
})

INSIGHTS.update({
    'rad1': [{'title': 'Pictures that became letters', 'text': 'Many characters began as drawings: 山 is three peaks, 火 is flames, 木 is a tree. Over the centuries the drawings were straightened into strokes, but the picture is still there. Twenty such pictures help you guess hundreds of other characters.', 'chain': []}],
    'rad2': [{'title': 'Body parts that shrink', 'text': 'Body characters often squeeze to the left side of other characters and hint at the meaning: 口 in 吃, 喝, 叫 (mouth actions), 扌 (hand) in 打, 忄 (heart) in 快. When you meet a new character, look at its left side first.', 'chain': []}],
    'rad3': [{'title': 'Meaning plus sound', 'text': 'Most characters pair a meaning part with a sound part. 妈 mā is 女 (woman) for meaning and 马 mǎ (horse) for sound. You already know both halves. The radical tells you the field and the other half hints at the sound.', 'chain': []}],
    'rad4': [{'title': 'East-west means thing', 'text': 'Chinese lists directions as 东南西北 (east, south, west, north). And 东西 (east-west) also means "thing": 买东西 is to buy things. 上 and 下 are not only up and down but also "previous" and "next": 上午 is the morning, 下午 the afternoon.', 'chain': []}],
    'rad5': [{'title': 'Colors come with 色', 'text': 'A color is usually followed by 色 (sè): 红色 is the color red. Many color characters carry the silk radical 纟 (红, 绿) because colors were first dyed on silk. Compare 明, the sun and moon together: the brightest word.', 'chain': []}],
})

INSIGHTS.update({
    "chengyu1": [
        {
            "title": "Idioms are tiny stories",
            "text": "English has \"when in Rome\" and \"kill two birds with one stone\". Chinese has "
                    "成语 (chéngyǔ): four characters that pack a whole story. Read them literally "
                    "first, then jump to the meaning: 人山人海 is \"people mountain, people sea\", "
                    "so: huge crowds. Your modern words help you decode them.",
            "chain": [
                ("I'm so-so.", ["我", "马马虎虎"],
                 "马马虎虎 is \"horse horse tiger tiger\": neither one thing nor the other. Like 很好, no 是."),
                ("Long time no see! How are you?", ["好久不见", "你", "好", "吗"],
                 "Greeting first, then a question you already know."),
            ],
        },
    ],
    "chengyu2": [
        {
            "title": "Decode with characters you know",
            "text": "You know 三 (three), 九 (nine), 一 (one), 学 and 心. Use them as anchors: "
                    "三心二意 is \"three hearts, two minds\": half-hearted. 九牛一毛 is \"one hair "
                    "from nine cows\": a tiny drop. Guess the picture first, then the meaning.",
            "chain": [
                ("You're being half-hearted.", ["你", "三心二意"],
                 "Idioms describe like adjectives, so no 是. Same rule as 你很好."),
                ("I am not a frog in a well.", ["我", "不", "是", "井底之蛙"],
                 "Here the idiom works as a noun (a frog), so you do need 是, with 不 in front."),
            ],
        },
    ],
    "classical1": [
        {
            "title": "Classical is modern, compressed",
            "text": "You don't start Classical Chinese from zero. Most of it maps onto words you "
                    "know: 吾 = 我, 汝 = 你, 乎 = 吗. The big difference: classical uses one "
                    "character where modern uses two. 学习 (study) splits back into 学 (learn) "
                    "and 习 (practise).",
            "chain": [
                ("I know it.", ["吾", "知", "之"],
                 "吾 is the classical 我. 知 = know. 之 means \"it\" and goes after the verb."),
                ("Do you know it?", ["汝", "知", "之", "乎"],
                 "Same trick as modern: keep the statement and add the question particle. 汝 = 你, 乎 = 吗."),
            ],
        },
        {
            "title": "Reading Confucius",
            "text": "The Analects (论语) open with 子曰 \"The Master said\". Then: 学而时习之, "
                    "\"learn, and practise it at the right times\". Every piece is something you "
                    "just met. 而 joins two actions, like \"and\".",
            "chain": [
                ("The Master said...", ["子", "曰"], "子 is the Master (Confucius), 曰 = say."),
                ("Learn, and practise it at the right times.", ["学", "而", "时", "习", "之"],
                 "learn + and + at-the-right-time + practise + it. Time comes before the action, as in modern."),
            ],
        },
    ],
    "classical2": [
        {
            "title": "Modern words grew from these",
            "text": "Look inside words you know: 老师 contains 师 (teacher), 时候 contains 时, "
                    "and 学习 is 学 + 习. Modern Chinese often glued two classical words "
                    "together to make one. So each classical word you learn makes modern words clearer.",
            "chain": [
                ("Review the old to understand the new.", ["温", "故", "而", "知", "新"],
                 "温 review + 故 the old, 而 and, 知 know + 新 the new."),
                ("When three walk together, one of them can be my teacher.",
                 ["三", "人", "行", "必", "有", "我", "师"],
                 "three people walk, certainly there-is my teacher. 有 works just like modern."),
            ],
        },
        {
            "title": "勿 is \"don't\"",
            "text": "Modern says 别 or 不要 for \"don't\". Classical says 勿. The golden rule in "
                    "Chinese: 己所不欲, 勿施于人, literally \"what oneself does not want, don't impose "
                    "on people\".",
            "chain": [
                ("Don't do to others what you don't want done to yourself.",
                 ["己", "所", "不", "欲", "勿", "施", "于", "人"],
                 "Start with what you don't want: 己所不欲. Then the command: 勿施于人."),
            ],
        },
    ],
})

HOOKS.update({
    "马马虎虎": "Legend: a painter drew a tiger's head on a horse's body, and called it \"horse-tiger\". Neither one nor the other: so-so.",
    "人山人海": "People like a mountain, people like a sea.",
    "一心一意": "One heart, one mind: all of you on one thing.",
    "自言自语": "Self speaks, self talks.",
    "一路平安": "The whole road, calm and safe. Said when someone leaves on a trip.",
    "好久不见": "Good (very) long, not see. English \"long time no see\" may come from this.",
    "不三不四": "Not three, not four: not fitting anywhere, so dubious.",
    "半途而废": "Halfway along the road, and abandon it.",
    "对牛弹琴": "A musician played beautiful music to a cow. The cow kept eating grass.",
    "画蛇添足": "Men raced to draw a snake. The fastest finished, then added feet, and lost: snakes have no feet.",
    "守株待兔": "A farmer saw a rabbit crash into a tree stump. He stopped farming and waited by the stump for more.",
    "井底之蛙": "A frog at the bottom of a well thinks the sky is the size of the well's opening. Note 之 = 的.",
    "亡羊补牢": "A shepherd lost sheep, then fixed the pen. Late, but it saved the rest.",
    "塞翁失马": "An old man on the frontier lost his horse. It came back with a second horse. Bad luck can be good luck.",
    "一石二鸟": "One stone, two birds. Same picture as the English idiom.",
    "入乡随俗": "Enter a village, follow its customs.",
    "熟能生巧": "Familiarity can give birth to skill.",
    "三心二意": "Three hearts, two minds: never fully on one thing.",
    "学以致用": "Learn in order to put it to use. 学 is the same as in 学习.",
    "九牛一毛": "One hair from nine cows: a tiny amount.",
    "吾": "Classical 我. You still see it in names and formal writing.",
    "汝": "Classical 你. 氵 is water, but here it just gives the sound.",
    "之": "Two jobs: \"it/him\" after a verb (知之 = know it), or 's between two nouns (井底之蛙, like 的).",
    "乎": "Classical 吗: put it at the end to make a question.",
    "曰": "Like 日 (sun) but wider: a mouth with breath coming out. Saying.",
    "学": "The first half of 学习 and 学生.",
    "习": "The second half of 学习: practising over and over.",
    "时": "The first half of 时候. 日 (sun) on the left tells the time.",
    "师": "The second half of 老师.",
    "新": "Hidden in many modern words, e.g. 新年 (New Year).",
    "日": "A picture of the sun. 日 also means day.",
    "身": "A picture of a body. In classical, \"oneself\".",
    "勿": "Classical \"don't\". Like modern 别.",
    "知": "Modern 知道 (to know) starts with this.",
})

# ---------------------------------------------------------------------------
# Practice chats. Bot lines and replies are token lists like sentences
# (punctuation tokens are allowed). Each turn has either "options"
# [(tokens, correct, explanation)] or "build" (tokens, English).
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "hello", "title": "Say hello", "partner": "Lili", "avatar": "丽",
        "requires": "greetings",
        "turns": [
            {"bot": ["你好", "！"], "en": "Hello!",
             "options": [(["你好", "！"], True, None),
                         (["再见", "！"], False, "再见 means goodbye. You're just meeting!"),
                         (["对不起"], False, "对不起 is \"sorry\". Nothing to apologise for yet.")]},
            {"bot": ["你", "好", "吗", "？"], "en": "How are you?",
             "options": [(["我", "很", "好", "，", "谢谢"], True, None),
                         (["我", "是", "好"], False, "English needs \"am\", Chinese doesn't: 我很好, no 是."),
                         (["我", "很", "好", "吗"], False, "吗 turns it into a question. You're answering, not asking.")]},
            {"bot": ["谢谢", "你"], "en": "Thank you.",
             "options": [(["不客气"], True, None),
                         (["没关系"], False, "没关系 answers \"sorry\". For \"thank you\", say 不客气."),
                         (["谢谢"], False, "She thanked you, so reply with \"you're welcome\": 不客气.")]},
            {"bot": ["再见", "！"], "en": "Goodbye!",
             "build": (["再见"], "Goodbye!")},
        ],
    },
    {
        "id": "classroom", "title": "First day of class", "partner": "Teacher Wang", "avatar": "王",
        "requires": "people",
        "turns": [
            {"bot": ["你好", "！", "你", "叫", "什么", "名字", "？"], "en": "Hello! What's your name?",
             "options": [(["我", "叫", "大明"], True, None),
                         (["什么", "名字", "我", "叫"], False, "Answer in the same order as the question: 我叫 + name."),
                         (["我", "是", "叫", "大明"], False, "叫 already means \"to be called\". No 是 needed.")],
             "note": "Pretend your name is 大明 (Dà Míng)."},
            {"bot": ["你", "是", "老师", "吗", "？"], "en": "Are you a teacher?",
             "options": [(["我", "不", "是", "老师", "，", "我", "是", "学生"], True, None),
                         (["我", "不", "老师"], False, "With nouns you do need 是: 我不是老师."),
                         (["我", "是", "不", "老师"], False, "不 goes right before the word it negates: 不是.")]},
            {"bot": ["他", "是", "谁", "？"], "en": "Who is he?",
             "build": (["他", "是", "我", "朋友"], "He is my friend.")},
            {"bot": ["好", "！", "我们", "是", "朋友", "！"], "en": "Great! We're friends!",
             "options": [(["谢谢", "老师"], True, None),
                         (["对不起", "老师"], False, "对不起 is \"sorry\". Try thanking her.")]},
        ],
    },
    {
        "id": "family", "title": "Family photos", "partner": "Xiaoyu", "avatar": "雨",
        "requires": "family",
        "turns": [
            {"bot": ["你", "家", "有", "几", "个", "人", "？"], "en": "How many people are in your family?",
             "options": [(["我", "家", "有", "四", "个", "人"], True, None),
                         (["我", "家", "有", "四", "人"], False, "Counting needs a measure word: 四个人."),
                         (["我", "家", "四", "个", "人", "有"], False, "有 comes before what you have, like English \"have\".")]},
            {"bot": ["你", "有", "狗", "吗", "？"], "en": "Do you have a dog?",
             "options": [(["我", "没有", "狗"], True, None),
                         (["我", "不", "有", "狗"], False, "有 is never negated with 不. Always 没有."),
                         (["我", "有", "不", "狗"], False, "The negative of 有 is one word: 没有.")]},
            {"bot": ["我", "有", "一", "个", "女儿", "！"], "en": "I have a daughter!",
             "build": (["她", "几", "岁"], "How old is she?")},
            {"bot": ["她", "八", "岁", "。", "你", "有", "儿子", "吗", "？"], "en": "She's eight. Do you have a son?",
             "options": [(["我", "有", "一", "个", "儿子"], True, None),
                         (["我", "有", "一", "儿子"], False, "Counting needs a measure word: 一个儿子."),
                         (["我", "不", "有", "儿子"], False, "Answering yes? Then 我有一个儿子. (And never 不有, it's 没有.)")]},
        ],
    },
    {
        "id": "restaurant", "title": "At the restaurant", "partner": "Waiter", "avatar": "店",
        "requires": "food",
        "turns": [
            {"bot": ["你好", "！", "你", "想", "吃", "什么", "？"], "en": "Hello! What would you like to eat?",
             "options": [(["我", "想", "吃", "面条"], True, None),
                         (["我", "想", "面条", "吃"], False, "Same order as English: want, eat, noodles."),
                         (["我", "吃", "想", "面条"], False, "想 (want to) comes before the action.")]},
            {"bot": ["你", "想", "喝", "什么", "？"], "en": "What would you like to drink?",
             "build": (["我", "想", "喝", "茶"], "I'd like to drink tea.")},
            {"bot": ["好", "！", "面条", "和", "茶", "。"], "en": "OK! Noodles and tea.",
             "options": [(["谢谢"], True, None),
                         (["没关系"], False, "没关系 answers an apology. Just say thank you.")]},
            {"bot": ["好吃", "吗", "？"], "en": "Is it tasty?",
             "options": [(["很", "好吃", "！"], True, None),
                         (["是", "好吃"], False, "Describing words don't need 是: 很好吃.")]},
        ],
    },
    {
        "id": "plans", "title": "Weekend plans", "partner": "Tom", "avatar": "汤",
        "requires": "places",
        "turns": [
            {"bot": ["你", "明天", "去", "哪儿", "？"], "en": "Where are you going tomorrow?",
             "options": [(["我", "明天", "去", "北京"], True, None),
                         (["我", "去", "北京", "明天"], False, "Time goes before the action: 我明天去北京."),
                         (["我", "明天", "去", "哪儿", "北京"], False, "Replace 哪儿 with the answer. It doesn't stay.")]},
            {"bot": ["你", "去", "北京", "做", "什么", "？"], "en": "What are you doing in Beijing?",
             "build": (["我", "去", "北京", "学习", "汉语"], "I'm going to Beijing to study Chinese.")},
            {"bot": ["太", "好", "了", "！"], "en": "That's great!",
             "options": [(["一路平安"], False, "He's not the one travelling, you are! Try thanking him."),
                         (["谢谢", "！", "再见"], True, None)]},
            {"bot": ["一路平安", "！"], "en": "Have a safe trip!",
             "options": [(["谢谢"], True, None),
                         (["好久不见"], False, "That's \"long time no see\", for when you meet again.")]},
        ],
    },
    {
        "id": "oldfriend", "title": "An old friend", "partner": "Lili", "avatar": "丽",
        "requires": "chengyu1",
        "turns": [
            {"bot": ["好久不见", "！", "你", "好", "吗", "？"], "en": "Long time no see! How are you?",
             "options": [(["马马虎虎"], True, None),
                         (["人山人海"], False, "人山人海 means huge crowds. You want \"so-so\"."),
                         (["对牛弹琴"], False, "That's \"talking to a cow\". Try \"so-so\".")]},
            {"bot": ["你", "还", "学", "汉语", "吗", "？"], "en": "Are you still learning Chinese?",
             "options": [(["我", "一心一意", "学习", "汉语"], True, None),
                         (["我", "半途而废"], False, "That says you gave up halfway! Don't stop now.")]},
            {"bot": ["熟能生巧", "！"], "en": "Practice makes perfect!",
             "build": (["谢谢", "你"], "Thank you.")},
        ],
    },
    {
        "id": "master", "title": "Ask the Master", "partner": "Old Scholar", "avatar": "子",
        "requires": "classical1",
        "turns": [
            {"bot": ["子", "曰", "：", "学", "而", "时", "习", "之"], "en": "The Master said: learn, and practise it at the right times.",
             "options": [(["吾", "知", "之"], True, None),
                         (["我", "知", "之"], False, "In classical style use 吾, not modern 我."),
                         (["吾", "之", "知"], False, "之 (it) comes after the verb: 知之.")]},
            {"bot": ["汝", "知", "之", "乎", "？"], "en": "Do you (truly) know it?",
             "build": (["知", "之", "为", "知", "之"], "When you know it, say you know it.")},
            {"bot": ["善", "！"], "en": "Excellent!",
             "options": [(["谢谢", "老师"], True, None),
                         (["再见"], False, "Thank the teacher before leaving!")]},
        ],
    },
]

# Pinyin for tokens that appear in chats but aren't course words.
CHAT_EXTRA = {
    "大明": ("Da4 Ming2", "Daming (a name)"),
    "还": ("hai2", "still"),
    "了": ("le5", "(change / completion particle)"),
    "善": ("shan4", "good; excellent (classical)"),
}
PUNCT = set("，。！？：、")

"""Treść kursu: serbski dla Polaków (pismo łacińskie + cyrylica).

Akcent: znak U+0301 po akcentowanej samogłosce (tylko miejsce akcentu, bez tonu)."""

PUNCT = {'!', ',', '.', ':', '?'}

TRACKS = {'wymowa': 'ПИСМО · PISMO', 'jezyk': 'ЈЕЗИК · JĘZYK'}

UNITS = [
    {'id': 'wymowa', 'title': 'Łacinka', 'icon': 'Č', 'track': 'wymowa',
     'letters': [
         ('č', '[tʃ]: twarde cz, jak polskie cz', 'čaj (herbata)'),
         ('ć', '[tɕ]: miękkie ć, jak polskie ć', 'kúća (dom)'),
         ('dž', '[dʒ]: jak polskie dż', 'džep (kieszeń)'),
         ('đ', '[dʑ]: miękkie dź, jak polskie dź', 'đak (uczeń)'),
         ('š', '[ʃ]: jak polskie sz', 'škóla (szkoła)'),
         ('ž', '[ʒ]: jak polskie ż', 'žéna (kobieta)'),
         ('lj', '[ʎ]: miękkie l, jak polskie li przed samogłoską', 'ljúbav (miłość)'),
         ('nj', '[ɲ]: jak polskie ń', 'konj (koń)'),
         ('c', '[ts]: jak polskie c', 'céna (cena)'),
         ('h', '[x]: jak polskie ch', 'hleb (chleb)'),
         ('j', '[j]: jak polskie j', 'jábuka (jabłko)'),
         ('r', '[r]: toczone; może być samogłoską w słowie', 'krv (krew)'),
         ('akcent', 'tonowy: długie i krótkie, rosnące i opadające sylaby', 'vóda (woda)'),
     ],
    },
    {'id': 'wymowa2', 'title': 'Ćirilica I', 'icon': 'А', 'track': 'wymowa',
     'letters': [
         ('а', '[a]: odpowiada łacińskiemu a', 'ма́јка (matka)'),
         ('б', '[b]: odpowiada łacińskiemu b', 'брат (brat)'),
         ('в', '[ʋ]: odpowiada łacińskiemu v', 'во́да (woda)'),
         ('г', '[ɡ]: odpowiada łacińskiemu g', 'град (miasto)'),
         ('д', '[d]: odpowiada łacińskiemu d', 'дан (dzień)'),
         ('ђ', '[dʑ]: odpowiada łacińskiemu đ', 'ђак (uczeń)'),
         ('е', '[e]: odpowiada łacińskiemu e', 'се́ло (wieś)'),
         ('ж', '[ʒ]: odpowiada łacińskiemu ž', 'же́на (kobieta)'),
         ('з', '[z]: odpowiada łacińskiemu z', 'зи́ма (zima)'),
         ('и', '[i]: odpowiada łacińskiemu i', 'мир (pokój)'),
         ('ј', '[j]: odpowiada łacińskiemu j (wygląda jak łacińskie J)', 'ја́бука (jabłko)'),
         ('к', '[k]: odpowiada łacińskiemu k', 'ку́ћа (dom)'),
         ('л', '[l]: odpowiada łacińskiemu l', 'ле́то (lato)'),
         ('љ', '[ʎ]: odpowiada łacińskiemu lj', 'љу́бав (miłość)'),
         ('м', '[m]: odpowiada łacińskiemu m', 'ма́ма (mama)'),
     ],
    },
    {'id': 'wymowa3', 'title': 'Ćirilica II', 'icon': 'Н', 'track': 'wymowa',
     'letters': [
         ('н', '[n]: odpowiada łacińskiemu n', 'нос (nos)'),
         ('њ', '[ɲ]: odpowiada łacińskiemu nj', 'коњ (koń)'),
         ('о', '[o]: odpowiada łacińskiemu o', 'о́ко (oko)'),
         ('п', '[p]: odpowiada łacińskiemu p', 'пас (pies)'),
         ('р', '[r]: odpowiada łacińskiemu r (wygląda jak łacińskie P)', 'ру́ка (ręka)'),
         ('с', '[s]: odpowiada łacińskiemu s (wygląda jak łacińskie C)', 'сир (ser)'),
         ('т', '[t]: odpowiada łacińskiemu t', 'та́та (tata)'),
         ('ћ', '[tɕ]: odpowiada łacińskiemu ć', 'ку́ћа (dom)'),
         ('у', '[u]: odpowiada łacińskiemu u (wygląda jak łacińskie y)', 'у́хо (ucho)'),
         ('ф', '[f]: odpowiada łacińskiemu f', 'фа́брика (fabryka)'),
         ('х', '[x]: odpowiada łacińskiemu h (wygląda jak łacińskie x)', 'хлеб (chleb)'),
         ('ц', '[ts]: odpowiada łacińskiemu c', 'це́на (cena)'),
         ('ч', '[tʃ]: odpowiada łacińskiemu č', 'чај (herbata)'),
         ('џ', '[dʒ]: odpowiada łacińskiemu dž', 'џеп (kieszeń)'),
         ('ш', '[ʃ]: odpowiada łacińskiemu š', 'шко́ла (szkoła)'),
     ],
    },
    {'id': 'slowa', 'title': 'Pierwsze słowa', 'icon': 'Z', 'track': 'jezyk', 'requires': 'wymowa',
     'words': [
         ('zdrávo', 'cześć', None, 'Od „zdrav”: zdrowy.'),
         ('doviđénja', 'do widzenia', None, None),
         ('hvála', 'dziękuję', None, None),
         ('mólim', 'proszę', None, None),
         ('da', 'tak', None, None),
         ('ne', 'nie', None, None),
         ('dóbar', 'dobry (męski)', None, None),
         ('dóbro', 'dobrze; dobre (nijaki)', None, None),
         ('dan', 'dzień', None, None),
         ('jútro', 'rano; jutro', None, None),
         ('láku', 'lekką', None, None),
         ('noć', 'noc', None, None),
         ('izvíni', 'przepraszam', None, None),
         ('mnógo', 'dużo; bardzo', None, None),
     ],
     'sentences': [
         (['zdrávo', '!'], 'Cześć!', {'doviđénja': 'doviđénja to „do widzenia”.'}),
         (['doviđénja', '!'], 'Do widzenia!', {'zdrávo': 'zdrávo to „cześć”.'}),
         (['dóbar', 'dan', '!'], 'Dzień dobry!', {'noć': 'noć to „noc”.'}),
         (['dóbro', 'jútro', '!'], 'Dzień dobry (rano)!', {'dan': 'dan to „dzień”.'}),
         (['láku', 'noć', '!'], 'Dobranoc!', {'dan': 'dan to „dzień”.'}),
         (['hvála', '!'], 'Dziękuję!', {'mólim': 'mólim to „proszę”. Tu dziękujesz.'}),
         (['da', ',', 'hvála'], 'Tak, dziękuję.', {'ne': 'ne to „nie”.'}),
         (['ne', ',', 'hvála'], 'Nie, dziękuję.', {'da': 'da to „tak”.'}),
         (['hvála', 'mnógo'], 'Dziękuję bardzo.', {}),
         (['izvíni', '!'], 'Przepraszam!', {}),
     ],
    },
    {'id': 'ja', 'title': 'Ja, ty, on', 'icon': 'J', 'track': 'jezyk',
     'words': [
         ('ja', 'ja', None, None),
         ('ti', 'ty', None, None),
         ('on', 'on', None, None),
         ('óna', 'ona', None, None),
         ('sam', 'jestem', None, None),
         ('si', 'jesteś', None, None),
         ('je', 'jest', None, None),
         ('stúdent', 'student', 'student', None),
         ('nástavnik', 'nauczyciel', None, None),
         ('Póljak', 'Polak', None, None),
         ('Póljakinja', 'Polka', None, None),
         ('iz', 'z', None, None),
         ('Póljske', 'Polski', None, 'Po „iz”: dopełniacz.'),
         ('Sŕbije', 'Serbii', None, 'Po „iz”: dopełniacz.'),
     ],
     'sentences': [
         (['ja', 'sam', 'stúdent'], 'Jestem studentem.', {'si': 'si to „jesteś”. O sobie: sam.'}),
         (['ti', 'si', 'nástavnik'], 'Jesteś nauczycielem.', {'sam': 'sam to „jestem”. Do „ti”: si.'}),
         (['on', 'je', 'Póljak'], 'On jest Polakiem.', {'Póljakinja': 'Dla mężczyzny: Póljak.'}),
         (['óna', 'je', 'Póljakinja'], 'Ona jest Polką.', {'Póljak': 'Dla kobiety: Póljakinja.'}),
         (['ja', 'sam', 'iz', 'Póljske'], 'Jestem z Polski.', {'Sŕbije': 'Sŕbije to „Serbii”.'}),
         (['óna', 'je', 'iz', 'Sŕbije'], 'Ona jest z Serbii.', {}),
     ],
    },
    {'id': 'ludzie', 'title': 'Ludzie i rodzina', 'icon': 'O', 'track': 'jezyk',
     'words': [
         ('májka', 'matka', None, None),
         ('ótac', 'ojciec', None, None),
         ('brat', 'brat', None, None),
         ('bráta', 'brata', None, 'Biernik: -a.'),
         ('séstra', 'siostra', None, None),
         ('séstru', 'siostrę', None, 'Biernik: -a → -u.'),
         ('déte', 'dziecko', None, None),
         ('príjatelj', 'przyjaciel', None, None),
         ('žéna', 'kobieta', None, None),
         ('muškárac', 'mężczyzna', None, None),
         ('moj', 'mój (męski)', None, None),
         ('mója', 'moja (żeński)', None, None),
         ('ímam', 'mam', None, None),
         ('ímaš', 'masz', None, None),
         ('máli', 'mały (męski)', None, None),
         ('mála', 'mała (żeński)', None, None),
         ('dóbra', 'dobra (żeński)', None, None),
     ],
     'sentences': [
         (['moj', 'brat', 'je', 'máli'], 'Mój brat jest mały.', {'mója': 'brat jest męski: moj.'}),
         (['mója', 'séstra', 'je', 'mála'], 'Moja siostra jest mała.', {'moj': 'séstra jest żeńska: moja.'}),
         (['májka', 'je', 'dóbra'], 'Matka jest dobra.', {}),
         (['ímam', 'bráta'], 'Mam brata.', {'ímaš': 'ímaš to „masz”. O sobie: ímam.'}),
         (['ímaš', 'séstru'], 'Masz siostrę.', {'ímam': 'ímam to „mam”. Do „ti”: ímaš.'}),
         (['ótac', 'je', 'muškárac'], 'Ojciec jest mężczyzną.', {}),
         (['moj', 'príjatelj', 'je', 'dóbar'], 'Mój przyjaciel jest dobry.', {}),
     ],
    },
    {'id': 'jedzenie', 'title': 'Jedzenie i picie', 'icon': 'K', 'track': 'jezyk',
     'words': [
         ('vóda', 'woda', None, None),
         ('vódu', 'wodę', None, 'Biernik: -a → -u.'),
         ('káfa', 'kawa', None, None),
         ('káfu', 'kawę', None, 'Biernik.'),
         ('čaj', 'herbata', None, None),
         ('hleb', 'chleb', None, None),
         ('sir', 'ser', None, None),
         ('mléko', 'mleko', None, None),
         ('ríba', 'ryba', None, None),
         ('ríbu', 'rybę', None, 'Biernik.'),
         ('jábuka', 'jabłko', None, None),
         ('jábuku', 'jabłko (biernik)', None, None),
         ('hóću', 'chcę', None, None),
         ('hóćeš', 'chcesz', None, None),
         ('úkusna', 'smaczna', None, None),
         ('véoma', 'bardzo', None, None),
         ('sáda', 'teraz', None, None),
     ],
     'sentences': [
         (['ja', 'hóću', 'káfu'], 'Chcę kawę.', {'hóćeš': 'hóćeš to „chcesz”. O sobie: hóću.'}),
         (['ti', 'hóćeš', 'čaj'], 'Chcesz herbatę.', {'hóću': 'hóću to „chcę”. Do „ti”: hóćeš.'}),
         (['ja', 'hóću', 'hleb'], 'Chcę chleb.', {}),
         (['ti', 'hóćeš', 'jábuku'], 'Chcesz jabłko.', {'jábuka': 'Po „hóćeš” biernik: jábuku.'}),
         (['ríba', 'je', 'véoma', 'úkusna'], 'Ryba jest bardzo smaczna.', {}),
         (['sáda', 'hóću', 'vódu'], 'Teraz chcę wodę.', {'vóda': 'Po „hóću” biernik: vódu.'}),
     ],
    },
    {'id': 'liczby', 'title': 'Liczby i czas', 'icon': '1', 'track': 'jezyk',
     'words': [
         ('dva', 'dwa', None, None),
         ('tri', 'trzy', None, None),
         ('čétiri', 'cztery', None, None),
         ('pet', 'pięć', None, None),
         ('déset', 'dziesięć', None, None),
         ('jábuke', 'jabłka', None, 'Po 2–4: dopełniacz lp.-e.'),
         ('dánas', 'dziś', None, None),
         ('sútra', 'jutro', None, None),
         ('júče', 'wczoraj', None, None),
         ('sáti', 'godzin', None, None),
         ('kolíko', 'ile', None, None),
     ],
     'sentences': [
         (['ímam', 'dva', 'bráta'], 'Mam dwóch braci.', {}),
         (['ja', 'hóću', 'tri', 'jábuke'], 'Chcę trzy jabłka.', {'dva': 'dva to „dwa”. Chcesz trzy: tri.'}),
         (['kolíko', 'je', 'sáti', '?'], 'Która jest godzina?', {}),
         (['sáda', 'je', 'déset', 'sáti'], 'Jest dziesiąta.', {'pet': 'pet to „pięć”.'}),
         (['dánas', 'hóću', 'káfu'], 'Dziś chcę kawę.', {'sútra': 'sútra to „jutro”. Tu „dziś”: dánas.'}),
         (['sútra', 'hóću', 'ríbu'], 'Jutro chcę rybę.', {'júče': 'júče to „wczoraj”.'}),
     ],
    },
    {'id': 'miejsca', 'title': 'Miejsca i podróż', 'icon': 'G', 'track': 'jezyk',
     'words': [
         ('kúća', 'dom', None, None),
         ('kúći', 'do domu', None, None),
         ('grad', 'miasto', None, None),
         ('úlica', 'ulica', None, None),
         ('škóla', 'szkoła', None, None),
         ('móre', 'morze', None, None),
         ('táksi', 'taksówka', 'taksówka', None),
         ('hótel', 'hotel', 'hotel', None),
         ('gde', 'gdzie', None, None),
         ('óvde', 'tu', None, None),
         ('támo', 'tam', None, None),
         ('ídem', 'idę; jadę', None, None),
         ('u', 'do; w', None, None),
         ('Beógrad', 'Belgrad', None, None),
         ('désno', 'w prawo; po prawej', None, None),
         ('lévo', 'w lewo; po lewej', None, None),
     ],
     'sentences': [
         (['gde', 'je', 'hótel', '?'], 'Gdzie jest hotel?', {'óvde': 'óvde to „tu”. Pytasz „gdzie”: gde.'}),
         (['hótel', 'je', 'támo'], 'Hotel jest tam.', {'óvde': 'óvde to „tu”. Tu „tam”: támo.'}),
         (['ídem', 'kúći'], 'Idę do domu.', {}),
         (['ídem', 'u', 'Beógrad'], 'Jadę do Belgradu.', {}),
         (['táksi', 'je', 'désno'], 'Taksówka jest po prawej.', {'lévo': 'lévo to „po lewej”.'}),
         (['škóla', 'je', 'támo'], 'Szkoła jest tam.', {}),
     ],
    },
]

INSIGHTS = {
    'wymowa': [
        {'title': 'Dwa pisma, jeden język', 'chain': [], 'text': 'Serbowie piszą i cyrylicą, i łacinką. Każda litera ma swój odpowiednik: č = ч, š = ш, ž = ж, ć = ћ, đ = ђ, lj = љ, nj = њ, dž = џ. Czyta się to, co się widzi: jedna litera, jeden dźwięk. Kreska nad samogłoską (vóda) pokazuje tylko miejsce akcentu; w zwykłych tekstach się jej nie pisze. Serbski ma też akcent tonowy (rosnący i opadający), którego ten kurs jeszcze nie zaznacza.'},
    ],
    'ja': [
        {'title': 'Sam, si, je', 'chain': [('Jestem studentem.', ['ja', 'sam', 'stúdent'], 'Do „ja” pasuje sam.'), ('Jesteś nauczycielem.', ['ti', 'si', 'nástavnik'], 'Do „ti” pasuje si.')], 'text': '„Być”: sam, si, je. To krótkie formy, które stoją po słowie, a zaimek ja, ti można pominąć. Nie ma rodzajników.'},
    ],
    'ludzie': [
        {'title': 'Rodzaj rzeczownika', 'chain': [], 'text': 'Rzeczowniki są męskie (brat), żeńskie (séstra) lub nijakie (déte). Zaimek „mój” się zgadza: moj brat, moja séstra. W bierniku -a przechodzi w -u: séstra → séstru.'},
    ],
    'jedzenie': [
        {'title': 'Biernik żeńskich na -a', 'chain': [], 'text': 'Po „hóću” (chcę) rzeczowniki żeńskie na -a mają -u: voda → vódu, káfa → káfu, jábuka → jábuku. Męskie nieżywotne (hleb, čaj) się nie zmieniają.'},
    ],
}

ENDINGS_INSIGHT = {'title': 'Rodzaj i forma czasownika', 'text': 'Po serbsku ćwiczysz rodzaj (moj/moja) i formy czasownika (sam, si, je; hoću, hoćeš). Tu to robisz.'}

ENDINGS = [
    ('ja ', '', 'sam', ' stúdent', ['sam', 'si', 'je'], 'ja jestem', 'Do „ja” pasuje sam.', 'ja'),
    ('ti ', '', 'si', ' nástavnik', ['sam', 'si', 'je'], 'ty jesteś', 'Do „ti” pasuje si.', 'ja'),
    ('on ', '', 'je', ' Póljak', ['sam', 'si', 'je'], 'on jest', 'Do „on” pasuje je.', 'ja'),
    ('', '', 'moj', ' brat', ['moj', 'mója'], 'mój (męski)', 'brat jest męski: moj.', 'ludzie'),
    ('', '', 'mója', ' séstra', ['moj', 'mója'], 'moja (żeński)', 'séstra jest żeńska: moja.', 'ludzie'),
    ('', '', 'ímam', ' bráta', ['ímam', 'ímaš'], 'ja mam', 'Do „ja” pasuje ímam.', 'ludzie'),
    ('', '', 'ímaš', ' séstru', ['ímam', 'ímaš'], 'ty masz', 'Do „ti” pasuje ímaš.', 'ludzie'),
    ('ja ', '', 'hóću', ' káfu', ['hóću', 'hóćeš'], 'ja chcę', 'Do „ja” pasuje hóću.', 'jedzenie'),
    ('ti ', '', 'hóćeš', ' čaj', ['hóću', 'hóćeš'], 'ty chcesz', 'Do „ti” pasuje hóćeš.', 'jedzenie'),
    ('ja sam ', '', 'iz', ' Póljske', ['iz', 'u'], 'z', 'iz to „z”, u to „do, w”.', 'miejsca'),
    ('ídem ', '', 'u', ' Beógrad', ['iz', 'u'], 'do', 'u to „do, w”.', 'miejsca'),
]

CHAT_EXTRA = {'i': 'i', 'Ána': 'Ana (imię)', 'Márko': 'Marko (imię)', 'taksísta': 'taksówkarz', 'kúda': 'dokąd', 'ídeš': 'idziesz; jedziesz'}

CHATS = [
    {'id': 'kafic', 'title': 'W kawiarni', 'partner': 'Ána', 'avatar': 'A', 'requires': 'jedzenie',
     'turns': [
         {'bot': ['dóbar', 'dan', '!'], 'en': 'Dzień dobry!', 'options': [(['dóbar', 'dan', '!'], True, None), (['láku', 'noć', '!'], False, 'láku noć to „dobranoc”. Jest dzień.')]},
         {'bot': ['káfu', '?'], 'en': 'Kawę?', 'options': [(['da', ',', 'ja', 'hóću', 'káfu'], True, None), (['da', ',', 'ti', 'hóćeš', 'káfu'], False, 'hóćeš jest do „ti”. O sobie: hóću.')]},
         {'bot': ['i', 'hleb', '?'], 'en': 'I chleb?', 'options': [(['ne', ',', 'hvála'], True, None), (['mólim', '!'], False, 'mólim to „proszę”. Odmów: ne, hvála.')]},
         {'bot': ['dóbro', '!'], 'build': (['hvála', '!'], 'Dziękuję!'), 'en': 'Dobrze!'},
     ]},
    {'id': 'upoznavanje', 'title': 'Poznajemy się', 'partner': 'Márko', 'avatar': 'M', 'requires': 'ludzie',
     'turns': [
         {'bot': ['zdrávo', '!'], 'en': 'Cześć!', 'options': [(['zdrávo', '!'], True, None), (['izvíni', '!'], False, 'izvíni to „przepraszam”. Powitaj: zdrávo.')]},
         {'bot': ['ti', 'si', 'iz', 'Sŕbije', '?'], 'en': 'Jesteś z Serbii?', 'options': [(['ne', ',', 'ja', 'sam', 'iz', 'Póljske'], True, None), (['ne', ',', 'ja', 'si', 'iz', 'Póljske'], False, 'si jest do „ti”. O sobie: sam.')]},
         {'bot': ['ímaš', 'bráta', '?'], 'en': 'Masz brata?', 'options': [(['da', ',', 'ímam', 'bráta'], True, None), (['da', ',', 'ímaš', 'bráta'], False, 'ímaš to „masz”. O sobie: ímam.')]},
         {'bot': ['doviđénja', '!'], 'build': (['doviđénja', '!'], 'Do widzenia!'), 'en': 'Do widzenia!'},
     ]},
    {'id': 'taksi', 'title': 'W taksówce', 'partner': 'taksísta', 'avatar': 'T', 'requires': 'miejsca',
     'turns': [
         {'bot': ['dóbar', 'dan', '!'], 'en': 'Dzień dobry!', 'options': [(['dóbar', 'dan', '!'], True, None), (['láku', 'noć', '!'], False, 'láku noć to „dobranoc”. Jest dzień.')]},
         {'bot': ['kúda', 'ídeš', '?'], 'en': 'Dokąd jedziesz?', 'options': [(['ídem', 'u', 'Beógrad'], True, None), (['ídeš', 'u', 'Beógrad'], False, 'ídeš to „idziesz”. O sobie: ídem.')]},
         {'bot': ['hótel', 'je', 'támo', '.'], 'en': 'Hotel jest tam.', 'options': [(['désno', '?'], True, None), (['óvde', '?'], False, 'Pytasz o kierunek: désno.')]},
         {'bot': ['da', '!'], 'build': (['hvála', '!'], 'Dziękuję!'), 'en': 'Tak!'},
     ]},
]


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['ja', 'ti', 'on/ona', 'mi', 'vi', 'oni/one'],
    'przyp': ['nominativ', 'genitiv', 'dativ', 'akuzativ', 'vokativ', 'instrumental', 'lokativ (o…)'],
    'lpart': ['męski lp.', 'żeński lp.', 'nijaki lp.', 'męski lm.', 'żeński lm.'],
    'trp': ['čitati', 'pisati', 'videti', 'napraviti', 'otvoriti'],
    'przyp6': ['nominativ', 'genitiv', 'dativ', 'akuzativ', 'instrumental', 'lokativ'],
    'liczrz': ['1', '2', '3', '4', '5', '11', '21', '22'],
    't_ff': ['reč', 'slovo', 'godina', 'sat', 'pravo', 'ponos', 'jutro'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'imati (mieć): -am', 'os', 'imam; imaš; ima; imamo; imate; imaju', 'Koniugacja -am: 3. osoba lm. -aju.'),
    ('conj', 'Wzory koniugacji', 'čitati (czytać): -am', 'os', 'čitam; čitaš; čita; čitamo; čitate; čitaju', None),
    ('conj', 'Wzory koniugacji', 'govoriti (mówić): -im', 'os', 'govorim; govoriš; govori; govorimo; govorite; govore', 'Koniugacja -im: 3. osoba lm. -e.'),
    ('conj', 'Wzory koniugacji', 'voleti (kochać, lubić): -im', 'os', 'volim; voliš; voli; volimo; volite; vole', None),
    ('conj', 'Wzory koniugacji', 'pisati (pisać): -em', 'os', 'pišem; pišeš; piše; pišemo; pišete; pišu', 'Koniugacja -em: 3. osoba lm. -u. Temat się zmienia: pis- → piš-.'),
    ('conj', 'Wzory koniugacji', 'piti (pić): -em', 'os', 'pijem; piješ; pije; pijemo; pijete; piju', None),
    ('conj', 'Czasowniki nieregularne', 'biti (być): formy krótkie', 'os', 'sam; si; je; smo; ste; su', None),
    ('conj', 'Czasowniki nieregularne', 'biti (być): formy pełne', 'os', 'jesam; jesi; jeste; jesmo; jeste; jesu', 'Formy pełne stoją na początku zdania i w krótkich odpowiedziach.'),
    ('conj', 'Czasowniki nieregularne', 'hteti (chcieć)', 'os', 'hoću; hoćeš; hoće; hoćemo; hoćete; hoće', None),
    ('conj', 'Czasowniki nieregularne', 'moći (móc)', 'os', 'mogu; možeš; može; možemo; možete; mogu', None),
    ('conj', 'Czasowniki nieregularne', 'ići (iść)', 'os', 'idem; ideš; ide; idemo; idete; idu', None),
    ('conj', 'Czasowniki nieregularne', 'jesti (jeść)', 'os', 'jedem; jedeš; jede; jedemo; jedete; jedu', None),
    ('decl', 'Wzory deklinacji', 'brat (brat): męski żywotny', 'przyp', 'brat; brata; bratu; brata; brate; bratom; bratu', 'U żywotnych biernik = dopełniacz.'),
    ('decl', 'Wzory deklinacji', 'grad (miasto): męski nieżywotny', 'przyp', 'grad; grada; gradu; grad; grade; gradom; gradu', 'U nieżywotnych biernik = mianownik.'),
    ('decl', 'Wzory deklinacji', 'žena (kobieta): żeński na -a', 'przyp', 'žena; žene; ženi; ženu; ženo; ženom; ženi', None),
    ('decl', 'Wzory deklinacji', 'selo (wieś): nijaki na -o', 'przyp', 'selo; sela; selu; selo; selo; selom; selu', None),
    ('decl', 'Wzory deklinacji', 'more (morze): nijaki na -e', 'przyp', 'more; mora; moru; more; more; morem; moru', 'Po miękkiej: narzędnik -em.'),
    ('decl', 'Wyjątki', 'otac (ojciec)', 'przyp', 'otac; oca; ocu; oca; oče; ocem; ocu', 'Ruchome a: otac → oca. Wołacz: oče.'),
    ('decl', 'Wyjątki', 'majka (matka)', 'przyp', 'majka; majke; majci; majku; majko; majkom; majci', 'Przed -i: k → c.'),
    ('decl', 'Wyjątki', 'dete (dziecko)', 'przyp', 'dete; deteta; detetu; dete; dete; detetom; detetu', 'Temat rozszerzony o -t-.'),
    ('form', 'Imiesłowy', 'biti: imiesłów czynny (na -o)', 'lpart', 'bio; bila; bilo; bili; bile', 'Z tym imiesłowem tworzy się czas przeszły: bio sam.'),
    ('form', 'Imiesłowy', 'čitati', 'lpart', 'čitao; čitala; čitalo; čitali; čitale', None),
    ('form', 'Imiesłowy', 'ići (wyjątek)', 'lpart', 'išao; išla; išlo; išli; išle', None),
    ('form', 'Imiesłowy', 'moći (wyjątek)', 'lpart', 'mogao; mogla; moglo; mogli; mogle', None),
    ('form', 'Imiesłowy', 'jesti (wyjątek)', 'lpart', 'jeo; jela; jelo; jeli; jele', None),
    ('form', 'Imiesłowy', 'Imiesłów bierny', 'trp', 'čitan; pisan; viđen; napravljen; otvoren', '-n, -en, -jen; przed -jen spółgłoska mięknie: videti → viđen.'),
    ('conj', 'Czas przeszły', 'čitati: perfekat', 'os', 'čitao sam; čitao si; čitao je; čitali smo; čitali ste; čitali su', None),
    ('conj', 'Czas przyszły', 'čitati: futur', 'os', 'ja ću čitati; ti ćeš čitati; on će čitati; mi ćemo čitati; vi ćete čitati; oni će čitati', 'Krótka forma hteti + bezokolicznik.'),
    ('decl', 'Liczebniki', 'jedan (jeden): rodzaj męski', 'przyp6', 'jedan; jednog; jednom; jedan; jednim; jednom', None),
    ('decl', 'Liczebniki', 'jedna (jedna): rodzaj żeński', 'przyp6', 'jedna; jedne; jednoj; jednu; jednom; jednoj', None),
    ('decl', 'Liczebniki', 'dva (dwa): męski i nijaki', 'przyp6', 'dva; dvaju; dvama; dva; dvama; dvama', 'W mowie potocznej 2–4 zwykle się nie odmienia; formy odmienione są książkowe.'),
    ('decl', 'Liczebniki', 'dve (dwie): żeński', 'przyp6', 'dve; dveju; dvema; dve; dvema; dvema', None),
    ('decl', 'Liczebniki', 'tri (trzy)', 'przyp6', 'tri; triju; trima; tri; trima; trima', None),
    ('form', 'Liczebniki', 'Liczebnik + rzeczownik: grad (miasto)', 'liczrz', 'jedan grad; dva grada; tri grada; četiri grada; pet gradova; jedanaest gradova; dvadeset jedan grad; dvadeset dva grada', 'Po 2–4: forma na -a. Od 5: dopełniacz lm. O formie decyduje ostatnie słowo liczebnika.'),
    ('form', 'Liczebniki', 'Liczebnik + rzeczownik: žena (kobieta)', 'liczrz', 'jedna žena; dve žene; tri žene; četiri žene; pet žena; jedanaest žena; dvadeset jedna žena; dvadeset dve žene', None),
    ('form', 'Typowe trudności', 'Fałszywi przyjaciele: co to znaczy?', 't_ff', 'słowo; litera; rok; godzina; prosto; duma; rano', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['___ li ti student?', 'Ja ___ student.', '— Jesi li student? — ___.', 'Ti ___ dobar.', '— Je li on ovde? — ___.', 'On ___ ovde.'],
    't_m1': ['Marko', 'Ana', 'brat', 'prijatelj', 'gospodin', 'majka', 'sestra', 'profesor'],
    't_m2': ['Ja ___ zovem Ana.', 'Zovem ___ Ana.', 'On ___ je video.', 'Video ___ je.', 'Ja ___ ga videti.', 'Videću ___.'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Krótka czy pełna forma „być”?', 't_m0', 'Jesi; sam; Jesam; si; Jeste; je', 'Formy krótkie stoją na drugim miejscu i nie mogą zaczynać zdania. Na początku i w krótkiej odpowiedzi używa się pełnych.'),
    ('form', 'Typowe trudności', 'Wołacz', 't_m1', 'Marko; Ana; brate; prijatelju; gospodine; majko; sestro; profesore', 'Imiona zwykle się nie zmieniają; rzeczowniki męskie dostają -e lub -u, żeńskie -o.'),
    ('form', 'Typowe trudności', 'Miejsce krótkich słów', 't_m2', 'se; se; me; me; ću; ga', 'Krótkie zaimki i formy czasownika stoją zaraz po pierwszym słowie zdania.'),
]

# Szyk zdania
PARADIGM_LABELS.update({
    't_s0': ['Dałem mu książkę.', 'Wczoraj go widziałem.', 'Nie widzę go.'],
})
PARADIGMS += [
    ('form', 'Szyk zdania', 'Szyk: krótkie słowa po pierwszym wyrazie', 't_s0', 'Dao sam mu knjigu.|Dao mu sam knjigu.|Sam mu dao knjigu.|Dao sam knjigu mu.; Juče sam ga video.|Juče ga sam video.|Juče video sam ga.|Sam ga juče video.; Ne vidim ga.|Ne ga vidim.|Ga ne vidim.|Vidim ga ne.', 'Krótkie zaimki i formy sam, si, je, ću stoją zaraz po pierwszym wyrazie lub zwrocie zdania.'),
]

# === PRONOUNS (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /PRONOUNS ===

# Pełne tłumaczenia zdań z ćwiczeń „Uzupełnij końcówkę” (gdy nie ma ich wśród zdań kursu)
ENDINGS_PL = {'moj brat': 'mój brat', 'mója séstra': 'moja siostra'}

# === STOPNIOWANIE (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('form', 'Stopniowanie', 'dobar (dobry)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'dobar; bolji; najbolji', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'velik (duży)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'velik; veći; najveći', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'mali (mały)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'mali; manji; najmanji', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'loš (zły)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'loš; gori; najgori', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'visok (wysoki)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'visok; viši; najviši', None),
    ('form', 'Stopniowanie', 'lep (piękny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'lep; lepši; najlepši', None),
    ('form', 'Stopniowanie', 'star (stary)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'star; stariji; najstariji', None),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /STOPNIOWANIE ===

"""Treść kursu: serbski dla Polaków (pismo łacińskie + cyrylica).

Akcent: znak U+0301 po akcentowanej samogłosce (tylko miejsce akcentu, bez tonu)."""

PUNCT = {'!', ',', '.', ':', '?'}

TRACKS = {'wymowa': 'ПИСМО · PISMO', 'jezyk': 'ЈЕЗИК · JĘZYK'}

UNITS = [
    {'id': 'wymowa', 'title': 'Łacinka', 'icon': 'Č', 'track': 'wymowa',
     'letters': [
         ('č', '[tʃ]: twarde cz, jak polskie cz', 'čaj (herbata)'),
         ('ć', '[tɕ]: miękkie ć, jak polskie ć', 'kúća (dom)'),
         ('dž', '[dʒ]: jak polskie dż', 'džep (kieszeń)'),
         ('đ', '[dʑ]: miękkie dź, jak polskie dź', 'đak (uczeń)'),
         ('š', '[ʃ]: jak polskie sz', 'škóla (szkoła)'),
         ('ž', '[ʒ]: jak polskie ż', 'žéna (kobieta)'),
         ('lj', '[ʎ]: miękkie l, jak polskie li przed samogłoską', 'ljúbav (miłość)'),
         ('nj', '[ɲ]: jak polskie ń', 'konj (koń)'),
         ('c', '[ts]: jak polskie c', 'céna (cena)'),
         ('h', '[x]: jak polskie ch', 'hleb (chleb)'),
         ('j', '[j]: jak polskie j', 'jábuka (jabłko)'),
         ('r', '[r]: toczone; może być samogłoską w słowie', 'krv (krew)'),
         ('akcent', 'tonowy: długie i krótkie, rosnące i opadające sylaby', 'vóda (woda)'),
     ],
    },
    {'id': 'wymowa2', 'title': 'Ćirilica I', 'icon': 'А', 'track': 'wymowa',
     'letters': [
         ('а', '[a]: odpowiada łacińskiemu a', 'ма́јка (matka)'),
         ('б', '[b]: odpowiada łacińskiemu b', 'брат (brat)'),
         ('в', '[ʋ]: odpowiada łacińskiemu v', 'во́да (woda)'),
         ('г', '[ɡ]: odpowiada łacińskiemu g', 'град (miasto)'),
         ('д', '[d]: odpowiada łacińskiemu d', 'дан (dzień)'),
         ('ђ', '[dʑ]: odpowiada łacińskiemu đ', 'ђак (uczeń)'),
         ('е', '[e]: odpowiada łacińskiemu e', 'се́ло (wieś)'),
         ('ж', '[ʒ]: odpowiada łacińskiemu ž', 'же́на (kobieta)'),
         ('з', '[z]: odpowiada łacińskiemu z', 'зи́ма (zima)'),
         ('и', '[i]: odpowiada łacińskiemu i', 'мир (pokój)'),
         ('ј', '[j]: odpowiada łacińskiemu j (wygląda jak łacińskie J)', 'ја́бука (jabłko)'),
         ('к', '[k]: odpowiada łacińskiemu k', 'ку́ћа (dom)'),
         ('л', '[l]: odpowiada łacińskiemu l', 'ле́то (lato)'),
         ('љ', '[ʎ]: odpowiada łacińskiemu lj', 'љу́бав (miłość)'),
         ('м', '[m]: odpowiada łacińskiemu m', 'ма́ма (mama)'),
     ],
    },
    {'id': 'wymowa3', 'title': 'Ćirilica II', 'icon': 'Н', 'track': 'wymowa',
     'letters': [
         ('н', '[n]: odpowiada łacińskiemu n', 'нос (nos)'),
         ('њ', '[ɲ]: odpowiada łacińskiemu nj', 'коњ (koń)'),
         ('о', '[o]: odpowiada łacińskiemu o', 'о́ко (oko)'),
         ('п', '[p]: odpowiada łacińskiemu p', 'пас (pies)'),
         ('р', '[r]: odpowiada łacińskiemu r (wygląda jak łacińskie P)', 'ру́ка (ręka)'),
         ('с', '[s]: odpowiada łacińskiemu s (wygląda jak łacińskie C)', 'сир (ser)'),
         ('т', '[t]: odpowiada łacińskiemu t', 'та́та (tata)'),
         ('ћ', '[tɕ]: odpowiada łacińskiemu ć', 'ку́ћа (dom)'),
         ('у', '[u]: odpowiada łacińskiemu u (wygląda jak łacińskie y)', 'у́хо (ucho)'),
         ('ф', '[f]: odpowiada łacińskiemu f', 'фа́брика (fabryka)'),
         ('х', '[x]: odpowiada łacińskiemu h (wygląda jak łacińskie x)', 'хлеб (chleb)'),
         ('ц', '[ts]: odpowiada łacińskiemu c', 'це́на (cena)'),
         ('ч', '[tʃ]: odpowiada łacińskiemu č', 'чај (herbata)'),
         ('џ', '[dʒ]: odpowiada łacińskiemu dž', 'џеп (kieszeń)'),
         ('ш', '[ʃ]: odpowiada łacińskiemu š', 'шко́ла (szkoła)'),
     ],
    },
    {'id': 'slowa', 'title': 'Pierwsze słowa', 'icon': 'Z', 'track': 'jezyk', 'requires': 'wymowa',
     'words': [
         ('zdrávo', 'cześć', None, 'Od „zdrav”: zdrowy.'),
         ('doviđénja', 'do widzenia', None, None),
         ('hvála', 'dziękuję', None, None),
         ('mólim', 'proszę', None, None),
         ('da', 'tak', None, None),
         ('ne', 'nie', None, None),
         ('dóbar', 'dobry (męski)', None, None),
         ('dóbro', 'dobrze; dobre (nijaki)', None, None),
         ('dan', 'dzień', None, None),
         ('jútro', 'rano; jutro', None, None),
         ('láku', 'lekką', None, None),
         ('noć', 'noc', None, None),
         ('izvíni', 'przepraszam', None, None),
         ('mnógo', 'dużo; bardzo', None, None),
     ],
     'sentences': [
         (['zdrávo', '!'], 'Cześć!', {'doviđénja': 'doviđénja to „do widzenia”.'}),
         (['doviđénja', '!'], 'Do widzenia!', {'zdrávo': 'zdrávo to „cześć”.'}),
         (['dóbar', 'dan', '!'], 'Dzień dobry!', {'noć': 'noć to „noc”.'}),
         (['dóbro', 'jútro', '!'], 'Dzień dobry (rano)!', {'dan': 'dan to „dzień”.'}),
         (['láku', 'noć', '!'], 'Dobranoc!', {'dan': 'dan to „dzień”.'}),
         (['hvála', '!'], 'Dziękuję!', {'mólim': 'mólim to „proszę”. Tu dziękujesz.'}),
         (['da', ',', 'hvála'], 'Tak, dziękuję.', {'ne': 'ne to „nie”.'}),
         (['ne', ',', 'hvála'], 'Nie, dziękuję.', {'da': 'da to „tak”.'}),
         (['hvála', 'mnógo'], 'Dziękuję bardzo.', {}),
         (['izvíni', '!'], 'Przepraszam!', {}),
     ],
    },
    {'id': 'ja', 'title': 'Ja, ty, on', 'icon': 'J', 'track': 'jezyk',
     'words': [
         ('ja', 'ja', None, None),
         ('ti', 'ty', None, None),
         ('on', 'on', None, None),
         ('óna', 'ona', None, None),
         ('sam', 'jestem', None, None),
         ('si', 'jesteś', None, None),
         ('je', 'jest', None, None),
         ('stúdent', 'student', 'student', None),
         ('nástavnik', 'nauczyciel', None, None),
         ('Póljak', 'Polak', None, None),
         ('Póljakinja', 'Polka', None, None),
         ('iz', 'z', None, None),
         ('Póljske', 'Polski', None, 'Po „iz”: dopełniacz.'),
         ('Sŕbije', 'Serbii', None, 'Po „iz”: dopełniacz.'),
     ],
     'sentences': [
         (['ja', 'sam', 'stúdent'], 'Jestem studentem.', {'si': 'si to „jesteś”. O sobie: sam.'}),
         (['ti', 'si', 'nástavnik'], 'Jesteś nauczycielem.', {'sam': 'sam to „jestem”. Do „ti”: si.'}),
         (['on', 'je', 'Póljak'], 'On jest Polakiem.', {'Póljakinja': 'Dla mężczyzny: Póljak.'}),
         (['óna', 'je', 'Póljakinja'], 'Ona jest Polką.', {'Póljak': 'Dla kobiety: Póljakinja.'}),
         (['ja', 'sam', 'iz', 'Póljske'], 'Jestem z Polski.', {'Sŕbije': 'Sŕbije to „Serbii”.'}),
         (['óna', 'je', 'iz', 'Sŕbije'], 'Ona jest z Serbii.', {}),
     ],
    },
    {'id': 'ludzie', 'title': 'Ludzie i rodzina', 'icon': 'O', 'track': 'jezyk',
     'words': [
         ('májka', 'matka', None, None),
         ('ótac', 'ojciec', None, None),
         ('brat', 'brat', None, None),
         ('bráta', 'brata', None, 'Biernik: -a.'),
         ('séstra', 'siostra', None, None),
         ('séstru', 'siostrę', None, 'Biernik: -a → -u.'),
         ('déte', 'dziecko', None, None),
         ('príjatelj', 'przyjaciel', None, None),
         ('žéna', 'kobieta', None, None),
         ('muškárac', 'mężczyzna', None, None),
         ('moj', 'mój (męski)', None, None),
         ('mója', 'moja (żeński)', None, None),
         ('ímam', 'mam', None, None),
         ('ímaš', 'masz', None, None),
         ('máli', 'mały (męski)', None, None),
         ('mála', 'mała (żeński)', None, None),
         ('dóbra', 'dobra (żeński)', None, None),
     ],
     'sentences': [
         (['moj', 'brat', 'je', 'máli'], 'Mój brat jest mały.', {'mója': 'brat jest męski: moj.'}),
         (['mója', 'séstra', 'je', 'mála'], 'Moja siostra jest mała.', {'moj': 'séstra jest żeńska: moja.'}),
         (['májka', 'je', 'dóbra'], 'Matka jest dobra.', {}),
         (['ímam', 'bráta'], 'Mam brata.', {'ímaš': 'ímaš to „masz”. O sobie: ímam.'}),
         (['ímaš', 'séstru'], 'Masz siostrę.', {'ímam': 'ímam to „mam”. Do „ti”: ímaš.'}),
         (['ótac', 'je', 'muškárac'], 'Ojciec jest mężczyzną.', {}),
         (['moj', 'príjatelj', 'je', 'dóbar'], 'Mój przyjaciel jest dobry.', {}),
     ],
    },
    {'id': 'jedzenie', 'title': 'Jedzenie i picie', 'icon': 'K', 'track': 'jezyk',
     'words': [
         ('vóda', 'woda', None, None),
         ('vódu', 'wodę', None, 'Biernik: -a → -u.'),
         ('káfa', 'kawa', None, None),
         ('káfu', 'kawę', None, 'Biernik.'),
         ('čaj', 'herbata', None, None),
         ('hleb', 'chleb', None, None),
         ('sir', 'ser', None, None),
         ('mléko', 'mleko', None, None),
         ('ríba', 'ryba', None, None),
         ('ríbu', 'rybę', None, 'Biernik.'),
         ('jábuka', 'jabłko', None, None),
         ('jábuku', 'jabłko (biernik)', None, None),
         ('hóću', 'chcę', None, None),
         ('hóćeš', 'chcesz', None, None),
         ('úkusna', 'smaczna', None, None),
         ('véoma', 'bardzo', None, None),
         ('sáda', 'teraz', None, None),
     ],
     'sentences': [
         (['ja', 'hóću', 'káfu'], 'Chcę kawę.', {'hóćeš': 'hóćeš to „chcesz”. O sobie: hóću.'}),
         (['ti', 'hóćeš', 'čaj'], 'Chcesz herbatę.', {'hóću': 'hóću to „chcę”. Do „ti”: hóćeš.'}),
         (['ja', 'hóću', 'hleb'], 'Chcę chleb.', {}),
         (['ti', 'hóćeš', 'jábuku'], 'Chcesz jabłko.', {'jábuka': 'Po „hóćeš” biernik: jábuku.'}),
         (['ríba', 'je', 'véoma', 'úkusna'], 'Ryba jest bardzo smaczna.', {}),
         (['sáda', 'hóću', 'vódu'], 'Teraz chcę wodę.', {'vóda': 'Po „hóću” biernik: vódu.'}),
     ],
    },
    {'id': 'liczby', 'title': 'Liczby i czas', 'icon': '1', 'track': 'jezyk',
     'words': [
         ('dva', 'dwa', None, None),
         ('tri', 'trzy', None, None),
         ('čétiri', 'cztery', None, None),
         ('pet', 'pięć', None, None),
         ('déset', 'dziesięć', None, None),
         ('jábuke', 'jabłka', None, 'Po 2–4: dopełniacz lp.-e.'),
         ('dánas', 'dziś', None, None),
         ('sútra', 'jutro', None, None),
         ('júče', 'wczoraj', None, None),
         ('sáti', 'godzin', None, None),
         ('kolíko', 'ile', None, None),
     ],
     'sentences': [
         (['ímam', 'dva', 'bráta'], 'Mam dwóch braci.', {}),
         (['ja', 'hóću', 'tri', 'jábuke'], 'Chcę trzy jabłka.', {'dva': 'dva to „dwa”. Chcesz trzy: tri.'}),
         (['kolíko', 'je', 'sáti', '?'], 'Która jest godzina?', {}),
         (['sáda', 'je', 'déset', 'sáti'], 'Jest dziesiąta.', {'pet': 'pet to „pięć”.'}),
         (['dánas', 'hóću', 'káfu'], 'Dziś chcę kawę.', {'sútra': 'sútra to „jutro”. Tu „dziś”: dánas.'}),
         (['sútra', 'hóću', 'ríbu'], 'Jutro chcę rybę.', {'júče': 'júče to „wczoraj”.'}),
     ],
    },
    {'id': 'miejsca', 'title': 'Miejsca i podróż', 'icon': 'G', 'track': 'jezyk',
     'words': [
         ('kúća', 'dom', None, None),
         ('kúći', 'do domu', None, None),
         ('grad', 'miasto', None, None),
         ('úlica', 'ulica', None, None),
         ('škóla', 'szkoła', None, None),
         ('móre', 'morze', None, None),
         ('táksi', 'taksówka', 'taksówka', None),
         ('hótel', 'hotel', 'hotel', None),
         ('gde', 'gdzie', None, None),
         ('óvde', 'tu', None, None),
         ('támo', 'tam', None, None),
         ('ídem', 'idę; jadę', None, None),
         ('u', 'do; w', None, None),
         ('Beógrad', 'Belgrad', None, None),
         ('désno', 'w prawo; po prawej', None, None),
         ('lévo', 'w lewo; po lewej', None, None),
     ],
     'sentences': [
         (['gde', 'je', 'hótel', '?'], 'Gdzie jest hotel?', {'óvde': 'óvde to „tu”. Pytasz „gdzie”: gde.'}),
         (['hótel', 'je', 'támo'], 'Hotel jest tam.', {'óvde': 'óvde to „tu”. Tu „tam”: támo.'}),
         (['ídem', 'kúći'], 'Idę do domu.', {}),
         (['ídem', 'u', 'Beógrad'], 'Jadę do Belgradu.', {}),
         (['táksi', 'je', 'désno'], 'Taksówka jest po prawej.', {'lévo': 'lévo to „po lewej”.'}),
         (['škóla', 'je', 'támo'], 'Szkoła jest tam.', {}),
     ],
    },
]

INSIGHTS = {
    'wymowa': [
        {'title': 'Dwa pisma, jeden język', 'chain': [], 'text': 'Serbowie piszą i cyrylicą, i łacinką. Każda litera ma swój odpowiednik: č = ч, š = ш, ž = ж, ć = ћ, đ = ђ, lj = љ, nj = њ, dž = џ. Czyta się to, co się widzi: jedna litera, jeden dźwięk. Kreska nad samogłoską (vóda) pokazuje tylko miejsce akcentu; w zwykłych tekstach się jej nie pisze. Serbski ma też akcent tonowy (rosnący i opadający), którego ten kurs jeszcze nie zaznacza.'},
    ],
    'ja': [
        {'title': 'Sam, si, je', 'chain': [('Jestem studentem.', ['ja', 'sam', 'stúdent'], 'Do „ja” pasuje sam.'), ('Jesteś nauczycielem.', ['ti', 'si', 'nástavnik'], 'Do „ti” pasuje si.')], 'text': '„Być”: sam, si, je. To krótkie formy, które stoją po słowie, a zaimek ja, ti można pominąć. Nie ma rodzajników.'},
    ],
    'ludzie': [
        {'title': 'Rodzaj rzeczownika', 'chain': [], 'text': 'Rzeczowniki są męskie (brat), żeńskie (séstra) lub nijakie (déte). Zaimek „mój” się zgadza: moj brat, moja séstra. W bierniku -a przechodzi w -u: séstra → séstru.'},
    ],
    'jedzenie': [
        {'title': 'Biernik żeńskich na -a', 'chain': [], 'text': 'Po „hóću” (chcę) rzeczowniki żeńskie na -a mają -u: voda → vódu, káfa → káfu, jábuka → jábuku. Męskie nieżywotne (hleb, čaj) się nie zmieniają.'},
    ],
}

ENDINGS_INSIGHT = {'title': 'Rodzaj i forma czasownika', 'text': 'Po serbsku ćwiczysz rodzaj (moj/moja) i formy czasownika (sam, si, je; hoću, hoćeš). Tu to robisz.'}

ENDINGS = [
    ('ja ', '', 'sam', ' stúdent', ['sam', 'si', 'je'], 'ja jestem', 'Do „ja” pasuje sam.', 'ja'),
    ('ti ', '', 'si', ' nástavnik', ['sam', 'si', 'je'], 'ty jesteś', 'Do „ti” pasuje si.', 'ja'),
    ('on ', '', 'je', ' Póljak', ['sam', 'si', 'je'], 'on jest', 'Do „on” pasuje je.', 'ja'),
    ('', '', 'moj', ' brat', ['moj', 'mója'], 'mój (męski)', 'brat jest męski: moj.', 'ludzie'),
    ('', '', 'mója', ' séstra', ['moj', 'mója'], 'moja (żeński)', 'séstra jest żeńska: moja.', 'ludzie'),
    ('', '', 'ímam', ' bráta', ['ímam', 'ímaš'], 'ja mam', 'Do „ja” pasuje ímam.', 'ludzie'),
    ('', '', 'ímaš', ' séstru', ['ímam', 'ímaš'], 'ty masz', 'Do „ti” pasuje ímaš.', 'ludzie'),
    ('ja ', '', 'hóću', ' káfu', ['hóću', 'hóćeš'], 'ja chcę', 'Do „ja” pasuje hóću.', 'jedzenie'),
    ('ti ', '', 'hóćeš', ' čaj', ['hóću', 'hóćeš'], 'ty chcesz', 'Do „ti” pasuje hóćeš.', 'jedzenie'),
    ('ja sam ', '', 'iz', ' Póljske', ['iz', 'u'], 'z', 'iz to „z”, u to „do, w”.', 'miejsca'),
    ('ídem ', '', 'u', ' Beógrad', ['iz', 'u'], 'do', 'u to „do, w”.', 'miejsca'),
]

CHAT_EXTRA = {'i': 'i', 'Ána': 'Ana (imię)', 'Márko': 'Marko (imię)', 'taksísta': 'taksówkarz', 'kúda': 'dokąd', 'ídeš': 'idziesz; jedziesz'}

CHATS = [
    {'id': 'kafic', 'title': 'W kawiarni', 'partner': 'Ána', 'avatar': 'A', 'requires': 'jedzenie',
     'turns': [
         {'bot': ['dóbar', 'dan', '!'], 'en': 'Dzień dobry!', 'options': [(['dóbar', 'dan', '!'], True, None), (['láku', 'noć', '!'], False, 'láku noć to „dobranoc”. Jest dzień.')]},
         {'bot': ['káfu', '?'], 'en': 'Kawę?', 'options': [(['da', ',', 'ja', 'hóću', 'káfu'], True, None), (['da', ',', 'ti', 'hóćeš', 'káfu'], False, 'hóćeš jest do „ti”. O sobie: hóću.')]},
         {'bot': ['i', 'hleb', '?'], 'en': 'I chleb?', 'options': [(['ne', ',', 'hvála'], True, None), (['mólim', '!'], False, 'mólim to „proszę”. Odmów: ne, hvála.')]},
         {'bot': ['dóbro', '!'], 'build': (['hvála', '!'], 'Dziękuję!'), 'en': 'Dobrze!'},
     ]},
    {'id': 'upoznavanje', 'title': 'Poznajemy się', 'partner': 'Márko', 'avatar': 'M', 'requires': 'ludzie',
     'turns': [
         {'bot': ['zdrávo', '!'], 'en': 'Cześć!', 'options': [(['zdrávo', '!'], True, None), (['izvíni', '!'], False, 'izvíni to „przepraszam”. Powitaj: zdrávo.')]},
         {'bot': ['ti', 'si', 'iz', 'Sŕbije', '?'], 'en': 'Jesteś z Serbii?', 'options': [(['ne', ',', 'ja', 'sam', 'iz', 'Póljske'], True, None), (['ne', ',', 'ja', 'si', 'iz', 'Póljske'], False, 'si jest do „ti”. O sobie: sam.')]},
         {'bot': ['ímaš', 'bráta', '?'], 'en': 'Masz brata?', 'options': [(['da', ',', 'ímam', 'bráta'], True, None), (['da', ',', 'ímaš', 'bráta'], False, 'ímaš to „masz”. O sobie: ímam.')]},
         {'bot': ['doviđénja', '!'], 'build': (['doviđénja', '!'], 'Do widzenia!'), 'en': 'Do widzenia!'},
     ]},
    {'id': 'taksi', 'title': 'W taksówce', 'partner': 'taksísta', 'avatar': 'T', 'requires': 'miejsca',
     'turns': [
         {'bot': ['dóbar', 'dan', '!'], 'en': 'Dzień dobry!', 'options': [(['dóbar', 'dan', '!'], True, None), (['láku', 'noć', '!'], False, 'láku noć to „dobranoc”. Jest dzień.')]},
         {'bot': ['kúda', 'ídeš', '?'], 'en': 'Dokąd jedziesz?', 'options': [(['ídem', 'u', 'Beógrad'], True, None), (['ídeš', 'u', 'Beógrad'], False, 'ídeš to „idziesz”. O sobie: ídem.')]},
         {'bot': ['hótel', 'je', 'támo', '.'], 'en': 'Hotel jest tam.', 'options': [(['désno', '?'], True, None), (['óvde', '?'], False, 'Pytasz o kierunek: désno.')]},
         {'bot': ['da', '!'], 'build': (['hvála', '!'], 'Dziękuję!'), 'en': 'Tak!'},
     ]},
]


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['ja', 'ti', 'on/ona', 'mi', 'vi', 'oni/one'],
    'przyp': ['nominativ', 'genitiv', 'dativ', 'akuzativ', 'vokativ', 'instrumental', 'lokativ (o…)'],
    'lpart': ['męski lp.', 'żeński lp.', 'nijaki lp.', 'męski lm.', 'żeński lm.'],
    'trp': ['čitati', 'pisati', 'videti', 'napraviti', 'otvoriti'],
    'przyp6': ['nominativ', 'genitiv', 'dativ', 'akuzativ', 'instrumental', 'lokativ'],
    'liczrz': ['1', '2', '3', '4', '5', '11', '21', '22'],
    't_ff': ['reč', 'slovo', 'godina', 'sat', 'pravo', 'ponos', 'jutro'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'imati (mieć): -am', 'os', 'imam; imaš; ima; imamo; imate; imaju', 'Koniugacja -am: 3. osoba lm. -aju.'),
    ('conj', 'Wzory koniugacji', 'čitati (czytać): -am', 'os', 'čitam; čitaš; čita; čitamo; čitate; čitaju', None),
    ('conj', 'Wzory koniugacji', 'govoriti (mówić): -im', 'os', 'govorim; govoriš; govori; govorimo; govorite; govore', 'Koniugacja -im: 3. osoba lm. -e.'),
    ('conj', 'Wzory koniugacji', 'voleti (kochać, lubić): -im', 'os', 'volim; voliš; voli; volimo; volite; vole', None),
    ('conj', 'Wzory koniugacji', 'pisati (pisać): -em', 'os', 'pišem; pišeš; piše; pišemo; pišete; pišu', 'Koniugacja -em: 3. osoba lm. -u. Temat się zmienia: pis- → piš-.'),
    ('conj', 'Wzory koniugacji', 'piti (pić): -em', 'os', 'pijem; piješ; pije; pijemo; pijete; piju', None),
    ('conj', 'Czasowniki nieregularne', 'biti (być): formy krótkie', 'os', 'sam; si; je; smo; ste; su', None),
    ('conj', 'Czasowniki nieregularne', 'biti (być): formy pełne', 'os', 'jesam; jesi; jeste; jesmo; jeste; jesu', 'Formy pełne stoją na początku zdania i w krótkich odpowiedziach.'),
    ('conj', 'Czasowniki nieregularne', 'hteti (chcieć)', 'os', 'hoću; hoćeš; hoće; hoćemo; hoćete; hoće', None),
    ('conj', 'Czasowniki nieregularne', 'moći (móc)', 'os', 'mogu; možeš; može; možemo; možete; mogu', None),
    ('conj', 'Czasowniki nieregularne', 'ići (iść)', 'os', 'idem; ideš; ide; idemo; idete; idu', None),
    ('conj', 'Czasowniki nieregularne', 'jesti (jeść)', 'os', 'jedem; jedeš; jede; jedemo; jedete; jedu', None),
    ('decl', 'Wzory deklinacji', 'brat (brat): męski żywotny', 'przyp', 'brat; brata; bratu; brata; brate; bratom; bratu', 'U żywotnych biernik = dopełniacz.'),
    ('decl', 'Wzory deklinacji', 'grad (miasto): męski nieżywotny', 'przyp', 'grad; grada; gradu; grad; grade; gradom; gradu', 'U nieżywotnych biernik = mianownik.'),
    ('decl', 'Wzory deklinacji', 'žena (kobieta): żeński na -a', 'przyp', 'žena; žene; ženi; ženu; ženo; ženom; ženi', None),
    ('decl', 'Wzory deklinacji', 'selo (wieś): nijaki na -o', 'przyp', 'selo; sela; selu; selo; selo; selom; selu', None),
    ('decl', 'Wzory deklinacji', 'more (morze): nijaki na -e', 'przyp', 'more; mora; moru; more; more; morem; moru', 'Po miękkiej: narzędnik -em.'),
    ('decl', 'Wyjątki', 'otac (ojciec)', 'przyp', 'otac; oca; ocu; oca; oče; ocem; ocu', 'Ruchome a: otac → oca. Wołacz: oče.'),
    ('decl', 'Wyjątki', 'majka (matka)', 'przyp', 'majka; majke; majci; majku; majko; majkom; majci', 'Przed -i: k → c.'),
    ('decl', 'Wyjątki', 'dete (dziecko)', 'przyp', 'dete; deteta; detetu; dete; dete; detetom; detetu', 'Temat rozszerzony o -t-.'),
    ('form', 'Imiesłowy', 'biti: imiesłów czynny (na -o)', 'lpart', 'bio; bila; bilo; bili; bile', 'Z tym imiesłowem tworzy się czas przeszły: bio sam.'),
    ('form', 'Imiesłowy', 'čitati', 'lpart', 'čitao; čitala; čitalo; čitali; čitale', None),
    ('form', 'Imiesłowy', 'ići (wyjątek)', 'lpart', 'išao; išla; išlo; išli; išle', None),
    ('form', 'Imiesłowy', 'moći (wyjątek)', 'lpart', 'mogao; mogla; moglo; mogli; mogle', None),
    ('form', 'Imiesłowy', 'jesti (wyjątek)', 'lpart', 'jeo; jela; jelo; jeli; jele', None),
    ('form', 'Imiesłowy', 'Imiesłów bierny', 'trp', 'čitan; pisan; viđen; napravljen; otvoren', '-n, -en, -jen; przed -jen spółgłoska mięknie: videti → viđen.'),
    ('conj', 'Czas przeszły', 'čitati: perfekat', 'os', 'čitao sam; čitao si; čitao je; čitali smo; čitali ste; čitali su', None),
    ('conj', 'Czas przyszły', 'čitati: futur', 'os', 'ja ću čitati; ti ćeš čitati; on će čitati; mi ćemo čitati; vi ćete čitati; oni će čitati', 'Krótka forma hteti + bezokolicznik.'),
    ('decl', 'Liczebniki', 'jedan (jeden): rodzaj męski', 'przyp6', 'jedan; jednog; jednom; jedan; jednim; jednom', None),
    ('decl', 'Liczebniki', 'jedna (jedna): rodzaj żeński', 'przyp6', 'jedna; jedne; jednoj; jednu; jednom; jednoj', None),
    ('decl', 'Liczebniki', 'dva (dwa): męski i nijaki', 'przyp6', 'dva; dvaju; dvama; dva; dvama; dvama', 'W mowie potocznej 2–4 zwykle się nie odmienia; formy odmienione są książkowe.'),
    ('decl', 'Liczebniki', 'dve (dwie): żeński', 'przyp6', 'dve; dveju; dvema; dve; dvema; dvema', None),
    ('decl', 'Liczebniki', 'tri (trzy)', 'przyp6', 'tri; triju; trima; tri; trima; trima', None),
    ('form', 'Liczebniki', 'Liczebnik + rzeczownik: grad (miasto)', 'liczrz', 'jedan grad; dva grada; tri grada; četiri grada; pet gradova; jedanaest gradova; dvadeset jedan grad; dvadeset dva grada', 'Po 2–4: forma na -a. Od 5: dopełniacz lm. O formie decyduje ostatnie słowo liczebnika.'),
    ('form', 'Liczebniki', 'Liczebnik + rzeczownik: žena (kobieta)', 'liczrz', 'jedna žena; dve žene; tri žene; četiri žene; pet žena; jedanaest žena; dvadeset jedna žena; dvadeset dve žene', None),
    ('form', 'Typowe trudności', 'Fałszywi przyjaciele: co to znaczy?', 't_ff', 'słowo; litera; rok; godzina; prosto; duma; rano', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['___ li ti student?', 'Ja ___ student.', '— Jesi li student? — ___.', 'Ti ___ dobar.', '— Je li on ovde? — ___.', 'On ___ ovde.'],
    't_m1': ['Marko', 'Ana', 'brat', 'prijatelj', 'gospodin', 'majka', 'sestra', 'profesor'],
    't_m2': ['Ja ___ zovem Ana.', 'Zovem ___ Ana.', 'On ___ je video.', 'Video ___ je.', 'Ja ___ ga videti.', 'Videću ___.'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Krótka czy pełna forma „być”?', 't_m0', 'Jesi; sam; Jesam; si; Jeste; je', 'Formy krótkie stoją na drugim miejscu i nie mogą zaczynać zdania. Na początku i w krótkiej odpowiedzi używa się pełnych.'),
    ('form', 'Typowe trudności', 'Wołacz', 't_m1', 'Marko; Ana; brate; prijatelju; gospodine; majko; sestro; profesore', 'Imiona zwykle się nie zmieniają; rzeczowniki męskie dostają -e lub -u, żeńskie -o.'),
    ('form', 'Typowe trudności', 'Miejsce krótkich słów', 't_m2', 'se; se; me; me; ću; ga', 'Krótkie zaimki i formy czasownika stoją zaraz po pierwszym słowie zdania.'),
]

# Szyk zdania
PARADIGM_LABELS.update({
    't_s0': ['Dałem mu książkę.', 'Wczoraj go widziałem.', 'Nie widzę go.'],
})
PARADIGMS += [
    ('form', 'Szyk zdania', 'Szyk: krótkie słowa po pierwszym wyrazie', 't_s0', 'Dao sam mu knjigu.|Dao mu sam knjigu.|Sam mu dao knjigu.|Dao sam knjigu mu.; Juče sam ga video.|Juče ga sam video.|Juče video sam ga.|Sam ga juče video.; Ne vidim ga.|Ne ga vidim.|Ga ne vidim.|Vidim ga ne.', 'Krótkie zaimki i formy sam, si, je, ću stoją zaraz po pierwszym wyrazie lub zwrocie zdania.'),
]

# === PRONOUNS (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /PRONOUNS ===

# Pełne tłumaczenia zdań z ćwiczeń „Uzupełnij końcówkę” (gdy nie ma ich wśród zdań kursu)
ENDINGS_PL = {'moj brat': 'mój brat', 'mója séstra': 'moja siostra'}

# === STOPNIOWANIE (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('form', 'Stopniowanie', 'dobar (dobry)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'dobar; bolji; najbolji', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'velik (duży)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'velik; veći; najveći', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'mali (mały)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'mali; manji; najmanji', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'loš (zły)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'loš; gori; najgori', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'visok (wysoki)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'visok; viši; najviši', None),
    ('form', 'Stopniowanie', 'lep (piękny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'lep; lepši; najlepši', None),
    ('form', 'Stopniowanie', 'star (stary)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'star; stariji; najstariji', None),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /STOPNIOWANIE ===

# === GRAMATYKA 2 (generowane) ===
PARADIGMS += [
    ('form', 'Czas przeszły', 'biti: perfekat', ['já (m.)', 'já (ż.)', 'on', 'ona', 'my (m.)', 'oni (m.)'], 'bio sam; bila sam; bio je; bila je; bili smo; bili su', None),
    ('form', 'Czas przeszły', 'raditi: perfekat', ['já (m.)', 'já (ż.)', 'on', 'ona', 'my (m.)', 'oni (m.)'], 'radio sam; radila sam; radio je; radila je; radili smo; radili su', None),
    ('form', 'Czas przeszły', 'imati: perfekat', ['já (m.)', 'já (ż.)', 'on', 'ona', 'my (m.)', 'oni (m.)'], 'imao sam; imala sam; imao je; imala je; imali smo; imali su', None),
    ('form', 'Czas przyszły', 'raditi: futur I', ['ja', 'ti', 'on / ona', 'mi', 'vi', 'oni'], 'ću raditi; ćeš raditi; će raditi; ćemo raditi; ćete raditi; će raditi', 'Futur = krótka forma od „hteti” + bezokolicznik.'),
    ('form', 'Tryb warunkowy', 'raditi: potencijal', ['já (m.)', 'já (ż.)', 'on', 'ona', 'my (m.)', 'oni (m.)'], 'radio bih; radila bih; radio bi; radila bi; radili bismo; radili bi', None),
    ('conj', 'Czasowniki nieregularne', 'morati (musieć)', ['ja', 'ti', 'on / ona', 'mi', 'vi', 'oni'], 'moram; moraš; mora; moramo; morate; moraju', None),
    ('conj', 'Czasowniki nieregularne', 'znati (wiedzieć)', ['ja', 'ti', 'on / ona', 'mi', 'vi', 'oni'], 'znam; znaš; zna; znamo; znate; znaju', None),
    ('form', 'Vid (aspekt)', 'vid: robić', ['nesvršeni', 'svršeni'], 'raditi; uraditi', None),
    ('form', 'Vid (aspekt)', 'vid: pisać', ['nesvršeni', 'svršeni'], 'pisati; napisati', None),
    ('form', 'Vid (aspekt)', 'vid: czytać', ['nesvršeni', 'svršeni'], 'čitati; pročitati', None),
    ('form', 'Vid (aspekt)', 'vid: kupować', ['nesvršeni', 'svršeni'], 'kupovati; kupiti', None),
    ('form', 'Vid (aspekt)', 'vid: dawać', ['nesvršeni', 'svršeni'], 'davati; dati', None),
    ('form', 'Vid (aspekt)', 'vid: otwierać', ['nesvršeni', 'svršeni'], 'otvarati; otvoriti', None),
    ('form', 'Vid (aspekt)', 'vid: jeść', ['nesvršeni', 'svršeni'], 'jesti; pojesti', None),
    ('form', 'Vid (aspekt)', 'vid: pić', ['nesvršeni', 'svršeni'], 'piti; popiti', None),
    ('form', 'Vid (aspekt)', 'vid: brać', ['nesvršeni', 'svršeni'], 'uzimati; uzeti', None),
    ('form', 'Vid (aspekt)', 'vid: zaczynać', ['nesvršeni', 'svršeni'], 'počinjati; početi', None),
    ('form', 'Typowe trudności', 'Przyimek: jaki przypadek?', ['Idem u ___ (škola)', 'Ja sam u ___ (škola)', 'Idem kod ___ (drug)', 'Idem sa ___ (drug)', 'Pričam o ___ (drug)', 'Vidim ___ (drug)'], 'školu; školi; druga; drugom; drugu; druga', None),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /GRAMATYKA 2 ===

# === SŁOWNICTWO (generowane z langs/vocab, nie edytuj ręcznie) ===
UNITS += [{'id': 'v01a', 'title': 'Ludzie 1', 'icon': 'L', 'track': 'jezyk', 'words': [('muškarac', 'mężczyzna', None, 'rodzaj męski'), ('žena', 'kobieta', None, 'rodzaj żeński'), ('dete', 'dziecko', None, 'rodzaj nijaki'), ('dečak', 'chłopiec', None, 'rodzaj męski'), ('devojčica', 'dziewczynka', None, 'rodzaj żeński'), ('čovek', 'człowiek', None, 'rodzaj męski'), ('ljudi', 'ludzie', None, None), ('porodica', 'rodzina', None, 'rodzaj żeński'), ('majka', 'matka', None, 'rodzaj żeński'), ('otac', 'ojciec', None, 'rodzaj męski'), ('sin', 'syn', None, 'rodzaj męski'), ('ćerka', 'córka', None, 'rodzaj żeński'), ('sestra', 'siostra', None, 'rodzaj żeński'), ('deda', 'dziadek', None, 'rodzaj męski'), ('baka', 'babcia', None, 'rodzaj żeński'), ('unuk', 'wnuk', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01b', 'title': 'Ludzie 2', 'icon': 'L', 'track': 'jezyk', 'words': [('ujak', 'wujek', None, 'rodzaj męski'), ('tetka', 'ciocia', None, 'rodzaj żeński'), ('rođak', 'kuzyn', None, 'rodzaj męski'), ('muž', 'mąż', None, 'rodzaj męski'), ('supruga', 'żona', None, 'rodzaj żeński'), ('prijatelj', 'przyjaciel', None, 'rodzaj męski'), ('komšija', 'sąsiad', None, 'rodzaj męski'), ('gost', 'gość', None, 'rodzaj męski'), ('šef', 'szef', None, 'rodzaj męski'), ('kolega', 'kolega', None, 'rodzaj męski'), ('neprijatelj', 'wróg', None, 'rodzaj męski'), ('kralj', 'król', None, 'rodzaj męski'), ('kraljica', 'królowa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v02a', 'title': 'Ciało 1', 'icon': 'C', 'track': 'jezyk', 'words': [('glava', 'głowa', None, 'rodzaj żeński'), ('lice', 'twarz', None, 'rodzaj nijaki'), ('oko', 'oko', None, 'rodzaj nijaki'), ('uvo', 'ucho', None, 'rodzaj nijaki'), ('nos', 'nos', None, 'rodzaj męski'), ('usta', 'usta', None, None), ('zub', 'ząb', None, 'rodzaj męski'), ('jezik', 'język (narząd)', None, 'rodzaj męski'), ('kosa', 'włosy', None, 'rodzaj żeński'), ('vrat', 'szyja', None, 'rodzaj męski'), ('rame', 'ramię', None, 'rodzaj nijaki'), ('ruka', 'ręka', None, 'rodzaj żeński'), ('prst', 'palec', None, 'rodzaj męski'), ('noga', 'noga', None, 'rodzaj żeński'), ('stopalo', 'stopa', None, 'rodzaj nijaki'), ('koleno', 'kolano', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v02b', 'title': 'Ciało 2', 'icon': 'C', 'track': 'jezyk', 'words': [('leđa', 'plecy', None, None), ('stomak', 'brzuch', None, 'rodzaj męski'), ('srce', 'serce', None, 'rodzaj nijaki'), ('krv', 'krew', None, 'rodzaj żeński'), ('kost', 'kość', None, 'rodzaj żeński'), ('koža', 'skóra', None, 'rodzaj żeński'), ('glas', 'głos', None, 'rodzaj męski'), ('telo', 'ciało', None, 'rodzaj nijaki'), ('želudac', 'żołądek', None, 'rodzaj męski'), ('brada', 'broda', None, 'rodzaj żeński'), ('usna', 'warga', None, 'rodzaj żeński'), ('nokat', 'paznokieć', None, 'rodzaj męski'), ('grudi', 'pierś', None, None), ('mozak', 'mózg', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03a', 'title': 'Jedzenie 1', 'icon': 'J', 'track': 'jezyk', 'words': [('puter', 'masło', None, 'rodzaj męski'), ('mleko', 'mleko', None, 'rodzaj nijaki'), ('jaje', 'jajko', None, 'rodzaj nijaki'), ('meso', 'mięso', None, 'rodzaj nijaki'), ('riba', 'ryba', None, 'rodzaj żeński'), ('piletina', 'kurczak', None, 'rodzaj żeński'), ('svinjetina', 'wieprzowina', None, 'rodzaj żeński'), ('supa', 'zupa', None, 'rodzaj żeński'), ('salata', 'sałatka', None, 'rodzaj żeński'), ('pirinač', 'ryż', None, 'rodzaj męski'), ('testenina', 'makaron', None, 'rodzaj żeński'), ('krompir', 'ziemniak', None, 'rodzaj męski'), ('šargarepa', 'marchewka', None, 'rodzaj żeński'), ('luk', 'cebula', None, 'rodzaj męski'), ('beli luk', 'czosnek', None, 'rodzaj męski'), ('paradajz', 'pomidor', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03b', 'title': 'Jedzenie 2', 'icon': 'J', 'track': 'jezyk', 'words': [('krastavac', 'ogórek', None, 'rodzaj męski'), ('jabuka', 'jabłko', None, 'rodzaj żeński'), ('kruška', 'gruszka', None, 'rodzaj żeński'), ('banana', 'banan', None, 'rodzaj żeński'), ('pomorandža', 'pomarańcza', None, 'rodzaj żeński'), ('limun', 'cytryna', None, 'rodzaj męski'), ('jagoda', 'truskawka', None, 'rodzaj żeński'), ('grožđe', 'winogrono', None, 'rodzaj nijaki'), ('šećer', 'cukier', None, 'rodzaj męski'), ('so', 'sól', None, 'rodzaj żeński'), ('biber', 'pieprz', None, 'rodzaj męski'), ('ulje', 'olej', None, 'rodzaj nijaki'), ('brašno', 'mąka', None, 'rodzaj nijaki'), ('med', 'miód', None, 'rodzaj męski'), ('čokolada', 'czekolada', None, 'rodzaj żeński'), ('sladoled', 'lody', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03c', 'title': 'Jedzenie 3', 'icon': 'J', 'track': 'jezyk', 'words': [('torta', 'ciasto (tort)', None, 'rodzaj żeński'), ('keks', 'ciastko', None, 'rodzaj męski'), ('doručak', 'śniadanie', None, 'rodzaj męski'), ('ručak', 'obiad', None, 'rodzaj męski'), ('večera', 'kolacja', None, 'rodzaj żeński'), ('užina', 'przekąska', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v04a', 'title': 'Napoje i restauracja 1', 'icon': 'N', 'track': 'jezyk', 'words': [('voda', 'woda', None, 'rodzaj żeński'), ('sok', 'sok', None, 'rodzaj męski'), ('kafa', 'kawa', None, 'rodzaj żeński'), ('pivo', 'piwo', None, 'rodzaj nijaki'), ('vino', 'wino', None, 'rodzaj nijaki'), ('piće', 'napój', None, 'rodzaj nijaki'), ('čaša', 'szklanka', None, 'rodzaj żeński'), ('šolja', 'filiżanka', None, 'rodzaj żeński'), ('tanjir', 'talerz', None, 'rodzaj męski'), ('nož', 'nóż', None, 'rodzaj męski'), ('viljuška', 'widelec', None, 'rodzaj żeński'), ('kašika', 'łyżka', None, 'rodzaj żeński'), ('flaša', 'butelka', None, 'rodzaj żeński'), ('jelovnik', 'menu', None, 'rodzaj męski'), ('račun', 'rachunek', None, 'rodzaj męski'), ('bakšiš', 'napiwek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04b', 'title': 'Napoje i restauracja 2', 'icon': 'N', 'track': 'jezyk', 'words': [('sto (w restauracji)', 'stolik', None, 'rodzaj męski'), ('konobar', 'kelner', None, 'rodzaj męski'), ('kuvar', 'kucharz', None, 'rodzaj męski'), ('gladan', 'głodny', None, None), ('žedan', 'spragniony', None, None), ('ukusan', 'smaczny', None, None)], 'sentences': []}, {'id': 'v05a', 'title': 'Dom 1', 'icon': 'D', 'track': 'jezyk', 'words': [('kuća', 'dom', None, 'rodzaj żeński'), ('stan', 'mieszkanie', None, 'rodzaj męski'), ('soba', 'pokój', None, 'rodzaj żeński'), ('kuhinja', 'kuchnia', None, 'rodzaj żeński'), ('kupatilo', 'łazienka', None, 'rodzaj nijaki'), ('spavaća soba', 'sypialnia', None, 'rodzaj żeński'), ('dnevna soba', 'salon', None, 'rodzaj żeński'), ('bašta', 'ogród', None, 'rodzaj żeński'), ('vrata', 'drzwi', None, None), ('prozor', 'okno', None, 'rodzaj męski'), ('zid', 'ściana', None, 'rodzaj męski'), ('pod', 'podłoga', None, 'rodzaj męski'), ('krov', 'dach', None, 'rodzaj męski'), ('stepenice', 'schody', None, None), ('ključ', 'klucz', None, 'rodzaj męski'), ('sto', 'stół', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v05b', 'title': 'Dom 2', 'icon': 'D', 'track': 'jezyk', 'words': [('stolica', 'krzesło', None, 'rodzaj żeński'), ('krevet', 'łóżko', None, 'rodzaj męski'), ('orman', 'szafa', None, 'rodzaj męski'), ('lampa', 'lampa', None, 'rodzaj żeński'), ('tepih', 'dywan', None, 'rodzaj męski'), ('ogledalo', 'lustro', None, 'rodzaj nijaki'), ('televizor', 'telewizor', None, 'rodzaj męski'), ('telefon', 'telefon', None, 'rodzaj męski'), ('računar', 'komputer', None, 'rodzaj męski'), ('sat', 'zegar', None, 'rodzaj męski'), ('jastuk', 'poduszka', None, 'rodzaj męski'), ('ćebe', 'koc', None, 'rodzaj nijaki'), ('peškir', 'ręcznik', None, 'rodzaj męski'), ('sapun', 'mydło', None, 'rodzaj męski'), ('četkica za zube', 'szczoteczka do zębów', None, 'rodzaj żeński'), ('frižider', 'lodówka', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v05c', 'title': 'Dom 3', 'icon': 'D', 'track': 'jezyk', 'words': [('peć', 'piec', None, 'rodzaj żeński'), ('veš-mašina', 'pralka', None, 'rodzaj żeński'), ('đubre', 'śmieci', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v06a', 'title': 'Ubrania 1', 'icon': 'U', 'track': 'jezyk', 'words': [('odeća', 'ubranie', None, 'rodzaj żeński'), ('košulja', 'koszula', None, 'rodzaj żeński'), ('pantalone', 'spodnie', None, None), ('haljina', 'sukienka', None, 'rodzaj żeński'), ('suknja', 'spódnica', None, 'rodzaj żeński'), ('jakna', 'kurtka', None, 'rodzaj żeński'), ('kaput', 'płaszcz', None, 'rodzaj męski'), ('džemper', 'sweter', None, 'rodzaj męski'), ('cipele', 'buty', None, None), ('čarape', 'skarpetki', None, None), ('kapa', 'czapka', None, 'rodzaj żeński'), ('šešir', 'kapelusz', None, 'rodzaj męski'), ('rukavice', 'rękawiczki', None, None), ('šal', 'szalik', None, 'rodzaj męski'), ('torba', 'torba', None, 'rodzaj żeński'), ('ranac', 'plecak', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v06b', 'title': 'Ubrania 2', 'icon': 'U', 'track': 'jezyk', 'words': [('novčanik', 'portfel', None, 'rodzaj męski'), ('naočare', 'okulary', None, None), ('ručni sat', 'zegarek', None, 'rodzaj męski'), ('prsten', 'pierścionek', None, 'rodzaj męski'), ('donje rublje', 'bielizna', None, 'rodzaj nijaki'), ('pidžama', 'piżama', None, 'rodzaj żeński'), ('kaiš', 'pasek', None, 'rodzaj męski'), ('kravata', 'krawat', None, 'rodzaj żeński'), ('odelo', 'garnitur', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v07a', 'title': 'Kolory i kształty 1', 'icon': 'K', 'track': 'jezyk', 'words': [('crven', 'czerwony', None, None), ('plav', 'niebieski', None, None), ('zelen', 'zielony', None, None), ('žut', 'żółty', None, None), ('crn', 'czarny', None, None), ('beo', 'biały', None, None), ('siv', 'szary', None, None), ('braon', 'brązowy', None, None), ('roze', 'różowy', None, None), ('ljubičast', 'fioletowy', None, None), ('boja', 'kolor', None, 'rodzaj żeński'), ('okrugao', 'okrągły', None, None), ('kvadratni', 'kwadratowy', None, None), ('ravan', 'prosty', None, None), ('kriv', 'krzywy', None, None), ('linija', 'linia', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v07b', 'title': 'Kolory i kształty 2', 'icon': 'K', 'track': 'jezyk', 'words': [('tačka', 'punkt', None, 'rodzaj żeński'), ('krug', 'koło', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v08a', 'title': 'Liczby i ilości 1', 'icon': 'L', 'track': 'jezyk', 'words': [('nula', 'zero', None, None), ('jedanaest', 'jedenaście', None, None), ('dvanaest', 'dwanaście', None, None), ('trinaest', 'trzynaście', None, None), ('četrnaest', 'czternaście', None, None), ('petnaest', 'piętnaście', None, None), ('šesnaest', 'szesnaście', None, None), ('sedamnaest', 'siedemnaście', None, None), ('osamnaest', 'osiemnaście', None, None), ('devetnaest', 'dziewiętnaście', None, None), ('dvadeset', 'dwadzieścia', None, None), ('trideset', 'trzydzieści', None, None), ('četrdeset', 'czterdzieści', None, None), ('pedeset', 'pięćdziesiąt', None, None), ('šezdeset', 'sześćdziesiąt', None, None), ('sedamdeset', 'siedemdziesiąt', None, None)], 'sentences': []}, {'id': 'v08b', 'title': 'Liczby i ilości 2', 'icon': 'L', 'track': 'jezyk', 'words': [('osamdeset', 'osiemdziesiąt', None, None), ('devedeset', 'dziewięćdziesiąt', None, None), ('hiljada', 'tysiąc', None, None), ('milion', 'milion', None, None), ('prvi', 'pierwszy', None, None), ('drugi', 'drugi', None, None), ('treći', 'trzeci', None, None), ('polovina', 'połowa', None, 'rodzaj żeński'), ('par', 'para', None, 'rodzaj męski'), ('nekoliko', 'kilka', None, None), ('mnogo', 'wiele', None, None), ('malo', 'mało', None, None), ('ceo', 'cały', None, None)], 'sentences': []}, {'id': 'v09a', 'title': 'Czas 1', 'icon': 'C', 'track': 'jezyk', 'words': [('sekunda', 'sekunda', None, 'rodzaj żeński'), ('minut', 'minuta', None, 'rodzaj męski'), ('čas', 'godzina', None, 'rodzaj męski'), ('nedelja (tydzień)', 'tydzień', None, 'rodzaj żeński'), ('mesec', 'miesiąc', None, 'rodzaj męski'), ('godina', 'rok', None, 'rodzaj żeński'), ('proleće', 'wiosna', None, 'rodzaj nijaki'), ('leto', 'lato', None, 'rodzaj nijaki'), ('jesen', 'jesień', None, 'rodzaj żeński'), ('zima', 'zima', None, 'rodzaj żeński'), ('ponedeljak', 'poniedziałek', None, 'rodzaj męski'), ('utorak', 'wtorek', None, 'rodzaj męski'), ('sreda', 'środa', None, 'rodzaj żeński'), ('četvrtak', 'czwartek', None, 'rodzaj męski'), ('petak', 'piątek', None, 'rodzaj męski'), ('subota', 'sobota', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v09b', 'title': 'Czas 2', 'icon': 'C', 'track': 'jezyk', 'words': [('nedelja', 'niedziela', None, 'rodzaj żeński'), ('januar', 'styczeń', None, 'rodzaj męski'), ('februar', 'luty', None, 'rodzaj męski'), ('mart', 'marzec', None, 'rodzaj męski'), ('april', 'kwiecień', None, 'rodzaj męski'), ('maj', 'maj', None, 'rodzaj męski'), ('jun', 'czerwiec', None, 'rodzaj męski'), ('jul', 'lipiec', None, 'rodzaj męski'), ('avgust', 'sierpień', None, 'rodzaj męski'), ('septembar', 'wrzesień', None, 'rodzaj męski'), ('oktobar', 'październik', None, 'rodzaj męski'), ('novembar', 'listopad', None, 'rodzaj męski'), ('decembar', 'grudzień', None, 'rodzaj męski'), ('jutro', 'rano (pora dnia)', None, 'rodzaj nijaki'), ('podne', 'południe', None, 'rodzaj nijaki'), ('uveče', 'wieczorem', None, None)], 'sentences': []}, {'id': 'v09c', 'title': 'Czas 3', 'icon': 'C', 'track': 'jezyk', 'words': [('uvek', 'zawsze', None, None), ('nikad', 'nigdy', None, None), ('ponekad', 'czasem', None, None), ('često', 'często', None, None), ('već', 'już', None, None), ('još', 'jeszcze', None, None), ('uskoro', 'wkrótce', None, None), ('kasnije', 'później', None, None), ('rano', 'wcześnie', None, None), ('kasno', 'późno', None, None), ('kada', 'kiedy (pytanie)', None, None), ('datum', 'data', None, 'rodzaj męski'), ('prošlost', 'przeszłość', None, 'rodzaj żeński'), ('budućnost', 'przyszłość', None, 'rodzaj żeński'), ('rođendan', 'urodziny', None, 'rodzaj męski'), ('praznik', 'święto', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v09d', 'title': 'Czas 4', 'icon': 'C', 'track': 'jezyk', 'words': [('odmor', 'wakacje', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10a', 'title': 'Natura i pogoda 1', 'icon': 'N', 'track': 'jezyk', 'words': [('sunce', 'słońce', None, 'rodzaj nijaki'), ('mesec (ciało niebieskie)', 'księżyc', None, 'rodzaj męski'), ('zvezda', 'gwiazda', None, 'rodzaj żeński'), ('nebo', 'niebo', None, 'rodzaj nijaki'), ('oblak', 'chmura', None, 'rodzaj męski'), ('kiša', 'deszcz', None, 'rodzaj żeński'), ('sneg', 'śnieg', None, 'rodzaj męski'), ('vetar', 'wiatr', None, 'rodzaj męski'), ('oluja', 'burza', None, 'rodzaj żeński'), ('magla', 'mgła', None, 'rodzaj żeński'), ('led', 'lód', None, 'rodzaj męski'), ('vatra', 'ogień', None, None), ('zemlja', 'grunt)', None, 'rodzaj żeński'), ('more', 'morze', None, 'rodzaj nijaki'), ('reka', 'rzeka', None, 'rodzaj żeński'), ('jezero', 'jezioro', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v10b', 'title': 'Natura i pogoda 2', 'icon': 'N', 'track': 'jezyk', 'words': [('planina', 'góra', None, 'rodzaj żeński'), ('šuma', 'las', None, 'rodzaj żeński'), ('drvo', 'drzewo', None, 'rodzaj nijaki'), ('cvet', 'kwiat', None, 'rodzaj męski'), ('trava', 'trawa', None, 'rodzaj żeński'), ('list', 'liść', None, 'rodzaj męski'), ('polje', 'pole', None, 'rodzaj nijaki'), ('ostrvo', 'wyspa', None, 'rodzaj nijaki'), ('plaža', 'plaża', None, 'rodzaj żeński'), ('pustinja', 'pustynia', None, 'rodzaj żeński'), ('stena', 'skała', None, 'rodzaj żeński'), ('kamen', 'kamień', None, 'rodzaj męski'), ('vreme', 'pogoda', None, 'rodzaj nijaki'), ('temperatura', 'temperatura', None, 'rodzaj żeński'), ('hladan', 'zimny', None, None), ('topao', 'ciepły', None, None)], 'sentences': []}, {'id': 'v10c', 'title': 'Natura i pogoda 3', 'icon': 'N', 'track': 'jezyk', 'words': [('vruć', 'gorący', None, None)], 'sentences': []}, {'id': 'v11a', 'title': 'Zwierzęta 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('pas', 'pies', None, 'rodzaj męski'), ('mačka', 'kot', None, 'rodzaj żeński'), ('konj', 'koń', None, 'rodzaj męski'), ('krava', 'krowa', None, 'rodzaj żeński'), ('svinja', 'świnia', None, 'rodzaj żeński'), ('ovca', 'owca', None, 'rodzaj żeński'), ('koza', 'koza', None, 'rodzaj żeński'), ('kokoška', 'kura', None, 'rodzaj żeński'), ('patka', 'kaczka', None, 'rodzaj żeński'), ('ptica', 'ptak', None, 'rodzaj żeński'), ('miš', 'mysz', None, 'rodzaj męski'), ('pacov', 'szczur', None, 'rodzaj męski'), ('zmija', 'wąż', None, 'rodzaj żeński'), ('žaba', 'żaba', None, 'rodzaj żeński'), ('lav', 'lew', None, 'rodzaj męski'), ('tigar', 'tygrys', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11b', 'title': 'Zwierzęta 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('slon', 'słoń', None, 'rodzaj męski'), ('medved', 'niedźwiedź', None, 'rodzaj męski'), ('vuk', 'wilk', None, 'rodzaj męski'), ('lisica', 'lis', None, 'rodzaj żeński'), ('zec', 'zając', None, 'rodzaj męski'), ('jelen', 'jeleń', None, 'rodzaj męski'), ('majmun', 'małpa', None, 'rodzaj męski'), ('leptir', 'motyl', None, 'rodzaj męski'), ('pčela', 'pszczoła', None, 'rodzaj żeński'), ('muva', 'mucha', None, 'rodzaj żeński'), ('pauk', 'pająk', None, 'rodzaj męski'), ('životinja', 'zwierzę', None, 'rodzaj żeński'), ('insekt', 'owad', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v12a', 'title': 'Miasto 1', 'icon': 'M', 'track': 'jezyk', 'words': [('selo', 'wieś', None, 'rodzaj nijaki'), ('ulica', 'ulica', None, 'rodzaj żeński'), ('put', 'droga', None, 'rodzaj męski'), ('trg', 'plac', None, 'rodzaj męski'), ('most', 'most', None, 'rodzaj męski'), ('park', 'park', None, 'rodzaj męski'), ('prodavnica', 'sklep', None, 'rodzaj żeński'), ('pijaca', 'targ', None, 'rodzaj żeński'), ('supermarket', 'supermarket', None, 'rodzaj męski'), ('banka', 'bank', None, 'rodzaj żeński'), ('pošta', 'poczta', None, 'rodzaj żeński'), ('bolnica', 'szpital', None, 'rodzaj żeński'), ('apoteka', 'apteka', None, 'rodzaj żeński'), ('univerzitet', 'uniwersytet', None, 'rodzaj męski'), ('biblioteka', 'biblioteka', None, 'rodzaj żeński'), ('muzej', 'muzeum', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v12b', 'title': 'Miasto 2', 'icon': 'M', 'track': 'jezyk', 'words': [('crkva', 'kościół', None, 'rodzaj żeński'), ('restoran', 'restauracja', None, 'rodzaj męski'), ('kafić', 'kawiarnia', None, 'rodzaj męski'), ('aerodrom', 'lotnisko', None, 'rodzaj męski'), ('stanica', 'dworzec', None, 'rodzaj żeński'), ('stajalište', 'przystanek', None, 'rodzaj nijaki'), ('bioskop', 'kino', None, 'rodzaj męski'), ('pozorište', 'teatr', None, 'rodzaj nijaki'), ('policija', 'policja', None, 'rodzaj żeński'), ('kancelarija', 'biuro', None, 'rodzaj żeński'), ('fabrika', 'fabryka', None, 'rodzaj żeński'), ('zgrada', 'budynek', None, 'rodzaj żeński'), ('toranj', 'wieża', None, 'rodzaj męski'), ('centar', 'centrum', None, 'rodzaj męski'), ('adresa', 'adres', None, 'rodzaj żeński'), ('mapa', 'mapa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13a', 'title': 'Transport i podróż 1', 'icon': 'T', 'track': 'jezyk', 'words': [('automobil', 'samochód', None, 'rodzaj męski'), ('autobus', 'autobus', None, 'rodzaj męski'), ('voz', 'pociąg', None, 'rodzaj męski'), ('tramvaj', 'tramwaj', None, 'rodzaj męski'), ('metro', 'metro', None, 'rodzaj męski'), ('avion', 'samolot', None, 'rodzaj męski'), ('brod', 'statek', None, 'rodzaj męski'), ('bicikl', 'rower', None, 'rodzaj męski'), ('motor', 'motocykl', None, 'rodzaj męski'), ('taksi', 'taksówka', None, 'rodzaj męski'), ('karta', 'bilet', None, 'rodzaj żeński'), ('putovanje', 'podróż', None, 'rodzaj nijaki'), ('izlet', 'wycieczka', None, 'rodzaj męski'), ('pasoš', 'paszport', None, 'rodzaj męski'), ('kofer', 'walizka', None, 'rodzaj męski'), ('benzin', 'benzyna', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13b', 'title': 'Transport i podróż 2', 'icon': 'T', 'track': 'jezyk', 'words': [('parking', 'parking', None, 'rodzaj męski'), ('raskrsnica', 'skrzyżowanie', None, 'rodzaj żeński'), ('semafor', 'światła', None, 'rodzaj męski'), ('vozačka dozvola', 'prawo jazdy', None, 'rodzaj żeński'), ('vozač', 'kierowca', None, 'rodzaj męski'), ('putnik', 'pasażer', None, 'rodzaj męski'), ('ulaz', 'wjazd', None, 'rodzaj męski'), ('izlaz', 'wyjazd', None, 'rodzaj męski'), ('železnica', 'kolej', None, 'rodzaj żeński'), ('luka', 'port', None, 'rodzaj żeński'), ('granica', 'granica', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v14a', 'title': 'Praca i szkoła 1', 'icon': 'P', 'track': 'jezyk', 'words': [('posao', 'praca', None, 'rodzaj męski'), ('zanimanje', 'zawód', None, 'rodzaj nijaki'), ('lekar', 'lekarz', None, 'rodzaj męski'), ('medicinska sestra', 'pielęgniarka', None, 'rodzaj żeński'), ('učitelj', 'nauczyciel', None, 'rodzaj męski'), ('učenik', 'uczeń', None, 'rodzaj męski'), ('student', 'student', None, 'rodzaj męski'), ('inženjer', 'inżynier', None, 'rodzaj męski'), ('pravnik', 'prawnik', None, 'rodzaj męski'), ('policajac', 'policjant', None, 'rodzaj męski'), ('vojnik', 'żołnierz', None, 'rodzaj męski'), ('seljak', 'rolnik', None, 'rodzaj męski'), ('prodavac', 'sprzedawca', None, 'rodzaj męski'), ('blagajnik', 'kasjer', None, 'rodzaj męski'), ('glumac', 'aktor', None, 'rodzaj męski'), ('pisac', 'pisarz', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v14b', 'title': 'Praca i szkoła 2', 'icon': 'P', 'track': 'jezyk', 'words': [('slikar', 'malarz', None, 'rodzaj męski'), ('muzičar', 'muzyk', None, 'rodzaj męski'), ('umetnik', 'artysta', None, 'rodzaj męski'), ('firma', 'firma', None, 'rodzaj żeński'), ('novac', 'pieniądze', None, 'rodzaj męski'), ('plata', 'pensja', None, 'rodzaj żeński'), ('ugovor', 'umowa', None, 'rodzaj męski'), ('sastanak', 'spotkanie', None, 'rodzaj męski'), ('lekcija', 'lekcja', None, 'rodzaj żeński'), ('ispit', 'egzamin', None, 'rodzaj męski'), ('ocena', 'ocena', None, 'rodzaj żeński'), ('razred', 'klasa', None, 'rodzaj męski'), ('knjiga', 'książka', None, 'rodzaj żeński'), ('sveska', 'zeszyt', None, 'rodzaj żeński'), ('hemijska olovka', 'długopis', None, 'rodzaj żeński'), ('olovka', 'ołówek', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v14c', 'title': 'Praca i szkoła 3', 'icon': 'P', 'track': 'jezyk', 'words': [('papir', 'papier', None, 'rodzaj męski'), ('tabla', 'tablica', None, 'rodzaj żeński'), ('rečnik', 'słownik', None, 'rodzaj męski'), ('pitanje', 'pytanie', None, 'rodzaj nijaki'), ('odgovor', 'odpowiedź', None, 'rodzaj męski'), ('zadatak', 'zadanie', None, 'rodzaj męski'), ('test', 'test', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v15a', 'title': 'Pieniądze i zakupy 1', 'icon': 'P', 'track': 'jezyk', 'words': [('cena', 'cena', None, 'rodzaj żeński'), ('platna kartica', 'karta (płatnicza)', None, 'rodzaj żeński'), ('gotovina', 'gotówka', None, 'rodzaj żeński'), ('novčić', 'moneta', None, 'rodzaj męski'), ('novčanica', 'banknot', None, 'rodzaj żeński'), ('kusur', 'reszta', None, 'rodzaj męski'), ('popust', 'zniżka', None, 'rodzaj męski'), ('korpa', 'koszyk', None, 'rodzaj żeński'), ('račun (paragon)', 'paragon', None, 'rodzaj męski'), ('roba', 'towar', None, 'rodzaj żeński'), ('kupovina', 'zakup', None, 'rodzaj żeński'), ('prodaja', 'sprzedaż', None, 'rodzaj żeński'), ('vrednost', 'wartość', None, 'rodzaj żeński'), ('kredit', 'kredyt', None, 'rodzaj męski'), ('dug', 'dług', None, 'rodzaj męski'), ('porez', 'podatek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v15b', 'title': 'Pieniądze i zakupy 2', 'icon': 'P', 'track': 'jezyk', 'words': [('bogatstvo', 'bogactwo', None, 'rodzaj nijaki'), ('siromašan', 'biedny', None, None), ('bogat', 'bogaty', None, None)], 'sentences': []}, {'id': 'v16a', 'title': 'Zdrowie 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('zdravlje', 'zdrowie', None, 'rodzaj nijaki'), ('bolest', 'choroba', None, 'rodzaj żeński'), ('bol', 'ból', None, 'rodzaj męski'), ('groznica', 'gorączka', None, 'rodzaj żeński'), ('kašalj', 'kaszel', None, 'rodzaj męski'), ('kijavica', 'katar', None, 'rodzaj żeński'), ('lek', 'lekarstwo', None, 'rodzaj męski'), ('tableta', 'tabletka', None, 'rodzaj żeński'), ('operacija', 'operacja', None, 'rodzaj żeński'), ('rana', 'rana', None, 'rodzaj żeński'), ('nesreća', 'wypadek', None, 'rodzaj żeński'), ('zdrav', 'zdrowy', None, None), ('bolestan', 'chory', None, None), ('umoran', 'zmęczony', None, None), ('pospan', 'śpiący', None, None), ('jak', 'silny', None, None)], 'sentences': []}, {'id': 'v16b', 'title': 'Zdrowie 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('slab', 'słaby', None, None)], 'sentences': []}, {'id': 'v17a', 'title': 'Uczucia i charakter 1', 'icon': 'U', 'track': 'jezyk', 'words': [('radost', 'radość', None, 'rodzaj żeński'), ('tuga', 'smutek', None, 'rodzaj żeński'), ('strah', 'strach', None, 'rodzaj męski'), ('bes', 'gniew', None, 'rodzaj męski'), ('ljubav', 'miłość', None, 'rodzaj żeński'), ('mržnja', 'nienawiść', None, 'rodzaj żeński'), ('nada', 'nadzieja', None, 'rodzaj żeński'), ('san (marzenie)', 'marzenie', None, 'rodzaj męski'), ('sreća', 'szczęście', None, 'rodzaj żeński'), ('stid', 'wstyd', None, 'rodzaj męski'), ('iznenađenje', 'zdziwienie', None, 'rodzaj nijaki'), ('radoznalost', 'ciekawość', None, 'rodzaj żeński'), ('strpljenje', 'cierpliwość', None, 'rodzaj nijaki'), ('hrabrost', 'odwaga', None, 'rodzaj żeński'), ('iskren', 'szczery', None, None), ('ljubazan', 'miły', None, None)], 'sentences': []}, {'id': 'v17b', 'title': 'Uczucia i charakter 2', 'icon': 'U', 'track': 'jezyk', 'words': [('učtiv', 'grzeczny', None, None), ('glup', 'głupi', None, None), ('pametan', 'mądry', None, None), ('lenj', 'leniwy', None, None), ('vredan', 'pracowity', None, None), ('zanimljiv', 'ciekawy', None, None), ('dosadan', 'nudny', None, None), ('veseo', 'wesoły', None, None), ('tužan', 'smutny', None, None), ('ljut', 'zły (rozgniewany)', None, None), ('srećan', 'szczęśliwy', None, None), ('zaljubljen', 'zakochany', None, None), ('usamljen', 'samotny', None, None), ('miran', 'spokojny', None, None)], 'sentences': []}, {'id': 'v18a', 'title': 'Przymiotniki 1', 'icon': 'P', 'track': 'jezyk', 'words': [('velik', 'duży', None, None), ('mali', 'mały', None, None), ('dugačak', 'długi', None, None), ('kratak', 'krótki', None, None), ('visok', 'wysoki', None, None), ('nizak', 'niski', None, None), ('širok', 'szeroki', None, None), ('uzak', 'wąski', None, None), ('debeo', 'gruby', None, None), ('mršav', 'chudy', None, None), ('težak', 'ciężki', None, None), ('lak', 'lekki', None, None), ('brz', 'szybki', None, None), ('spor', 'wolny', None, None), ('tvrd', 'twardy', None, None), ('mekan', 'miękki', None, None)], 'sentences': []}, {'id': 'v18b', 'title': 'Przymiotniki 2', 'icon': 'P', 'track': 'jezyk', 'words': [('mokar', 'mokry', None, None), ('suv', 'suchy', None, None), ('čist', 'czysty', None, None), ('prljav', 'brudny', None, None), ('pun', 'pełny', None, None), ('prazan', 'pusty', None, None), ('oštar', 'ostry', None, None), ('glasan', 'głośny', None, None), ('tih', 'cichy', None, None), ('svetao', 'jasny', None, None), ('taman', 'ciemny', None, None), ('mlad', 'młody', None, None), ('star', 'stary', None, None), ('nov', 'nowy', None, None), ('dobar', 'dobry', None, None), ('loš', 'zły (niedobry)', None, None)], 'sentences': []}, {'id': 'v18c', 'title': 'Przymiotniki 3', 'icon': 'P', 'track': 'jezyk', 'words': [('lep', 'ładny', None, None), ('ružan', 'brzydki', None, None), ('lak (łatwy)', 'łatwy', None, None), ('težak (trudny)', 'trudny', None, None), ('važan', 'ważny', None, None), ('moguć', 'możliwy', None, None), ('istinit', 'prawdziwy', None, None), ('lažan', 'fałszywy', None, None), ('skup', 'drogi', None, None), ('jeftin', 'tani', None, None)], 'sentences': []}, {'id': 'v19a', 'title': 'Czasowniki podstawowe 1', 'icon': 'C', 'track': 'jezyk', 'words': [('biti', 'być', None, None), ('imati', 'mieć', None, None), ('raditi', 'robić', None, None), ('ići', 'iść', None, None), ('voziti se', 'jechać', None, None), ('doći', 'przyjść', None, None), ('izaći', 'wyjść', None, None), ('ući', 'wejść', None, None), ('vratiti se', 'wrócić', None, None), ('trčati', 'biec', None, None), ('stajati', 'stać', None, None), ('sedeti', 'siedzieć', None, None), ('ležati', 'leżeć', None, None), ('spavati', 'spać', None, None), ('ustati', 'wstać', None, None), ('jesti', 'jeść', None, None)], 'sentences': []}, {'id': 'v19b', 'title': 'Czasowniki podstawowe 2', 'icon': 'C', 'track': 'jezyk', 'words': [('piti', 'pić', None, None), ('kuvati', 'gotować', None, None), ('prati', 'myć', None, None), ('oblačiti se', 'ubierać się', None, None), ('govoriti', 'mówić', None, None), ('reći', 'powiedzieć', None, None), ('pitati', 'pytać', None, None), ('odgovarati', 'odpowiadać', None, None), ('čuti', 'słyszeć', None, None), ('slušati', 'słuchać', None, None), ('videti', 'widzieć', None, None), ('gledati', 'patrzeć', None, None), ('čitati', 'czytać', None, None), ('pisati', 'pisać', None, None), ('učiti', 'uczyć się', None, None), ('podučavati', 'uczyć (kogoś)', None, None)], 'sentences': []}, {'id': 'v19c', 'title': 'Czasowniki podstawowe 3', 'icon': 'C', 'track': 'jezyk', 'words': [('razumeti', 'rozumieć', None, None), ('znati', 'wiedzieć', None, None), ('poznavati', 'znać', None, None), ('misliti', 'myśleć', None, None), ('pamtiti', 'pamiętać', None, None), ('zaboravljati', 'zapominać', None, None), ('hteti', 'chcieć', None, None), ('voleti', 'lubić', None, None), ('ljubiti', 'kochać', None, None), ('trebati', 'potrzebować', None, None), ('moći', 'móc', None, None), ('morati', 'musieć', None, None), ('davati', 'dawać', None, None), ('uzimati', 'brać', None, None), ('kupovati', 'kupować', None, None), ('prodavati', 'sprzedawać', None, None)], 'sentences': []}, {'id': 'v19d', 'title': 'Czasowniki podstawowe 4', 'icon': 'C', 'track': 'jezyk', 'words': [('plaćati', 'płacić', None, None), ('otvarati', 'otwierać', None, None), ('zatvarati', 'zamykać', None, None), ('počinjati', 'zaczynać', None, None), ('završavati', 'kończyć', None, None), ('raditi (pracować)', 'pracować', None, None), ('igrati', 'grać', None, None), ('pevati', 'śpiewać', None, None), ('plesati', 'tańczyć', None, None), ('plivati', 'pływać', None, None), ('letati', 'latać', None, None), ('stavljati', 'kłaść', None, None), ('tražiti', 'szukać', None, None), ('nalaziti', 'znajdować', None, None), ('čekati', 'czekać', None, None), ('pomagati', 'pomagać', None, None)], 'sentences': []}, {'id': 'v19e', 'title': 'Czasowniki podstawowe 5', 'icon': 'C', 'track': 'jezyk', 'words': [('moliti', 'prosić', None, None), ('izvinjavati se', 'przepraszać', None, None), ('dozvoljavati', 'pozwalać', None, None), ('pokušavati', 'próbować', None, None), ('menjati', 'zmieniać', None, None), ('nositi', 'nosić', None, None), ('držati', 'trzymać', None, None), ('bacati', 'rzucać', None, None), ('hvatati', 'łapać', None, None), ('tući', 'bić', None, None), ('ubijati', 'zabijać', None, None), ('umirati', 'umierać', None, None), ('živeti', 'żyć', None, None), ('stanovati', 'mieszkać', None, None), ('sretati', 'spotykać', None, None), ('zvati', 'dzwonić', None, None)], 'sentences': []}, {'id': 'v19f', 'title': 'Czasowniki podstawowe 6', 'icon': 'C', 'track': 'jezyk', 'words': [('slati', 'wysyłać', None, None), ('dobijati', 'dostawać', None, None), ('pokazivati', 'pokazywać', None, None), ('pozivati', 'zapraszać', None, None), ('posećivati', 'odwiedzać', None, None), ('plakati', 'płakać', None, None), ('smejati se', 'śmiać się', None, None), ('osmehivati se', 'uśmiechać się', None, None), ('bojati se', 'bać się', None, None), ('radovati se', 'cieszyć się', None, None), ('verovati', 'wierzyć', None, None), ('slagati se', 'zgadzać się', None, None), ('birati', 'wybierać', None, None), ('odlučivati', 'decydować', None, None), ('brojati', 'liczyć', None, None), ('meriti', 'ważyć', None, None)], 'sentences': []}, {'id': 'v20a', 'title': 'Czasowniki dnia codziennego 1', 'icon': 'C', 'track': 'jezyk', 'words': [('hodati', 'chodzić', None, None), ('voziti', 'jeździć', None, None), ('ulaziti u vozilo', 'wsiadać', None, None), ('izlaziti iz vozila', 'wysiadać', None, None), ('skretati', 'skręcać', None, None), ('zaustavljati se', 'zatrzymywać się', None, None), ('kasniti', 'spóźniać się', None, None), ('žuriti', 'spieszyć się', None, None), ('odmarati', 'odpoczywać', None, None), ('zabavljati se', 'bawić się', None, None), ('crtati', 'rysować', None, None), ('graditi', 'budować', None, None), ('popravljati', 'naprawiać', None, None), ('seći', 'ciąć', None, None), ('pržiti', 'smażyć', None, None), ('peći', 'piec', None, None)], 'sentences': []}, {'id': 'v20b', 'title': 'Czasowniki dnia codziennego 2', 'icon': 'C', 'track': 'jezyk', 'words': [('mešati', 'mieszać', None, None), ('sipati', 'nalewać', None, None), ('čistiti', 'sprzątać', None, None), ('prati (prać)', 'prać', None, None), ('peglati', 'prasować', None, None), ('brijati se', 'golić się', None, None), ('češljati', 'czesać', None, None), ('kupati se', 'kąpać się', None, None), ('buditi se', 'budzić się', None, None), ('zaspati', 'zasypiać', None, None), ('sanjariti', 'marzyć', None, None), ('sanjati', 'śnić', None, None), ('vežbati', 'ćwiczyć', None, None), ('trenirati', 'trenować', None, None), ('pobeđivati', 'wygrywać', None, None), ('gubiti', 'przegrywać', None, None)], 'sentences': []}, {'id': 'v20c', 'title': 'Czasowniki dnia codziennego 3', 'icon': 'C', 'track': 'jezyk', 'words': [('pomerati', 'ruszać', None, None), ('vući', 'ciągnąć', None, None), ('gurati', 'pchać', None, None), ('dizati', 'podnosić', None, None), ('padati', 'spadać', None, None), ('skakati', 'skakać', None, None), ('peti se', 'wspinać się', None, None), ('kriti', 'ukrywać', None, None), ('krasti', 'kraść', None, None), ('vraćati', 'oddawać', None, None), ('pozajmljivati', 'pożyczać', None, None), ('trošiti', 'wydawać', None, None), ('štedeti', 'oszczędzać', None, None)], 'sentences': []}, {'id': 'v21a', 'title': 'Słowa funkcyjne 1', 'icon': 'S', 'track': 'jezyk', 'words': [('ovaj', 'ten', None, None), ('onaj', 'tamten', None, None), ('ovde', 'tutaj', None, None), ('kako', 'jak', None, None), ('zašto', 'dlaczego', None, None), ('šta', 'co', None, None), ('ko', 'kto', None, None), ('koji', 'który', None, None), ('kakav', 'jaki', None, None), ('koliko', 'ile (policzalne)', None, None), ('ali', 'ale', None, None), ('ili', 'lub', None, None), ('jer', 'bo', None, None), ('ako', 'jeśli', None, None), ('dakle', 'więc', None, None), ('takođe', 'też', None, None)], 'sentences': []}, {'id': 'v21b', 'title': 'Słowa funkcyjne 2', 'icon': 'S', 'track': 'jezyk', 'words': [('samo', 'tylko', None, None), ('malo (trochę)', 'trochę', None, None), ('mnogo (dużo)', 'dużo', None, None), ('sve', 'wszystko', None, None), ('ništa', 'nic', None, None), ('nešto', 'coś', None, None), ('neko', 'ktoś', None, None), ('niko', 'nikt', None, None), ('svaki', 'każdy', None, None), ('isti', 'ten sam', None, None), ('možda', 'może (być)', None, None), ('sigurno', 'na pewno', None, None), ('zajedno', 'razem', None, None), ('bez', 'bez', None, None), ('sa', 'z (towarzysząc)', None, None), ('na', 'na (powierzchni)', None, None)], 'sentences': []}, {'id': 'v21c', 'title': 'Słowa funkcyjne 3', 'icon': 'S', 'track': 'jezyk', 'words': [('do', 'do (kierunek)', None, None), ('od', 'od', None, None), ('za', 'dla', None, None), ('kroz', 'przez', None, None), ('posle', 'po (czas)', None, None), ('pre', 'przed', None, None), ('iza', 'za (z tyłu)', None, None), ('iznad', 'nad', None, None), ('ispod', 'pod', None, None), ('pored', 'obok', None, None), ('između', 'między', None, None), ('protiv', 'przeciw', None, None), ('o', 'o (temat)', None, None), ('kod', 'u (przy)', None, None), ('skoro', 'prawie', None, None), ('čak', 'nawet', None, None)], 'sentences': []}, {'id': 'v21d', 'title': 'Słowa funkcyjne 4', 'icon': 'S', 'track': 'jezyk', 'words': [('još jednom', 'jeszcze raz', None, None), ('sada', 'teraz', None, None), ('tada', 'wtedy', None, None), ('negde', 'gdzieś', None, None), ('nigde', 'nigdzie', None, None), ('svuda', 'wszędzie', None, None)], 'sentences': []}, {'id': 'v22a', 'title': 'Świat i społeczeństwo 1', 'icon': 'Ś', 'track': 'jezyk', 'words': [('život', 'życie', None, 'rodzaj męski'), ('smrt', 'śmierć', None, 'rodzaj żeński'), ('svet', 'świat', None, 'rodzaj męski'), ('zemlja (kraj)', 'kraj', None, 'rodzaj żeński'), ('država', 'państwo', None, 'rodzaj żeński'), ('govor', 'język (mowa)', None, 'rodzaj męski'), ('reč', 'słowo', None, 'rodzaj żeński'), ('rečenica', 'zdanie', None, 'rodzaj żeński'), ('ime', 'imię', None, 'rodzaj nijaki'), ('prezime', 'nazwisko', None, 'rodzaj nijaki'), ('starost', 'wiek', None, 'rodzaj żeński'), ('istorija', 'historia', None, 'rodzaj żeński'), ('kultura', 'kultura', None, 'rodzaj żeński'), ('vera', 'religia', None, 'rodzaj żeński'), ('Bog', 'Bóg', None, 'rodzaj męski'), ('rat', 'wojna', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v22b', 'title': 'Świat i społeczeństwo 2', 'icon': 'Ś', 'track': 'jezyk', 'words': [('mir', 'pokój (brak wojny)', None, 'rodzaj męski'), ('zakon', 'prawo (przepis)', None, 'rodzaj męski'), ('sloboda', 'wolność', None, 'rodzaj żeński'), ('vlast', 'władza', None, 'rodzaj żeński'), ('vlada', 'rząd', None, 'rodzaj żeński'), ('izbori', 'wybory', None, None), ('problem', 'problem', None, 'rodzaj męski'), ('ideja', 'pomysł', None, 'rodzaj żeński'), ('razlog', 'powód', None, 'rodzaj męski'), ('rezultat', 'wynik', None, 'rodzaj męski'), ('način', 'sposób', None, 'rodzaj męski'), ('početak', 'początek', None, 'rodzaj męski'), ('kraj', 'koniec', None, 'rodzaj męski'), ('deo', 'część', None, 'rodzaj męski'), ('mesto', 'miejsce', None, 'rodzaj nijaki'), ('stvar', 'rzecz', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22c', 'title': 'Świat i społeczeństwo 3', 'icon': 'Ś', 'track': 'jezyk', 'words': [('stvar (sprawa)', 'sprawa', None, 'rodzaj żeński'), ('informacija', 'informacja', None, 'rodzaj żeński'), ('poruka', 'wiadomość', None, 'rodzaj żeński'), ('pismo', 'list', None, 'rodzaj nijaki'), ('novine', 'gazeta', None, None), ('film', 'film', None, 'rodzaj męski'), ('muzika', 'muzyka', None, 'rodzaj żeński'), ('pesma', 'piosenka', None, 'rodzaj żeński'), ('slika', 'obraz', None, 'rodzaj żeński'), ('igra', 'gra', None, 'rodzaj żeński'), ('sport', 'sport', None, 'rodzaj męski'), ('utakmica', 'mecz', None, 'rodzaj żeński'), ('tim', 'drużyna', None, 'rodzaj męski'), ('lopta', 'piłka', None, 'rodzaj żeński'), ('zabava', 'zabawa', None, 'rodzaj żeński'), ('žurka', 'impreza', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22d', 'title': 'Świat i społeczeństwo 4', 'icon': 'Ś', 'track': 'jezyk', 'words': [('poklon', 'prezent', None, 'rodzaj męski'), ('san', 'sen', None, 'rodzaj męski'), ('plan', 'plan', None, 'rodzaj męski'), ('izbor', 'wybór', None, 'rodzaj męski'), ('greška', 'błąd', None, 'rodzaj żeński'), ('istina', 'prawda', None, 'rodzaj żeński'), ('laž', 'kłamstwo', None, 'rodzaj żeński'), ('tajna', 'tajemnica', None, 'rodzaj żeński'), ('snaga', 'siła', None, 'rodzaj żeński'), ('energija', 'energia', None, 'rodzaj żeński'), ('svetlo', 'światło', None, 'rodzaj nijaki'), ('zvuk', 'dźwięk', None, 'rodzaj męski'), ('tišina', 'cisza', None, 'rodzaj żeński'), ('kretanje', 'ruch', None, 'rodzaj nijaki'), ('promena', 'zmiana', None, 'rodzaj żeński'), ('razlika', 'różnica', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22e', 'title': 'Świat i społeczeństwo 5', 'icon': 'Ś', 'track': 'jezyk', 'words': [('primer', 'przykład', None, 'rodzaj męski'), ('celina', 'całość', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v23a', 'title': 'Technologia 1', 'icon': 'T', 'track': 'jezyk', 'words': [('internet', 'internet', None, 'rodzaj męski'), ('imejl', 'e-mail', None, 'rodzaj męski'), ('lozinka', 'hasło', None, 'rodzaj żeński'), ('veb-sajt', 'strona internetowa', None, 'rodzaj męski'), ('program', 'program', None, 'rodzaj męski'), ('aplikacija', 'aplikacja', None, 'rodzaj żeński'), ('ekran', 'ekran', None, 'rodzaj męski'), ('tastatura', 'klawiatura', None, 'rodzaj żeński'), ('računarski miš', 'myszka komputerowa', None, 'rodzaj męski'), ('fajl', 'plik', None, 'rodzaj męski'), ('fotografija', 'zdjęcie', None, 'rodzaj żeński'), ('kamera', 'kamera', None, 'rodzaj żeński'), ('baterija', 'bateria', None, 'rodzaj żeński'), ('struja', 'prąd', None, 'rodzaj żeński'), ('kabl', 'kabel', None, 'rodzaj męski'), ('mašina', 'maszyna', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v23b', 'title': 'Technologia 2', 'icon': 'T', 'track': 'jezyk', 'words': [('alat', 'narzędzie', None, 'rodzaj męski'), ('čekić', 'młotek', None, 'rodzaj męski'), ('štampač', 'drukarka', None, 'rodzaj męski'), ('punjač', 'ładowarka', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v24a', 'title': 'Geografia 1', 'icon': 'G', 'track': 'jezyk', 'words': [('sever', 'północ', None, 'rodzaj męski'), ('jug', 'południe (kierunek)', None, 'rodzaj męski'), ('istok', 'wschód', None, 'rodzaj męski'), ('zapad', 'zachód', None, 'rodzaj męski'), ('Poljska', 'Polska', None, 'rodzaj żeński'), ('Evropa', 'Europa', None, 'rodzaj żeński'), ('Nemačka', 'Niemcy', None, 'rodzaj żeński'), ('Francuska', 'Francja', None, 'rodzaj żeński'), ('Italija', 'Włochy', None, 'rodzaj żeński'), ('Španija', 'Hiszpania', None, 'rodzaj żeński'), ('Rusija', 'Rosja', None, 'rodzaj żeński'), ('Engleska', 'Anglia', None, 'rodzaj żeński'), ('Amerika', 'Ameryka', None, 'rodzaj żeński'), ('Kina', 'Chiny', None, 'rodzaj żeński'), ('Japan', 'Japonia', None, 'rodzaj męski'), ('Afrika', 'Afryka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v24b', 'title': 'Geografia 2', 'icon': 'G', 'track': 'jezyk', 'words': [('Azija', 'Azja', None, 'rodzaj żeński'), ('kontinent', 'kontynent', None, 'rodzaj męski'), ('glavni grad', 'stolica', None, 'rodzaj męski'), ('građanin', 'obywatel', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v25a', 'title': 'Materiały i przedmioty 1', 'icon': 'M', 'track': 'jezyk', 'words': [('komad', 'kawałek', None, 'rodzaj męski'), ('kap', 'kropla', None, 'rodzaj żeński'), ('kutija', 'pudełko', None, 'rodzaj żeński'), ('džak', 'worek', None, 'rodzaj męski'), ('konac', 'nić', None, 'rodzaj męski'), ('žica', 'drut', None, 'rodzaj żeński'), ('igla', 'igła', None, 'rodzaj żeński'), ('makaze', 'nożyczki', None, None), ('štap', 'kij', None, 'rodzaj męski'), ('uže', 'lina', None, 'rodzaj nijaki'), ('lanac', 'łańcuch', None, 'rodzaj męski'), ('šraf', 'śruba', None, 'rodzaj męski'), ('ekser', 'gwóźdź', None, 'rodzaj męski'), ('lepak', 'klej', None, 'rodzaj męski'), ('farba', 'farba', None, 'rodzaj żeński'), ('staklo', 'szkło', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v25b', 'title': 'Materiały i przedmioty 2', 'icon': 'M', 'track': 'jezyk', 'words': [('drvo (materiał)', 'drewno', None, 'rodzaj nijaki'), ('metal', 'metal', None, 'rodzaj męski'), ('zlato', 'złoto', None, 'rodzaj nijaki'), ('srebro', 'srebro', None, 'rodzaj nijaki'), ('gvožđe', 'żelazo', None, 'rodzaj nijaki'), ('plastika', 'plastik', None, 'rodzaj żeński'), ('koža (materiał)', 'skóra (materiał)', None, 'rodzaj żeński'), ('pamuk', 'bawełna', None, 'rodzaj męski'), ('vuna', 'wełna', None, 'rodzaj żeński'), ('pesak', 'piasek', None, 'rodzaj męski'), ('blato', 'błoto', None, 'rodzaj nijaki'), ('prašina', 'kurz', None, 'rodzaj żeński'), ('dim', 'dym', None, 'rodzaj męski'), ('para', 'para (wodna)', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v26a', 'title': 'Kierunki i miejsca 1', 'icon': 'K', 'track': 'jezyk', 'words': [('gore', 'góra (kierunek)', None, None), ('dole', 'dół', None, None), ('napred', 'przód', None, None), ('pozadi', 'tył', None, None), ('sredina', 'środek', None, 'rodzaj żeński'), ('strana', 'bok', None, 'rodzaj żeński'), ('unutra', 'wewnątrz', None, None), ('napolju', 'na zewnątrz', None, None), ('daleko', 'daleko', None, None), ('blizu', 'blisko', None, None), ('visoko', 'wysoko', None, None), ('nisko', 'nisko', None, None), ('brzo', 'szybko', None, None), ('sporo', 'wolno', None, None), ('dobro', 'dobrze', None, None), ('loše', 'źle', None, None)], 'sentences': []}, {'id': 'v26b', 'title': 'Kierunki i miejsca 2', 'icon': 'K', 'track': 'jezyk', 'words': [('lako', 'łatwo', None, None), ('teško', 'trudno', None, None), ('posebno', 'osobno', None, None), ('naspram', 'naprzeciw', None, None), ('duž', 'wzdłuż', None, None), ('poprečno', 'w poprzek', None, None), ('unaokolo', 'dokoła', None, None)], 'sentences': []}, {'id': 'v27a', 'title': 'Więcej jedzenia 1', 'icon': 'W', 'track': 'jezyk', 'words': [('kupus', 'kapusta', None, 'rodzaj męski'), ('grašak', 'groszek', None, 'rodzaj męski'), ('pasulj', 'fasola', None, 'rodzaj męski'), ('pečurka', 'grzyb', None, 'rodzaj żeński'), ('orah', 'orzech', None, 'rodzaj męski'), ('šljiva', 'śliwka', None, 'rodzaj żeński'), ('višnja', 'wiśnia', None, 'rodzaj żeński'), ('breskva', 'brzoskwinia', None, 'rodzaj żeński'), ('lubenica', 'arbuz', None, 'rodzaj żeński'), ('malina', 'malina', None, 'rodzaj żeński'), ('kobasica', 'kiełbasa', None, 'rodzaj żeński'), ('šunka', 'szynka', None, 'rodzaj żeński'), ('pecivo', 'bułka', None, 'rodzaj nijaki'), ('sendvič', 'kanapka', None, 'rodzaj męski'), ('palačinka', 'naleśnik', None, 'rodzaj żeński'), ('jogurt', 'jogurt', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v27b', 'title': 'Więcej jedzenia 2', 'icon': 'W', 'track': 'jezyk', 'words': [('pavlaka', 'śmietana', None, 'rodzaj żeński'), ('sos', 'sos', None, 'rodzaj męski'), ('sirće', 'ocet', None, 'rodzaj nijaki'), ('kvasac', 'drożdże', None, 'rodzaj męski'), ('žele (kisiel)', 'kisiel', None, 'rodzaj nijaki'), ('žele', 'galaretka', None, 'rodzaj nijaki'), ('suvo grožđe', 'rodzynek', None, 'rodzaj nijaki'), ('badem', 'migdał', None, 'rodzaj męski'), ('peršun', 'pietruszka', None, 'rodzaj męski'), ('mirođija', 'koperek', None, 'rodzaj żeński'), ('paprika', 'papryka', None, 'rodzaj żeński'), ('zelena salata', 'sałata', None, 'rodzaj żeński'), ('spanać', 'szpinak', None, 'rodzaj męski'), ('cvekla', 'burak', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v28a', 'title': 'Rodzina i zawody 1', 'icon': 'R', 'track': 'jezyk', 'words': [('tast', 'teść', None, 'rodzaj męski'), ('tašta', 'teściowa', None, 'rodzaj żeński'), ('zet', 'szwagier', None, 'rodzaj męski'), ('bratanac', 'bratanek', None, 'rodzaj męski'), ('sestričina', 'siostrzenica', None, 'rodzaj żeński'), ('siroče', 'sierota', None, 'rodzaj nijaki'), ('udovica', 'wdowa', None, 'rodzaj żeński'), ('verenik', 'narzeczony', None, 'rodzaj męski'), ('venčanje', 'ślub', None, 'rodzaj nijaki'), ('razvod', 'rozwód', None, 'rodzaj męski'), ('rođenje', 'urodzenie', None, 'rodzaj nijaki'), ('sahrana', 'pogrzeb', None, 'rodzaj żeński'), ('frizer', 'fryzjer', None, 'rodzaj męski'), ('pekar', 'piekarz', None, 'rodzaj męski'), ('mesar', 'rzeźnik', None, 'rodzaj męski'), ('konobarica', 'kelnerka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v28b', 'title': 'Rodzina i zawody 2', 'icon': 'R', 'track': 'jezyk', 'words': [('poštar', 'listonosz', None, 'rodzaj męski'), ('vatrogasac', 'strażak', None, 'rodzaj męski'), ('sudija', 'sędzia', None, 'rodzaj męski'), ('direktor', 'dyrektor', None, 'rodzaj męski')], 'sentences': []}]
# === /SŁOWNICTWO ===

"""[en — wygenerowane przez tools/i18n.py, nie edytuj] Treść kursu: greka starożytna (attycka i koine) dla Polaków.

Słowo:     (forma z akcentem, znaczenie po polsku, polskie słowo z greki lub None, skojarzenie lub None)
Litera:    (litera lub dwuznak, jak czytać, nazwa)
Zdanie:    (lista słów w formie słownikowej, tłumaczenie, {pułapka: wyjaśnienie})
           Akcent ostry na końcu słowa zmienia się sam w ciężki (ὸ), gdy po nim stoi
           kolejne słowo (engine.display).
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź, wyjaśnienie, dział)

Wymowa (pole „tr”) powstaje automatycznie: wymowa erazmiańska zapisana po polsku.
"""

UNITS = [
    # ---------------------------------------------------------------- alfabet
    {
        "id": "alfa1", "title": 'Alphabet I', "icon": "Α", "track": "pismo",
        "letters": [
            ("α", '[a]', "ἄλφα"), ("β", '[b]', "βῆτα"), ("γ", '[ɡ]', "γάμμα"), ("δ", '[d]', "δέλτα"),
            ("ε", '[e] (short)', "ἒ ψιλόν"), ("ζ", '[zd] (school: dz)', "ζῆτα"), ("η", '[ɛː] (long e)', "ἦτα"),
            ("θ", '[tʰ] (school: th)', "θῆτα"), ("ι", '[i]', "ἰῶτα"), ("κ", '[k]', "κάππα"), ("λ", '[l]', "λάμβδα"),
            ("μ", '[m]', "μῦ"),
        ],
    },
    {
        "id": "alfa2", "title": 'Alphabet II', "icon": "Ω", "track": "pismo",
        "letters": [
            ("ν", '[n]', "νῦ"), ("ξ", '[ks]', "ξεῖ"), ("ο", '[o] (short)', "ὂ μικρόν"),
            ("π", '[p]', "πεῖ"), ("ρ", '[r]', "ῥῶ"), ("σ", '[s]', "σίγμα"),
            ("ς", '[s] at the end of a word', "σίγμα τελικόν"), ("τ", '[t]', "ταῦ"), ("υ", '[y] (school: y)', "ὖ ψιλόν"),
            ("φ", '[pʰ] (school: f)', "φεῖ"), ("χ", '[kʰ] (school: kh)', "χεῖ"), ("ψ", '[ps]', "ψεῖ"),
            ("ω", '[ɔː] (long o)', "ὦ μέγα"),
        ],
    },
    {
        "id": "alfa3", "title": 'Marks and diphthongs', "icon": "ἁ", "track": "pismo",
        "letters": [
            ("ἁ", '[h] at the start of a word (ἁ = ha)', "δασεῖα"),
            ("ἀ", 'no sound (ἀ = a)', "ψιλή"),
            ("ά", 'pitch accent: an old melody, read normally', "ὀξεῖα"),
            ("ᾳ", 'iota subscript: once [i], now silent', "ὑπογεγραμμένη"),
            ("αι", '[ai̯] (school: ai)', "δίφθογγος"), ("ει", '[eː] (school: ei)', "δίφθογγος"),
            ("οι", '[oi̯] (school: oi)', "δίφθογγος"), ("ου", '[uː]', "δίφθογγος"),
            ("αυ", '[au̯]', "δίφθογγος"), ("ευ", '[eu̯]', "δίφθογγος"),
            ("γγ", '[ŋɡ]: ἄγγελος is read “angelos”', "γάμμα"),
        ],
    },
    {
        "id": 'wielkie1', "title": 'Capital letters I', "icon": 'Δ', "track": "pismo",
        "letters": [
            ('Α', '[a] (capital α)', 'ἄλφα'),
            ('Β', '[b] (capital β)', 'βῆτα'),
            ('Γ', '[ɡ] (capital γ)', 'γάμμα'),
            ('Δ', '[d] (capital δ)', 'δέλτα'),
            ('Ε', '[e] (capital ε)', 'ἒ ψιλόν'),
            ('Ζ', '[zd] (capital ζ)', 'ζῆτα'),
            ('Η', '[ɛː] (capital η)', 'ἦτα'),
            ('Θ', '[tʰ] (capital θ)', 'θῆτα'),
            ('Ι', '[i] (capital ι)', 'ἰῶτα'),
            ('Κ', '[k] (capital κ)', 'κάππα'),
            ('Λ', '[l] (capital λ)', 'λάμβδα'),
            ('Μ', '[m] (capital μ)', 'μῦ'),
        ],
    },
    {
        "id": 'wielkie2', "title": 'Capital letters II', "icon": 'Σ', "track": "pismo",
        "letters": [
            ('Ν', '[n] (capital ν)', 'νῦ'),
            ('Ξ', '[ks] (capital ξ)', 'ξεῖ'),
            ('Ο', '[o] (capital ο)', 'ὂ μικρόν'),
            ('Π', '[p] (capital π)', 'πεῖ'),
            ('Ρ', '[r] (capital ρ)', 'ῥῶ'),
            ('Σ', '[s] (capital σ)', 'σίγμα'),
            ('Τ', '[t] (capital τ)', 'ταῦ'),
            ('Υ', '[y] (capital υ)', 'ὖ ψιλόν'),
            ('Φ', '[pʰ] (capital φ)', 'φεῖ'),
            ('Χ', '[kʰ] (capital χ)', 'χεῖ'),
            ('Ψ', '[ps] (capital ψ)', 'ψεῖ'),
            ('Ω', '[ɔː] (capital ω)', 'ὦ μέγα'),
        ],
    },
    {
        "id": 'akcenty2', "title": 'Accents and breathings II', "icon": 'ᾶ', "track": "pismo",
        "letters": [
            ('ὰ', 'grave accent (gravis): an acute inside a sentence turns into a grave, read it normally', 'βαρεῖα'),
            ('ᾶ', 'circumflex on a long vowel: the old falling-rising pitch', 'περισπωμένη'),
            ('ἄ', 'smooth breathing and acute accent together: ἄ = a', 'ψιλὴ καὶ ὀξεῖα'),
            ('ἅ', 'rough breathing and acute accent together: ἅ = ha', 'δασεῖα καὶ ὀξεῖα'),
            ('ὁ', '[ho]: the article “the” (masculine), rough breathing at the start', 'ὁ'),
            ('ἡ', '[hɛː]: the article “the” (feminine)', 'ἡ'),
            ('οὐ', '[uː]: “not”, the smooth breathing changes nothing', 'οὐ'),
            ('ῥ', '[rh]: ρ at the start of a word always has a rough breathing', 'ῥῶ'),
            ('ϊ', 'two dots over ι: read the vowels separately (ἀϊ)', 'διαλυτικά'),
            ('ῃ', '[ɛː]: η with iota underneath, the iota is silent', 'ἦτα ὑπογεγραμμένη'),
            ('ῳ', '[ɔː]: ω with iota underneath, the iota is silent', 'ὦ ὑπογεγραμμένη'),
        ],
    },
    {
        "id": 'grupy2', "title": 'Diphthongs and groups II', "icon": 'γκ', "track": "pismo",
        "letters": [
            ('υι', '[yi̯]: υἱός read “huios” (son)', 'δίφθογγος'),
            ('ηυ', '[ɛːu̯]: ηὗρον read “ēuron”', 'δίφθογγος'),
            ('γκ', '[ŋk]: ἄγκυρα read “ankyra”', 'γάμμα κάππα'),
            ('γξ', '[ŋks]: σάλπιγξ read “salpinks”', 'γάμμα ξεῖ'),
            ('γχ', '[ŋkʰ]: ἄγχω read “ankhō”', 'γάμμα χεῖ'),
            ('ρρ', '[rː]: double r (ἄρρην)', 'ῥῶ ῥῶ'),
            ('σσ', '[ss]: θάλασσα; Attic often has ττ', 'σίγμα σίγμα'),
            ('ττ', '[tt]: θάλαττα, the Attic variant', 'ταῦ ταῦ'),
            ('μμ', '[mm]: γράμμα', 'μῦ μῦ'),
            ('λλ', '[ll]: ἄλλος', 'λάμβδα λάμβδα'),
        ],
    },
    {
        "id": 'liczby1', "title": 'Letter numbers I', "icon": 'αʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('αʹ', '1', 'ἄλφα'),
            ('βʹ', '2', 'βῆτα'),
            ('γʹ', '3', 'γάμμα'),
            ('δʹ', '4', 'δέλτα'),
            ('εʹ', '5', 'ἒ ψιλόν'),
            ('ϛʹ', '6', 'στῖγμα'),
            ('ζʹ', '7', 'ζῆτα'),
            ('ηʹ', '8', 'ἦτα'),
            ('θʹ', '9', 'θῆτα'),
        ],
    },
    {
        "id": 'liczby2', "title": 'Letter numbers II', "icon": 'ιʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('ιʹ', '10', 'ἰῶτα'),
            ('κʹ', '20', 'κάππα'),
            ('λʹ', '30', 'λάμβδα'),
            ('μʹ', '40', 'μῦ'),
            ('νʹ', '50', 'νῦ'),
            ('ξʹ', '60', 'ξεῖ'),
            ('οʹ', '70', 'ὂ μικρόν'),
            ('πʹ', '80', 'πεῖ'),
            ('ϙʹ', '90', 'κόππα'),
        ],
    },
    {
        "id": 'liczby3', "title": 'Letter numbers III', "icon": 'ρʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('ρʹ', '100', 'ῥῶ'),
            ('σʹ', '200', 'σίγμα'),
            ('τʹ', '300', 'ταῦ'),
            ('υʹ', '400', 'ὖ ψιλόν'),
            ('φʹ', '500', 'φεῖ'),
            ('χʹ', '600', 'χεῖ'),
            ('ψʹ', '700', 'ψεῖ'),
            ('ωʹ', '800', 'ὦ μέγα'),
            ('ϡʹ', '900', 'σαμπῖ'),
        ],
    },
    {
        "id": 'archaiczne', "title": 'Old letters and variants', "icon": 'ϝ', "track": "pismo",
        "letters": [
            ('ϝ', '[w]: an old letter, the digamma (“double gamma”), lost from Greek before the classical era', 'δίγαμμα'),
            ('ϙ', '[k]: an old letter, today only the number 90', 'κόππα'),
            ('ϛ', '[st]: a ligature of σ and τ, today only the number 6', 'στῖγμα'),
            ('ϡ', 'an old letter, today only the number 900', 'σαμπῖ'),
            ('ϲ', '[s]: sigma shaped like a C, in manuscripts and inscriptions', 'λουνατὸν σίγμα'),
            ('Ϲ', '[s]: capital sigma shaped like a C', 'λουνατὸν σίγμα'),
            ('ϑ', 'a variant of θ, in print and mathematics: [tʰ]', 'θῆτα'),
            ('ϕ', 'a variant of φ, in print and mathematics: [pʰ]', 'φεῖ'),
            ('ϖ', 'a variant of π: [p]', 'πεῖ'),
            ('ϐ', 'a variant of β in manuscripts: [b]', 'βῆτα'),
        ],
    },
    # ----------------------------------------------------------------- język
    {
        "id": "slowa", "title": 'First words', "icon": "Β", "track": "jezyk", "requires": "alfa2",
        "words": [
            ("χαῖρε", 'hello; farewell', None, 'Literally “rejoice”. Greeks said it both to greet and to say goodbye.'),
            ("ἐγώ", 'I', 'egoism', None),
            ("σύ", 'you', None, None),
            ("καί", 'and; also', None, None),
            ("εἶ", 'you are', None, None),
            ("εἰμί", 'I am', None, 'An “enclitic” word: it often loses its accent and leans on the word before.'),
            ("ἐστί", 'is', None, None),
            ("ὁ", 'the (masculine)', None, 'The article was once a demonstrative, like “this, that”.'),
            ("ἡ", 'the (feminine)', None, None),
            ("τό", 'the (neuter)', None, None),
            ("φίλος", 'friend; dear', 'philosophy', 'A philosopher is a friend of wisdom; Philip is a lover of horses.'),
            ("ἄνθρωπος", 'human being', 'anthropology', None),
            ("καλός", 'beautiful; fine', 'calligraphy', 'Calligraphy = beautiful writing.'),
            ("ἀγαθός", 'good', 'Agatha', 'Agatha means “good” (ἀγαθή).'),
            ("μέγας", 'great; big', 'megaphone', None),
        ],
        "sentences": [
            (["ὁ", "φίλος", "ἀγαθός"], 'The friend is good.',
             {"ἐστί": 'Greeks often leave out “is”: ὁ φίλος ἀγαθός = the friend (is) good.'}),
            (["σύ", "εἶ", "φίλος"], 'You are a friend.',
             {"εἰμί": 'εἰμί means “I am”. To “you”: εἶ.'}),
            (["ὁ", "ἄνθρωπος", "καλός"], 'The human being is beautiful.', {"ἡ": 'ἄνθρωπος is masculine: ὁ.'}),
            (["ὁ", "φίλος", "μέγας"], 'The friend is great.', {}),
        ],
    },
    {
        "id": "dom", "title": 'Family', "icon": "Γ", "track": "jezyk",
        "words": [
            ("πατήρ", 'father', 'patriot', 'A patriot loves the land of the fathers (πατρίς).'),
            ("μήτηρ", 'mother', 'metropolis', 'Metropolis = mother city.'),
            ("υἱός", 'son', None, None),
            ("θυγάτηρ", 'daughter', None, 'The same Proto-Indo-European word as English daughter.'),
            ("ἀδελφός", 'brother', 'Philadelphia', 'Philadelphia = brotherly love.'),
            ("ἀδελφή", 'sister', None, None),
            ("ἀνήρ", 'man; husband', 'Andrew', 'Andrew (Ἀνδρέας) means “manly”.'),
            ("γυνή", 'woman; wife', 'gynaecology', None),
            ("παῖς", 'child', 'pedagogue', 'A pedagogue was a slave who “led the child” to school.'),
            ("οἶκος", 'house; household', 'economy', 'Economy = running a household.'),
            ("διδάσκαλος", 'teacher', 'didactic', None),
            ("ἐμός", 'my (masculine)', None, None),
            ("ἐμή", 'my (feminine)', None, None),
            ("καλή", 'beautiful (feminine)', None, None),
        ],
        "sentences": [
            (["ὁ", "πατήρ", "ἀγαθός"], 'The father is good.', {"ἡ": 'πατήρ is masculine: ὁ.'}),
            (["ἡ", "μήτηρ", "καλή"], 'The mother is beautiful.', {"καλός": 'μήτηρ is feminine: καλή.'}),
            (["ὁ", "ἐμός", "πατήρ", "ἀγαθός"], 'My father is good.',
             {"ἐμή": 'πατήρ is masculine: ἐμός.'}),
            (["ἡ", "ἐμή", "μήτηρ", "καλή"], 'My mother is beautiful.', {"ἐμός": 'μήτηρ is feminine: ἐμή.'}),
        ],
    },
    {
        "id": "liczby", "title": 'Numbers', "icon": "Δ", "track": "jezyk",
        "words": [
            ("εἷς", 'one', None, None),
            ("δύο", 'two', 'dilemma', 'A dilemma: two (δι-) premises.'),
            ("τρεῖς", 'three', 'trilogy', None),
            ("τέτταρες", 'four', 'tetralogy', None),
            ("πέντε", 'five', 'pentagon', None),
            ("ἕξ", 'six', 'hexagon', None),
            ("ἑπτά", 'seven', 'heptagon', None),
            ("ὀκτώ", 'eight', 'octahedron', None),
            ("ἐννέα", 'nine', 'enneagram', None),
            ("δέκα", 'ten', 'decade', None),
            ("ἑκατόν", 'hundred', 'hecatomb', 'A hecatomb was a sacrifice of a hundred oxen.'),
            ("ἀδελφοί", 'brothers', None, None),
            ("φίλοι", 'friends', None, None),
        ],
        "sentences": [
            (["δύο", "ἀδελφοί"], 'Two brothers.', {"ἀδελφός": 'Two: plural, ἀδελφοί.'}),
            (["τρεῖς", "φίλοι"], 'Three friends.', {"φίλος": 'Three: φίλοι.'}),
        ],
    },
    {
        "id": "swiat", "title": 'The world', "icon": "Ε", "track": "jezyk",
        "words": [
            ("ἥλιος", 'sun', 'helium', 'Helium was discovered in the spectrum of the Sun.'),
            ("σελήνη", 'moon', 'selenium', None),
            ("γῆ", 'earth; land', 'geography', None),
            ("θάλασσα", 'sea', 'thalassotherapy', None),
            ("οὐρανός", 'sky; heaven', 'Uranus', None),
            ("ὕδωρ", 'water', 'hydraulics', None),
            ("πῦρ", 'fire', 'pyrotechnics', None),
            ("λίθος", 'stone', 'lithography', None),
            ("φῶς", 'light', 'photography', None),
            ("κόσμος", 'world; order', 'cosmos; cosmetics', 'Cosmetics = putting your looks in order.'),
            ("χρόνος", 'time', 'chronology', None),
            ("βίος", 'life', 'biology', None),
            ("ἐν", 'in; on', None, None),
            ("τῷ", '(in) the (dative)', None, None),
            ("οὐρανῷ", '(in) heaven', None, None),
        ],
        "sentences": [
            (["ὁ", "ἥλιος", "ἐν", "τῷ", "οὐρανῷ"], 'The sun is in the sky.',
             {"οὐρανός": 'Where? After ἐν the dative: τῷ οὐρανῷ.'}),
            (["ἡ", "θάλασσα", "καλή"], 'The sea is beautiful.', {"καλός": 'θάλασσα is feminine: καλή.'}),
            (["ὁ", "βίος", "καλός"], 'Life is beautiful.', {}),
        ],
    },
    {
        "id": "czas", "title": 'Verbs', "icon": "Ζ", "track": "jezyk",
        "words": [
            ("γράφω", 'I write', 'graphic', None),
            ("γράφεις", 'you write', None, None),
            ("γράφει", '(he/she) writes', None, None),
            ("λέγω", 'I say; I speak', 'lexicon', None),
            ("λέγεις", 'you say', None, None),
            ("ἀκούω", 'I hear', 'acoustics', None),
            ("βλέπω", 'I see', None, None),
            ("ἔχω", 'I have', None, None),
            ("τί", 'what?', None, 'The question word τί never changes its accent.'),
            ("βιβλίον", 'book', 'bibliography', None),
            ("τόν", 'the (accusative)', None, None),
            ("φίλον", 'friend (object)', None, None),
        ],
        "sentences": [
            (["γράφω", "βιβλίον"], 'I am writing a book.',
             {"γράφει": 'γράφει means “writes” (he). About yourself: γράφω.'}),
            (["τί", "λέγεις", ";"], 'What are you saying?', {"λέγω": "You're asking someone: λέγεις (-εις means “you”)."}),
            (["ὁ", "διδάσκαλος", "γράφει"], 'The teacher is writing.', {"γράφω": 'He: γράφει.'}),
            (["ἀκούω", "τόν", "φίλον"], 'I hear the friend.',
             {"φίλος": 'Whom do I hear? Accusative: τὸν φίλον.'}),
        ],
    },
    {
        "id": "przypadki", "title": 'Cases', "icon": "Η", "track": "jezyk",
        "words": [
            ("λόγος", 'word; reason', 'logic', 'Hence -logy: biology = the study of life.'),
            ("θεός", 'god', 'theology', None),
            ("θεοῦ", 'of god (genitive)', None, None),
            ("θεόν", 'god (object)', None, None),
            ("τοῦ", 'of the (genitive)', None, None),
            ("φίλε", 'friend! (vocative)', None, 'Vocative in -ε, used to address someone.'),
            ("ὦ", 'O! (before a vocative)', None, None),
        ],
        "sentences": [
            (["χαῖρε", ",", "ὦ", "φίλε"], 'Hello, friend!',
             {"φίλος": 'Addressing someone: vocative φίλε.'}),
            (["ὁ", "λόγος", "τοῦ", "θεοῦ"], 'The word of God.', {"θεός": 'Whose word? Genitive: τοῦ θεοῦ.'}),
        ],
    },
    {
        "id": "aoryst", "title": 'Past tense', "icon": "Θ", "track": "jezyk",
        "words": [
            ("ἔγραψα", 'I wrote', None, 'ἐ- at the start (the augment) marks the past.'),
            ("ἔγραψε", '(he/she) wrote', None, None),
            ("εἶπε", '(he/she) said', None, None),
            ("ἦλθον", 'I came', None, None),
            ("εἶδον", 'I saw', 'idea', 'An idea (ἰδέα) is literally “what is seen”. Same root.'),
            ("ἐνίκησα", 'I conquered', 'Nike', None),
            ("ἦν", 'was', None, None),
            ("εὕρηκα", 'I have found!', 'eureka', 'Archimedes in his bath: εὕρηκα! (perfect tense).'),
        ],
        "sentences": [
            (["εὕρηκα"], 'I have found it!', {}),
            (["ἦλθον", "καί", "εἶδον"], 'I came and I saw.', {}),
            (["ὁ", "διδάσκαλος", "εἶπε"], 'The teacher said.', {}),
            (["ἔγραψα", "βιβλίον"], 'I wrote a book.', {"γράφω": 'In the past: ἔγραψα (I wrote).'}),
        ],
    },
    # --------------------------------------------------------------- sentencje
    {
        "id": "sent", "title": 'Sayings', "icon": "Ι", "track": "sentencje", "requires": "czas",
        "words": [
            ("γνῶθι", 'know (command)', 'diagnosis', None),
            ("σεαυτόν", 'yourself', None, None),
            ("πάντα", 'everything', 'panorama', None),
            ("ῥεῖ", 'flows', 'rheumatism', None),
            ("μηδέν", 'nothing (not)', None, None),
            ("ἄγαν", 'too much', None, None),
            ("ἕν", 'one thing', None, None),
            ("οἶδα", 'I know', None, None),
            ("ὅτι", 'that', None, None),
            ("οὐδέν", 'nothing', None, None),
        ],
        "sentences": [
            (["γνῶθι", "σεαυτόν"], 'Know yourself.', {}),
            (["πάντα", "ῥεῖ"], 'Everything flows.', {}),
            (["μηδέν", "ἄγαν"], 'Nothing in excess.', {}),
            (["ἕν", "οἶδα", "ὅτι", "οὐδέν", "οἶδα"], 'I know that I know nothing.', {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "pater", "title": 'Our Father', "icon": "Κ", "track": "teksty", "requires": "przypadki",
        "words": [
            ("πάτερ", 'Father! (vocative)', None, None),
            ("ἡμῶν", 'our (lit. “of us”)', None, None),
            ("τοῖς", 'the (dative plural)', None, None),
            ("οὐρανοῖς", 'heavens', None, None),
            ("ἁγιασθήτω", 'may it be hallowed', 'hagiography', None),
            ("ὄνομά", 'name', 'anonymous', 'Before σου it gets a second accent: ὄνομα → ὄνομά σου.'),
            ("σου", 'your (lit. “of you”)', None, 'Enclitic: no accent.'),
            ("ἐλθέτω", 'may it come', None, None),
            ("βασιλεία", 'kingdom', 'basilica', 'A basilica is a “royal” building.'),
            ("γενηθήτω", 'may it be done', 'genesis', None),
            ("θέλημά", 'will', None, None),
            ("ὡς", 'as; just as', None, None),
            ("ἐπί", 'on', 'epicentre', None),
            ("γῆς", 'earth (genitive)', None, None),
        ],
        "sentences": [
            (["πάτερ", "ἡμῶν", "ὁ", "ἐν", "τοῖς", "οὐρανοῖς"], 'Our Father, who art in heaven.', {}),
            (["ἁγιασθήτω", "τό", "ὄνομά", "σου"], 'Hallowed be thy name.', {}),
            (["ἐλθέτω", "ἡ", "βασιλεία", "σου"], 'Thy kingdom come.', {}),
            (["γενηθήτω", "τό", "θέλημά", "σου"], 'Thy will be done.', {}),
            (["ὡς", "ἐν", "οὐρανῷ", "καί", "ἐπί", "γῆς"], 'On earth as it is in heaven.', {}),
        ],
    },
    {
        "id": "jan", "title": 'Gospel of John', "icon": "Λ", "track": "teksty",
        "words": [
            ("ἀρχῇ", '(in the) beginning', 'archaic', None),
            ("πρός", 'with; towards', None, None),
        ],
        "sentences": [
            (["ἐν", "ἀρχῇ", "ἦν", "ὁ", "λόγος"], 'In the beginning was the Word.', {}),
            (["καί", "ὁ", "λόγος", "ἦν", "πρός", "τόν", "θεόν"], 'And the Word was with God.', {}),
            (["καί", "θεός", "ἦν", "ὁ", "λόγος"], 'And the Word was God.', {}),
        ],
    },
]

TRACKS = {
    "pismo": 'ΓΡΑΜΜΑΤΑ · WRITING',
    "jezyk": 'ΓΛΩΣΣΑ · LANGUAGE',
    "sentencje": 'ΓΝΩΜΑΙ · SAYINGS',
    "teksty": 'ΚΕΙΜΕΝΑ · TEXTS',
}

INSIGHTS = {
    "alfa1": [
        {"title": 'You know half of it from maths',
         "text": 'α, β, γ, δ, λ, μ, π: you know them from school. The Greek alphabet gave us the word “alphabet” (alpha + beta). η is a long e, and θ is “th”.',
         "chain": []},
    ],
    "alfa2": [
        {"title": 'False friends',
         "text": "ν is n, ρ is r, υ is y (like French u), χ is kh. They look like v, p, u, x, but they aren't. σ at the end of a word is written ς. ω is a long o: Ω is the last letter, hence “alpha and omega”.",
         "chain": []},
    ],
    "wielkie1": [
        {"title": 'Familiar letters, foreign sounds',
         "text": 'Capital letters look like Latin ones, but you do not read them all the same way. Β is [b], not “v”. Η is a long e, not h. Ρ is r, not p. Χ is kh, not “ex”. Υ is y, not u. Ν is n. You use capitals at the start of proper names; in the old days whole texts were written in them.',
         "chain": []},
    ],
    "akcenty2": [
        {"title": 'Three accents, one melody',
         "text": 'The acute (ά), grave (ὰ) and circumflex (ᾶ) are traces of the old melody of words. Today you read them normally, but a circumflex tells you the vowel is long. Rough and smooth breathings go on the first vowel of a word; ρ at the start always has a rough breathing: ῥ.',
         "chain": []},
    ],
    "liczby1": [
        {"title": 'Letters as digits',
         "text": 'The Greeks had no separate digits: they wrote numbers with letters and a small mark at the top right. α΄ = 1, β΄ = 2, γ΄ = 3. The alphabet has 24 letters, but there are 27 numbers, so three old letters were added: ϛ (6), ϙ (90) and ϡ (900). Hence the word “alphabet”, and “alpha and omega” for the beginning and the end.',
         "chain": []},
    ],
    "alfa3": [
        {"title": 'Marks over the letters',
         "text": 'Rough breathing (ἁ) is h: ἥλιος reads “hēlios”, hence “helium”. Smooth breathing (ἀ) changes nothing. Accents were an old melody: for now, read normally. An acute on the last syllable becomes a grave before another word: καλός → καλὸς.',
         "chain": []},
    ],
    "slowa": [
        {"title": 'The article: “the”',
         "text": 'Greek has an article, like English “the”: ὁ, ἡ, τό, one for each gender. ὁ φίλος = the friend. And Greeks often leave out “is”: ὁ φίλος ἀγαθός = the friend (is) good.',
         "chain": [
             ('The friend is good.', ["ὁ", "φίλος", "ἀγαθός"], 'ὁ (the) + φίλος + ἀγαθός. No “is”.'),
             ('You are a friend.', ["σύ", "εἶ", "φίλος"], 'σύ (you) + εἶ (are) + φίλος.'),
         ]},
    ],
    "dom": [
        {"title": 'Three genders',
         "text": 'Masculine, feminine, neuter, and adjectives must match: καλός, καλή = beautiful (m., f.). The adjective goes between the article and the noun: ὁ ἐμὸς πατήρ = (the) my father.',
         "chain": [('My father is good.', ["ὁ", "ἐμός", "πατήρ", "ἀγαθός"], 'ὁ ἐμὸς πατήρ, then the adjective.')]},
    ],
    "liczby": [
        {"title": 'Numbers from geometry',
         "text": 'Pentagon, hexagon, decade, hecatomb: you know the Greek numbers from shapes and measures.',
         "chain": [('Two brothers.', ["δύο", "ἀδελφοί"], 'δύο + plural ἀδελφοί.')]},
    ],
    "swiat": [
        {"title": 'Science speaks Greek',
         "text": 'Geography (γῆ), biology (βίος), photography (φῶς), chronology (χρόνος), hydraulics (ὕδωρ). When you learn a Greek word, look for it inside an English scientific word.',
         "chain": [('The sun is in the sky.', ["ὁ", "ἥλιος", "ἐν", "τῷ", "οὐρανῷ"],
                    'Where? ἐν + dative: τῷ οὐρανῷ.')]},
    ],
    "czas": [
        {"title": '-ω, -εις, -ει = I, you, he',
         "text": 'The person is in the ending: γράφω, γράφεις, γράφει = I write, you write, he writes. No pronoun needed. The Greek question mark is a semicolon: τί λέγεις; = What are you saying?',
         "chain": [
             ('I am writing a book.', ["γράφω", "βιβλίον"], 'γράφω (I write) + βιβλίον (bibliography!).'),
             ('I hear the friend.', ["ἀκούω", "τόν", "φίλον"], 'Whom? Accusative: τὸν φίλον.'),
         ]},
    ],
    "przypadki": [
        {"title": 'Five cases',
         "text": 'Greek has nominative, genitive, dative, accusative and vocative. The vocative is for addressing someone: ὦ φίλε! = O friend! The genitive means “of”: ὁ λόγος τοῦ θεοῦ = the word of God.',
         "chain": [('Hello, friend!', ["χαῖρε", ",", "ὦ", "φίλε"], 'Vocative φίλε, with ὦ before it.')]},
    ],
    "aoryst": [
        {"title": 'The past at the front',
         "text": "English marks the past at the end (writ-ed, wrote), Greek at the front: ἐ- (the augment). γράφω → ἔγραψα (I wrote). Archimedes' famous εὕρηκα means “I have found!”.",
         "chain": [('I came and I saw.', ["ἦλθον", "καί", "εἶδον"], 'ἦλθον (I came), εἶδον (I saw).')]},
    ],
    "sent": [
        {"title": 'Wisdom from Delphi',
         "text": 'γνῶθι σεαυτόν and μηδὲν ἄγαν were carved at the temple of Apollo at Delphi. πάντα ῥεῖ is a late summary of Heraclitus (first recorded by Simplicius, 6th c.). “I know that I know nothing” in this form is a later formula: in Plato (Apology 21d) Socrates says something similar.',
         "chain": [('Know yourself.', ["γνῶθι", "σεαυτόν"], 'γνῶθι (know, cf. diagnosis) + σεαυτόν.')]},
    ],
    "pater": [
        {"title": 'The prayer in the original',
         "text": "The Gospel of Matthew (6:9-10) in the original. σου (your) comes after the noun, as in “hallowed be thy name”, and has no accent: that's why ὄνομα gets a second accent (ὄνομά σου).",
         "chain": [('Hallowed be thy name.', ["ἁγιασθήτω", "τό", "ὄνομά", "σου"],
                    'ἁγιασθήτω (hagiography!) + τὸ ὄνομά σου.')]},
    ],
    "jan": [
        {"title": 'λόγος: word and reason',
         "text": 'John begins with λόγος, which means both “word” and “reason, meaning”. Hence logic and every -logy. ἐν ἀρχῇ = in the beginning (archaic!).',
         "chain": [('In the beginning was the Word.', ["ἐν", "ἀρχῇ", "ἦν", "ὁ", "λόγος"], 'ἐν ἀρχῇ + ἦν (was) + ὁ λόγος.')]},
    ],
}

ENDINGS_INSIGHT = {
    "title": 'The ending says it all',
    "text": 'English says “I see him”, not “I see he”: a trace of cases. Greek does this with every noun: τὸν φίλον (the friend, as object). Ask: who? whose? to whom? whom? where?',
}

ENDINGS = [
    ("ὁ ", "φίλ", "ος", "", ["ος", "ον", "ου", "ῳ"], 'the friend (who?)', 'Nominative: -ος.', "slowa"),
    ("ἡ μήτηρ ", "καλ", "ή", "", ["ός", "ή", "όν", "οῦ"], 'the mother is beautiful', 'Feminine: -ή.', "dom"),
    ("ἡ ", "ἀδελφ", "ή", "", ["ός", "ή", "όν", "οί"], 'the sister', 'Feminine: -ή.', "dom"),
    ("δύο ", "ἀδελφ", "οί", "", ["ός", "ή", "όν", "οί"], 'two brothers', 'Plural: -οί.', "liczby"),
    ("ἐν τῷ ", "οὐραν", "ῷ", "", ["ός", "όν", "οῦ", "ῷ"], 'in heaven (where?)', 'After ἐν the dative: -ῷ.', "swiat"),
    ("", "γράφ", "ω", " βιβλίον", ["ω", "εις", "ει", "ουσι"], 'I write a book', 'I: -ω.', "czas"),
    ("σὺ ", "γράφ", "εις", "", ["ω", "εις", "ει", "ουσι"], 'you write', 'You: -εις.', "czas"),
    ("ὁ διδάσκαλος ", "γράφ", "ει", "", ["ω", "εις", "ει", "ουσι"], 'the teacher writes', 'He: -ει.', "czas"),
    ("ἀκούω τὸν ", "φίλ", "ον", "", ["ος", "ον", "ου", "ε"], 'I hear the friend (whom?)', 'Accusative: -ον.', "czas"),
    ("ὁ λόγος τοῦ ", "θε", "οῦ", "", ["ός", "όν", "οῦ", "ῷ"], 'the word of God (whose?)', 'Genitive: -οῦ.', "przypadki"),
    ("χαῖρε, ὦ ", "φίλ", "ε", "", ["ος", "ε", "ον", "ου"], 'hello, friend!', 'Vocative: -ε.', "przypadki"),
    ("", "ἔγραψ", "α", "", ["α", "ε", "ω", "ον"], 'I wrote', 'Aorist, I: -α.', "aoryst"),
]

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "agora", "title": 'In the agora', "partner": "Kriton", "avatar": "Κ", "requires": "slowa",
        "turns": [
            {"bot": ["χαῖρε", "."], "en": 'Hello!',
             "options": [(["χαῖρε", "."], True, None),
                         (["οὐ", "."], False, 'οὐ means “not”. Reply with a greeting: χαῖρε.')]},
            {"bot": ["τίς", "εἶ", ";"], "en": 'Who are you?',
             "options": [(["φίλος", "εἰμί"], True, None),
                         (["φίλος", "εἶ"], False, 'εἶ means “you are”. About yourself: εἰμί.'),
                         (["φίλος", "ἐστί"], False, 'ἐστί means “is”. About yourself: εἰμί.')],
             "note": 'The Greek question mark looks like a semicolon: ;'},
            {"bot": ["ὁ", "κόσμος", "καλός", "."], "en": 'The world is beautiful.',
             "options": [(["ναί", ",", "ὁ", "κόσμος", "καλός"], True, None),
                         (["ναί", ",", "ὁ", "κόσμος", "καλή"], False, 'κόσμος is masculine: καλός.')]},
            {"bot": ["χαῖρε", "."], "en": 'Farewell!', "build": (["χαῖρε"], 'Farewell!')},
        ],
    },
    {
        "id": "szkola", "title": 'At school', "partner": "Nauczyciel", "avatar": "Δ", "requires": "czas",
        "turns": [
            {"bot": ["τί", "γράφεις", ";"], "en": 'What are you writing?',
             "options": [(["γράφω", "βιβλίον"], True, None),
                         (["γράφει", "βιβλίον"], False, 'γράφει means “writes” (he). About yourself: γράφω.'),
                         (["γράφεις", "βιβλίον"], False, 'γράφεις means “you write”. About yourself: γράφω.')]},
            {"bot": ["τί", "ἀκούεις", ";"], "en": 'What do you hear?',
             "build": (["ἀκούω", "τόν", "φίλον"], 'I hear the friend.')},
        ],
    },
    {
        "id": "sokrates", "title": 'Socrates', "partner": "Sokrates", "avatar": "Σ", "requires": "sent",
        "turns": [
            {"bot": ["τί", "οἶδας", ";"], "en": 'What do you know?',
             "options": [(["ἕν", "οἶδα", "ὅτι", "οὐδέν", "οἶδα"], True, None),
                         (["ἕν", "οἶδε", "ὅτι", "οὐδέν", "οἶδε"], False, 'οἶδε means “knows” (he). About yourself: οἶδα.')]},
            {"bot": ["εὖ", "λέγεις", ".", "τί", "ἐστι", "σοφία", ";"], "en": 'Well said. What is wisdom?',
             "build": (["γνῶθι", "σεαυτόν"], 'Know yourself.')},
        ],
    },
    {
        "id": "archimedes", "title": 'Archimedes', "partner": "Archimedes", "avatar": "Α", "requires": "aoryst",
        "turns": [
            {"bot": ["εὕρηκα", "!"], "en": 'I have found it!',
             "options": [(["τί", "εὗρες", ";"], True, None),
                         (["τί", "ἔγραψα", ";"], False, 'ἔγραψα means “I wrote”. Ask what he found: τί εὗρες;')]},
            {"bot": ["τί", "εἶδες", ";"], "en": 'And what did you see?',
             "build": (["ἦλθον", "καί", "εἶδον"], 'I came and I saw.')},
        ],
    },
]

CHAT_EXTRA = {
    "τίς": 'who?', "ναί": 'yes', "ἀκούεις": 'you hear', "οἶδας": 'you know', "οἶδε": 'knows',
    "εὖ": 'well', "ἐστι": 'is (unaccented)', "σοφία": 'wisdom', "εὗρες": 'you found',
    "εἶδες": 'you saw', "οὐ": 'not',
}
PUNCT = set(",.;·!")
ENCLITICS = {"σου", "μου", "ἐστι", "τις", "τι"}
NO_GRAVE = {"τί", "τίς"}


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['ἐγώ', 'σύ', 'αὐτός', 'ἡμεῖς', 'ὑμεῖς', 'αὐτοί'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'wołacz lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.'],
    'part': ['part. praes. act. (m.)', 'part. praes. act. (ż.)', 'part. praes. act. (n.)', 'part. praes. med.-pass.', 'part. aor. act.', 'part. aor. pass.'],
    'przyp8': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.'],
    'inf': ['inf. praes. act.', 'inf. praes. med.-pass.', 'inf. aor. act.', 'inf. aor. pass.', 'inf. fut. act.'],
    'stopn3': ['stopień równy', 'stopień wyższy', 'stopień najwyższy'],
    'przyp4': ['mianownik', 'dopełniacz', 'celownik', 'biernik'],
    't_art': ['λόγος (słowo)', 'ἀρχή (początek)', 'ἔργον (dzieło)', 'ἡμέρα (dzień)', 'πατήρ (ojciec)', 'ὄνομα (imię)', 'θάλασσα (morze)', 'ἄνθρωπος (człowiek)'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'λύω (rozwiązuję)', 'os', 'λύω; λύεις; λύει; λύομεν; λύετε; λύουσι(ν)', 'Końcówki: -ω, -εις, -ει, -ομεν, -ετε, -ουσι(ν).'),
    ('conj', 'Wzory koniugacji', 'λέγω (mówię)', 'os', 'λέγω; λέγεις; λέγει; λέγομεν; λέγετε; λέγουσι(ν)', None),
    ('conj', 'Wzory koniugacji', 'ἔχω (mam)', 'os', 'ἔχω; ἔχεις; ἔχει; ἔχομεν; ἔχετε; ἔχουσι(ν)', None),
    ('conj', 'Wyjątki', 'φιλέω (kocham): ściągnięty na -έω', 'os', 'φιλῶ; φιλεῖς; φιλεῖ; φιλοῦμεν; φιλεῖτε; φιλοῦσι(ν)', 'ε zlewa się z końcówką: ε + ο → ου, ε + ε → ει.'),
    ('conj', 'Wyjątki', 'ἀγαπάω (miłuję): ściągnięty na -άω', 'os', 'ἀγαπῶ; ἀγαπᾷς; ἀγαπᾷ; ἀγαπῶμεν; ἀγαπᾶτε; ἀγαπῶσι(ν)', 'α + ο → ω, α + ε → α.'),
    ('conj', 'Czasowniki nieregularne', 'εἰμί (jestem)', 'os', 'εἰμί; εἶ; ἐστί(ν); ἐσμέν; ἐστέ; εἰσί(ν)', None),
    ('conj', 'Czasowniki nieregularne', 'δίδωμι (daję)', 'os', 'δίδωμι; δίδως; δίδωσι(ν); δίδομεν; δίδοτε; διδόασι(ν)', 'Czasownik na -μι: własne końcówki.'),
    ('conj', 'Strona medialna', 'λύομαι', 'os', 'λύομαι; λύῃ; λύεται; λυόμεθα; λύεσθε; λύονται', 'Końcówki: -ομαι, -ῃ, -εται, -όμεθα, -εσθε, -ονται.'),
    ('conj', 'Czas przeszły', 'λύω: imperfectum', 'os', 'ἔλυον; ἔλυες; ἔλυε(ν); ἐλύομεν; ἐλύετε; ἔλυον', 'Augment ἐ- na początku.'),
    ('conj', 'Czas przeszły', 'λύω: aoryst', 'os', 'ἔλυσα; ἔλυσας; ἔλυσε(ν); ἐλύσαμεν; ἐλύσατε; ἔλυσαν', 'Augment ἐ- i znak -σα-.'),
    ('decl', 'Wzory deklinacji', 'ὁ λόγος (słowo): II deklinacja', 'przyp', 'ὁ λόγος; τοῦ λόγου; τῷ λόγῳ; τὸν λόγον; ὦ λόγε; οἱ λόγοι; τῶν λόγων; τοῖς λόγοις; τοὺς λόγους', None),
    ('decl', 'Wzory deklinacji', 'τὸ ἔργον (dzieło): II deklinacja, nijaki', 'przyp', 'τὸ ἔργον; τοῦ ἔργου; τῷ ἔργῳ; τὸ ἔργον; ὦ ἔργον; τὰ ἔργα; τῶν ἔργων; τοῖς ἔργοις; τὰ ἔργα', 'Nijakie: mianownik = biernik, w lm. na -α.'),
    ('decl', 'Wzory deklinacji', 'ἡ ἀρχή (początek): I deklinacja na -η', 'przyp', 'ἡ ἀρχή; τῆς ἀρχῆς; τῇ ἀρχῇ; τὴν ἀρχήν; ὦ ἀρχή; αἱ ἀρχαί; τῶν ἀρχῶν; ταῖς ἀρχαῖς; τὰς ἀρχάς', None),
    ('decl', 'Wzory deklinacji', 'ἡ ἡμέρα (dzień): I deklinacja na -α', 'przyp', 'ἡ ἡμέρα; τῆς ἡμέρας; τῇ ἡμέρᾳ; τὴν ἡμέραν; ὦ ἡμέρα; αἱ ἡμέραι; τῶν ἡμερῶν; ταῖς ἡμέραις; τὰς ἡμέρας', 'Po ε, ι, ρ α zostaje we wszystkich przypadkach.'),
    ('decl', 'Wyjątki', 'ἡ θάλασσα (morze)', 'przyp', 'ἡ θάλασσα; τῆς θαλάσσης; τῇ θαλάσσῃ; τὴν θάλασσαν; ὦ θάλασσα; αἱ θάλασσαι; τῶν θαλασσῶν; ταῖς θαλάσσαις; τὰς θαλάσσας', 'Krótkie α: w dopełniaczu i celowniku lp. przechodzi w η.'),
    ('decl', 'Wyjątki', 'ὁ πατήρ (ojciec): III deklinacja', 'przyp', 'ὁ πατήρ; τοῦ πατρός; τῷ πατρί; τὸν πατέρα; ὦ πάτερ; οἱ πατέρες; τῶν πατέρων; τοῖς πατράσι(ν); τοὺς πατέρας', None),
    ('decl', 'Wyjątki', 'τὸ ὄνομα (imię): III deklinacja, nijaki', 'przyp', 'τὸ ὄνομα; τοῦ ὀνόματος; τῷ ὀνόματι; τὸ ὄνομα; ὦ ὄνομα; τὰ ὀνόματα; τῶν ὀνομάτων; τοῖς ὀνόμασι(ν); τὰ ὀνόματα', 'Temat na -ματ-.'),
    ('form', 'Imiesłowy', 'λύω (rozwiązuję)', 'part', 'λύων; λύουσα; λῦον; λυόμενος; λύσας; λυθείς', 'Imiesłowy są w grece wszechobecne: zastępują zdania podrzędne.'),
    ('form', 'Imiesłowy', 'λέγω (mówię)', 'part', 'λέγων; λέγουσα; λέγον; λεγόμενος; λέξας; λεχθείς', None),
    ('decl', 'Imiesłowy: odmiana', 'ὁ λύων (rozwiązujący)', 'przyp8', 'ὁ λύων; τοῦ λύοντος; τῷ λύοντι; τὸν λύοντα; οἱ λύοντες; τῶν λυόντων; τοῖς λύουσι(ν); τοὺς λύοντας', 'Odmiana według III deklinacji, temat λυοντ-.'),
    ('form', 'Bezokoliczniki', 'λύω', 'inf', 'λύειν; λύεσθαι; λῦσαι; λυθῆναι; λύσειν', None),
    ('conj', 'Czas przyszły', 'λύω: futurum', 'os', 'λύσω; λύσεις; λύσει; λύσομεν; λύσετε; λύσουσι(ν)', 'Znak -σ- przed końcówką.'),
    ('conj', 'Czas przeszły', 'λαμβάνω (biorę): aoryst II', 'os', 'ἔλαβον; ἔλαβες; ἔλαβε(ν); ἐλάβομεν; ἐλάβετε; ἔλαβον', 'Aoryst II: inny temat (λαβ-) i końcówki imperfectum.'),
    ('conj', 'Strona bierna', 'λύω: aoryst bierny', 'os', 'ἐλύθην; ἐλύθης; ἐλύθη; ἐλύθημεν; ἐλύθητε; ἐλύθησαν', 'Znak -θη-.'),
    ('conj', 'Wyjątki', 'δηλόω (pokazuję): ściągnięty na -όω', 'os', 'δηλῶ; δηλοῖς; δηλοῖ; δηλοῦμεν; δηλοῦτε; δηλοῦσι(ν)', None),
    ('form', 'Stopniowanie', 'σοφός (mądry)', 'stopn3', 'σοφός; σοφώτερος; σοφώτατος', 'Regularnie: -τερος, -τατος.'),
    ('form', 'Stopniowanie', 'ἀγαθός (dobry)', 'stopn3', 'ἀγαθός; ἀμείνων; ἄριστος', None),
    ('form', 'Stopniowanie', 'μέγας (wielki)', 'stopn3', 'μέγας; μείζων; μέγιστος', None),
    ('form', 'Stopniowanie', 'κακός (zły)', 'stopn3', 'κακός; κακίων; κάκιστος', None),
    ('decl', 'Zaimki', 'ἐγώ (ja)', 'przyp4', 'ἐγώ; ἐμοῦ; ἐμοί; ἐμέ', None),
    ('decl', 'Zaimki', 'σύ (ty)', 'przyp4', 'σύ; σοῦ; σοί; σέ', None),
    ('form', 'Typowe trudności', 'Rodzajnik: ὁ, ἡ czy τό?', 't_art', 'ὁ; ἡ; τό; ἡ; ὁ; τό; ἡ; ὁ', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['ὁ', 'τοῦ', 'τῷ', 'τόν', 'οἱ', 'τῶν', 'τοῖς', 'τούς'],
    't_m1': ['λέγω (mówię)', 'λαμβάνω (biorę)', 'ὁράω (widzę)', 'ἔρχομαι (idę)', 'ἔχω (mam)', 'φέρω (niosę)'],
    't_m2': ['ὁ', 'ἡμέρα', 'ἄνθρωπος', 'ὕδωρ', 'ἐγώ', 'ὑμεῖς', 'ἀρχή', 'ἑπτά'],
    't_m3': ['λύω', 'λύομαι', 'λύει', 'λύεται', 'λύουσι(ν)', 'λύονται'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Rodzajnik: jaki przypadek?', 't_m0', 'mianownik lp.; dopełniacz lp.; celownik lp.; biernik lp.; mianownik lm.; dopełniacz lm.; celownik lm.; biernik lm.', 'Rodzajnik jest najlepszą wskazówką przypadku.'),
    ('form', 'Typowe trudności', 'Aoryst: inny temat', 't_m1', 'εἶπον; ἔλαβον; εἶδον; ἦλθον; ἔσχον; ἤνεγκον', 'Najczęstsze czasowniki mają w aoryście zupełnie inny temat.'),
    ('form', 'Typowe trudności', 'Przydech: mocny czy słaby?', 't_m2', 'mocny (h); mocny (h); słaby; mocny (h); słaby; mocny (h); słaby; mocny (h)', 'Znak zwrócony jak ʽ to mocny przydech (h), jak ʼ słaby. Początkowe υ ma zawsze mocny.'),
    ('form', 'Typowe trudności', 'Strona: czynna czy medialno-bierna?', 't_m3', 'czynna; medialno-bierna; czynna; medialno-bierna; czynna; medialno-bierna', 'Końcówki -μαι, -ται, -νται oznaczają stronę medialną lub bierną.'),
]

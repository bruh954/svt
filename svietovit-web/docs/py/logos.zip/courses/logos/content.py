"""Treść kursu: greka starożytna (attycka i koine) dla Polaków.

Słowo:     (forma z akcentem, znaczenie po polsku, polskie słowo z greki lub None, skojarzenie lub None)
Litera:    (litera lub dwuznak, jak czytać, nazwa)
Zdanie:    (lista słów w formie słownikowej, tłumaczenie, {pułapka: wyjaśnienie})
           Akcent ostry na końcu słowa zmienia się sam w ciężki (ὸ), gdy po nim stoi
           kolejne słowo (engine.display).
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź, wyjaśnienie, dział)

Wymowa (pole „tr”) powstaje automatycznie: wymowa erazmiańska zapisana po polsku.
"""

UNITS = [
    # ---------------------------------------------------------------- alfabet
    {
        "id": "alfa1", "title": "Alfabet I", "icon": "Α", "track": "pismo",
        "letters": [
            ("α", "[a]", "ἄλφα"), ("β", "[b]", "βῆτα"), ("γ", "[ɡ]", "γάμμα"), ("δ", "[d]", "δέλτα"),
            ("ε", "[e] (krótkie)", "ἒ ψιλόν"), ("ζ", "[zd] (szkolnie dz)", "ζῆτα"), ("η", "[ɛː] (długie e)", "ἦτα"),
            ("θ", "[tʰ] (szkolnie th)", "θῆτα"), ("ι", "[i]", "ἰῶτα"), ("κ", "[k]", "κάππα"), ("λ", "[l]", "λάμβδα"),
            ("μ", "[m]", "μῦ"),
        ],
    },
    {
        "id": "alfa2", "title": "Alfabet II", "icon": "Ω", "track": "pismo",
        "letters": [
            ("ν", "[n]", "νῦ"), ("ξ", "[ks]", "ξεῖ"), ("ο", "[o] (krótkie)", "ὂ μικρόν"),
            ("π", "[p]", "πεῖ"), ("ρ", "[r]", "ῥῶ"), ("σ", "[s]", "σίγμα"),
            ("ς", "[s] na końcu słowa", "σίγμα τελικόν"), ("τ", "[t]", "ταῦ"), ("υ", "[y] (szkolnie y)", "ὖ ψιλόν"),
            ("φ", "[pʰ] (szkolnie f)", "φεῖ"), ("χ", "[kʰ] (szkolnie ch)", "χεῖ"), ("ψ", "[ps]", "ψεῖ"),
            ("ω", "[ɔː] (długie o)", "ὦ μέγα"),
        ],
    },
    {
        "id": "alfa3", "title": "Znaki i dwugłoski", "icon": "ἁ", "track": "pismo",
        "letters": [
            ("ἁ", "[h] na początku słowa (ἁ = ha)", "δασεῖα"),
            ("ἀ", "brak dźwięku (ἀ = a)", "ψιλή"),
            ("ά", "akcent tonalny: dawna melodia, czytaj zwyczajnie", "ὀξεῖα"),
            ("ᾳ", "jota pod spodem: dawniej [i], dziś niewymawiana", "ὑπογεγραμμένη"),
            ("αι", "[ai̯] (szkolnie aj)", "δίφθογγος"), ("ει", "[eː] (szkolnie ej)", "δίφθογγος"),
            ("οι", "[oi̯] (szkolnie oj)", "δίφθογγος"), ("ου", "[uː]", "δίφθογγος"),
            ("αυ", "[au̯]", "δίφθογγος"), ("ευ", "[eu̯]", "δίφθογγος"),
            ("γγ", "[ŋɡ]: ἄγγελος czytaj „angelos”", "γάμμα"),
        ],
    },
    {
        "id": 'wielkie1', "title": 'Wielkie litery I', "icon": 'Δ', "track": "pismo",
        "letters": [
            ('Α', '[a] (wielkie α)', 'ἄλφα'),
            ('Β', '[b] (wielkie β)', 'βῆτα'),
            ('Γ', '[ɡ] (wielkie γ)', 'γάμμα'),
            ('Δ', '[d] (wielkie δ)', 'δέλτα'),
            ('Ε', '[e] (wielkie ε)', 'ἒ ψιλόν'),
            ('Ζ', '[zd] (wielkie ζ)', 'ζῆτα'),
            ('Η', '[ɛː] (wielkie η)', 'ἦτα'),
            ('Θ', '[tʰ] (wielkie θ)', 'θῆτα'),
            ('Ι', '[i] (wielkie ι)', 'ἰῶτα'),
            ('Κ', '[k] (wielkie κ)', 'κάππα'),
            ('Λ', '[l] (wielkie λ)', 'λάμβδα'),
            ('Μ', '[m] (wielkie μ)', 'μῦ'),
        ],
    },
    {
        "id": 'wielkie2', "title": 'Wielkie litery II', "icon": 'Σ', "track": "pismo",
        "letters": [
            ('Ν', '[n] (wielkie ν)', 'νῦ'),
            ('Ξ', '[ks] (wielkie ξ)', 'ξεῖ'),
            ('Ο', '[o] (wielkie ο)', 'ὂ μικρόν'),
            ('Π', '[p] (wielkie π)', 'πεῖ'),
            ('Ρ', '[r] (wielkie ρ)', 'ῥῶ'),
            ('Σ', '[s] (wielkie σ)', 'σίγμα'),
            ('Τ', '[t] (wielkie τ)', 'ταῦ'),
            ('Υ', '[y] (wielkie υ)', 'ὖ ψιλόν'),
            ('Φ', '[pʰ] (wielkie φ)', 'φεῖ'),
            ('Χ', '[kʰ] (wielkie χ)', 'χεῖ'),
            ('Ψ', '[ps] (wielkie ψ)', 'ψεῖ'),
            ('Ω', '[ɔː] (wielkie ω)', 'ὦ μέγα'),
        ],
    },
    {
        "id": 'akcenty2', "title": 'Akcenty i duchy II', "icon": 'ᾶ', "track": "pismo",
        "letters": [
            ('ὰ', 'akcent „ciężki” (gravis): ostry w środku zdania zmienia się w ciężki, czytaj zwyczajnie', 'βαρεῖα'),
            ('ᾶ', 'okółek (circumflex) na długiej samogłosce: dawny dźwięk opadająco-wznoszący', 'περισπωμένη'),
            ('ἄ', 'duch słaby i akcent ostry razem: ἄ = a', 'ψιλὴ καὶ ὀξεῖα'),
            ('ἅ', 'duch mocny i akcent ostry razem: ἅ = ha', 'δασεῖα καὶ ὀξεῖα'),
            ('ὁ', '[ho]: rodzajnik „ten”, duch mocny na początku', 'ὁ'),
            ('ἡ', '[hɛː]: rodzajnik „ta”', 'ἡ'),
            ('οὐ', '[uː]: „nie”, duch słaby nic nie zmienia', 'οὐ'),
            ('ῥ', '[rh]: ρ na początku słowa zawsze ma duch mocny', 'ῥῶ'),
            ('ϊ', 'kropki nad ι: samogłoski czytaj osobno (ἀϊ)', 'διαλυτικά'),
            ('ῃ', '[ɛː]: η z jotą pod spodem, jota nie brzmi', 'ἦτα ὑπογεγραμμένη'),
            ('ῳ', '[ɔː]: ω z jotą pod spodem, jota nie brzmi', 'ὦ ὑπογεγραμμένη'),
        ],
    },
    {
        "id": 'grupy2', "title": 'Dwugłoski i grupy II', "icon": 'γκ', "track": "pismo",
        "letters": [
            ('υι', '[yi̯]: υἱός czytaj „huios” (syn)', 'δίφθογγος'),
            ('ηυ', '[ɛːu̯]: ηὗρον czytaj „ēuron”', 'δίφθογγος'),
            ('γκ', '[ŋk]: ἄγκυρα czytaj „ankyra”', 'γάμμα κάππα'),
            ('γξ', '[ŋks]: σάλπιγξ czytaj „salpinks”', 'γάμμα ξεῖ'),
            ('γχ', '[ŋkʰ]: ἄγχω czytaj „ankhō”', 'γάμμα χεῖ'),
            ('ρρ', '[rː]: podwójne r (ἄρρην)', 'ῥῶ ῥῶ'),
            ('σσ', '[ss]: θάλασσα; w Attyce często ττ', 'σίγμα σίγμα'),
            ('ττ', '[tt]: θάλαττα, wariant attycki', 'ταῦ ταῦ'),
            ('μμ', '[mm]: γράμμα', 'μῦ μῦ'),
            ('λλ', '[ll]: ἄλλος', 'λάμβδα λάμβδα'),
        ],
    },
    {
        "id": 'liczby1', "title": 'Liczby literowe I', "icon": 'αʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('αʹ', '1', 'ἄλφα'),
            ('βʹ', '2', 'βῆτα'),
            ('γʹ', '3', 'γάμμα'),
            ('δʹ', '4', 'δέλτα'),
            ('εʹ', '5', 'ἒ ψιλόν'),
            ('ϛʹ', '6', 'στῖγμα'),
            ('ζʹ', '7', 'ζῆτα'),
            ('ηʹ', '8', 'ἦτα'),
            ('θʹ', '9', 'θῆτα'),
        ],
    },
    {
        "id": 'liczby2', "title": 'Liczby literowe II', "icon": 'ιʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('ιʹ', '10', 'ἰῶτα'),
            ('κʹ', '20', 'κάππα'),
            ('λʹ', '30', 'λάμβδα'),
            ('μʹ', '40', 'μῦ'),
            ('νʹ', '50', 'νῦ'),
            ('ξʹ', '60', 'ξεῖ'),
            ('οʹ', '70', 'ὂ μικρόν'),
            ('πʹ', '80', 'πεῖ'),
            ('ϙʹ', '90', 'κόππα'),
        ],
    },
    {
        "id": 'liczby3', "title": 'Liczby literowe III', "icon": 'ρʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('ρʹ', '100', 'ῥῶ'),
            ('σʹ', '200', 'σίγμα'),
            ('τʹ', '300', 'ταῦ'),
            ('υʹ', '400', 'ὖ ψιλόν'),
            ('φʹ', '500', 'φεῖ'),
            ('χʹ', '600', 'χεῖ'),
            ('ψʹ', '700', 'ψεῖ'),
            ('ωʹ', '800', 'ὦ μέγα'),
            ('ϡʹ', '900', 'σαμπῖ'),
        ],
    },
    {
        "id": 'archaiczne', "title": 'Litery dawne i warianty', "icon": 'ϝ', "track": "pismo",
        "letters": [
            ('ϝ', '[w]: dawna litera, digamma („podwójne gamma”), znikła z greki przed epoką klasyczną', 'δίγαμμα'),
            ('ϙ', '[k]: dawna litera, dziś tylko liczba 90', 'κόππα'),
            ('ϛ', '[st]: ligatura σ i τ, dziś tylko liczba 6', 'στῖγμα'),
            ('ϡ', 'dawna litera, dziś tylko liczba 900', 'σαμπῖ'),
            ('ϲ', '[s]: sigma w kształcie C, w rękopisach i napisach', 'λουνατὸν σίγμα'),
            ('Ϲ', '[s]: wielka sigma w kształcie C', 'λουνατὸν σίγμα'),
            ('ϑ', 'wariant θ, w druku i matematyce: [tʰ]', 'θῆτα'),
            ('ϕ', 'wariant φ, w druku i matematyce: [pʰ]', 'φεῖ'),
            ('ϖ', 'wariant π: [p]', 'πεῖ'),
            ('ϐ', 'wariant β w rękopisach: [b]', 'βῆτα'),
        ],
    },
    # ----------------------------------------------------------------- język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "Β", "track": "jezyk", "requires": "alfa2",
        "words": [
            ("χαῖρε", "witaj; bywaj", None, "Dosłownie „ciesz się”. Grecy tak się witali i żegnali."),
            ("ἐγώ", "ja", "egoizm", None),
            ("σύ", "ty", None, None),
            ("καί", "i; także", None, None),
            ("εἶ", "jesteś", None, None),
            ("εἰμί", "jestem", None, "Słowo „enklityczne”: często traci akcent i opiera się o poprzednie."),
            ("ἐστί", "jest", None, None),
            ("ὁ", "ten (rodzajnik męski)", "ten", "Rodzajnik to dawny zaimek wskazujący, jak polskie „ten, ta, to”."),
            ("ἡ", "ta (rodzajnik żeński)", "ta", None),
            ("τό", "to (rodzajnik nijaki)", "to", None),
            ("φίλος", "przyjaciel; miły", "filozofia", "Filozof = przyjaciel mądrości, Filip = miłośnik koni."),
            ("ἄνθρωπος", "człowiek", "antropologia", None),
            ("καλός", "piękny; dobry", "kaligrafia", "Kaligrafia = piękne pisanie."),
            ("ἀγαθός", "dobry", "Agata", "Agata to „dobra” (ἀγαθή)."),
            ("μέγας", "wielki", "megafon", None),
        ],
        "sentences": [
            (["ὁ", "φίλος", "ἀγαθός"], "Przyjaciel jest dobry.",
             {"ἐστί": "Grecy często pomijają „jest”: ὁ φίλος ἀγαθός = przyjaciel (jest) dobry."}),
            (["σύ", "εἶ", "φίλος"], "Jesteś przyjacielem.",
             {"εἰμί": "εἰμί to „jestem”. Do „ty”: εἶ."}),
            (["ὁ", "ἄνθρωπος", "καλός"], "Człowiek jest piękny.", {"ἡ": "ἄνθρωπος jest męski: ὁ."}),
            (["ὁ", "φίλος", "μέγας"], "Przyjaciel jest wielki.", {}),
        ],
    },
    {
        "id": "dom", "title": "Rodzina", "icon": "Γ", "track": "jezyk",
        "words": [
            ("πατήρ", "ojciec", "patriota", "Patriota: ten, kto kocha ziemię ojców (πατρίς)."),
            ("μήτηρ", "matka", "metropolia", "Metropolia = miasto-matka."),
            ("υἱός", "syn", None, None),
            ("θυγάτηρ", "córka", None, "Ten sam praindoeuropejski wyraz co angielskie daughter."),
            ("ἀδελφός", "brat", "Filadelfia", "Filadelfia = miłość braterska."),
            ("ἀδελφή", "siostra", None, None),
            ("ἀνήρ", "mąż; mężczyzna", "Andrzej", "Andrzej (Ἀνδρέας) to „męski”."),
            ("γυνή", "kobieta; żona", "ginekologia", None),
            ("παῖς", "dziecko", "pedagog", "Pedagog to „prowadzący dziecko”."),
            ("οἶκος", "dom", "ekonomia", "Ekonomia = zarządzanie domem."),
            ("διδάσκαλος", "nauczyciel", "dydaktyka", None),
            ("ἐμός", "mój", None, None),
            ("ἐμή", "moja", None, None),
            ("καλή", "piękna", None, None),
        ],
        "sentences": [
            (["ὁ", "πατήρ", "ἀγαθός"], "Ojciec jest dobry.", {"ἡ": "πατήρ jest męski: ὁ."}),
            (["ἡ", "μήτηρ", "καλή"], "Matka jest piękna.", {"καλός": "μήτηρ jest żeńska: καλή."}),
            (["ὁ", "ἐμός", "πατήρ", "ἀγαθός"], "Mój ojciec jest dobry.",
             {"ἐμή": "πατήρ jest męski: ἐμός."}),
            (["ἡ", "ἐμή", "μήτηρ", "καλή"], "Moja matka jest piękna.", {"ἐμός": "μήτηρ jest żeńska: ἐμή."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "Δ", "track": "jezyk",
        "words": [
            ("εἷς", "jeden", None, None),
            ("δύο", "dwa", "dylemat", "Dylemat: dwa (δι-) założenia."),
            ("τρεῖς", "trzy", "trylogia", None),
            ("τέτταρες", "cztery", "tetralogia", None),
            ("πέντε", "pięć", "pentagon", None),
            ("ἕξ", "sześć", "heksagon", None),
            ("ἑπτά", "siedem", "heptagon", None),
            ("ὀκτώ", "osiem", "oktaedr", None),
            ("ἐννέα", "dziewięć", "enneagram", None),
            ("δέκα", "dziesięć", "dekada", None),
            ("ἑκατόν", "sto", "hekatomba", "Hekatomba: ofiara ze stu wołów."),
            ("ἀδελφοί", "bracia", None, None),
            ("φίλοι", "przyjaciele", None, None),
        ],
        "sentences": [
            (["δύο", "ἀδελφοί"], "Dwaj bracia.", {"ἀδελφός": "Dwaj: liczba mnoga, ἀδελφοί."}),
            (["τρεῖς", "φίλοι"], "Trzej przyjaciele.", {"φίλος": "Trzej: φίλοι."}),
        ],
    },
    {
        "id": "swiat", "title": "Świat", "icon": "Ε", "track": "jezyk",
        "words": [
            ("ἥλιος", "słońce", "hel", "Hel odkryto w widmie Słońca."),
            ("σελήνη", "księżyc", "selen", None),
            ("γῆ", "ziemia", "geografia", None),
            ("θάλασσα", "morze", "talasoterapia", None),
            ("οὐρανός", "niebo", "Uran", None),
            ("ὕδωρ", "woda", "hydraulika", None),
            ("πῦρ", "ogień", "pirotechnika", None),
            ("λίθος", "kamień", "litografia", None),
            ("φῶς", "światło", "fotografia", None),
            ("κόσμος", "świat; porządek", "kosmos; kosmetyka", "Kosmetyka = porządkowanie wyglądu."),
            ("χρόνος", "czas", "chronologia", None),
            ("βίος", "życie", "biologia", None),
            ("ἐν", "w; na", None, None),
            ("τῷ", "(w) tym (celownik)", None, None),
            ("οὐρανῷ", "(na) niebie", None, None),
        ],
        "sentences": [
            (["ὁ", "ἥλιος", "ἐν", "τῷ", "οὐρανῷ"], "Słońce jest na niebie.",
             {"οὐρανός": "Gdzie? Po ἐν celownik: τῷ οὐρανῷ."}),
            (["ἡ", "θάλασσα", "καλή"], "Morze jest piękne.", {"καλός": "θάλασσα jest żeńska: καλή."}),
            (["ὁ", "βίος", "καλός"], "Życie jest piękne.", {}),
        ],
    },
    {
        "id": "czas", "title": "Czasowniki", "icon": "Ζ", "track": "jezyk",
        "words": [
            ("γράφω", "piszę", "grafika", None),
            ("γράφεις", "piszesz", None, None),
            ("γράφει", "pisze", None, None),
            ("λέγω", "mówię", "leksykon", None),
            ("λέγεις", "mówisz", None, None),
            ("ἀκούω", "słyszę", "akustyka", None),
            ("βλέπω", "widzę", None, None),
            ("ἔχω", "mam", None, None),
            ("τί", "co?", None, "Pytające τί nigdy nie zmienia akcentu."),
            ("βιβλίον", "książka", "biblioteka", None),
            ("τόν", "tego (biernik)", None, None),
            ("φίλον", "przyjaciela (biernik)", None, None),
        ],
        "sentences": [
            (["γράφω", "βιβλίον"], "Piszę książkę.",
             {"γράφει": "γράφει to „pisze” (on). O sobie: γράφω, -ω jak polskie -ę."}),
            (["τί", "λέγεις", ";"], "Co mówisz?", {"λέγω": "Pytasz kogoś: λέγεις (-εις jak -sz)."}),
            (["ὁ", "διδάσκαλος", "γράφει"], "Nauczyciel pisze.", {"γράφω": "On: γράφει."}),
            (["ἀκούω", "τόν", "φίλον"], "Słyszę przyjaciela.",
             {"φίλος": "Kogo słyszę? Biernik: τὸν φίλον."}),
        ],
    },
    {
        "id": "przypadki", "title": "Przypadki", "icon": "Η", "track": "jezyk",
        "words": [
            ("λόγος", "słowo; rozum", "logika", "Stąd -logia: biologia = nauka o życiu."),
            ("θεός", "bóg", "teologia", None),
            ("θεοῦ", "boga (dopełniacz)", None, None),
            ("θεόν", "boga (biernik)", None, None),
            ("τοῦ", "tego (dopełniacz)", None, None),
            ("φίλε", "przyjacielu! (wołacz)", None, "Wołacz na -ε, jak polskie „Boże!”."),
            ("ὦ", "o! (przed wołaczem)", None, None),
        ],
        "sentences": [
            (["χαῖρε", ",", "ὦ", "φίλε"], "Witaj, przyjacielu!",
             {"φίλος": "Zwracasz się do kogoś: wołacz φίλε."}),
            (["ὁ", "λόγος", "τοῦ", "θεοῦ"], "Słowo Boga.", {"θεός": "Czyje słowo? Dopełniacz: τοῦ θεοῦ."}),
        ],
    },
    {
        "id": "aoryst", "title": "Czas przeszły", "icon": "Θ", "track": "jezyk",
        "words": [
            ("ἔγραψα", "napisałem", None, "ἐ- na początku (augment) oznacza przeszłość."),
            ("ἔγραψε", "napisał", None, None),
            ("εἶπε", "powiedział", None, None),
            ("ἦλθον", "przyszedłem", None, None),
            ("εἶδον", "zobaczyłem", "idea", "Idea (ἰδέα) to „to, co widać”. Ten sam rdzeń."),
            ("ἐνίκησα", "zwyciężyłem", "Nike", None),
            ("ἦν", "był; była; było", None, None),
            ("εὕρηκα", "znalazłem!", "eureka", "Archimedes w wannie: εὕρηκα! (perfekt)."),
        ],
        "sentences": [
            (["εὕρηκα"], "Znalazłem!", {}),
            (["ἦλθον", "καί", "εἶδον"], "Przyszedłem i zobaczyłem.", {}),
            (["ὁ", "διδάσκαλος", "εἶπε"], "Nauczyciel powiedział.", {}),
            (["ἔγραψα", "βιβλίον"], "Napisałem książkę.", {"γράφω": "W przeszłości: ἔγραψα (napisałem)."}),
        ],
    },
    # --------------------------------------------------------------- sentencje
    {
        "id": "sent", "title": "Sentencje", "icon": "Ι", "track": "sentencje", "requires": "czas",
        "words": [
            ("γνῶθι", "poznaj", "diagnoza", None),
            ("σεαυτόν", "samego siebie", None, None),
            ("πάντα", "wszystko", "panorama", None),
            ("ῥεῖ", "płynie", "reumatyzm", None),
            ("μηδέν", "nic (nie)", None, None),
            ("ἄγαν", "zbyt; za bardzo", None, None),
            ("ἕν", "jedno; jedną rzecz", None, None),
            ("οἶδα", "wiem", None, None),
            ("ὅτι", "że", None, None),
            ("οὐδέν", "nic", None, None),
        ],
        "sentences": [
            (["γνῶθι", "σεαυτόν"], "Poznaj samego siebie.", {}),
            (["πάντα", "ῥεῖ"], "Wszystko płynie.", {}),
            (["μηδέν", "ἄγαν"], "Nic ponad miarę.", {}),
            (["ἕν", "οἶδα", "ὅτι", "οὐδέν", "οἶδα"], "Wiem, że nic nie wiem.", {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "pater", "title": "Ojcze nasz", "icon": "Κ", "track": "teksty", "requires": "przypadki",
        "words": [
            ("πάτερ", "ojcze! (wołacz)", None, None),
            ("ἡμῶν", "nasz (dosł. „nas”)", None, None),
            ("τοῖς", "tych (celownik l.mn.)", None, None),
            ("οὐρανοῖς", "niebiosach", None, None),
            ("ἁγιασθήτω", "niech będzie uświęcone", "hagiografia", None),
            ("ὄνομά", "imię", "anonim", "Przed σου dostaje drugi akcent: ὄνομα → ὄνομά σου."),
            ("σου", "twój (dosł. „ciebie”)", None, "Enklityka: bez akcentu."),
            ("ἐλθέτω", "niech przyjdzie", None, None),
            ("βασιλεία", "królestwo", "bazylika", "Bazylika = budowla „królewska”."),
            ("γενηθήτω", "niech się stanie", "geneza", None),
            ("θέλημά", "wola", None, None),
            ("ὡς", "jak; jako", None, None),
            ("ἐπί", "na", "epicentrum", None),
            ("γῆς", "ziemi (dopełniacz)", None, None),
        ],
        "sentences": [
            (["πάτερ", "ἡμῶν", "ὁ", "ἐν", "τοῖς", "οὐρανοῖς"], "Ojcze nasz, który jesteś w niebie.", {}),
            (["ἁγιασθήτω", "τό", "ὄνομά", "σου"], "Święć się imię Twoje.", {}),
            (["ἐλθέτω", "ἡ", "βασιλεία", "σου"], "Przyjdź królestwo Twoje.", {}),
            (["γενηθήτω", "τό", "θέλημά", "σου"], "Bądź wola Twoja.", {}),
            (["ὡς", "ἐν", "οὐρανῷ", "καί", "ἐπί", "γῆς"], "Jako w niebie, tak i na ziemi.", {}),
        ],
    },
    {
        "id": "jan", "title": "Ewangelia Jana", "icon": "Λ", "track": "teksty",
        "words": [
            ("ἀρχῇ", "(na) początku", "archaiczny", None),
            ("πρός", "do; u; przy", None, None),
        ],
        "sentences": [
            (["ἐν", "ἀρχῇ", "ἦν", "ὁ", "λόγος"], "Na początku było Słowo.", {}),
            (["καί", "ὁ", "λόγος", "ἦν", "πρός", "τόν", "θεόν"], "A Słowo było u Boga.", {}),
            (["καί", "θεός", "ἦν", "ὁ", "λόγος"], "I Bogiem było Słowo.", {}),
        ],
    },
]

TRACKS = {
    "pismo": "ΓΡΑΜΜΑΤΑ · PISMO",
    "jezyk": "ΓΛΩΣΣΑ · JĘZYK",
    "sentencje": "ΓΝΩΜΑΙ · SENTENCJE",
    "teksty": "ΚΕΙΜΕΝΑ · TEKSTY",
}

INSIGHTS = {
    "alfa1": [
        {"title": "Znasz połowę z matematyki",
         "text": "α, β, γ, δ, λ, μ, π: znasz je z lekcji. Grecki alfabet dał nam nazwę „alfabet” "
                 "(alfa + beta). η to długie e, a θ to „th”: wymawiaj jak t z wydechem.",
         "chain": []},
    ],
    "alfa2": [
        {"title": "Fałszywi przyjaciele",
         "text": "ν to n, ρ to r, υ to y, χ to ch. Wyglądają jak v, p, u, x, ale nimi nie są. "
                 "σ na końcu słowa pisze się ς. ω to długie o: Ω na końcu alfabetu, stąd „alfa i omega”.",
         "chain": []},
    ],
    "wielkie1": [
        {"title": "Znajome litery, obce dźwięki",
         "text": "Wielkie litery wyglądają jak łacińskie, ale nie wszystkie czytasz tak samo. Β to [b], nie „w”. "
                 "Η to długie e, nie h. Ρ to r, nie p. Χ to ch, nie iks. Υ to y, nie u. Ν to n. "
                 "Wielkich używasz na początku nazw własnych; dawniej pisano nimi cały tekst.",
         "chain": []},
    ],
    "akcenty2": [
        {"title": "Trzy akcenty, jedna melodia",
         "text": "Akcent ostry (ά), ciężki (ὰ) i okółek (ᾶ) to ślady dawnej melodii słów. Dziś czytasz je "
                 "zwyczajnie, ale okółek podpowiada ci, że samogłoska jest długa. Duch mocny i słaby "
                 "stawia się na pierwszej samogłosce słowa; ρ na początku zawsze ma duch mocny: ῥ.",
         "chain": []},
    ],
    "liczby1": [
        {"title": "Litery jako cyfry",
         "text": "Grecy nie mieli osobnych cyfr: liczby pisali literami z kreską u góry po prawej. α΄ = 1, β΄ = 2, "
                 "γ΄ = 3. Alfabet ma 24 litery, ale liczb jest 27, więc doszły trzy dawne litery: ϛ (6), ϙ (90) i ϡ (900). "
                 "Stąd nasze „alfabet” i „alfa i omega” jako początek i koniec.",
         "chain": []},
    ],
    "alfa3": [
        {"title": "Znaczki nad literami",
         "text": "Przydech mocny (ἁ) to h: ἥλιος czytaj „hēlios”, stąd „hel”. Przydech słaby (ἀ) "
                 "nic nie zmienia. Akcenty to dawna melodia: na początek czytaj zwyczajnie. Akcent ostry "
                 "na końcu słowa przed kolejnym słowem pisze się jako ciężki: καλός → καλὸς.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Rodzajnik to polskie „ten, ta, to”",
         "text": "Polski nie ma rodzajnika, greka ma: ὁ, ἡ, τό. To dawny zaimek wskazujący, więc myśl "
                 "o nim jak o „ten, ta, to”: ὁ φίλος = ten przyjaciel. A „jest” Grecy często pomijają: "
                 "ὁ φίλος ἀγαθός = przyjaciel (jest) dobry.",
         "chain": [
             ("Przyjaciel jest dobry.", ["ὁ", "φίλος", "ἀγαθός"], "ὁ (ten) + φίλος + ἀγαθός. Bez „jest”."),
             ("Jesteś przyjacielem.", ["σύ", "εἶ", "φίλος"], "σύ (ty) + εἶ (jesteś) + φίλος."),
         ]},
    ],
    "dom": [
        {"title": "Rodzaj jak w polskim",
         "text": "Męski, żeński, nijaki, jak u nas. καλός, καλή = piękny, piękna. Przymiotnik stawiasz "
                 "między rodzajnikiem a rzeczownikiem: ὁ ἐμὸς πατήρ = (ten) mój ojciec.",
         "chain": [("Mój ojciec jest dobry.", ["ὁ", "ἐμός", "πατήρ", "ἀγαθός"], "ὁ ἐμὸς πατήρ, potem cecha.")]},
    ],
    "liczby": [
        {"title": "Liczby z geometrii",
         "text": "Pentagon, heksagon, dekada, hekatomba: liczby greckie znasz z nazw figur i miar.",
         "chain": [("Dwaj bracia.", ["δύο", "ἀδελφοί"], "δύο + liczba mnoga ἀδελφοί.")]},
    ],
    "swiat": [
        {"title": "Nauka mówi po grecku",
         "text": "Geografia (γῆ), biologia (βίος), fotografia (φῶς), chronologia (χρόνος), hydraulika (ὕδωρ). "
                 "Gdy uczysz się greckiego słowa, szukaj go w polskim słowie naukowym.",
         "chain": [("Słońce jest na niebie.", ["ὁ", "ἥλιος", "ἐν", "τῷ", "οὐρανῷ"],
                    "Gdzie? ἐν + celownik: τῷ οὐρανῷ.")]},
    ],
    "czas": [
        {"title": "-ω, -εις, -ει = -ę, -sz, -",
         "text": "Jak po polsku, osoba siedzi w końcówce: γράφω, γράφεις, γράφει = piszę, piszesz, pisze. "
                 "Zaimka nie potrzebujesz. Pytajnik grecki to średnik: τί λέγεις; = Co mówisz?",
         "chain": [
             ("Piszę książkę.", ["γράφω", "βιβλίον"], "γράφω (piszę) + βιβλίον (biblioteka!)."),
             ("Słyszę przyjaciela.", ["ἀκούω", "τόν", "φίλον"], "Kogo? Biernik: τὸν φίλον."),
         ]},
    ],
    "przypadki": [
        {"title": "Pięć przypadków, wołacz jak u nas",
         "text": "Greka ma mianownik, dopełniacz, celownik, biernik i wołacz. Wołacz działa jak polski: "
                 "ὦ φίλε! = przyjacielu! Dopełniacz: ὁ λόγος τοῦ θεοῦ = słowo Boga.",
         "chain": [("Witaj, przyjacielu!", ["χαῖρε", ",", "ὦ", "φίλε"], "Wołacz φίλε, przed nim ὦ.")]},
    ],
    "aoryst": [
        {"title": "Przeszłość z przodu",
         "text": "Polski oznacza przeszłość z tyłu (pisa-ł), greka z przodu: ἐ- (augment). γράφω → "
                 "ἔγραψα (napisałem). Słynne εὕρηκα Archimedesa to „znalazłem!”.",
         "chain": [("Przyszedłem i zobaczyłem.", ["ἦλθον", "καί", "εἶδον"], "ἦλθον (przyszedłem), εἶδον (zobaczyłem).")]},
    ],
    "sent": [
        {"title": "Mądrość z Delf",
         "text": "γνῶθι σεαυτόν i μηδὲν ἄγαν wyryto w świątyni Apollina w Delfach. πάντα ῥεῖ to późne "
                 "streszczenie myśli Heraklita (pierwszy zapisał je Symplikios, VI w.). „Wiem, że nic nie wiem” "
                 "w tej formie to późniejsza formuła: u Platona (Obrona 21d) Sokrates mówi coś podobnego.",
         "chain": [("Poznaj samego siebie.", ["γνῶθι", "σεαυτόν"], "γνῶθι (poznaj, por. diagnoza) + σεαυτόν.")]},
    ],
    "pater": [
        {"title": "Modlitwa w oryginale",
         "text": "Ewangelia Mateusza (6,9-10) w oryginale. σου (twój) stoi po rzeczowniku, jak w polskim "
                 "„imię Twoje”, i nie ma akcentu: dlatego ὄνομα dostaje drugi akcent (ὄνομά σου).",
         "chain": [("Święć się imię Twoje.", ["ἁγιασθήτω", "τό", "ὄνομά", "σου"],
                    "ἁγιασθήτω (hagiografia!) + τὸ ὄνομά σου.")]},
    ],
    "jan": [
        {"title": "λόγος: słowo i rozum",
         "text": "Jan zaczyna od słowa λόγος, które znaczy i „słowo”, i „rozum, sens”. Stąd logika i "
                 "wszystkie -logie. ἐν ἀρχῇ = na początku (archaiczny!).",
         "chain": [("Na początku było Słowo.", ["ἐν", "ἀρχῇ", "ἦν", "ὁ", "λόγος"], "ἐν ἀρχῇ + ἦν (było) + ὁ λόγος.")]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Końcówka mówi wszystko",
    "text": "Jak w polskim: „widzę przyjaciela”, nie „widzę przyjaciel”. W grece τὸν φίλον. "
            "Zadaj pytanie jak na lekcji polskiego: kto? czyj? komu? kogo? gdzie?",
}

ENDINGS = [
    ("ὁ ", "φίλ", "ος", "", ["ος", "ον", "ου", "ῳ"], "przyjaciel (kto?)", "Mianownik: -ος.", "slowa"),
    ("ἡ μήτηρ ", "καλ", "ή", "", ["ός", "ή", "όν", "οῦ"], "matka jest piękna", "Żeńska: -ή.", "dom"),
    ("ἡ ", "ἀδελφ", "ή", "", ["ός", "ή", "όν", "οί"], "siostra", "Żeńska: -ή.", "dom"),
    ("δύο ", "ἀδελφ", "οί", "", ["ός", "ή", "όν", "οί"], "dwaj bracia", "Liczba mnoga: -οί.", "liczby"),
    ("ἐν τῷ ", "οὐραν", "ῷ", "", ["ός", "όν", "οῦ", "ῷ"], "na niebie (gdzie?)", "Po ἐν celownik: -ῷ.", "swiat"),
    ("", "γράφ", "ω", " βιβλίον", ["ω", "εις", "ει", "ουσι"], "piszę książkę", "Ja: -ω, jak polskie -ę.", "czas"),
    ("σὺ ", "γράφ", "εις", "", ["ω", "εις", "ει", "ουσι"], "ty piszesz", "Ty: -εις, jak polskie -sz.", "czas"),
    ("ὁ διδάσκαλος ", "γράφ", "ει", "", ["ω", "εις", "ει", "ουσι"], "nauczyciel pisze", "On: -ει.", "czas"),
    ("ἀκούω τὸν ", "φίλ", "ον", "", ["ος", "ον", "ου", "ε"], "słyszę przyjaciela (kogo?)", "Biernik: -ον.", "czas"),
    ("ὁ λόγος τοῦ ", "θε", "οῦ", "", ["ός", "όν", "οῦ", "ῷ"], "słowo Boga (czyje?)", "Dopełniacz: -οῦ.", "przypadki"),
    ("χαῖρε, ὦ ", "φίλ", "ε", "", ["ος", "ε", "ον", "ου"], "witaj, przyjacielu!", "Wołacz: -ε.", "przypadki"),
    ("", "ἔγραψ", "α", "", ["α", "ε", "ω", "ον"], "napisałem", "Aoryst, ja: -α.", "aoryst"),
]

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "agora", "title": "Na agorze", "partner": "Kriton", "avatar": "Κ", "requires": "slowa",
        "turns": [
            {"bot": ["χαῖρε", "."], "en": "Witaj!",
             "options": [(["χαῖρε", "."], True, None),
                         (["οὐ", "."], False, "οὐ to „nie”. Odpowiedz pozdrowieniem: χαῖρε.")]},
            {"bot": ["τίς", "εἶ", ";"], "en": "Kim jesteś?",
             "options": [(["φίλος", "εἰμί"], True, None),
                         (["φίλος", "εἶ"], False, "εἶ to „jesteś”. O sobie: εἰμί."),
                         (["φίλος", "ἐστί"], False, "ἐστί to „jest”. O sobie: εἰμί.")],
             "note": "Grecki znak zapytania wygląda jak nasz średnik: ;"},
            {"bot": ["ὁ", "κόσμος", "καλός", "."], "en": "Świat jest piękny.",
             "options": [(["ναί", ",", "ὁ", "κόσμος", "καλός"], True, None),
                         (["ναί", ",", "ὁ", "κόσμος", "καλή"], False, "κόσμος jest męski: καλός.")]},
            {"bot": ["χαῖρε", "."], "en": "Bywaj!", "build": (["χαῖρε"], "Bywaj!")},
        ],
    },
    {
        "id": "szkola", "title": "W szkole", "partner": "Nauczyciel", "avatar": "Δ", "requires": "czas",
        "turns": [
            {"bot": ["τί", "γράφεις", ";"], "en": "Co piszesz?",
             "options": [(["γράφω", "βιβλίον"], True, None),
                         (["γράφει", "βιβλίον"], False, "γράφει to „pisze” (on). O sobie: γράφω."),
                         (["γράφεις", "βιβλίον"], False, "γράφεις to „piszesz”. O sobie: γράφω.")]},
            {"bot": ["τί", "ἀκούεις", ";"], "en": "Co słyszysz?",
             "build": (["ἀκούω", "τόν", "φίλον"], "Słyszę przyjaciela.")},
        ],
    },
    {
        "id": "sokrates", "title": "Sokrates", "partner": "Sokrates", "avatar": "Σ", "requires": "sent",
        "turns": [
            {"bot": ["τί", "οἶδας", ";"], "en": "Co wiesz?",
             "options": [(["ἕν", "οἶδα", "ὅτι", "οὐδέν", "οἶδα"], True, None),
                         (["ἕν", "οἶδε", "ὅτι", "οὐδέν", "οἶδε"], False, "οἶδε to „wie” (on). O sobie: οἶδα.")]},
            {"bot": ["εὖ", "λέγεις", ".", "τί", "ἐστι", "σοφία", ";"], "en": "Dobrze mówisz. Czym jest mądrość?",
             "build": (["γνῶθι", "σεαυτόν"], "Poznaj samego siebie.")},
        ],
    },
    {
        "id": "archimedes", "title": "Archimedes", "partner": "Archimedes", "avatar": "Α", "requires": "aoryst",
        "turns": [
            {"bot": ["εὕρηκα", "!"], "en": "Znalazłem!",
             "options": [(["τί", "εὗρες", ";"], True, None),
                         (["τί", "ἔγραψα", ";"], False, "ἔγραψα to „napisałem”. Zapytaj, co znalazł: τί εὗρες;")]},
            {"bot": ["τί", "εἶδες", ";"], "en": "A co ty widziałeś?",
             "build": (["ἦλθον", "καί", "εἶδον"], "Przyszedłem i zobaczyłem.")},
        ],
    },
]

CHAT_EXTRA = {
    "τίς": "kto?", "ναί": "tak", "ἀκούεις": "słyszysz", "οἶδας": "wiesz", "οἶδε": "wie",
    "εὖ": "dobrze", "ἐστι": "jest (bez akcentu)", "σοφία": "mądrość", "εὗρες": "znalazłeś",
    "εἶδες": "zobaczyłeś", "οὐ": "nie",
}
PUNCT = set(",.;·!")
ENCLITICS = {"σου", "μου", "ἐστι", "τις", "τι"}
NO_GRAVE = {"τί", "τίς"}


# ---------------------------------------------------------------------------
# Gramatyka: wzory odmian. Wpis: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, stopniowanie itp.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------
PARADIGM_LABELS = {
    'os': ['ἐγώ', 'σύ', 'αὐτός', 'ἡμεῖς', 'ὑμεῖς', 'αὐτοί'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'wołacz lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.'],
    'part': ['part. praes. act. (m.)', 'part. praes. act. (ż.)', 'part. praes. act. (n.)', 'part. praes. med.-pass.', 'part. aor. act.', 'part. aor. pass.'],
    'przyp8': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.'],
    'inf': ['inf. praes. act.', 'inf. praes. med.-pass.', 'inf. aor. act.', 'inf. aor. pass.', 'inf. fut. act.'],
    'stopn3': ['stopień równy', 'stopień wyższy', 'stopień najwyższy'],
    'przyp4': ['mianownik', 'dopełniacz', 'celownik', 'biernik'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'λύω (rozwiązuję)', 'os', 'λύω; λύεις; λύει; λύομεν; λύετε; λύουσι(ν)', 'Końcówki: -ω, -εις, -ει, -ομεν, -ετε, -ουσι(ν).'),
    ('conj', 'Wzory koniugacji', 'λέγω (mówię)', 'os', 'λέγω; λέγεις; λέγει; λέγομεν; λέγετε; λέγουσι(ν)', None),
    ('conj', 'Wzory koniugacji', 'ἔχω (mam)', 'os', 'ἔχω; ἔχεις; ἔχει; ἔχομεν; ἔχετε; ἔχουσι(ν)', None),
    ('conj', 'Wyjątki', 'φιλέω (kocham): ściągnięty na -έω', 'os', 'φιλῶ; φιλεῖς; φιλεῖ; φιλοῦμεν; φιλεῖτε; φιλοῦσι(ν)', 'ε zlewa się z końcówką: ε + ο → ου, ε + ε → ει.'),
    ('conj', 'Wyjątki', 'ἀγαπάω (miłuję): ściągnięty na -άω', 'os', 'ἀγαπῶ; ἀγαπᾷς; ἀγαπᾷ; ἀγαπῶμεν; ἀγαπᾶτε; ἀγαπῶσι(ν)', 'α + ο → ω, α + ε → α.'),
    ('conj', 'Czasowniki nieregularne', 'εἰμί (jestem)', 'os', 'εἰμί; εἶ; ἐστί(ν); ἐσμέν; ἐστέ; εἰσί(ν)', None),
    ('conj', 'Czasowniki nieregularne', 'δίδωμι (daję)', 'os', 'δίδωμι; δίδως; δίδωσι(ν); δίδομεν; δίδοτε; διδόασι(ν)', 'Czasownik na -μι: własne końcówki.'),
    ('conj', 'Strona medialna', 'λύομαι', 'os', 'λύομαι; λύῃ; λύεται; λυόμεθα; λύεσθε; λύονται', 'Końcówki: -ομαι, -ῃ, -εται, -όμεθα, -εσθε, -ονται.'),
    ('conj', 'Czas przeszły', 'λύω: imperfectum', 'os', 'ἔλυον; ἔλυες; ἔλυε(ν); ἐλύομεν; ἐλύετε; ἔλυον', 'Augment ἐ- na początku.'),
    ('conj', 'Czas przeszły', 'λύω: aoryst', 'os', 'ἔλυσα; ἔλυσας; ἔλυσε(ν); ἐλύσαμεν; ἐλύσατε; ἔλυσαν', 'Augment ἐ- i znak -σα-.'),
    ('decl', 'Wzory deklinacji', 'ὁ λόγος (słowo): II deklinacja', 'przyp', 'ὁ λόγος; τοῦ λόγου; τῷ λόγῳ; τὸν λόγον; ὦ λόγε; οἱ λόγοι; τῶν λόγων; τοῖς λόγοις; τοὺς λόγους', None),
    ('decl', 'Wzory deklinacji', 'τὸ ἔργον (dzieło): II deklinacja, nijaki', 'przyp', 'τὸ ἔργον; τοῦ ἔργου; τῷ ἔργῳ; τὸ ἔργον; ὦ ἔργον; τὰ ἔργα; τῶν ἔργων; τοῖς ἔργοις; τὰ ἔργα', 'Nijakie: mianownik = biernik, w lm. na -α.'),
    ('decl', 'Wzory deklinacji', 'ἡ ἀρχή (początek): I deklinacja na -η', 'przyp', 'ἡ ἀρχή; τῆς ἀρχῆς; τῇ ἀρχῇ; τὴν ἀρχήν; ὦ ἀρχή; αἱ ἀρχαί; τῶν ἀρχῶν; ταῖς ἀρχαῖς; τὰς ἀρχάς', None),
    ('decl', 'Wzory deklinacji', 'ἡ ἡμέρα (dzień): I deklinacja na -α', 'przyp', 'ἡ ἡμέρα; τῆς ἡμέρας; τῇ ἡμέρᾳ; τὴν ἡμέραν; ὦ ἡμέρα; αἱ ἡμέραι; τῶν ἡμερῶν; ταῖς ἡμέραις; τὰς ἡμέρας', 'Po ε, ι, ρ α zostaje we wszystkich przypadkach.'),
    ('decl', 'Wyjątki', 'ἡ θάλασσα (morze)', 'przyp', 'ἡ θάλασσα; τῆς θαλάσσης; τῇ θαλάσσῃ; τὴν θάλασσαν; ὦ θάλασσα; αἱ θάλασσαι; τῶν θαλασσῶν; ταῖς θαλάσσαις; τὰς θαλάσσας', 'Krótkie α: w dopełniaczu i celowniku lp. przechodzi w η.'),
    ('decl', 'Wyjątki', 'ὁ πατήρ (ojciec): III deklinacja', 'przyp', 'ὁ πατήρ; τοῦ πατρός; τῷ πατρί; τὸν πατέρα; ὦ πάτερ; οἱ πατέρες; τῶν πατέρων; τοῖς πατράσι(ν); τοὺς πατέρας', None),
    ('decl', 'Wyjątki', 'τὸ ὄνομα (imię): III deklinacja, nijaki', 'przyp', 'τὸ ὄνομα; τοῦ ὀνόματος; τῷ ὀνόματι; τὸ ὄνομα; ὦ ὄνομα; τὰ ὀνόματα; τῶν ὀνομάτων; τοῖς ὀνόμασι(ν); τὰ ὀνόματα', 'Temat na -ματ-.'),
    ('form', 'Imiesłowy', 'λύω (rozwiązuję)', 'part', 'λύων; λύουσα; λῦον; λυόμενος; λύσας; λυθείς', 'Imiesłowy są w grece wszechobecne: zastępują zdania podrzędne.'),
    ('form', 'Imiesłowy', 'λέγω (mówię)', 'part', 'λέγων; λέγουσα; λέγον; λεγόμενος; λέξας; λεχθείς', None),
    ('decl', 'Imiesłowy: odmiana', 'ὁ λύων (rozwiązujący)', 'przyp8', 'ὁ λύων; τοῦ λύοντος; τῷ λύοντι; τὸν λύοντα; οἱ λύοντες; τῶν λυόντων; τοῖς λύουσι(ν); τοὺς λύοντας', 'Odmiana według III deklinacji, temat λυοντ-.'),
    ('form', 'Bezokoliczniki', 'λύω', 'inf', 'λύειν; λύεσθαι; λῦσαι; λυθῆναι; λύσειν', None),
    ('conj', 'Czas przyszły', 'λύω: futurum', 'os', 'λύσω; λύσεις; λύσει; λύσομεν; λύσετε; λύσουσι(ν)', 'Znak -σ- przed końcówką.'),
    ('conj', 'Czas przeszły', 'λαμβάνω (biorę): aoryst II', 'os', 'ἔλαβον; ἔλαβες; ἔλαβε(ν); ἐλάβομεν; ἐλάβετε; ἔλαβον', 'Aoryst II: inny temat (λαβ-) i końcówki imperfectum.'),
    ('conj', 'Strona bierna', 'λύω: aoryst bierny', 'os', 'ἐλύθην; ἐλύθης; ἐλύθη; ἐλύθημεν; ἐλύθητε; ἐλύθησαν', 'Znak -θη-.'),
    ('conj', 'Wyjątki', 'δηλόω (pokazuję): ściągnięty na -όω', 'os', 'δηλῶ; δηλοῖς; δηλοῖ; δηλοῦμεν; δηλοῦτε; δηλοῦσι(ν)', None),
    ('form', 'Stopniowanie', 'σοφός (mądry)', 'stopn3', 'σοφός; σοφώτερος; σοφώτατος', 'Regularnie: -τερος, -τατος.'),
    ('form', 'Stopniowanie', 'ἀγαθός (dobry)', 'stopn3', 'ἀγαθός; ἀμείνων; ἄριστος', None),
    ('form', 'Stopniowanie', 'μέγας (wielki)', 'stopn3', 'μέγας; μείζων; μέγιστος', None),
    ('form', 'Stopniowanie', 'κακός (zły)', 'stopn3', 'κακός; κακίων; κάκιστος', None),
    ('decl', 'Zaimki', 'ἐγώ (ja)', 'przyp4', 'ἐγώ; ἐμοῦ; ἐμοί; ἐμέ', None),
    ('decl', 'Zaimki', 'σύ (ty)', 'przyp4', 'σύ; σοῦ; σοί; σέ', None),
]

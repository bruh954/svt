"""Treść kursu: greka starożytna (attycka i koine) dla Polaków.

Słowo:     (forma z akcentem, znaczenie po polsku, polskie słowo z greki lub None, skojarzenie lub None)
Litera:    (litera lub dwuznak, jak czytać, nazwa)
Zdanie:    (lista słów w formie słownikowej, tłumaczenie, {pułapka: wyjaśnienie})
           Akcent ostry na końcu słowa zmienia się sam w ciężki (ὸ), gdy po nim stoi
           kolejne słowo (engine.display).
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź, wyjaśnienie, dział)

Wymowa (pole „tr”) powstaje automatycznie: wymowa erazmiańska zapisana po polsku.
"""

UNITS = [
    # ---------------------------------------------------------------- alfabet
    {
        "id": "alfa1", "title": "Alfabet I", "icon": "Α", "track": "pismo",
        "letters": [
            ("α", "[a]", "ἄλφα"), ("β", "[b]", "βῆτα"), ("γ", "[ɡ]", "γάμμα"), ("δ", "[d]", "δέλτα"),
            ("ε", "[e] (krótkie)", "ἒ ψιλόν"), ("ζ", "[zd] (szkolnie dz)", "ζῆτα"), ("η", "[ɛː] (długie e)", "ἦτα"),
            ("θ", "[tʰ] (szkolnie th)", "θῆτα"), ("ι", "[i]", "ἰῶτα"), ("κ", "[k]", "κάππα"), ("λ", "[l]", "λάμβδα"),
            ("μ", "[m]", "μῦ"),
        ],
    },
    {
        "id": "alfa2", "title": "Alfabet II", "icon": "Ω", "track": "pismo",
        "letters": [
            ("ν", "[n]", "νῦ"), ("ξ", "[ks]", "ξεῖ"), ("ο", "[o] (krótkie)", "ὂ μικρόν"),
            ("π", "[p]", "πεῖ"), ("ρ", "[r]", "ῥῶ"), ("σ", "[s]", "σίγμα"),
            ("ς", "[s] na końcu słowa", "σίγμα τελικόν"), ("τ", "[t]", "ταῦ"), ("υ", "[y] (szkolnie y)", "ὖ ψιλόν"),
            ("φ", "[pʰ] (szkolnie f)", "φεῖ"), ("χ", "[kʰ] (szkolnie ch)", "χεῖ"), ("ψ", "[ps]", "ψεῖ"),
            ("ω", "[ɔː] (długie o)", "ὦ μέγα"),
        ],
    },
    {
        "id": "alfa3", "title": "Znaki i dwugłoski", "icon": "ἁ", "track": "pismo",
        "letters": [
            ("ἁ", "[h] na początku słowa (ἁ = ha)", "δασεῖα"),
            ("ἀ", "brak dźwięku (ἀ = a)", "ψιλή"),
            ("ά", "akcent tonalny: dawna melodia, czytaj zwyczajnie", "ὀξεῖα"),
            ("ᾳ", "jota pod spodem: dawniej [i], dziś niewymawiana", "ὑπογεγραμμένη"),
            ("αι", "[ai̯] (szkolnie aj)", "δίφθογγος"), ("ει", "[eː] (szkolnie ej)", "δίφθογγος"),
            ("οι", "[oi̯] (szkolnie oj)", "δίφθογγος"), ("ου", "[uː]", "δίφθογγος"),
            ("αυ", "[au̯]", "δίφθογγος"), ("ευ", "[eu̯]", "δίφθογγος"),
            ("γγ", "[ŋɡ]: ἄγγελος czytaj „angelos”", "γάμμα"),
        ],
    },
    {
        "id": 'wielkie1', "title": 'Wielkie litery I', "icon": 'Δ', "track": "pismo",
        "letters": [
            ('Α', '[a] (wielkie α)', 'ἄλφα'),
            ('Β', '[b] (wielkie β)', 'βῆτα'),
            ('Γ', '[ɡ] (wielkie γ)', 'γάμμα'),
            ('Δ', '[d] (wielkie δ)', 'δέλτα'),
            ('Ε', '[e] (wielkie ε)', 'ἒ ψιλόν'),
            ('Ζ', '[zd] (wielkie ζ)', 'ζῆτα'),
            ('Η', '[ɛː] (wielkie η)', 'ἦτα'),
            ('Θ', '[tʰ] (wielkie θ)', 'θῆτα'),
            ('Ι', '[i] (wielkie ι)', 'ἰῶτα'),
            ('Κ', '[k] (wielkie κ)', 'κάππα'),
            ('Λ', '[l] (wielkie λ)', 'λάμβδα'),
            ('Μ', '[m] (wielkie μ)', 'μῦ'),
        ],
    },
    {
        "id": 'wielkie2', "title": 'Wielkie litery II', "icon": 'Σ', "track": "pismo",
        "letters": [
            ('Ν', '[n] (wielkie ν)', 'νῦ'),
            ('Ξ', '[ks] (wielkie ξ)', 'ξεῖ'),
            ('Ο', '[o] (wielkie ο)', 'ὂ μικρόν'),
            ('Π', '[p] (wielkie π)', 'πεῖ'),
            ('Ρ', '[r] (wielkie ρ)', 'ῥῶ'),
            ('Σ', '[s] (wielkie σ)', 'σίγμα'),
            ('Τ', '[t] (wielkie τ)', 'ταῦ'),
            ('Υ', '[y] (wielkie υ)', 'ὖ ψιλόν'),
            ('Φ', '[pʰ] (wielkie φ)', 'φεῖ'),
            ('Χ', '[kʰ] (wielkie χ)', 'χεῖ'),
            ('Ψ', '[ps] (wielkie ψ)', 'ψεῖ'),
            ('Ω', '[ɔː] (wielkie ω)', 'ὦ μέγα'),
        ],
    },
    {
        "id": 'akcenty2', "title": 'Akcenty i duchy II', "icon": 'ᾶ', "track": "pismo",
        "letters": [
            ('ὰ', 'akcent „ciężki” (gravis): ostry w środku zdania zmienia się w ciężki, czytaj zwyczajnie', 'βαρεῖα'),
            ('ᾶ', 'okółek (circumflex) na długiej samogłosce: dawny dźwięk opadająco-wznoszący', 'περισπωμένη'),
            ('ἄ', 'duch słaby i akcent ostry razem: ἄ = a', 'ψιλὴ καὶ ὀξεῖα'),
            ('ἅ', 'duch mocny i akcent ostry razem: ἅ = ha', 'δασεῖα καὶ ὀξεῖα'),
            ('ὁ', '[ho]: rodzajnik „ten”, duch mocny na początku', 'ὁ'),
            ('ἡ', '[hɛː]: rodzajnik „ta”', 'ἡ'),
            ('οὐ', '[uː]: „nie”, duch słaby nic nie zmienia', 'οὐ'),
            ('ῥ', '[rh]: ρ na początku słowa zawsze ma duch mocny', 'ῥῶ'),
            ('ϊ', 'kropki nad ι: samogłoski czytaj osobno (ἀϊ)', 'διαλυτικά'),
            ('ῃ', '[ɛː]: η z jotą pod spodem, jota nie brzmi', 'ἦτα ὑπογεγραμμένη'),
            ('ῳ', '[ɔː]: ω z jotą pod spodem, jota nie brzmi', 'ὦ ὑπογεγραμμένη'),
        ],
    },
    {
        "id": 'grupy2', "title": 'Dwugłoski i grupy II', "icon": 'γκ', "track": "pismo",
        "letters": [
            ('υι', '[yi̯]: υἱός czytaj „huios” (syn)', 'δίφθογγος'),
            ('ηυ', '[ɛːu̯]: ηὗρον czytaj „ēuron”', 'δίφθογγος'),
            ('γκ', '[ŋk]: ἄγκυρα czytaj „ankyra”', 'γάμμα κάππα'),
            ('γξ', '[ŋks]: σάλπιγξ czytaj „salpinks”', 'γάμμα ξεῖ'),
            ('γχ', '[ŋkʰ]: ἄγχω czytaj „ankhō”', 'γάμμα χεῖ'),
            ('ρρ', '[rː]: podwójne r (ἄρρην)', 'ῥῶ ῥῶ'),
            ('σσ', '[ss]: θάλασσα; w Attyce często ττ', 'σίγμα σίγμα'),
            ('ττ', '[tt]: θάλαττα, wariant attycki', 'ταῦ ταῦ'),
            ('μμ', '[mm]: γράμμα', 'μῦ μῦ'),
            ('λλ', '[ll]: ἄλλος', 'λάμβδα λάμβδα'),
        ],
    },
    {
        "id": 'liczby1', "title": 'Liczby literowe I', "icon": 'αʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('αʹ', '1', 'ἄλφα'),
            ('βʹ', '2', 'βῆτα'),
            ('γʹ', '3', 'γάμμα'),
            ('δʹ', '4', 'δέλτα'),
            ('εʹ', '5', 'ἒ ψιλόν'),
            ('ϛʹ', '6', 'στῖγμα'),
            ('ζʹ', '7', 'ζῆτα'),
            ('ηʹ', '8', 'ἦτα'),
            ('θʹ', '9', 'θῆτα'),
        ],
    },
    {
        "id": 'liczby2', "title": 'Liczby literowe II', "icon": 'ιʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('ιʹ', '10', 'ἰῶτα'),
            ('κʹ', '20', 'κάππα'),
            ('λʹ', '30', 'λάμβδα'),
            ('μʹ', '40', 'μῦ'),
            ('νʹ', '50', 'νῦ'),
            ('ξʹ', '60', 'ξεῖ'),
            ('οʹ', '70', 'ὂ μικρόν'),
            ('πʹ', '80', 'πεῖ'),
            ('ϙʹ', '90', 'κόππα'),
        ],
    },
    {
        "id": 'liczby3', "title": 'Liczby literowe III', "icon": 'ρʹ', "track": "pismo", "kind": "number",
        "letters": [
            ('ρʹ', '100', 'ῥῶ'),
            ('σʹ', '200', 'σίγμα'),
            ('τʹ', '300', 'ταῦ'),
            ('υʹ', '400', 'ὖ ψιλόν'),
            ('φʹ', '500', 'φεῖ'),
            ('χʹ', '600', 'χεῖ'),
            ('ψʹ', '700', 'ψεῖ'),
            ('ωʹ', '800', 'ὦ μέγα'),
            ('ϡʹ', '900', 'σαμπῖ'),
        ],
    },
    {
        "id": 'archaiczne', "title": 'Litery dawne i warianty', "icon": 'ϝ', "track": "pismo",
        "letters": [
            ('ϝ', '[w]: dawna litera, digamma („podwójne gamma”), znikła z greki przed epoką klasyczną', 'δίγαμμα'),
            ('ϙ', '[k]: dawna litera, dziś tylko liczba 90', 'κόππα'),
            ('ϛ', '[st]: ligatura σ i τ, dziś tylko liczba 6', 'στῖγμα'),
            ('ϡ', 'dawna litera, dziś tylko liczba 900', 'σαμπῖ'),
            ('ϲ', '[s]: sigma w kształcie C, w rękopisach i napisach', 'λουνατὸν σίγμα'),
            ('Ϲ', '[s]: wielka sigma w kształcie C', 'λουνατὸν σίγμα'),
            ('ϑ', 'wariant θ, w druku i matematyce: [tʰ]', 'θῆτα'),
            ('ϕ', 'wariant φ, w druku i matematyce: [pʰ]', 'φεῖ'),
            ('ϖ', 'wariant π: [p]', 'πεῖ'),
            ('ϐ', 'wariant β w rękopisach: [b]', 'βῆτα'),
        ],
    },
    # ----------------------------------------------------------------- język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "Β", "track": "jezyk", "requires": "alfa2",
        "words": [
            ("χαῖρε", "witaj; bywaj", None, "Dosłownie „ciesz się”. Grecy tak się witali i żegnali."),
            ("ἐγώ", "ja", "egoizm", None),
            ("σύ", "ty", None, None),
            ("καί", "i; także", None, None),
            ("εἶ", "jesteś", None, None),
            ("εἰμί", "jestem", None, "Słowo „enklityczne”: często traci akcent i opiera się o poprzednie."),
            ("ἐστί", "jest", None, None),
            ("ὁ", "ten (rodzajnik męski)", "ten", "Rodzajnik to dawny zaimek wskazujący, jak polskie „ten, ta, to”."),
            ("ἡ", "ta (rodzajnik żeński)", "ta", None),
            ("τό", "to (rodzajnik nijaki)", "to", None),
            ("φίλος", "przyjaciel; miły", "filozofia", "Filozof = przyjaciel mądrości, Filip = miłośnik koni."),
            ("ἄνθρωπος", "człowiek", "antropologia", None),
            ("καλός", "piękny; dobry", "kaligrafia", "Kaligrafia = piękne pisanie."),
            ("ἀγαθός", "dobry", "Agata", "Agata to „dobra” (ἀγαθή)."),
            ("μέγας", "wielki", "megafon", None),
        ],
        "sentences": [
            (["ὁ", "φίλος", "ἀγαθός"], "Przyjaciel jest dobry.",
             {"ἐστί": "Grecy często pomijają „jest”: ὁ φίλος ἀγαθός = przyjaciel (jest) dobry."}),
            (["σύ", "εἶ", "φίλος"], "Jesteś przyjacielem.",
             {"εἰμί": "εἰμί to „jestem”. Do „ty”: εἶ."}),
            (["ὁ", "ἄνθρωπος", "καλός"], "Człowiek jest piękny.", {"ἡ": "ἄνθρωπος jest męski: ὁ."}),
            (["ὁ", "φίλος", "μέγας"], "Przyjaciel jest wielki.", {}),
        ],
    },
    {
        "id": "dom", "title": "Rodzina", "icon": "Γ", "track": "jezyk",
        "words": [
            ("πατήρ", "ojciec", "patriota", "Patriota: ten, kto kocha ziemię ojców (πατρίς)."),
            ("μήτηρ", "matka", "metropolia", "Metropolia = miasto-matka."),
            ("υἱός", "syn", None, None),
            ("θυγάτηρ", "córka", None, "Ten sam praindoeuropejski wyraz co angielskie daughter."),
            ("ἀδελφός", "brat", "Filadelfia", "Filadelfia = miłość braterska."),
            ("ἀδελφή", "siostra", None, None),
            ("ἀνήρ", "mąż; mężczyzna", "Andrzej", "Andrzej (Ἀνδρέας) to „męski”."),
            ("γυνή", "kobieta; żona", "ginekologia", None),
            ("παῖς", "dziecko", "pedagog", "Pedagog to „prowadzący dziecko”."),
            ("οἶκος", "dom", "ekonomia", "Ekonomia = zarządzanie domem."),
            ("διδάσκαλος", "nauczyciel", "dydaktyka", None),
            ("ἐμός", "mój", None, None),
            ("ἐμή", "moja", None, None),
            ("καλή", "piękna", None, None),
        ],
        "sentences": [
            (["ὁ", "πατήρ", "ἀγαθός"], "Ojciec jest dobry.", {"ἡ": "πατήρ jest męski: ὁ."}),
            (["ἡ", "μήτηρ", "καλή"], "Matka jest piękna.", {"καλός": "μήτηρ jest żeńska: καλή."}),
            (["ὁ", "ἐμός", "πατήρ", "ἀγαθός"], "Mój ojciec jest dobry.",
             {"ἐμή": "πατήρ jest męski: ἐμός."}),
            (["ἡ", "ἐμή", "μήτηρ", "καλή"], "Moja matka jest piękna.", {"ἐμός": "μήτηρ jest żeńska: ἐμή."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "Δ", "track": "jezyk",
        "words": [
            ("εἷς", "jeden", None, None),
            ("δύο", "dwa", "dylemat", "Dylemat: dwa (δι-) założenia."),
            ("τρεῖς", "trzy", "trylogia", None),
            ("τέτταρες", "cztery", "tetralogia", None),
            ("πέντε", "pięć", "pentagon", None),
            ("ἕξ", "sześć", "heksagon", None),
            ("ἑπτά", "siedem", "heptagon", None),
            ("ὀκτώ", "osiem", "oktaedr", None),
            ("ἐννέα", "dziewięć", "enneagram", None),
            ("δέκα", "dziesięć", "dekada", None),
            ("ἑκατόν", "sto", "hekatomba", "Hekatomba: ofiara ze stu wołów."),
            ("ἀδελφοί", "bracia", None, None),
            ("φίλοι", "przyjaciele", None, None),
        ],
        "sentences": [
            (["δύο", "ἀδελφοί"], "Dwaj bracia.", {"ἀδελφός": "Dwaj: liczba mnoga, ἀδελφοί."}),
            (["τρεῖς", "φίλοι"], "Trzej przyjaciele.", {"φίλος": "Trzej: φίλοι."}),
        ],
    },
    {
        "id": "swiat", "title": "Świat", "icon": "Ε", "track": "jezyk",
        "words": [
            ("ἥλιος", "słońce", "hel", "Hel odkryto w widmie Słońca."),
            ("σελήνη", "księżyc", "selen", None),
            ("γῆ", "ziemia", "geografia", None),
            ("θάλασσα", "morze", "talasoterapia", None),
            ("οὐρανός", "niebo", "Uran", None),
            ("ὕδωρ", "woda", "hydraulika", None),
            ("πῦρ", "ogień", "pirotechnika", None),
            ("λίθος", "kamień", "litografia", None),
            ("φῶς", "światło", "fotografia", None),
            ("κόσμος", "świat; porządek", "kosmos; kosmetyka", "Kosmetyka = porządkowanie wyglądu."),
            ("χρόνος", "czas", "chronologia", None),
            ("βίος", "życie", "biologia", None),
            ("ἐν", "w; na", None, None),
            ("τῷ", "(w) tym (celownik)", None, None),
            ("οὐρανῷ", "(na) niebie", None, None),
        ],
        "sentences": [
            (["ὁ", "ἥλιος", "ἐν", "τῷ", "οὐρανῷ"], "Słońce jest na niebie.",
             {"οὐρανός": "Gdzie? Po ἐν celownik: τῷ οὐρανῷ."}),
            (["ἡ", "θάλασσα", "καλή"], "Morze jest piękne.", {"καλός": "θάλασσα jest żeńska: καλή."}),
            (["ὁ", "βίος", "καλός"], "Życie jest piękne.", {}),
        ],
    },
    {
        "id": "czas", "title": "Czasowniki", "icon": "Ζ", "track": "jezyk",
        "words": [
            ("γράφω", "piszę", "grafika", None),
            ("γράφεις", "piszesz", None, None),
            ("γράφει", "pisze", None, None),
            ("λέγω", "mówię", "leksykon", None),
            ("λέγεις", "mówisz", None, None),
            ("ἀκούω", "słyszę", "akustyka", None),
            ("βλέπω", "widzę", None, None),
            ("ἔχω", "mam", None, None),
            ("τί", "co?", None, "Pytające τί nigdy nie zmienia akcentu."),
            ("βιβλίον", "książka", "biblioteka", None),
            ("τόν", "tego (biernik)", None, None),
            ("φίλον", "przyjaciela (biernik)", None, None),
        ],
        "sentences": [
            (["γράφω", "βιβλίον"], "Piszę książkę.",
             {"γράφει": "γράφει to „pisze” (on). O sobie: γράφω, -ω jak polskie -ę."}),
            (["τί", "λέγεις", ";"], "Co mówisz?", {"λέγω": "Pytasz kogoś: λέγεις (-εις jak -sz)."}),
            (["ὁ", "διδάσκαλος", "γράφει"], "Nauczyciel pisze.", {"γράφω": "On: γράφει."}),
            (["ἀκούω", "τόν", "φίλον"], "Słyszę przyjaciela.",
             {"φίλος": "Kogo słyszę? Biernik: τὸν φίλον."}),
        ],
    },
    {
        "id": "przypadki", "title": "Przypadki", "icon": "Η", "track": "jezyk",
        "words": [
            ("λόγος", "słowo; rozum", "logika", "Stąd -logia: biologia = nauka o życiu."),
            ("θεός", "bóg", "teologia", None),
            ("θεοῦ", "boga (dopełniacz)", None, None),
            ("θεόν", "boga (biernik)", None, None),
            ("τοῦ", "tego (dopełniacz)", None, None),
            ("φίλε", "przyjacielu! (wołacz)", None, "Wołacz na -ε, jak polskie „Boże!”."),
            ("ὦ", "o! (przed wołaczem)", None, None),
        ],
        "sentences": [
            (["χαῖρε", ",", "ὦ", "φίλε"], "Witaj, przyjacielu!",
             {"φίλος": "Zwracasz się do kogoś: wołacz φίλε."}),
            (["ὁ", "λόγος", "τοῦ", "θεοῦ"], "Słowo Boga.", {"θεός": "Czyje słowo? Dopełniacz: τοῦ θεοῦ."}),
        ],
    },
    {
        "id": "aoryst", "title": "Czas przeszły", "icon": "Θ", "track": "jezyk",
        "words": [
            ("ἔγραψα", "napisałem", None, "ἐ- na początku (augment) oznacza przeszłość."),
            ("ἔγραψε", "napisał", None, None),
            ("εἶπε", "powiedział", None, None),
            ("ἦλθον", "przyszedłem", None, None),
            ("εἶδον", "zobaczyłem", "idea", "Idea (ἰδέα) to „to, co widać”. Ten sam rdzeń."),
            ("ἐνίκησα", "zwyciężyłem", "Nike", None),
            ("ἦν", "był; była; było", None, None),
            ("εὕρηκα", "znalazłem!", "eureka", "Archimedes w wannie: εὕρηκα! (perfekt)."),
        ],
        "sentences": [
            (["εὕρηκα"], "Znalazłem!", {}),
            (["ἦλθον", "καί", "εἶδον"], "Przyszedłem i zobaczyłem.", {}),
            (["ὁ", "διδάσκαλος", "εἶπε"], "Nauczyciel powiedział.", {}),
            (["ἔγραψα", "βιβλίον"], "Napisałem książkę.", {"γράφω": "W przeszłości: ἔγραψα (napisałem)."}),
        ],
    },
    # --------------------------------------------------------------- sentencje
    {
        "id": "sent", "title": "Sentencje", "icon": "Ι", "track": "sentencje", "requires": "czas",
        "words": [
            ("γνῶθι", "poznaj", "diagnoza", None),
            ("σεαυτόν", "samego siebie", None, None),
            ("πάντα", "wszystko", "panorama", None),
            ("ῥεῖ", "płynie", "reumatyzm", None),
            ("μηδέν", "nic (nie)", None, None),
            ("ἄγαν", "zbyt; za bardzo", None, None),
            ("ἕν", "jedno; jedną rzecz", None, None),
            ("οἶδα", "wiem", None, None),
            ("ὅτι", "że", None, None),
            ("οὐδέν", "nic", None, None),
        ],
        "sentences": [
            (["γνῶθι", "σεαυτόν"], "Poznaj samego siebie.", {}),
            (["πάντα", "ῥεῖ"], "Wszystko płynie.", {}),
            (["μηδέν", "ἄγαν"], "Nic ponad miarę.", {}),
            (["ἕν", "οἶδα", "ὅτι", "οὐδέν", "οἶδα"], "Wiem, że nic nie wiem.", {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "pater", "title": "Ojcze nasz", "icon": "Κ", "track": "teksty", "requires": "przypadki",
        "words": [
            ("πάτερ", "ojcze! (wołacz)", None, None),
            ("ἡμῶν", "nasz (dosł. „nas”)", None, None),
            ("τοῖς", "tych (celownik l.mn.)", None, None),
            ("οὐρανοῖς", "niebiosach", None, None),
            ("ἁγιασθήτω", "niech będzie uświęcone", "hagiografia", None),
            ("ὄνομά", "imię", "anonim", "Przed σου dostaje drugi akcent: ὄνομα → ὄνομά σου."),
            ("σου", "twój (dosł. „ciebie”)", None, "Enklityka: bez akcentu."),
            ("ἐλθέτω", "niech przyjdzie", None, None),
            ("βασιλεία", "królestwo", "bazylika", "Bazylika = budowla „królewska”."),
            ("γενηθήτω", "niech się stanie", "geneza", None),
            ("θέλημά", "wola", None, None),
            ("ὡς", "jak; jako", None, None),
            ("ἐπί", "na", "epicentrum", None),
            ("γῆς", "ziemi (dopełniacz)", None, None),
        ],
        "sentences": [
            (["πάτερ", "ἡμῶν", "ὁ", "ἐν", "τοῖς", "οὐρανοῖς"], "Ojcze nasz, który jesteś w niebie.", {}),
            (["ἁγιασθήτω", "τό", "ὄνομά", "σου"], "Święć się imię Twoje.", {}),
            (["ἐλθέτω", "ἡ", "βασιλεία", "σου"], "Przyjdź królestwo Twoje.", {}),
            (["γενηθήτω", "τό", "θέλημά", "σου"], "Bądź wola Twoja.", {}),
            (["ὡς", "ἐν", "οὐρανῷ", "καί", "ἐπί", "γῆς"], "Jako w niebie, tak i na ziemi.", {}),
        ],
    },
    {
        "id": "jan", "title": "Ewangelia Jana", "icon": "Λ", "track": "teksty",
        "words": [
            ("ἀρχῇ", "(na) początku", "archaiczny", None),
            ("πρός", "do; u; przy", None, None),
        ],
        "sentences": [
            (["ἐν", "ἀρχῇ", "ἦν", "ὁ", "λόγος"], "Na początku było Słowo.", {}),
            (["καί", "ὁ", "λόγος", "ἦν", "πρός", "τόν", "θεόν"], "A Słowo było u Boga.", {}),
            (["καί", "θεός", "ἦν", "ὁ", "λόγος"], "I Bogiem było Słowo.", {}),
        ],
    },
]

TRACKS = {
    "pismo": "ΓΡΑΜΜΑΤΑ · PISMO",
    "jezyk": "ΓΛΩΣΣΑ · JĘZYK",
    "sentencje": "ΓΝΩΜΑΙ · SENTENCJE",
    "teksty": "ΚΕΙΜΕΝΑ · TEKSTY",
}

INSIGHTS = {
    "alfa1": [
        {"title": "Znasz połowę z matematyki",
         "text": "α, β, γ, δ, λ, μ, π: znasz je z lekcji. Grecki alfabet dał nam nazwę „alfabet” "
                 "(alfa + beta). η to długie e, a θ to „th”: wymawiaj jak t z wydechem.",
         "chain": []},
    ],
    "alfa2": [
        {"title": "Fałszywi przyjaciele",
         "text": "ν to n, ρ to r, υ to y, χ to ch. Wyglądają jak v, p, u, x, ale nimi nie są. "
                 "σ na końcu słowa pisze się ς. ω to długie o: Ω na końcu alfabetu, stąd „alfa i omega”.",
         "chain": []},
    ],
    "wielkie1": [
        {"title": "Znajome litery, obce dźwięki",
         "text": "Wielkie litery wyglądają jak łacińskie, ale nie wszystkie czytasz tak samo. Β to [b], nie „w”. "
                 "Η to długie e, nie h. Ρ to r, nie p. Χ to ch, nie iks. Υ to y, nie u. Ν to n. "
                 "Wielkich używasz na początku nazw własnych; dawniej pisano nimi cały tekst.",
         "chain": []},
    ],
    "akcenty2": [
        {"title": "Trzy akcenty, jedna melodia",
         "text": "Akcent ostry (ά), ciężki (ὰ) i okółek (ᾶ) to ślady dawnej melodii słów. Dziś czytasz je "
                 "zwyczajnie, ale okółek podpowiada ci, że samogłoska jest długa. Duch mocny i słaby "
                 "stawia się na pierwszej samogłosce słowa; ρ na początku zawsze ma duch mocny: ῥ.",
         "chain": []},
    ],
    "liczby1": [
        {"title": "Litery jako cyfry",
         "text": "Grecy nie mieli osobnych cyfr: liczby pisali literami z kreską u góry po prawej. α΄ = 1, β΄ = 2, "
                 "γ΄ = 3. Alfabet ma 24 litery, ale liczb jest 27, więc doszły trzy dawne litery: ϛ (6), ϙ (90) i ϡ (900). "
                 "Stąd nasze „alfabet” i „alfa i omega” jako początek i koniec.",
         "chain": []},
    ],
    "alfa3": [
        {"title": "Znaczki nad literami",
         "text": "Przydech mocny (ἁ) to h: ἥλιος czytaj „hēlios”, stąd „hel”. Przydech słaby (ἀ) "
                 "nic nie zmienia. Akcenty to dawna melodia: na początek czytaj zwyczajnie. Akcent ostry "
                 "na końcu słowa przed kolejnym słowem pisze się jako ciężki: καλός → καλὸς.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Rodzajnik to polskie „ten, ta, to”",
         "text": "Polski nie ma rodzajnika, greka ma: ὁ, ἡ, τό. To dawny zaimek wskazujący, więc myśl "
                 "o nim jak o „ten, ta, to”: ὁ φίλος = ten przyjaciel. A „jest” Grecy często pomijają: "
                 "ὁ φίλος ἀγαθός = przyjaciel (jest) dobry.",
         "chain": [
             ("Przyjaciel jest dobry.", ["ὁ", "φίλος", "ἀγαθός"], "ὁ (ten) + φίλος + ἀγαθός. Bez „jest”."),
             ("Jesteś przyjacielem.", ["σύ", "εἶ", "φίλος"], "σύ (ty) + εἶ (jesteś) + φίλος."),
         ]},
    ],
    "dom": [
        {"title": "Rodzaj jak w polskim",
         "text": "Męski, żeński, nijaki, jak u nas. καλός, καλή = piękny, piękna. Przymiotnik stawiasz "
                 "między rodzajnikiem a rzeczownikiem: ὁ ἐμὸς πατήρ = (ten) mój ojciec.",
         "chain": [("Mój ojciec jest dobry.", ["ὁ", "ἐμός", "πατήρ", "ἀγαθός"], "ὁ ἐμὸς πατήρ, potem cecha.")]},
    ],
    "liczby": [
        {"title": "Liczby z geometrii",
         "text": "Pentagon, heksagon, dekada, hekatomba: liczby greckie znasz z nazw figur i miar.",
         "chain": [("Dwaj bracia.", ["δύο", "ἀδελφοί"], "δύο + liczba mnoga ἀδελφοί.")]},
    ],
    "swiat": [
        {"title": "Nauka mówi po grecku",
         "text": "Geografia (γῆ), biologia (βίος), fotografia (φῶς), chronologia (χρόνος), hydraulika (ὕδωρ). "
                 "Gdy uczysz się greckiego słowa, szukaj go w polskim słowie naukowym.",
         "chain": [("Słońce jest na niebie.", ["ὁ", "ἥλιος", "ἐν", "τῷ", "οὐρανῷ"],
                    "Gdzie? ἐν + celownik: τῷ οὐρανῷ.")]},
    ],
    "czas": [
        {"title": "-ω, -εις, -ει = -ę, -sz, -",
         "text": "Jak po polsku, osoba siedzi w końcówce: γράφω, γράφεις, γράφει = piszę, piszesz, pisze. "
                 "Zaimka nie potrzebujesz. Pytajnik grecki to średnik: τί λέγεις; = Co mówisz?",
         "chain": [
             ("Piszę książkę.", ["γράφω", "βιβλίον"], "γράφω (piszę) + βιβλίον (biblioteka!)."),
             ("Słyszę przyjaciela.", ["ἀκούω", "τόν", "φίλον"], "Kogo? Biernik: τὸν φίλον."),
         ]},
    ],
    "przypadki": [
        {"title": "Pięć przypadków, wołacz jak u nas",
         "text": "Greka ma mianownik, dopełniacz, celownik, biernik i wołacz. Wołacz działa jak polski: "
                 "ὦ φίλε! = przyjacielu! Dopełniacz: ὁ λόγος τοῦ θεοῦ = słowo Boga.",
         "chain": [("Witaj, przyjacielu!", ["χαῖρε", ",", "ὦ", "φίλε"], "Wołacz φίλε, przed nim ὦ.")]},
    ],
    "aoryst": [
        {"title": "Przeszłość z przodu",
         "text": "Polski oznacza przeszłość z tyłu (pisa-ł), greka z przodu: ἐ- (augment). γράφω → "
                 "ἔγραψα (napisałem). Słynne εὕρηκα Archimedesa to „znalazłem!”.",
         "chain": [("Przyszedłem i zobaczyłem.", ["ἦλθον", "καί", "εἶδον"], "ἦλθον (przyszedłem), εἶδον (zobaczyłem).")]},
    ],
    "sent": [
        {"title": "Mądrość z Delf",
         "text": "γνῶθι σεαυτόν i μηδὲν ἄγαν wyryto w świątyni Apollina w Delfach. πάντα ῥεῖ to późne "
                 "streszczenie myśli Heraklita (pierwszy zapisał je Symplikios, VI w.). „Wiem, że nic nie wiem” "
                 "w tej formie to późniejsza formuła: u Platona (Obrona 21d) Sokrates mówi coś podobnego.",
         "chain": [("Poznaj samego siebie.", ["γνῶθι", "σεαυτόν"], "γνῶθι (poznaj, por. diagnoza) + σεαυτόν.")]},
    ],
    "pater": [
        {"title": "Modlitwa w oryginale",
         "text": "Ewangelia Mateusza (6,9-10) w oryginale. σου (twój) stoi po rzeczowniku, jak w polskim "
                 "„imię Twoje”, i nie ma akcentu: dlatego ὄνομα dostaje drugi akcent (ὄνομά σου).",
         "chain": [("Święć się imię Twoje.", ["ἁγιασθήτω", "τό", "ὄνομά", "σου"],
                    "ἁγιασθήτω (hagiografia!) + τὸ ὄνομά σου.")]},
    ],
    "jan": [
        {"title": "λόγος: słowo i rozum",
         "text": "Jan zaczyna od słowa λόγος, które znaczy i „słowo”, i „rozum, sens”. Stąd logika i "
                 "wszystkie -logie. ἐν ἀρχῇ = na początku (archaiczny!).",
         "chain": [("Na początku było Słowo.", ["ἐν", "ἀρχῇ", "ἦν", "ὁ", "λόγος"], "ἐν ἀρχῇ + ἦν (było) + ὁ λόγος.")]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Końcówka mówi wszystko",
    "text": "Jak w polskim: „widzę przyjaciela”, nie „widzę przyjaciel”. W grece τὸν φίλον. "
            "Zadaj pytanie jak na lekcji polskiego: kto? czyj? komu? kogo? gdzie?",
}

ENDINGS = [
    ("ὁ ", "φίλ", "ος", "", ["ος", "ον", "ου", "ῳ"], "przyjaciel (kto?)", "Mianownik: -ος.", "slowa"),
    ("ἡ μήτηρ ", "καλ", "ή", "", ["ός", "ή", "όν", "οῦ"], "matka jest piękna", "Żeńska: -ή.", "dom"),
    ("ἡ ", "ἀδελφ", "ή", "", ["ός", "ή", "όν", "οί"], "siostra", "Żeńska: -ή.", "dom"),
    ("δύο ", "ἀδελφ", "οί", "", ["ός", "ή", "όν", "οί"], "dwaj bracia", "Liczba mnoga: -οί.", "liczby"),
    ("ἐν τῷ ", "οὐραν", "ῷ", "", ["ός", "όν", "οῦ", "ῷ"], "na niebie (gdzie?)", "Po ἐν celownik: -ῷ.", "swiat"),
    ("", "γράφ", "ω", " βιβλίον", ["ω", "εις", "ει", "ουσι"], "piszę książkę", "Ja: -ω, jak polskie -ę.", "czas"),
    ("σὺ ", "γράφ", "εις", "", ["ω", "εις", "ει", "ουσι"], "ty piszesz", "Ty: -εις, jak polskie -sz.", "czas"),
    ("ὁ διδάσκαλος ", "γράφ", "ει", "", ["ω", "εις", "ει", "ουσι"], "nauczyciel pisze", "On: -ει.", "czas"),
    ("ἀκούω τὸν ", "φίλ", "ον", "", ["ος", "ον", "ου", "ε"], "słyszę przyjaciela (kogo?)", "Biernik: -ον.", "czas"),
    ("ὁ λόγος τοῦ ", "θε", "οῦ", "", ["ός", "όν", "οῦ", "ῷ"], "słowo Boga (czyje?)", "Dopełniacz: -οῦ.", "przypadki"),
    ("χαῖρε, ὦ ", "φίλ", "ε", "", ["ος", "ε", "ον", "ου"], "witaj, przyjacielu!", "Wołacz: -ε.", "przypadki"),
    ("", "ἔγραψ", "α", "", ["α", "ε", "ω", "ον"], "napisałem", "Aoryst, ja: -α.", "aoryst"),
]

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "agora", "title": "Na agorze", "partner": "Kriton", "avatar": "Κ", "requires": "slowa",
        "turns": [
            {"bot": ["χαῖρε", "."], "en": "Witaj!",
             "options": [(["χαῖρε", "."], True, None),
                         (["οὐ", "."], False, "οὐ to „nie”. Odpowiedz pozdrowieniem: χαῖρε.")]},
            {"bot": ["τίς", "εἶ", ";"], "en": "Kim jesteś?",
             "options": [(["φίλος", "εἰμί"], True, None),
                         (["φίλος", "εἶ"], False, "εἶ to „jesteś”. O sobie: εἰμί."),
                         (["φίλος", "ἐστί"], False, "ἐστί to „jest”. O sobie: εἰμί.")],
             "note": "Grecki znak zapytania wygląda jak nasz średnik: ;"},
            {"bot": ["ὁ", "κόσμος", "καλός", "."], "en": "Świat jest piękny.",
             "options": [(["ναί", ",", "ὁ", "κόσμος", "καλός"], True, None),
                         (["ναί", ",", "ὁ", "κόσμος", "καλή"], False, "κόσμος jest męski: καλός.")]},
            {"bot": ["χαῖρε", "."], "en": "Bywaj!", "build": (["χαῖρε"], "Bywaj!")},
        ],
    },
    {
        "id": "szkola", "title": "W szkole", "partner": "Nauczyciel", "avatar": "Δ", "requires": "czas",
        "turns": [
            {"bot": ["τί", "γράφεις", ";"], "en": "Co piszesz?",
             "options": [(["γράφω", "βιβλίον"], True, None),
                         (["γράφει", "βιβλίον"], False, "γράφει to „pisze” (on). O sobie: γράφω."),
                         (["γράφεις", "βιβλίον"], False, "γράφεις to „piszesz”. O sobie: γράφω.")]},
            {"bot": ["τί", "ἀκούεις", ";"], "en": "Co słyszysz?",
             "build": (["ἀκούω", "τόν", "φίλον"], "Słyszę przyjaciela.")},
        ],
    },
    {
        "id": "sokrates", "title": "Sokrates", "partner": "Sokrates", "avatar": "Σ", "requires": "sent",
        "turns": [
            {"bot": ["τί", "οἶδας", ";"], "en": "Co wiesz?",
             "options": [(["ἕν", "οἶδα", "ὅτι", "οὐδέν", "οἶδα"], True, None),
                         (["ἕν", "οἶδε", "ὅτι", "οὐδέν", "οἶδε"], False, "οἶδε to „wie” (on). O sobie: οἶδα.")]},
            {"bot": ["εὖ", "λέγεις", ".", "τί", "ἐστι", "σοφία", ";"], "en": "Dobrze mówisz. Czym jest mądrość?",
             "build": (["γνῶθι", "σεαυτόν"], "Poznaj samego siebie.")},
        ],
    },
    {
        "id": "archimedes", "title": "Archimedes", "partner": "Archimedes", "avatar": "Α", "requires": "aoryst",
        "turns": [
            {"bot": ["εὕρηκα", "!"], "en": "Znalazłem!",
             "options": [(["τί", "εὗρες", ";"], True, None),
                         (["τί", "ἔγραψα", ";"], False, "ἔγραψα to „napisałem”. Zapytaj, co znalazł: τί εὗρες;")]},
            {"bot": ["τί", "εἶδες", ";"], "en": "A co ty widziałeś?",
             "build": (["ἦλθον", "καί", "εἶδον"], "Przyszedłem i zobaczyłem.")},
        ],
    },
]

CHAT_EXTRA = {
    "τίς": "kto?", "ναί": "tak", "ἀκούεις": "słyszysz", "οἶδας": "wiesz", "οἶδε": "wie",
    "εὖ": "dobrze", "ἐστι": "jest (bez akcentu)", "σοφία": "mądrość", "εὗρες": "znalazłeś",
    "εἶδες": "zobaczyłeś", "οὐ": "nie",
}
PUNCT = set(",.;·!")
ENCLITICS = {"σου", "μου", "ἐστι", "τις", "τι"}
NO_GRAVE = {"τί", "τίς"}


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['ἐγώ', 'σύ', 'αὐτός', 'ἡμεῖς', 'ὑμεῖς', 'αὐτοί'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'wołacz lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.'],
    'part': ['part. praes. act. (m.)', 'part. praes. act. (ż.)', 'part. praes. act. (n.)', 'part. praes. med.-pass.', 'part. aor. act.', 'part. aor. pass.'],
    'przyp8': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'mianownik lm.', 'dopełniacz lm.', 'celownik lm.', 'biernik lm.'],
    'inf': ['inf. praes. act.', 'inf. praes. med.-pass.', 'inf. aor. act.', 'inf. aor. pass.', 'inf. fut. act.'],
    'stopn3': ['stopień równy', 'stopień wyższy', 'stopień najwyższy'],
    'przyp4': ['mianownik', 'dopełniacz', 'celownik', 'biernik'],
    't_art': ['λόγος (słowo)', 'ἀρχή (początek)', 'ἔργον (dzieło)', 'ἡμέρα (dzień)', 'πατήρ (ojciec)', 'ὄνομα (imię)', 'θάλασσα (morze)', 'ἄνθρωπος (człowiek)'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'λύω (rozwiązuję)', 'os', 'λύω; λύεις; λύει; λύομεν; λύετε; λύουσι(ν)', 'Końcówki: -ω, -εις, -ει, -ομεν, -ετε, -ουσι(ν).'),
    ('conj', 'Wzory koniugacji', 'λέγω (mówię)', 'os', 'λέγω; λέγεις; λέγει; λέγομεν; λέγετε; λέγουσι(ν)', None),
    ('conj', 'Wzory koniugacji', 'ἔχω (mam)', 'os', 'ἔχω; ἔχεις; ἔχει; ἔχομεν; ἔχετε; ἔχουσι(ν)', None),
    ('conj', 'Wyjątki', 'φιλέω (kocham): ściągnięty na -έω', 'os', 'φιλῶ; φιλεῖς; φιλεῖ; φιλοῦμεν; φιλεῖτε; φιλοῦσι(ν)', 'ε zlewa się z końcówką: ε + ο → ου, ε + ε → ει.'),
    ('conj', 'Wyjątki', 'ἀγαπάω (miłuję): ściągnięty na -άω', 'os', 'ἀγαπῶ; ἀγαπᾷς; ἀγαπᾷ; ἀγαπῶμεν; ἀγαπᾶτε; ἀγαπῶσι(ν)', 'α + ο → ω, α + ε → α.'),
    ('conj', 'Czasowniki nieregularne', 'εἰμί (jestem)', 'os', 'εἰμί; εἶ; ἐστί(ν); ἐσμέν; ἐστέ; εἰσί(ν)', None),
    ('conj', 'Czasowniki nieregularne', 'δίδωμι (daję)', 'os', 'δίδωμι; δίδως; δίδωσι(ν); δίδομεν; δίδοτε; διδόασι(ν)', 'Czasownik na -μι: własne końcówki.'),
    ('conj', 'Strona medialna', 'λύομαι', 'os', 'λύομαι; λύῃ; λύεται; λυόμεθα; λύεσθε; λύονται', 'Końcówki: -ομαι, -ῃ, -εται, -όμεθα, -εσθε, -ονται.'),
    ('conj', 'Czas przeszły', 'λύω: imperfectum', 'os', 'ἔλυον; ἔλυες; ἔλυε(ν); ἐλύομεν; ἐλύετε; ἔλυον', 'Augment ἐ- na początku.'),
    ('conj', 'Czas przeszły', 'λύω: aoryst', 'os', 'ἔλυσα; ἔλυσας; ἔλυσε(ν); ἐλύσαμεν; ἐλύσατε; ἔλυσαν', 'Augment ἐ- i znak -σα-.'),
    ('decl', 'Wzory deklinacji', 'ὁ λόγος (słowo): II deklinacja', 'przyp', 'ὁ λόγος; τοῦ λόγου; τῷ λόγῳ; τὸν λόγον; ὦ λόγε; οἱ λόγοι; τῶν λόγων; τοῖς λόγοις; τοὺς λόγους', None),
    ('decl', 'Wzory deklinacji', 'τὸ ἔργον (dzieło): II deklinacja, nijaki', 'przyp', 'τὸ ἔργον; τοῦ ἔργου; τῷ ἔργῳ; τὸ ἔργον; ὦ ἔργον; τὰ ἔργα; τῶν ἔργων; τοῖς ἔργοις; τὰ ἔργα', 'Nijakie: mianownik = biernik, w lm. na -α.'),
    ('decl', 'Wzory deklinacji', 'ἡ ἀρχή (początek): I deklinacja na -η', 'przyp', 'ἡ ἀρχή; τῆς ἀρχῆς; τῇ ἀρχῇ; τὴν ἀρχήν; ὦ ἀρχή; αἱ ἀρχαί; τῶν ἀρχῶν; ταῖς ἀρχαῖς; τὰς ἀρχάς', None),
    ('decl', 'Wzory deklinacji', 'ἡ ἡμέρα (dzień): I deklinacja na -α', 'przyp', 'ἡ ἡμέρα; τῆς ἡμέρας; τῇ ἡμέρᾳ; τὴν ἡμέραν; ὦ ἡμέρα; αἱ ἡμέραι; τῶν ἡμερῶν; ταῖς ἡμέραις; τὰς ἡμέρας', 'Po ε, ι, ρ α zostaje we wszystkich przypadkach.'),
    ('decl', 'Wyjątki', 'ἡ θάλασσα (morze)', 'przyp', 'ἡ θάλασσα; τῆς θαλάσσης; τῇ θαλάσσῃ; τὴν θάλασσαν; ὦ θάλασσα; αἱ θάλασσαι; τῶν θαλασσῶν; ταῖς θαλάσσαις; τὰς θαλάσσας', 'Krótkie α: w dopełniaczu i celowniku lp. przechodzi w η.'),
    ('decl', 'Wyjątki', 'ὁ πατήρ (ojciec): III deklinacja', 'przyp', 'ὁ πατήρ; τοῦ πατρός; τῷ πατρί; τὸν πατέρα; ὦ πάτερ; οἱ πατέρες; τῶν πατέρων; τοῖς πατράσι(ν); τοὺς πατέρας', None),
    ('decl', 'Wyjątki', 'τὸ ὄνομα (imię): III deklinacja, nijaki', 'przyp', 'τὸ ὄνομα; τοῦ ὀνόματος; τῷ ὀνόματι; τὸ ὄνομα; ὦ ὄνομα; τὰ ὀνόματα; τῶν ὀνομάτων; τοῖς ὀνόμασι(ν); τὰ ὀνόματα', 'Temat na -ματ-.'),
    ('form', 'Imiesłowy', 'λύω (rozwiązuję)', 'part', 'λύων; λύουσα; λῦον; λυόμενος; λύσας; λυθείς', 'Imiesłowy są w grece wszechobecne: zastępują zdania podrzędne.'),
    ('form', 'Imiesłowy', 'λέγω (mówię)', 'part', 'λέγων; λέγουσα; λέγον; λεγόμενος; λέξας; λεχθείς', None),
    ('decl', 'Imiesłowy: odmiana', 'ὁ λύων (rozwiązujący)', 'przyp8', 'ὁ λύων; τοῦ λύοντος; τῷ λύοντι; τὸν λύοντα; οἱ λύοντες; τῶν λυόντων; τοῖς λύουσι(ν); τοὺς λύοντας', 'Odmiana według III deklinacji, temat λυοντ-.'),
    ('form', 'Bezokoliczniki', 'λύω', 'inf', 'λύειν; λύεσθαι; λῦσαι; λυθῆναι; λύσειν', None),
    ('conj', 'Czas przyszły', 'λύω: futurum', 'os', 'λύσω; λύσεις; λύσει; λύσομεν; λύσετε; λύσουσι(ν)', 'Znak -σ- przed końcówką.'),
    ('conj', 'Czas przeszły', 'λαμβάνω (biorę): aoryst II', 'os', 'ἔλαβον; ἔλαβες; ἔλαβε(ν); ἐλάβομεν; ἐλάβετε; ἔλαβον', 'Aoryst II: inny temat (λαβ-) i końcówki imperfectum.'),
    ('conj', 'Strona bierna', 'λύω: aoryst bierny', 'os', 'ἐλύθην; ἐλύθης; ἐλύθη; ἐλύθημεν; ἐλύθητε; ἐλύθησαν', 'Znak -θη-.'),
    ('conj', 'Wyjątki', 'δηλόω (pokazuję): ściągnięty na -όω', 'os', 'δηλῶ; δηλοῖς; δηλοῖ; δηλοῦμεν; δηλοῦτε; δηλοῦσι(ν)', None),
    ('form', 'Stopniowanie', 'σοφός (mądry)', 'stopn3', 'σοφός; σοφώτερος; σοφώτατος', 'Regularnie: -τερος, -τατος.'),
    ('form', 'Stopniowanie', 'ἀγαθός (dobry)', 'stopn3', 'ἀγαθός; ἀμείνων; ἄριστος', None),
    ('form', 'Stopniowanie', 'μέγας (wielki)', 'stopn3', 'μέγας; μείζων; μέγιστος', None),
    ('form', 'Stopniowanie', 'κακός (zły)', 'stopn3', 'κακός; κακίων; κάκιστος', None),
    ('decl', 'Zaimki', 'ἐγώ (ja)', 'przyp4', 'ἐγώ; ἐμοῦ; ἐμοί; ἐμέ', None),
    ('decl', 'Zaimki', 'σύ (ty)', 'przyp4', 'σύ; σοῦ; σοί; σέ', None),
    ('form', 'Typowe trudności', 'Rodzajnik: ὁ, ἡ czy τό?', 't_art', 'ὁ; ἡ; τό; ἡ; ὁ; τό; ἡ; ὁ', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['ὁ', 'τοῦ', 'τῷ', 'τόν', 'οἱ', 'τῶν', 'τοῖς', 'τούς'],
    't_m1': ['λέγω (mówię)', 'λαμβάνω (biorę)', 'ὁράω (widzę)', 'ἔρχομαι (idę)', 'ἔχω (mam)', 'φέρω (niosę)'],
    't_m2': ['ὁ', 'ἡμέρα', 'ἄνθρωπος', 'ὕδωρ', 'ἐγώ', 'ὑμεῖς', 'ἀρχή', 'ἑπτά'],
    't_m3': ['λύω', 'λύομαι', 'λύει', 'λύεται', 'λύουσι(ν)', 'λύονται'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Rodzajnik: jaki przypadek?', 't_m0', 'mianownik lp.; dopełniacz lp.; celownik lp.; biernik lp.; mianownik lm.; dopełniacz lm.; celownik lm.; biernik lm.', 'Rodzajnik jest najlepszą wskazówką przypadku.'),
    ('form', 'Typowe trudności', 'Aoryst: inny temat', 't_m1', 'εἶπον; ἔλαβον; εἶδον; ἦλθον; ἔσχον; ἤνεγκον', 'Najczęstsze czasowniki mają w aoryście zupełnie inny temat.'),
    ('form', 'Typowe trudności', 'Przydech: mocny czy słaby?', 't_m2', 'mocny (h); mocny (h); słaby; mocny (h); słaby; mocny (h); słaby; mocny (h)', 'Znak zwrócony jak ʽ to mocny przydech (h), jak ʼ słaby. Początkowe υ ma zawsze mocny.'),
    ('form', 'Typowe trudności', 'Strona: czynna czy medialno-bierna?', 't_m3', 'czynna; medialno-bierna; czynna; medialno-bierna; czynna; medialno-bierna', 'Końcówki -μαι, -ται, -νται oznaczają stronę medialną lub bierną.'),
]

# === PRONOUNS (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('decl', 'Zaimki', 'ἡμεῖς (my)', 'przyp4', 'ἡμεῖς; ἡμῶν; ἡμῖν; ἡμᾶς', None),
    ('decl', 'Zaimki', 'ὑμεῖς (wy)', 'przyp4', 'ὑμεῖς; ὑμῶν; ὑμῖν; ὑμᾶς', None),
    ('decl', 'Zaimki', 'αὐτός (on, sam)', 'przyp4', 'αὐτός; αὐτοῦ; αὐτῷ; αὐτόν', 'W przypadkach zależnych znaczy „go”, w mianowniku „sam”.'),
    ('decl', 'Zaimki', 'αὐτή (ona)', 'przyp4', 'αὐτή; αὐτῆς; αὐτῇ; αὐτήν', None),
    ('decl', 'Zaimki', 'αὐτό (ono)', 'przyp4', 'αὐτό; αὐτοῦ; αὐτῷ; αὐτό', None),
    ('decl', 'Zaimki', 'οὗτος (ten)', 'przyp4', 'οὗτος; τούτου; τούτῳ; τοῦτον', None),
    ('decl', 'Zaimki', 'αὕτη (ta)', 'przyp4', 'αὕτη; ταύτης; ταύτῃ; ταύτην', None),
    ('decl', 'Zaimki', 'τοῦτο (to)', 'przyp4', 'τοῦτο; τούτου; τούτῳ; τοῦτο', None),
    ('decl', 'Zaimki', 'τίς (kto)', 'przyp4', 'τίς; τίνος; τίνι; τίνα', 'Pytajny: z akcentem ostrym na i.'),
    ('decl', 'Zaimki', 'τί (co)', 'przyp4', 'τί; τίνος; τίνι; τί', None),
    ('decl', 'Zaimki', 'ὅς (który)', 'przyp4', 'ὅς; οὗ; ᾧ; ὅν', 'Zaimek względny.'),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /PRONOUNS ===

# === STOPNIOWANIE (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('form', 'Stopniowanie', 'καλός (piękny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'καλός; καλλίων; κάλλιστος', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'πολύς (liczny)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'πολύς; πλείων; πλεῖστος', 'Nieregularne.'),
    ('form', 'Stopniowanie', 'δίκαιος (sprawiedliwy)', ['stopień równy', 'stopień wyższy', 'stopień najwyższy'], 'δίκαιος; δικαιότερος; δικαιότατος', 'Regularne: -τερος, -τατος.'),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /STOPNIOWANIE ===

# === SŁOWNICTWO (generowane z langs/vocab, nie edytuj ręcznie) ===
UNITS += [{'id': 'v01a', 'title': 'Ludzie 1', 'icon': 'L', 'track': 'jezyk', 'words': [('παιδίον', 'chłopiec', None, 'rodzaj nijaki'), ('κόρη', 'dziewczynka', None, 'rodzaj żeński'), ('οἰκογένεια', 'rodzina', None, 'rodzaj żeński'), ('πάππος', 'dziadek', None, 'rodzaj męski'), ('τήθη', 'babcia', None, 'rodzaj żeński'), ('ἔκγονος', 'wnuk', None, 'rodzaj męski'), ('θεῖος', 'wuj', None, 'rodzaj męski'), ('θεία', 'ciotka', None, 'rodzaj żeński'), ('σύζυγος', 'żona', None, 'rodzaj żeński'), ('γείτων', 'sąsiad', None, 'rodzaj męski'), ('ξένος', 'gość', None, 'rodzaj męski'), ('ἐχθρός', 'wróg', None, 'rodzaj męski'), ('βασιλεύς', 'król', None, 'rodzaj męski'), ('βασίλισσα', 'królowa', None, 'rodzaj żeński'), ('στρατηγός', 'wódz', None, 'rodzaj męski'), ('ἥρως', 'bohater', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01b', 'title': 'Ludzie 2', 'icon': 'L', 'track': 'jezyk', 'words': [('ἱερεύς', 'kapłan', None, 'rodzaj męski'), ('ποιητής', 'poeta', None, 'rodzaj męski'), ('φιλόσοφος', 'filozof', None, 'rodzaj męski'), ('μαθητής', 'uczeń', None, 'rodzaj męski'), ('ἰατρός', 'lekarz', None, 'rodzaj męski'), ('στρατιώτης', 'żołnierz', None, 'rodzaj męski'), ('γεωργός', 'rolnik', None, 'rodzaj męski'), ('ἔμπορος', 'kupiec', None, 'rodzaj męski'), ('ναύτης', 'żeglarz', None, 'rodzaj męski'), ('θηρευτής', 'myśliwy', None, 'rodzaj męski'), ('τεχνίτης', 'rzemieślnik', None, 'rodzaj męski'), ('ποιμήν', 'pasterz', None, 'rodzaj męski'), ('δικαστής', 'sędzia', None, 'rodzaj męski'), ('πολίτης', 'obywatel', None, 'rodzaj męski'), ('δοῦλος', 'niewolnik', None, 'rodzaj męski'), ('δούλη', 'niewolnica', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v01c', 'title': 'Ludzie 3', 'icon': 'L', 'track': 'jezyk', 'words': [('γέρων', 'starzec', None, 'rodzaj męski'), ('γραῦς', 'staruszka', None, 'rodzaj żeński'), ('νεανίας', 'młodzieniec', None, 'rodzaj męski'), ('παρθένος', 'dziewica', None, 'rodzaj żeński'), ('χήρα', 'wdowa', None, 'rodzaj żeński'), ('ὀρφανός', 'sierota', None, 'rodzaj męski'), ('βάρβαρος', 'cudzoziemiec', None, 'rodzaj męski'), ('τύραννος', 'tyran', None, 'rodzaj męski'), ('ἡγεμών', 'wódz (przywódca)', None, 'rodzaj męski'), ('δεσπότης', 'pan', None, 'rodzaj męski'), ('ἄρχων', 'władca', None, 'rodzaj męski'), ('ῥήτωρ', 'mówca', None, 'rodzaj męski'), ('ἱστορικός', 'historyk', None, 'rodzaj męski'), ('ζωγράφος', 'malarz', None, 'rodzaj męski'), ('ἀγαλματοποιός', 'rzeźbiarz', None, 'rodzaj męski'), ('μουσικός', 'muzyk', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01d', 'title': 'Ludzie 4', 'icon': 'L', 'track': 'jezyk', 'words': [('ὑποκριτής', 'aktor', None, 'rodzaj męski'), ('φύλαξ', 'strażnik', None, 'rodzaj męski'), ('ἄγγελος', 'posłaniec', None, 'rodzaj męski'), ('φυγάς', 'wygnaniec', None, 'rodzaj męski'), ('αἰχμάλωτος', 'jeniec', None, 'rodzaj męski'), ('ἐλεύθερος', 'wolny', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v02a', 'title': 'Ciało 1', 'icon': 'C', 'track': 'jezyk', 'words': [('κεφαλή', 'głowa', None, 'rodzaj żeński'), ('πρόσωπον', 'twarz', None, 'rodzaj nijaki'), ('ὀφθαλμός', 'oko', None, 'rodzaj męski'), ('οὖς', 'ucho', None, 'rodzaj nijaki'), ('ῥίς', 'nos', None, 'rodzaj żeński'), ('στόμα', 'usta', None, 'rodzaj nijaki'), ('ὀδούς', 'ząb', None, 'rodzaj męski'), ('γλῶσσα', 'język (narząd)', None, 'rodzaj żeński'), ('τρίχες', 'włosy', None, None), ('τράχηλος', 'szyja', None, 'rodzaj męski'), ('βραχίων', 'ramię', None, 'rodzaj męski'), ('χείρ', 'ręka', None, 'rodzaj żeński'), ('δάκτυλος', 'palec', None, 'rodzaj męski'), ('σκέλος', 'noga', None, 'rodzaj nijaki'), ('πούς', 'stopa', None, 'rodzaj męski'), ('γόνυ', 'kolano', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v02b', 'title': 'Ciało 2', 'icon': 'C', 'track': 'jezyk', 'words': [('νῶτον', 'plecy', None, 'rodzaj nijaki'), ('γαστήρ', 'brzuch', None, 'rodzaj żeński'), ('καρδία', 'serce', None, 'rodzaj żeński'), ('αἷμα', 'krew', None, 'rodzaj nijaki'), ('ὀστέον', 'kość', None, 'rodzaj nijaki'), ('δέρμα', 'skóra', None, 'rodzaj nijaki'), ('φωνή', 'głos', None, 'rodzaj żeński'), ('σῶμα', 'ciało', None, 'rodzaj nijaki'), ('στόμαχος', 'żołądek', None, 'rodzaj męski'), ('πώγων', 'broda', None, 'rodzaj męski'), ('χεῖλος', 'warga', None, 'rodzaj nijaki'), ('ὄνυξ', 'paznokieć', None, 'rodzaj męski'), ('στῆθος', 'pierś', None, 'rodzaj nijaki'), ('ἐγκέφαλος', 'mózg', None, 'rodzaj męski'), ('ἀγκών', 'łokieć', None, 'rodzaj męski'), ('μέτωπον', 'czoło', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v02c', 'title': 'Ciało 3', 'icon': 'C', 'track': 'jezyk', 'words': [('παρειά', 'policzek', None, 'rodzaj żeński'), ('πτέρνα', 'pięta', None, 'rodzaj żeński'), ('ἧπαρ', 'wątroba', None, 'rodzaj nijaki'), ('πλεύμων', 'płuco', None, 'rodzaj męski'), ('ἱδρώς', 'pot', None, 'rodzaj męski'), ('δάκρυον', 'łza', None, 'rodzaj nijaki'), ('αὐχήν', 'kark', None, 'rodzaj męski'), ('φλέψ', 'żyła', None, 'rodzaj żeński'), ('στέαρ', 'tłuszcz', None, 'rodzaj nijaki'), ('νεφρός', 'nerka', None, 'rodzaj męski'), ('πτερόν', 'skrzydło', None, 'rodzaj nijaki'), ('κέρας', 'róg', None, 'rodzaj nijaki'), ('οὐρά', 'ogon', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v03a', 'title': 'Jedzenie 1', 'icon': 'J', 'track': 'jezyk', 'words': [('ἄρτος', 'chleb', None, 'rodzaj męski'), ('βούτυρον', 'masło', None, 'rodzaj nijaki'), ('τυρός', 'ser', None, 'rodzaj męski'), ('γάλα', 'mleko', None, 'rodzaj nijaki'), ('ᾠόν', 'jajko', None, 'rodzaj nijaki'), ('κρέας', 'mięso', None, 'rodzaj nijaki'), ('ἰχθύς', 'ryba', None, 'rodzaj męski'), ('ἀλεκτρυών', 'kurczak', None, 'rodzaj męski'), ('χοίρεια', 'wieprzowina', None, 'rodzaj nijaki'), ('ζωμός', 'zupa', None, 'rodzaj męski'), ('ἄλφιτον', 'kasza', None, 'rodzaj nijaki'), ('ἄλευρον', 'mąka', None, 'rodzaj nijaki'), ('κρόμμυον', 'cebula', None, 'rodzaj nijaki'), ('σκόροδον', 'czosnek', None, 'rodzaj nijaki'), ('μῆλον', 'jabłko', None, 'rodzaj nijaki'), ('ἄπιον', 'gruszka', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v03b', 'title': 'Jedzenie 2', 'icon': 'J', 'track': 'jezyk', 'words': [('σταφυλή', 'winogrono', None, 'rodzaj żeński'), ('σῦκον', 'figa', None, 'rodzaj nijaki'), ('ἐλαία', 'oliwka', None, 'rodzaj żeński'), ('κάρυον', 'orzech', None, 'rodzaj nijaki'), ('μέλι', 'miód', None, 'rodzaj nijaki'), ('ἅλς', 'sól', None, 'rodzaj męski'), ('πέπερι', 'pieprz', None, 'rodzaj nijaki'), ('ἔλαιον', 'oliwa', None, 'rodzaj nijaki'), ('οἶνος', 'wino', None, 'rodzaj męski'), ('ὄξος', 'ocet', None, 'rodzaj nijaki'), ('ἄριστον', 'śniadanie', None, 'rodzaj nijaki'), ('δεῖπνον', 'obiad', None, 'rodzaj nijaki'), ('συμπόσιον', 'uczta', None, 'rodzaj nijaki'), ('λιμός', 'głód', None, 'rodzaj męski'), ('σῖτος', 'jedzenie', None, 'rodzaj męski'), ('πλακοῦς', 'ciasto', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03c', 'title': 'Jedzenie 3', 'icon': 'J', 'track': 'jezyk', 'words': [('πίσον', 'groch', None, 'rodzaj nijaki'), ('κύαμος', 'bób', None, 'rodzaj męski'), ('κράμβη', 'kapusta', None, 'rodzaj żeński'), ('θρίδαξ', 'sałata', None, 'rodzaj żeński'), ('σίκυος', 'ogórek', None, 'rodzaj męski'), ('ῥόα', 'granat', None, 'rodzaj żeński'), ('φοῖνιξ', 'daktyl', None, 'rodzaj męski'), ('ἔντερον', 'kiełbasa', None, 'rodzaj nijaki'), ('ἀρνεία', 'baranina', None, 'rodzaj żeński'), ('βόεια', 'wołowina', None, 'rodzaj żeński'), ('ὄστρεον', 'ostryga', None, 'rodzaj nijaki'), ('βρόμος', 'owies', None, 'rodzaj męski'), ('πυρός', 'pszenica', None, 'rodzaj męski'), ('κριθή', 'jęczmień', None, 'rodzaj żeński'), ('κέγχρος', 'proso', None, 'rodzaj męski'), ('ὀπτόν', 'mięso z rusztu', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v03d', 'title': 'Jedzenie 4', 'icon': 'J', 'track': 'jezyk', 'words': [('τροφή', 'pokarm', None, 'rodzaj żeński'), ('πόμα', 'napój', None, 'rodzaj nijaki'), ('μέλας οἶνος', 'czerwone wino', None, 'rodzaj męski'), ('γλυκύς οἶνος', 'wino słodkie', None, 'rodzaj męski'), ('οἰνοποτέω', 'pić wino', None, None), ('κρήνη', 'woda źródlana', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v04a', 'title': 'Dom 1', 'icon': 'D', 'track': 'jezyk', 'words': [('οἴκησις', 'mieszkanie', None, 'rodzaj żeński'), ('δωμάτιον', 'pokój', None, 'rodzaj nijaki'), ('μαγειρεῖον', 'kuchnia', None, 'rodzaj nijaki'), ('βαλανεῖον', 'łazienka', None, 'rodzaj nijaki'), ('κοιτών', 'sypialnia', None, 'rodzaj męski'), ('ἀνδρών', 'salon', None, 'rodzaj męski'), ('κῆπος', 'ogród', None, 'rodzaj męski'), ('θύρα', 'drzwi', None, 'rodzaj żeński'), ('πύλη', 'brama', None, 'rodzaj żeński'), ('θυρίς', 'okno', None, 'rodzaj żeński'), ('τοῖχος', 'ściana', None, 'rodzaj męski'), ('ἔδαφος', 'podłoga', None, 'rodzaj nijaki'), ('ὀροφή', 'dach', None, 'rodzaj żeński'), ('κλίμαξ', 'schody', None, 'rodzaj żeński'), ('κλείς', 'klucz', None, 'rodzaj żeński'), ('μοχλός', 'zamek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04b', 'title': 'Dom 2', 'icon': 'D', 'track': 'jezyk', 'words': [('τράπεζα', 'stół', None, 'rodzaj żeński'), ('θρόνος', 'krzesło', None, 'rodzaj męski'), ('κλίνη', 'łóżko', None, 'rodzaj żeński'), ('κιβωτός', 'szafa', None, 'rodzaj żeński'), ('λύχνος', 'lampa', None, 'rodzaj męski'), ('τάπης', 'dywan', None, 'rodzaj męski'), ('κάτοπτρον', 'lustro', None, 'rodzaj nijaki'), ('προσκεφάλαιον', 'poduszka', None, 'rodzaj nijaki'), ('στρῶμα', 'koc', None, 'rodzaj nijaki'), ('ἑστία', 'ognisko', None, 'rodzaj żeński'), ('φρέαρ', 'studnia', None, 'rodzaj nijaki'), ('κλίβανος', 'piec', None, 'rodzaj męski'), ('αὐλή', 'dziedziniec', None, 'rodzaj żeński'), ('κίων', 'kolumna', None, 'rodzaj męski'), ('σιτών', 'spichlerz', None, 'rodzaj męski'), ('ἱππών', 'stajnia', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04c', 'title': 'Dom 3', 'icon': 'D', 'track': 'jezyk', 'words': [('βουστάσιον', 'obora', None, 'rodzaj nijaki'), ('ἀγρός', 'farma', None, 'rodzaj męski'), ('φραγμός', 'płot', None, 'rodzaj męski'), ('δοκός', 'belka', None, 'rodzaj żeński'), ('πλίνθος', 'cegła', None, 'rodzaj żeński'), ('μάρμαρος', 'marmur', None, 'rodzaj męski'), ('κηρίον', 'świeca', None, 'rodzaj nijaki'), ('δᾷς', 'pochodnia', None, 'rodzaj żeński'), ('κάδος', 'wiadro', None, 'rodzaj męski'), ('κάλαθος', 'kosz', None, 'rodzaj męski'), ('λάρναξ', 'skrzynia', None, 'rodzaj żeński'), ('κρωσσός', 'dzban', None, 'rodzaj męski'), ('ἀμφορεύς', 'amfora', None, 'rodzaj męski'), ('κύλιξ', 'kielich', None, 'rodzaj żeński'), ('φιάλη', 'miska', None, 'rodzaj żeński'), ('λέβης', 'kociołek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04d', 'title': 'Dom 4', 'icon': 'D', 'track': 'jezyk', 'words': [('χύτρα', 'garnek', None, 'rodzaj żeński'), ('σκεῦος', 'naczynie', None, 'rodzaj nijaki'), ('ἔπιπλον', 'mebel', None, 'rodzaj nijaki'), ('βωμός', 'ołtarz domowy', None, 'rodzaj męski'), ('πρόθυρον', 'sień', None, 'rodzaj nijaki'), ('ἐνδοτέρω', 'wnętrze', None, None), ('στέγη', 'dach domu', None, 'rodzaj żeński'), ('παραπέτασμα', 'okiennica', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v05a', 'title': 'Ubrania 1', 'icon': 'U', 'track': 'jezyk', 'words': [('ἱμάτιον', 'ubranie', None, 'rodzaj nijaki'), ('χιτών', 'tunika', None, 'rodzaj męski'), ('χλαῖνα', 'płaszcz', None, 'rodzaj żeński'), ('χλαμύς', 'płaszcz podróżny', None, 'rodzaj żeński'), ('σάνδαλον', 'sandał', None, 'rodzaj nijaki'), ('ὑπόδημα', 'but', None, 'rodzaj nijaki'), ('πέτασος', 'kapelusz', None, 'rodzaj męski'), ('κράνος', 'hełm', None, 'rodzaj nijaki'), ('ζώνη', 'pas', None, 'rodzaj żeński'), ('περόνη', 'broszka', None, 'rodzaj żeński'), ('δακτύλιος', 'pierścień', None, 'rodzaj męski'), ('ὅρμος', 'naszyjnik', None, 'rodzaj męski'), ('ψέλιον', 'bransoleta', None, 'rodzaj nijaki'), ('ὕφασμα', 'tkanina', None, 'rodzaj nijaki'), ('ἔριον', 'wełna', None, 'rodzaj nijaki'), ('λίνον', 'len', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v05b', 'title': 'Ubrania 2', 'icon': 'U', 'track': 'jezyk', 'words': [('σηρικόν', 'jedwab', None, 'rodzaj nijaki'), ('βύρσα', 'skóra (wyprawiona)', None, 'rodzaj żeński'), ('κάλυμμα', 'welon', None, 'rodzaj nijaki'), ('πέπλος', 'szal', None, 'rodzaj męski'), ('στέφανος', 'wieniec', None, 'rodzaj męski'), ('διάδημα', 'korona', None, 'rodzaj nijaki'), ('πορφύρα', 'purpura', None, 'rodzaj żeński'), ('ἐσθής', 'szata', None, 'rodzaj żeński'), ('πένθιμα', 'szata żałobna', None, 'rodzaj nijaki'), ('χειρίς', 'rękaw', None, 'rodzaj żeński'), ('ὑπόδυσις', 'bielizna', None, 'rodzaj żeński'), ('νῆμα', 'nić', None, 'rodzaj nijaki'), ('βελόνη', 'igła', None, 'rodzaj żeński'), ('ἱστός', 'krosno', None, 'rodzaj męski'), ('ἄτρακτος', 'wrzeciono', None, 'rodzaj żeński'), ('ἠλακάτη', 'kołowrotek', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v05c', 'title': 'Ubrania 3', 'icon': 'U', 'track': 'jezyk', 'words': [('ὑφάντρια', 'tkaczka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v06a', 'title': 'Kolory i kształty 1', 'icon': 'K', 'track': 'jezyk', 'words': [('ἐρυθρός', 'czerwony', None, None), ('κυάνεος', 'niebieski', None, None), ('χλωρός', 'zielony', None, None), ('ξανθός', 'żółty', None, None), ('μέλας', 'czarny', None, None), ('λευκός', 'biały', None, None), ('πολιός', 'szary', None, None), ('φαιός', 'brązowy', None, None), ('ῥόδινος', 'różowy', None, None), ('ἰοειδής', 'fioletowy', None, None), ('χρύσεος', 'złoty', None, None), ('ἀργύρεος', 'srebrny', None, None), ('λαμπρός', 'jasny', None, None), ('σκοτεινός', 'ciemny', None, None), ('χρῶμα', 'kolor', None, 'rodzaj nijaki'), ('στρογγύλος', 'okrągły', None, None)], 'sentences': []}, {'id': 'v06b', 'title': 'Kolory i kształty 2', 'icon': 'K', 'track': 'jezyk', 'words': [('τετράγωνος', 'kwadratowy', None, None), ('εὐθύς', 'prosty', None, None), ('σκολιός', 'krzywy', None, None), ('γραμμή', 'linia', None, 'rodzaj żeński'), ('στιγμή', 'punkt', None, 'rodzaj żeński'), ('κύκλος', 'koło', None, 'rodzaj męski'), ('τρίγωνον', 'trójkąt', None, 'rodzaj nijaki'), ('σχῆμα', 'kształt', None, 'rodzaj nijaki'), ('σφαῖρα', 'kula', None, 'rodzaj żeński'), ('γωνία', 'kąt', None, 'rodzaj żeński'), ('πλευρά', 'bok', None, 'rodzaj żeński'), ('κέντρον', 'środek', None, 'rodzaj nijaki'), ('ἐπιφάνεια', 'powierzchnia', None, 'rodzaj żeński'), ('ὕψος', 'wysokość', None, 'rodzaj nijaki'), ('μῆκος', 'długość', None, 'rodzaj nijaki'), ('πλάτος', 'szerokość', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v06c', 'title': 'Kolory i kształty 3', 'icon': 'K', 'track': 'jezyk', 'words': [('βάθος', 'głębokość', None, 'rodzaj nijaki'), ('μέγεθος', 'wielkość', None, 'rodzaj nijaki'), ('μέτρον', 'miara', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v07a', 'title': 'Liczby i ilości 1', 'icon': 'L', 'track': 'jezyk', 'words': [('ἕνδεκα', 'jedenaście', None, None), ('δώδεκα', 'dwanaście', None, None), ('τρεισκαίδεκα', 'trzynaście', None, None), ('τετταρεσκαίδεκα', 'czternaście', None, None), ('πεντεκαίδεκα', 'piętnaście', None, None), ('ἑκκαίδεκα', 'szesnaście', None, None), ('ἑπτακαίδεκα', 'siedemnaście', None, None), ('ὀκτωκαίδεκα', 'osiemnaście', None, None), ('ἐννεακαίδεκα', 'dziewiętnaście', None, None), ('εἴκοσι', 'dwadzieścia', None, None), ('τριάκοντα', 'trzydzieści', None, None), ('τετταράκοντα', 'czterdzieści', None, None), ('πεντήκοντα', 'pięćdziesiąt', None, None), ('ἑξήκοντα', 'sześćdziesiąt', None, None), ('ἑβδομήκοντα', 'siedemdziesiąt', None, None), ('ὀγδοήκοντα', 'osiemdziesiąt', None, None)], 'sentences': []}, {'id': 'v07b', 'title': 'Liczby i ilości 2', 'icon': 'L', 'track': 'jezyk', 'words': [('ἐνενήκοντα', 'dziewięćdziesiąt', None, None), ('διακόσιοι', 'dwieście', None, None), ('τριακόσιοι', 'trzysta', None, None), ('χίλιοι', 'tysiąc', None, None), ('μύριοι', 'dziesięć tysięcy', None, None), ('πρῶτος', 'pierwszy', None, None), ('δεύτερος', 'drugi', None, None), ('τρίτος', 'trzeci', None, None), ('τέταρτος', 'czwarty', None, None), ('πέμπτος', 'piąty', None, None), ('ἕκτος', 'szósty', None, None), ('ἕβδομος', 'siódmy', None, None), ('ὄγδοος', 'ósmy', None, None), ('ἔνατος', 'dziewiąty', None, None), ('δέκατος', 'dziesiąty', None, None), ('ἥμισυς', 'połowa', None, None)], 'sentences': []}, {'id': 'v07c', 'title': 'Liczby i ilości 3', 'icon': 'L', 'track': 'jezyk', 'words': [('ζεῦγος', 'para', None, 'rodzaj nijaki'), ('ὀλίγοι', 'kilka', None, None), ('πολλοί', 'wiele', None, None), ('σμικρόν', 'mało', None, None), ('ὅλος', 'cały', None, None), ('πάντες', 'wszyscy', None, None), ('οὐδείς', 'żaden', None, None), ('τις', 'jakiś', None, None), ('δίς', 'dwa razy', None, None), ('τρίς', 'trzy razy', None, None), ('ἅπαξ', 'raz', None, None), ('τοσοῦτος', 'tyle', None, None), ('πόσος', 'ile', None, None), ('πλείων', 'więcej', None, None), ('πλεῖστος', 'najwięcej', None, None), ('ἐλάττων', 'mniej', None, None)], 'sentences': []}, {'id': 'v07d', 'title': 'Liczby i ilości 4', 'icon': 'L', 'track': 'jezyk', 'words': [('ἱκανός', 'dość', None, None), ('λίαν', 'zbyt', None, None), ('διπλοῦς', 'podwójny', None, None), ('τριπλοῦς', 'potrójny', None, None), ('ἑκατοντάς', 'setka', None, 'rodzaj żeński'), ('δεκάς', 'dziesiątka', None, 'rodzaj żeński'), ('χιλιετία', 'tysiąclecie', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v08a', 'title': 'Czas 1', 'icon': 'C', 'track': 'jezyk', 'words': [('λεπτόν', 'minuta', None, 'rodzaj nijaki'), ('ὥρα', 'godzina', None, 'rodzaj żeński'), ('ἡμέρα', 'dzień', None, 'rodzaj żeński'), ('νύξ', 'noc', None, 'rodzaj żeński'), ('ἑβδομάς', 'tydzień', None, 'rodzaj żeński'), ('μήν', 'miesiąc', None, 'rodzaj męski'), ('ἔτος', 'rok', None, 'rodzaj nijaki'), ('ἔαρ', 'wiosna', None, 'rodzaj nijaki'), ('θέρος', 'lato', None, 'rodzaj nijaki'), ('φθινόπωρον', 'jesień', None, 'rodzaj nijaki'), ('χειμών', 'zima', None, 'rodzaj męski'), ('ἕως', 'rano', None, 'rodzaj żeński'), ('μεσημβρία', 'południe', None, 'rodzaj żeński'), ('ἑσπέρα', 'wieczór', None, 'rodzaj żeński'), ('ἀεί', 'zawsze', None, None), ('οὐδέποτε', 'nigdy', None, None)], 'sentences': []}, {'id': 'v08b', 'title': 'Czas 2', 'icon': 'C', 'track': 'jezyk', 'words': [('ἐνίοτε', 'czasem', None, None), ('πολλάκις', 'często', None, None), ('ἤδη', 'już', None, None), ('ἔτι', 'jeszcze', None, None), ('τάχα', 'wkrótce', None, None), ('ὕστερον', 'później', None, None), ('πρῴ', 'wcześnie', None, None), ('ὀψέ', 'późno', None, None), ('πότε', 'kiedy', None, None), ('ἡμερομηνία', 'data', None, 'rodzaj żeński'), ('παρελθόν', 'przeszłość', None, 'rodzaj nijaki'), ('μέλλον', 'przyszłość', None, 'rodzaj nijaki'), ('παρόν', 'teraźniejszość', None, 'rodzaj nijaki'), ('γενέθλια', 'urodziny', None, 'rodzaj nijaki'), ('ἑορτή', 'święto', None, 'rodzaj żeński'), ('ἀναπαύλα', 'wakacje', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v08c', 'title': 'Czas 3', 'icon': 'C', 'track': 'jezyk', 'words': [('σήμερον', 'dziś', None, None), ('αὔριον', 'jutro', None, None), ('χθές', 'wczoraj', None, None), ('νῦν', 'teraz', None, None), ('τότε', 'wtedy', None, None), ('αἰών', 'wiek', None, 'rodzaj męski'), ('νεότης', 'młodość', None, 'rodzaj żeński'), ('γῆρας', 'starość', None, 'rodzaj nijaki'), ('παιδεία', 'dzieciństwo', None, 'rodzaj żeński'), ('ὄρθρος', 'świt', None, 'rodzaj męski'), ('δείλη', 'zmierzch', None, 'rodzaj żeński'), ('μεσονύκτιον', 'północ', None, 'rodzaj nijaki'), ('πρῴην', 'przedwczoraj', None, None), ('εἰς τρίτην', 'pojutrze', None, None), ('ἐντεῦθεν', 'odtąd', None, None), ('πάλαι', 'dawno', None, None)], 'sentences': []}, {'id': 'v08d', 'title': 'Czas 4', 'icon': 'C', 'track': 'jezyk', 'words': [('ἄρτι', 'niedawno', None, None), ('ἐν τούτῳ', 'tymczasem', None, None), ('πρότερον', 'przedtem', None, None), ('τέλος', 'wreszcie', None, None), ('πρῶτον', 'najpierw', None, None), ('ἔπειτα', 'potem', None, None), ('ὀλυμπιάς', 'olimpiada', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v09a', 'title': 'Przyroda i pogoda 1', 'icon': 'P', 'track': 'jezyk', 'words': [('ἀστήρ', 'gwiazda', None, 'rodzaj męski'), ('νεφέλη', 'chmura', None, 'rodzaj żeński'), ('ὑετός', 'deszcz', None, 'rodzaj męski'), ('χιών', 'śnieg', None, 'rodzaj żeński'), ('ἄνεμος', 'wiatr', None, 'rodzaj męski'), ('καταιγίς', 'burza', None, 'rodzaj żeński'), ('ὀμίχλη', 'mgła', None, 'rodzaj żeński'), ('κρύσταλλος', 'lód', None, 'rodzaj męski'), ('ποταμός', 'rzeka', None, 'rodzaj męski'), ('λίμνη', 'jezioro', None, 'rodzaj żeński'), ('ὄρος', 'góra', None, 'rodzaj nijaki'), ('ὕλη', 'las', None, 'rodzaj żeński'), ('δένδρον', 'drzewo', None, 'rodzaj nijaki'), ('ἄνθος', 'kwiat', None, 'rodzaj nijaki'), ('ποία', 'trawa', None, 'rodzaj żeński'), ('φύλλον', 'liść', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v09b', 'title': 'Przyroda i pogoda 2', 'icon': 'P', 'track': 'jezyk', 'words': [('πεδίον', 'pole', None, 'rodzaj nijaki'), ('λειμών', 'łąka', None, 'rodzaj męski'), ('νῆσος', 'wyspa', None, 'rodzaj żeński'), ('αἰγιαλός', 'plaża', None, 'rodzaj męski'), ('ἐρημία', 'pustynia', None, 'rodzaj żeński'), ('πέτρα', 'skała', None, 'rodzaj żeński'), ('εὐδία', 'pogoda', None, 'rodzaj żeński'), ('καῦμα', 'upał', None, 'rodzaj nijaki'), ('ψῦχος', 'zimno', None, 'rodzaj nijaki'), ('θάλπος', 'ciepło', None, 'rodzaj nijaki'), ('πάγος', 'mróz', None, 'rodzaj męski'), ('χάλαζα', 'grad', None, 'rodzaj żeński'), ('βροντή', 'grzmot', None, 'rodzaj żeński'), ('ἀστραπή', 'błyskawica', None, 'rodzaj żeński'), ('ἶρις', 'tęcza', None, 'rodzaj żeński'), ('τέναγος', 'kałuża', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v09c', 'title': 'Przyroda i pogoda 3', 'icon': 'P', 'track': 'jezyk', 'words': [('πηλός', 'błoto', None, 'rodzaj męski'), ('ψάμμος', 'piasek', None, 'rodzaj żeński'), ('κοιλάς', 'dolina', None, 'rodzaj żeński'), ('λόφος', 'wzgórze', None, 'rodzaj męski'), ('σπήλαιον', 'jaskinia', None, 'rodzaj nijaki'), ('καταρράκτης', 'wodospad', None, 'rodzaj męski'), ('πηγή', 'źródło', None, 'rodzaj żeński'), ('κόλπος', 'zatoka', None, 'rodzaj męski'), ('ἀκτή', 'wybrzeże', None, 'rodzaj żeński'), ('ἕλος', 'bagno', None, 'rodzaj nijaki'), ('τέλμα', 'staw', None, 'rodzaj nijaki'), ('θάμνος', 'krzak', None, 'rodzaj męski'), ('ῥίζα', 'korzeń', None, 'rodzaj żeński'), ('κλάδος', 'gałąź', None, 'rodzaj męski'), ('κῦμα', 'fala', None, 'rodzaj nijaki'), ('δρόσος', 'rosa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v09d', 'title': 'Przyroda i pogoda 4', 'icon': 'P', 'track': 'jezyk', 'words': [('κατακλυσμός', 'powódź', None, 'rodzaj męski'), ('σεισμός', 'trzęsienie ziemi', None, 'rodzaj męski'), ('ἡφαίστειον', 'wulkan', None, 'rodzaj nijaki'), ('σκότος', 'ciemność', None, 'rodzaj nijaki'), ('φάος', 'światło dzienne', None, 'rodzaj nijaki'), ('σκιά', 'cień', None, 'rodzaj żeński'), ('οἰκουμένη', 'świat', None, 'rodzaj żeński'), ('φύσις', 'natura', None, 'rodzaj żeński'), ('σπόρος', 'ziarno', None, 'rodzaj męski'), ('καρπός', 'owoc', None, 'rodzaj męski'), ('στέλεχος', 'pień', None, 'rodzaj nijaki'), ('φλοιός', 'kora', None, 'rodzaj męski'), ('λόχμη', 'zarośla', None, 'rodzaj żeński'), ('τρίβος', 'ścieżka', None, 'rodzaj żeński'), ('ἄκρα', 'przylądek', None, 'rodzaj żeński'), ('ἰσθμός', 'przesmyk', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v09e', 'title': 'Przyroda i pogoda 5', 'icon': 'P', 'track': 'jezyk', 'words': [('ἄβυσσος', 'otchłań', None, 'rodzaj żeński'), ('ἀήρ', 'powietrze', None, 'rodzaj męski'), ('αἰθήρ', 'eter', None, 'rodzaj męski'), ('ἠώς', 'zorza', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v10a', 'title': 'Zwierzęta 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('κύων', 'pies', None, 'rodzaj męski'), ('αἴλουρος', 'kot', None, 'rodzaj męski'), ('ἵππος', 'koń', None, 'rodzaj męski'), ('βοῦς', 'krowa', None, 'rodzaj żeński'), ('ταῦρος', 'byk', None, 'rodzaj męski'), ('ὗς', 'świnia', None, 'rodzaj żeński'), ('ὄϊς', 'owca', None, 'rodzaj żeński'), ('αἴξ', 'koza', None, 'rodzaj żeński'), ('ὄρνις', 'kura', None, 'rodzaj żeński'), ('νῆσσα', 'kaczka', None, 'rodzaj żeński'), ('μῦς', 'mysz', None, 'rodzaj męski'), ('ὄφις', 'wąż', None, 'rodzaj męski'), ('βάτραχος', 'żaba', None, 'rodzaj męski'), ('λέων', 'lew', None, 'rodzaj męski'), ('τίγρις', 'tygrys', None, 'rodzaj żeński'), ('ἐλέφας', 'słoń', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10b', 'title': 'Zwierzęta 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('ἄρκτος', 'niedźwiedź', None, 'rodzaj żeński'), ('λύκος', 'wilk', None, 'rodzaj męski'), ('ἀλώπηξ', 'lis', None, 'rodzaj żeński'), ('λαγώς', 'zając', None, 'rodzaj męski'), ('ἔλαφος', 'jeleń', None, 'rodzaj męski'), ('πίθηκος', 'małpa', None, 'rodzaj męski'), ('ψυχή', 'motyl', None, 'rodzaj żeński'), ('μέλισσα', 'pszczoła', None, 'rodzaj żeński'), ('μυῖα', 'mucha', None, 'rodzaj żeński'), ('ἀράχνη', 'pająk', None, 'rodzaj żeński'), ('ζῷον', 'zwierzę', None, 'rodzaj nijaki'), ('ἔντομον', 'owad', None, 'rodzaj nijaki'), ('ὄνος', 'osioł', None, 'rodzaj męski'), ('ἡμίονος', 'mul', None, 'rodzaj męski'), ('κάμηλος', 'wielbłąd', None, 'rodzaj męski'), ('κροκόδειλος', 'krokodyl', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10c', 'title': 'Zwierzęta 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('δελφίς', 'delfin', None, 'rodzaj męski'), ('φάλαινα', 'wieloryb', None, 'rodzaj żeński'), ('ἀετός', 'orzeł', None, 'rodzaj męski'), ('γλαῦξ', 'sowa', None, 'rodzaj żeński'), ('περιστερά', 'gołąb', None, 'rodzaj żeński'), ('κορώνη', 'wrona', None, 'rodzaj żeński'), ('κόραξ', 'kruk', None, 'rodzaj męski'), ('κύκνος', 'łabędź', None, 'rodzaj męski'), ('χήν', 'gęś', None, 'rodzaj męski'), ('ταώς', 'paw', None, 'rodzaj męski'), ('ἀηδών', 'słowik', None, 'rodzaj żeński'), ('χελιδών', 'jaskółka', None, 'rodzaj żeński'), ('ἱέραξ', 'sokół', None, 'rodzaj męski'), ('κάπρος', 'dzik', None, 'rodzaj męski'), ('πάρδαλις', 'pantera', None, 'rodzaj żeński'), ('ὕαινα', 'hiena', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v10d', 'title': 'Zwierzęta 4', 'icon': 'Z', 'track': 'jezyk', 'words': [('χελώνη', 'żółw', None, 'rodzaj żeński'), ('κοχλίας', 'ślimak', None, 'rodzaj męski'), ('σκώληξ', 'robak', None, 'rodzaj męski'), ('μύρμηξ', 'mrówka', None, 'rodzaj męski'), ('κώνωψ', 'komar', None, 'rodzaj męski'), ('σφήξ', 'osa', None, 'rodzaj żeński'), ('οἶστρος', 'szerszeń', None, 'rodzaj męski'), ('ψύλλα', 'pchła', None, 'rodzaj żeński'), ('φθείρ', 'wesz', None, 'rodzaj męski'), ('σκορπίος', 'skorpion', None, 'rodzaj męski'), ('καρκίνος', 'krab', None, 'rodzaj męski'), ('πολύπους', 'ośmiornica', None, 'rodzaj męski'), ('ποίμνη', 'stado', None, 'rodzaj żeński'), ('ἀγέλη', 'trzoda', None, 'rodzaj żeński'), ('ἀρήν', 'jagnię', None, 'rodzaj męski'), ('μόσχος', 'cielę', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10e', 'title': 'Zwierzęta 5', 'icon': 'Z', 'track': 'jezyk', 'words': [('σκύλαξ', 'szczeniak', None, 'rodzaj męski'), ('νεοσσιά', 'gniazdo', None, 'rodzaj żeński'), ('ὁπλή', 'kopyto', None, 'rodzaj żeński'), ('δορά', 'futro', None, 'rodzaj żeński'), ('κλωβός', 'klatka', None, 'rodzaj męski'), ('σμῆνος', 'ul', None, 'rodzaj nijaki'), ('ποῦς ζῴου', 'łapa', None, 'rodzaj męski'), ('χαυλιόδους', 'kieł', None, 'rodzaj męski'), ('ὄνυξ ζῴου', 'pazur', None, 'rodzaj męski'), ('τρίχωμα', 'sierść', None, 'rodzaj nijaki'), ('Πήγασος', 'pegaz', None, 'rodzaj męski'), ('Μινώταυρος', 'minotaur', None, 'rodzaj męski'), ('δράκων', 'smok', None, 'rodzaj męski'), ('σφίγξ', 'sfinks', None, 'rodzaj żeński'), ('χίμαιρα', 'chimera', None, 'rodzaj żeński'), ('κένταυρος', 'centaur', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10f', 'title': 'Zwierzęta 6', 'icon': 'Z', 'track': 'jezyk', 'words': [('σειρήν', 'syrena', None, 'rodzaj żeński'), ('ἅρπυια', 'harpia', None, 'rodzaj żeński'), ('γρύψ', 'gryf', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11a', 'title': 'Miasto i budynki 1', 'icon': 'M', 'track': 'jezyk', 'words': [('πόλις', 'miasto', None, 'rodzaj żeński'), ('κώμη', 'wieś', None, 'rodzaj żeński'), ('ὁδός', 'ulica', None, 'rodzaj żeński'), ('λεωφόρος', 'droga (publiczna)', None, 'rodzaj żeński'), ('ἀγορά', 'plac', None, 'rodzaj żeński'), ('γέφυρα', 'most', None, 'rodzaj żeński'), ('ἄλσος', 'park', None, 'rodzaj nijaki'), ('ἐργαστήριον', 'sklep', None, 'rodzaj nijaki'), ('ἰατρεῖον', 'szpital', None, 'rodzaj nijaki'), ('ἀκαδημία', 'uniwersytet', None, 'rodzaj żeński'), ('βιβλιοθήκη', 'biblioteka', None, 'rodzaj żeński'), ('μουσεῖον', 'muzeum', None, 'rodzaj nijaki'), ('ναός', 'świątynia', None, 'rodzaj męski'), ('ἱερόν', 'sanktuarium', None, 'rodzaj nijaki'), ('ἐκκλησία', 'kościół', None, 'rodzaj żeński'), ('πανδοχεῖον', 'restauracja', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v11b', 'title': 'Miasto i budynki 2', 'icon': 'M', 'track': 'jezyk', 'words': [('καπηλεῖον', 'karczma', None, 'rodzaj nijaki'), ('λιμήν', 'port', None, 'rodzaj męski'), ('θέατρον', 'teatr', None, 'rodzaj nijaki'), ('στάδιον', 'stadion', None, 'rodzaj nijaki'), ('γυμνάσιον', 'gimnazjon', None, 'rodzaj nijaki'), ('βαλανεῖα', 'łaźnie', None, 'rodzaj nijaki'), ('ὑδραγωγός', 'akwedukt', None, 'rodzaj męski'), ('ὄχετος', 'kanał', None, 'rodzaj męski'), ('βουλευτήριον', 'rada', None, 'rodzaj nijaki'), ('τείχη', 'mury miejskie', None, 'rodzaj nijaki'), ('πύργος', 'wieża', None, 'rodzaj męski'), ('φρούριον', 'twierdza', None, 'rodzaj nijaki'), ('ἀκρόπολις', 'akropol', None, 'rodzaj żeński'), ('στρατόπεδον', 'obóz', None, 'rodzaj nijaki'), ('δεσμωτήριον', 'więzienie', None, 'rodzaj nijaki'), ('τάφος', 'grób', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11c', 'title': 'Miasto i budynki 3', 'icon': 'M', 'track': 'jezyk', 'words': [('νεκροταφεῖον', 'cmentarz', None, 'rodzaj nijaki'), ('μνημεῖον', 'pomnik', None, 'rodzaj nijaki'), ('διδασκαλεῖον', 'szkoła', None, 'rodzaj nijaki'), ('μύλη', 'młyn', None, 'rodzaj żeński'), ('ἀμφοδον', 'dzielnica', None, 'rodzaj nijaki'), ('ἄστυ', 'centrum', None, 'rodzaj nijaki'), ('πίναξ', 'mapa', None, 'rodzaj męski'), ('ἀνάκτορον', 'pałac', None, 'rodzaj nijaki'), ('ἕδρα', 'siedziba', None, 'rodzaj żeński'), ('πύλαι', 'brama miasta', None, 'rodzaj żeński'), ('ἔρυμα', 'forteca', None, 'rodzaj nijaki'), ('σηκός', 'świątynia (część)', None, 'rodzaj męski'), ('στοά', 'portyk', None, 'rodzaj żeński'), ('δῆμος', 'wieś (osada)', None, 'rodzaj męski'), ('παλαίστρα', 'plac ćwiczeń', None, 'rodzaj żeński'), ('ἱππόδρομος', 'hipodrom', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11d', 'title': 'Miasto i budynki 4', 'icon': 'M', 'track': 'jezyk', 'words': [('πρυτανεῖον', 'ratusz', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v12a', 'title': 'Podróż i transport 1', 'icon': 'P', 'track': 'jezyk', 'words': [('ἅρμα', 'rydwan', None, 'rodzaj nijaki'), ('ἅμαξα', 'wóz', None, 'rodzaj żeński'), ('ἱππεία', 'jazda konna', None, 'rodzaj żeński'), ('ναῦς', 'statek', None, 'rodzaj żeński'), ('τριήρης', 'okręt wojenny', None, 'rodzaj żeński'), ('πλοῖον', 'łódź', None, 'rodzaj nijaki'), ('ἐρετμόν', 'wiosło', None, 'rodzaj nijaki'), ('ἱστίον', 'żagiel', None, 'rodzaj nijaki'), ('πηδάλιον', 'ster', None, 'rodzaj nijaki'), ('ἄγκυρα', 'kotwica', None, 'rodzaj żeński'), ('ὁδοιπορία', 'podróż', None, 'rodzaj żeński'), ('στόλος', 'wyprawa', None, 'rodzaj męski'), ('τρίοδος', 'skrzyżowanie', None, 'rodzaj żeński'), ('ἑρμῆς', 'kamień milowy', None, 'rodzaj męski'), ('πόρος', 'brod', None, 'rodzaj męski'), ('διάβασις', 'przeprawa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v12b', 'title': 'Podróż i transport 2', 'icon': 'P', 'track': 'jezyk', 'words': [('ὅρος', 'granica', None, 'rodzaj męski'), ('ἡνίοχος', 'kierowca', None, 'rodzaj męski'), ('ἐπιβάτης', 'pasażer', None, 'rodzaj męski'), ('κῆρυξ', 'posłaniec', None, 'rodzaj męski'), ('καταγώγιον', 'gospoda', None, 'rodzaj nijaki'), ('ὁδίτης', 'podróżnik', None, 'rodzaj męski'), ('ναυτιλία', 'żeglarstwo', None, 'rodzaj żeński'), ('ἤπειρος', 'ląd', None, 'rodzaj żeński'), ('οὖρος', 'wiatr w żagle', None, 'rodzaj męski'), ('ναυαγός', 'rozbitek', None, 'rodzaj męski'), ('ναυάγιον', 'zatonięcie', None, 'rodzaj nijaki'), ('ἐρέτης', 'żeglarz (wioślarz)', None, 'rodzaj męski'), ('κυβερνήτης', 'kapitan', None, 'rodzaj męski'), ('πλοῦς', 'kurs', None, 'rodzaj męski'), ('παρασάγγης', 'parasanga', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13a', 'title': 'Praca i szkoła 1', 'icon': 'P', 'track': 'jezyk', 'words': [('ἔργον', 'praca', None, 'rodzaj nijaki'), ('τέχνη', 'zawód', None, 'rodzaj żeński'), ('χαλκεύς', 'kowal', None, 'rodzaj męski'), ('τέκτων', 'stolarz', None, 'rodzaj męski'), ('σκυτοτόμος', 'szewc', None, 'rodzaj męski'), ('ἁλιεύς', 'rybak', None, 'rodzaj męski'), ('ἀρτοποιός', 'piekarz', None, 'rodzaj męski'), ('μάγειρος', 'rzeźnik', None, 'rodzaj męski'), ('ὀψοποιός', 'kucharz', None, 'rodzaj męski'), ('κουρεύς', 'fryzjer', None, 'rodzaj męski'), ('ῥάπτης', 'krawiec', None, 'rodzaj męski'), ('ἀρχιτέκτων', 'architekt', None, 'rodzaj męski'), ('κάπηλος', 'kupiec (detaliczny)', None, 'rodzaj męski'), ('τραπεζίτης', 'bankier', None, 'rodzaj męski'), ('χρήματα', 'pieniądze', None, 'rodzaj nijaki'), ('μισθός', 'pensja', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13b', 'title': 'Praca i szkoła 2', 'icon': 'P', 'track': 'jezyk', 'words': [('συνθήκη', 'umowa', None, 'rodzaj żeński'), ('σύνοδος', 'spotkanie', None, 'rodzaj żeński'), ('μάθημα', 'lekcja', None, 'rodzaj nijaki'), ('δοκιμασία', 'egzamin', None, 'rodzaj żeński'), ('κρίσις', 'ocena', None, 'rodzaj żeński'), ('τάξις', 'klasa', None, 'rodzaj żeński'), ('βίβλος', 'zwój', None, 'rodzaj żeński'), ('δέλτος', 'tabliczka woskowa', None, 'rodzaj żeński'), ('κάλαμος', 'pióro', None, 'rodzaj męski'), ('μέλαν', 'atrament', None, 'rodzaj nijaki'), ('πάπυρος', 'papirus', None, 'rodzaj żeński'), ('διφθέρα', 'pergamin', None, 'rodzaj żeński'), ('λεξικόν', 'słownik', None, 'rodzaj nijaki'), ('ἐρώτημα', 'pytanie', None, 'rodzaj nijaki'), ('ἀπόκρισις', 'odpowiedź', None, 'rodzaj żeński'), ('πεῖρα', 'test', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13c', 'title': 'Praca i szkoła 3', 'icon': 'P', 'track': 'jezyk', 'words': [('σχολή', 'szkoła', None, 'rodzaj żeński'), ('γραμματική', 'gramatyka', None, 'rodzaj żeński'), ('ῥητορική', 'retoryka', None, 'rodzaj żeński'), ('ἐπιστήμη', 'nauka', None, 'rodzaj żeński'), ('γνῶσις', 'wiedza', None, 'rodzaj żeński'), ('σοφία', 'mądrość', None, 'rodzaj żeński'), ('βουλή', 'rada', None, 'rodzaj żeński'), ('ἐντολή', 'polecenie', None, 'rodzaj żeński'), ('πρόσταγμα', 'rozkaz', None, 'rodzaj nijaki'), ('νόμος', 'ustawa', None, 'rodzaj męski'), ('ψῆφος', 'wyrok', None, 'rodzaj żeński'), ('τιμωρία', 'kara', None, 'rodzaj żeński'), ('ἆθλον', 'nagroda', None, 'rodzaj nijaki'), ('καθῆκον', 'obowiązek', None, 'rodzaj nijaki'), ('ὄργανον', 'narzędzie', None, 'rodzaj nijaki'), ('σφῦρα', 'młot', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13d', 'title': 'Praca i szkoła 4', 'icon': 'P', 'track': 'jezyk', 'words': [('ἄκμων', 'kowadło', None, 'rodzaj męski'), ('πέλεκυς', 'siekiera', None, 'rodzaj męski'), ('πρίων', 'piła', None, 'rodzaj męski'), ('γλυφίς', 'dłuto', None, 'rodzaj żeński'), ('ἄροτρον', 'pług', None, 'rodzaj nijaki'), ('δρέπανον', 'sierp', None, 'rodzaj nijaki'), ('πτύον', 'łopata', None, 'rodzaj nijaki'), ('σχοινίον', 'lina', None, 'rodzaj nijaki'), ('ἅλυσις', 'łańcuch', None, 'rodzaj żeński'), ('ἦλος', 'gwóźdź', None, 'rodzaj męski'), ('διδασκαλία', 'nauczanie', None, 'rodzaj żeński'), ('μάθησις', 'uczenie się', None, 'rodzaj żeński'), ('φιλοσοφία', 'filozofia', None, 'rodzaj żeński'), ('μαθηματικά', 'matematyka', None, 'rodzaj nijaki'), ('γεωμετρία', 'geometria', None, 'rodzaj żeński'), ('ἀστρονομία', 'astronomia', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13e', 'title': 'Praca i szkoła 5', 'icon': 'P', 'track': 'jezyk', 'words': [('μουσική', 'muzyka', None, 'rodzaj żeński'), ('ποίησις', 'poezja', None, 'rodzaj żeński'), ('τραγῳδία', 'tragedia', None, 'rodzaj żeński'), ('κωμῳδία', 'komedia', None, 'rodzaj żeński'), ('ἔπος', 'epos', None, 'rodzaj nijaki'), ('ᾠδή', 'pieśń', None, 'rodzaj żeński'), ('ὕμνος', 'hymn', None, 'rodzaj męski'), ('μῦθος', 'bajka', None, 'rodzaj męski'), ('ἱστορία', 'historia (badanie)', None, 'rodzaj żeński'), ('διάλογος', 'dialog', None, 'rodzaj męski'), ('ἐπιχείρημα', 'argument', None, 'rodzaj nijaki'), ('ἀπόδειξις', 'dowód', None, 'rodzaj żeński'), ('ὁρισμός', 'definicja', None, 'rodzaj męski'), ('ἔννοια', 'pojęcie', None, 'rodzaj żeński'), ('διάνοια', 'myśl', None, 'rodzaj żeński'), ('νοῦς', 'rozum', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13f', 'title': 'Praca i szkoła 6', 'icon': 'P', 'track': 'jezyk', 'words': [('πνεῦμα', 'duch', None, 'rodzaj nijaki'), ('ἀρετή', 'cnota', None, 'rodzaj żeński'), ('κακία', 'wada', None, 'rodzaj żeński'), ('εὐδαιμονία', 'szczęście (stan)', None, 'rodzaj żeński'), ('ἀγαθόν', 'dobro', None, 'rodzaj nijaki'), ('κακόν', 'zło', None, 'rodzaj nijaki'), ('κάλλος', 'piękno', None, 'rodzaj nijaki'), ('ἀλήθεια', 'prawda', None, 'rodzaj żeński'), ('ψεῦδος', 'kłamstwo', None, 'rodzaj nijaki'), ('δικαιοσύνη', 'sprawiedliwość', None, 'rodzaj żeński'), ('ἀνδρεία', 'odwaga (cnota)', None, 'rodzaj żeński'), ('σωφροσύνη', 'umiar', None, 'rodzaj żeński'), ('φρόνησις', 'roztropność', None, 'rodzaj żeński'), ('ἐλευθερία', 'wolność', None, 'rodzaj żeński'), ('δουλεία', 'niewola', None, 'rodzaj żeński'), ('δημοκρατία', 'demokracja', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13g', 'title': 'Praca i szkoła 7', 'icon': 'P', 'track': 'jezyk', 'words': [('μοναρχία', 'monarchia', None, 'rodzaj żeński'), ('ὀλιγαρχία', 'oligarchia', None, 'rodzaj żeński'), ('τυραννίς', 'tyrania', None, 'rodzaj żeński'), ('πόλεμος', 'wojna', None, 'rodzaj męski'), ('εἰρήνη', 'pokój', None, 'rodzaj żeński'), ('ὁμόνοια', 'zgoda', None, 'rodzaj żeński'), ('ἔρις', 'spór', None, 'rodzaj żeński'), ('μάχη', 'bitwa', None, 'rodzaj żeński'), ('νίκη', 'zwycięstwo', None, 'rodzaj żeński'), ('ἧττα', 'klęska', None, 'rodzaj żeński'), ('συμμαχία', 'sojusz', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v14a', 'title': 'Pieniądze i handel 1', 'icon': 'P', 'track': 'jezyk', 'words': [('τιμή', 'cena', None, 'rodzaj żeński'), ('νόμισμα', 'moneta', None, 'rodzaj nijaki'), ('δραχμή', 'drachma', None, 'rodzaj żeński'), ('τάλαντον', 'talent', None, 'rodzaj nijaki'), ('ὀβολός', 'obol', None, 'rodzaj męski'), ('ὑπόλοιπον', 'reszta', None, 'rodzaj nijaki'), ('ἄφεσις', 'zniżka', None, 'rodzaj żeński'), ('κάνεον', 'koszyk', None, 'rodzaj nijaki'), ('ἐμπορία', 'towar', None, 'rodzaj żeński'), ('ὠνή', 'zakup', None, 'rodzaj żeński'), ('πρᾶσις', 'sprzedaż', None, 'rodzaj żeński'), ('ἀξία', 'wartość', None, 'rodzaj żeński'), ('δάνειον', 'kredyt', None, 'rodzaj nijaki'), ('ὀφείλημα', 'dług', None, 'rodzaj nijaki'), ('φόρος', 'podatek', None, 'rodzaj męski'), ('πλοῦτος', 'bogactwo', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v14b', 'title': 'Pieniądze i handel 2', 'icon': 'P', 'track': 'jezyk', 'words': [('πένης', 'biedny', None, None), ('πλούσιος', 'bogaty', None, None), ('εὐτελής', 'tani', None, None), ('πολυτελής', 'drogi', None, None), ('τόκος', 'lichwa', None, 'rodzaj męski'), ('κέρδος', 'zysk', None, 'rodzaj nijaki'), ('ζημία', 'strata', None, 'rodzaj żeński'), ('θησαυρός', 'skarb', None, 'rodzaj męski'), ('οὐσία', 'majątek', None, 'rodzaj żeński'), ('κλῆρος', 'spadek', None, 'rodzaj męski'), ('δῶρον', 'dar', None, 'rodzaj nijaki'), ('λεία', 'łup', None, 'rodzaj żeński'), ('λύτρον', 'okup', None, 'rodzaj nijaki'), ('ὠνέομαι', 'kupować', None, None), ('πωλέω', 'sprzedawać', None, None), ('τελέω', 'płacić', None, None)], 'sentences': []}, {'id': 'v14c', 'title': 'Pieniądze i handel 3', 'icon': 'P', 'track': 'jezyk', 'words': [('δανείζω', 'pożyczać', None, None), ('κερδαίνω', 'zarabiać', None, None), ('ὀφειλέτης', 'dłużnik', None, 'rodzaj męski'), ('δανειστής', 'wierzyciel', None, 'rodzaj męski'), ('πενία', 'ubóstwo', None, 'rodzaj żeński'), ('πτωχός', 'biedak', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v15a', 'title': 'Zdrowie 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('ὑγίεια', 'zdrowie', None, 'rodzaj żeński'), ('νόσος', 'choroba', None, 'rodzaj żeński'), ('ἄλγος', 'ból', None, 'rodzaj nijaki'), ('πυρετός', 'gorączka', None, 'rodzaj męski'), ('βήξ', 'kaszel', None, 'rodzaj żeński'), ('φάρμακον', 'lekarstwo', None, 'rodzaj nijaki'), ('τομή', 'operacja', None, 'rodzaj żeński'), ('τραῦμα', 'rana', None, 'rodzaj nijaki'), ('συμφορά', 'wypadek', None, 'rodzaj żeński'), ('ὑγιής', 'zdrowy', None, None), ('ἀσθενής', 'chory', None, None), ('κάμνων', 'zmęczony', None, None), ('νυστάζων', 'śpiący', None, None), ('ἰσχυρός', 'silny', None, None), ('ἀδύνατος', 'słaby', None, None), ('κωφός', 'głuchy', None, None)], 'sentences': []}, {'id': 'v15b', 'title': 'Zdrowie 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('τυφλός', 'ślepy', None, None), ('χωλός', 'kulawy', None, None), ('ἄφωνος', 'niemy', None, None), ('μανιώδης', 'szalony', None, None), ('δηλητήριον', 'trucizna', None, 'rodzaj nijaki'), ('θάνατος', 'śmierć', None, 'rodzaj męski'), ('νεκρός', 'trup', None, 'rodzaj męski'), ('ἴασις', 'uzdrowienie', None, 'rodzaj żeński'), ('βοήθεια', 'pomoc', None, 'rodzaj żeński'), ('λοιμός', 'zaraza', None, 'rodzaj męski'), ('οὐλή', 'blizna', None, 'rodzaj żeński'), ('ὕπνος', 'sen', None, 'rodzaj męski'), ('ἀνάπαυσις', 'odpoczynek', None, 'rodzaj żeński'), ('πνοή', 'oddech', None, 'rodzaj żeński'), ('δίαιτα', 'dieta', None, 'rodzaj żeński'), ('βοτάνη', 'zioło', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v15c', 'title': 'Zdrowie 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('ἄλειμμα', 'maść', None, 'rodzaj nijaki'), ('λουτρόν', 'kąpiel', None, 'rodzaj nijaki'), ('κεφαλαλγία', 'ból głowy', None, 'rodzaj żeński'), ('θεραπεία', 'kuracja', None, 'rodzaj żeński'), ('σύμπτωμα', 'objaw', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v16a', 'title': 'Uczucia i charakter 1', 'icon': 'U', 'track': 'jezyk', 'words': [('χαρά', 'radość', None, 'rodzaj żeński'), ('λύπη', 'smutek', None, 'rodzaj żeński'), ('φόβος', 'strach', None, 'rodzaj męski'), ('ὀργή', 'gniew', None, 'rodzaj żeński'), ('ἔρως', 'miłość', None, 'rodzaj męski'), ('ἀγάπη', 'miłość (agape)', None, 'rodzaj żeński'), ('φιλία', 'przyjaźń', None, 'rodzaj żeński'), ('μῖσος', 'nienawiść', None, 'rodzaj nijaki'), ('ἐλπίς', 'nadzieja', None, 'rodzaj żeński'), ('ὄνειρος', 'marzenie', None, 'rodzaj męski'), ('τύχη', 'szczęście (traf)', None, 'rodzaj żeński'), ('αἰδώς', 'wstyd', None, 'rodzaj żeński'), ('θαῦμα', 'zdziwienie', None, 'rodzaj nijaki'), ('περιεργία', 'ciekawość', None, 'rodzaj żeński'), ('ὑπομονή', 'cierpliwość', None, 'rodzaj żeński'), ('ἁπλοῦς', 'szczery', None, None)], 'sentences': []}, {'id': 'v16b', 'title': 'Uczucia i charakter 2', 'icon': 'U', 'track': 'jezyk', 'words': [('ἡδύς', 'miły', None, None), ('εὐγενής', 'grzeczny', None, None), ('ἠλίθιος', 'głupi', None, None), ('σοφός', 'mądry', None, None), ('ἀργός', 'leniwy', None, None), ('φιλόπονος', 'pracowity', None, None), ('περίεργος', 'ciekawy', None, None), ('φαιδρός', 'wesoły', None, None), ('λυπηρός', 'smutny', None, None), ('ὀργίλος', 'zły (rozgniewany)', None, None), ('εὐδαίμων', 'szczęśliwy', None, None), ('ἐρῶν', 'zakochany', None, None), ('μόνος', 'samotny', None, None), ('ἥσυχος', 'spokojny', None, None), ('ὑπερήφανος', 'dumny', None, None), ('ζηλότυπος', 'zazdrosny', None, None)], 'sentences': []}, {'id': 'v16c', 'title': 'Uczucia i charakter 3', 'icon': 'U', 'track': 'jezyk', 'words': [('εὐχάριστος', 'wdzięczny', None, None), ('ἀνιώμενος', 'zmartwiony', None, None), ('ἀνδρεῖος', 'odważny', None, None), ('πιστός', 'wierny', None, None), ('ἄπιστος', 'zdradziecki', None, None), ('φειδωλός', 'skąpy', None, None), ('ἐλευθέριος', 'hojny', None, None), ('ταπεινός', 'pokorny', None, None), ('αὐθάδης', 'uparty', None, None), ('ἐλεήμων', 'litościwy', None, None), ('ὠμός', 'okrutny', None, None), ('δίκαιος', 'sprawiedliwy', None, None), ('ἄδικος', 'niesprawiedliwy', None, None), ('χρηστός', 'uczciwy', None, None), ('πονηρός', 'nikczemny', None, None), ('δειλός', 'tchórzliwy', None, None)], 'sentences': []}, {'id': 'v16d', 'title': 'Uczucia i charakter 4', 'icon': 'U', 'track': 'jezyk', 'words': [('εὐσεβής', 'pobożny', None, None), ('ἀσεβής', 'bezbożny', None, None), ('γενναῖος', 'szlachetny', None, None), ('ἀγεννής', 'podły', None, None), ('φιλικός', 'przyjazny', None, None), ('ἐχθρικός', 'wrogi', None, None), ('φιλόφρων', 'uprzejmy', None, None), ('ἔλεος', 'litość', None, 'rodzaj nijaki'), ('μεταμέλεια', 'żal', None, 'rodzaj żeński'), ('πόθος', 'tęsknota', None, 'rodzaj męski'), ('ζῆλος', 'zazdrość', None, 'rodzaj męski'), ('ἐκδίκησις', 'zemsta', None, 'rodzaj żeński'), ('ὅρκος', 'przysięga', None, 'rodzaj męski'), ('μοῖρα', 'los', None, 'rodzaj żeński'), ('εἱμαρμένη', 'przeznaczenie', None, 'rodzaj żeński'), ('ὕβρις', 'hybris', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v16e', 'title': 'Uczucia i charakter 5', 'icon': 'U', 'track': 'jezyk', 'words': [('νέμεσις', 'kara boska', None, 'rodzaj żeński'), ('ἔκστασις', 'zachwyt', None, 'rodzaj żeński'), ('ἐνθουσιασμός', 'entuzjazm', None, 'rodzaj męski'), ('πάθος', 'wzruszenie', None, 'rodzaj nijaki'), ('ἦθος', 'charakter', None, 'rodzaj nijaki'), ('ἔθος', 'zwyczaj', None, 'rodzaj nijaki'), ('φύσις ἀνθρώπου', 'natura człowieka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v17a', 'title': 'Przymiotniki 1', 'icon': 'P', 'track': 'jezyk', 'words': [('μικρός', 'mały', None, None), ('μακρός', 'długi', None, None), ('βραχύς', 'krótki', None, None), ('ὑψηλός', 'wysoki', None, None), ('εὐρύς', 'szeroki', None, None), ('στενός', 'wąski', None, None), ('παχύς', 'gruby', None, None), ('λεπτός', 'chudy', None, None), ('βαρύς', 'ciężki', None, None), ('ἐλαφρός', 'lekki', None, None), ('ταχύς', 'szybki', None, None), ('βραδύς', 'wolny', None, None), ('σκληρός', 'twardy', None, None), ('μαλακός', 'miękki', None, None), ('ὑγρός', 'mokry', None, None), ('ξηρός', 'suchy', None, None)], 'sentences': []}, {'id': 'v17b', 'title': 'Przymiotniki 2', 'icon': 'P', 'track': 'jezyk', 'words': [('καθαρός', 'czysty', None, None), ('ῥυπαρός', 'brudny', None, None), ('πλήρης', 'pełny', None, None), ('κενός', 'pusty', None, None), ('ὀξύς', 'ostry', None, None), ('μεγαλόφωνος', 'głośny', None, None), ('σιγηλός', 'cichy', None, None), ('νέος', 'młody', None, None), ('παλαιός', 'stary', None, None), ('καινός', 'nowy', None, None), ('κακός', 'zły', None, None), ('αἰσχρός', 'brzydki', None, None), ('ῥᾴδιος', 'łatwy', None, None), ('χαλεπός', 'trudny', None, None), ('σπουδαῖος', 'ważny', None, None), ('δυνατός', 'możliwy', None, None)], 'sentences': []}, {'id': 'v17c', 'title': 'Przymiotniki 3', 'icon': 'P', 'track': 'jezyk', 'words': [('ἀληθής', 'prawdziwy', None, None), ('ψευδής', 'fałszywy', None, None), ('ἴδιος', 'własny', None, None), ('ἀλλότριος', 'obcy', None, None), ('ἅγιος', 'święty', None, None), ('κραταιός', 'potężny', None, None), ('ἔνδοξος', 'sławny', None, None), ('ἐγγύς', 'bliski', None, None), ('πόρρω', 'daleki', None, None), ('βέβαιος', 'pewny', None, None), ('ἄδηλος', 'niepewny', None, None), ('ἕτοιμος', 'gotowy', None, None), ('ὅμοιος', 'podobny', None, None), ('ἀνόμοιος', 'niepodobny', None, None), ('ἄλλος', 'inny', None, None), ('ἕκαστος', 'każdy', None, None)], 'sentences': []}, {'id': 'v17d', 'title': 'Przymiotniki 4', 'icon': 'P', 'track': 'jezyk', 'words': [('πᾶς', 'wszelki', None, None), ('βαθύς', 'głęboki', None, None), ('γλυκύς', 'słodki', None, None), ('πικρός', 'gorzki', None, None), ('ἁλμυρός', 'słony', None, None), ('θερμός', 'gorący', None, None), ('ψυχρός', 'zimny', None, None), ('χλιαρός', 'ciepły', None, None), ('ὡραῖος', 'piękny', None, None), ('κοινός', 'pospolity', None, None), ('σπάνιος', 'rzadki', None, None), ('εὔπορος', 'bogaty (w)', None, None), ('ἄπορος', 'ubogi', None, None), ('ἀσφαλής', 'bezpieczny', None, None), ('ἐπικίνδυνος', 'niebezpieczny', None, None), ('χωριστός', 'osobny', None, None)], 'sentences': []}, {'id': 'v17e', 'title': 'Przymiotniki 5', 'icon': 'P', 'track': 'jezyk', 'words': [('ὁλόκληρος', 'cały (nienaruszony)', None, None), ('ἔσχατος', 'ostatni', None, None), ('ἑπόμενος', 'następny', None, None), ('προηγούμενος', 'poprzedni', None, None), ('ἀρχαῖος', 'dawny', None, None), ('αἰώνιος', 'wieczny', None, None), ('θνητός', 'śmiertelny', None, None), ('ἀθάνατος', 'nieśmiertelny', None, None), ('ἀνθρώπινος', 'ludzki', None, None), ('Ἑλληνικός', 'grecki', None, None), ('βαρβαρικός', 'barbarzyński', None, None), ('αὐτόνομος', 'wolny (swobodny)', None, None), ('ὁ αὐτός', 'ten sam', None, None), ('ἑκάτερος', 'każdy z dwóch', None, None), ('οὐδέτερος', 'żaden z dwóch', None, None), ('ἀμφότεροι', 'obaj', None, None)], 'sentences': []}, {'id': 'v18a', 'title': 'Czasowniki podstawowe 1', 'icon': 'C', 'track': 'jezyk', 'words': [('ποιέω', 'robić', None, None), ('βαίνω', 'iść', None, None), ('ἐλαύνω', 'jechać', None, None), ('ἔρχομαι', 'przyjść', None, None), ('ἐξέρχομαι', 'wyjść', None, None), ('εἰσέρχομαι', 'wejść', None, None), ('ἐπανέρχομαι', 'wrócić', None, None), ('τρέχω', 'biec', None, None), ('ἵσταμαι', 'stać', None, None), ('κάθημαι', 'siedzieć', None, None), ('κεῖμαι', 'leżeć', None, None), ('καθεύδω', 'spać', None, None), ('ἀνίσταμαι', 'wstać', None, None), ('ἐσθίω', 'jeść', None, None), ('πίνω', 'pić', None, None), ('ἕψω', 'gotować', None, None)], 'sentences': []}, {'id': 'v18b', 'title': 'Czasowniki podstawowe 2', 'icon': 'C', 'track': 'jezyk', 'words': [('λούω', 'myć', None, None), ('ἐνδύομαι', 'ubierać się', None, None), ('φημί', 'powiedzieć', None, None), ('ἐρωτάω', 'pytać', None, None), ('ἀποκρίνομαι', 'odpowiadać', None, None), ('ἐπακούω', 'słuchać', None, None), ('ὁράω', 'widzieć', None, None), ('ἀναγιγνώσκω', 'czytać', None, None), ('μανθάνω', 'uczyć się', None, None), ('διδάσκω', 'uczyć (kogoś)', None, None), ('συνίημι', 'rozumieć', None, None), ('γιγνώσκω', 'znać', None, None), ('νομίζω', 'myśleć', None, None), ('μιμνῄσκομαι', 'pamiętać', None, None), ('ἐπιλανθάνομαι', 'zapominać', None, None), ('βούλομαι', 'chcieć', None, None)], 'sentences': []}, {'id': 'v18c', 'title': 'Czasowniki podstawowe 3', 'icon': 'C', 'track': 'jezyk', 'words': [('φιλέω', 'lubić', None, None), ('ἀγαπάω', 'kochać', None, None), ('δέομαι', 'potrzebować', None, None), ('δύναμαι', 'móc', None, None), ('δεῖ', 'musieć', None, None), ('δίδωμι', 'dawać', None, None), ('λαμβάνω', 'brać', None, None), ('ἀγοράζω', 'kupować', None, None), ('ἀποδίδωμι', 'płacić', None, None), ('ἀνοίγω', 'otwierać', None, None), ('κλείω', 'zamykać', None, None), ('ἄρχομαι', 'zaczynać', None, None), ('ἐργάζομαι', 'pracować', None, None), ('παίζω', 'grać', None, None), ('ᾄδω', 'śpiewać', None, None), ('ὀρχέομαι', 'tańczyć', None, None)], 'sentences': []}, {'id': 'v18d', 'title': 'Czasowniki podstawowe 4', 'icon': 'C', 'track': 'jezyk', 'words': [('νέω', 'pływać', None, None), ('πέτομαι', 'latać', None, None), ('τίθημι', 'kłaść', None, None), ('ζητέω', 'szukać', None, None), ('εὑρίσκω', 'znajdować', None, None), ('μένω', 'czekać', None, None), ('βοηθέω', 'pomagać', None, None), ('αἰτέω', 'prosić', None, None), ('συγγιγνώσκω', 'przepraszać', None, None), ('ἐάω', 'pozwalać', None, None), ('πειράομαι', 'próbować', None, None), ('μεταβάλλω', 'zmieniać', None, None), ('φέρω', 'nosić', None, None), ('κρατέω', 'trzymać', None, None), ('βάλλω', 'rzucać', None, None), ('θηράω', 'łapać', None, None)], 'sentences': []}, {'id': 'v18e', 'title': 'Czasowniki podstawowe 5', 'icon': 'C', 'track': 'jezyk', 'words': [('τύπτω', 'bić', None, None), ('κτείνω', 'zabijać', None, None), ('ἀποθνῄσκω', 'umierać', None, None), ('ζάω', 'żyć', None, None), ('οἰκέω', 'mieszkać', None, None), ('ἀπαντάω', 'spotykać', None, None), ('καλέω', 'dzwonić', None, None), ('πέμπω', 'wysyłać', None, None), ('δέχομαι', 'dostawać', None, None), ('δείκνυμι', 'pokazywać', None, None), ('ἐπισκέπτομαι', 'odwiedzać', None, None), ('δακρύω', 'płakać', None, None), ('γελάω', 'śmiać się', None, None), ('μειδιάω', 'uśmiechać się', None, None), ('φοβέομαι', 'bać się', None, None), ('χαίρω', 'cieszyć się', None, None)], 'sentences': []}, {'id': 'v18f', 'title': 'Czasowniki podstawowe 6', 'icon': 'C', 'track': 'jezyk', 'words': [('πιστεύω', 'wierzyć', None, None), ('συμφωνέω', 'zgadzać się', None, None), ('αἱρέομαι', 'wybierać', None, None), ('κρίνω', 'decydować', None, None), ('ἀριθμέω', 'liczyć', None, None), ('ἵστημι', 'ważyć', None, None), ('ἄρχω', 'rządzić', None, None), ('ἄγω', 'prowadzić', None, None), ('εἴκω', 'poddać się', None, None), ('νικάω', 'zwyciężać', None, None), ('μάχομαι', 'walczyć', None, None), ('ἀμύνω', 'bronić', None, None), ('ἐπιτίθεμαι', 'atakować', None, None), ('ἀπόλλυμι', 'niszczyć', None, None), ('οἰκοδομέω', 'budować', None, None), ('καθαιρέω', 'burzyć', None, None)], 'sentences': []}, {'id': 'v18g', 'title': 'Czasowniki podstawowe 7', 'icon': 'C', 'track': 'jezyk', 'words': [('καίω', 'palić', None, None), ('σβέννυμι', 'gasić', None, None), ('ἐπιθυμέω', 'pragnąć', None, None), ('αἰσχύνομαι', 'wstydzić się', None, None), ('μεταμέλομαι', 'żałować', None, None), ('ἔξεστι', 'wolno', None, None), ('χρή', 'trzeba', None, None), ('πρέπει', 'wypada', None, None), ('θεραπεύω', 'pomagać (leczyć)', None, None), ('σῴζω', 'ratować', None, None), ('ἐλευθερόω', 'wyzwalać', None, None), ('καταδουλόω', 'zniewalać', None, None), ('σέβομαι', 'czcić', None, None), ('εὔχομαι', 'modlić się', None, None), ('θύω', 'składać ofiarę', None, None), ('ὄμνυμι', 'przysięgać', None, None)], 'sentences': []}, {'id': 'v18h', 'title': 'Czasowniki podstawowe 8', 'icon': 'C', 'track': 'jezyk', 'words': [('ὑπισχνέομαι', 'obiecywać', None, None), ('ψεύδομαι', 'kłamać', None, None), ('κατηγορέω', 'oskarżać', None, None), ('ἀπολογέομαι', 'bronić (w sądzie)', None, None), ('δικάζω', 'sądzić', None, None), ('κολάζω', 'karać', None, None), ('ἀμείβομαι', 'nagradzać', None, None), ('εὐχαριστέω', 'dziękować', None, None), ('ἀσπάζομαι', 'pozdrawiać', None, None)], 'sentences': []}, {'id': 'v19a', 'title': 'Czasowniki dnia codziennego 1', 'icon': 'C', 'track': 'jezyk', 'words': [('περιπατέω', 'chodzić', None, None), ('ἱππεύω', 'jeździć', None, None), ('ἀναβαίνω', 'wsiadać', None, None), ('καταβαίνω', 'wysiadać', None, None), ('τρέπω', 'skręcać', None, None), ('μέλλω', 'spóźniać się', None, None), ('σπεύδω', 'spieszyć się', None, None), ('ἀναπαύομαι', 'odpoczywać', None, None), ('ἐπισκευάζω', 'naprawiać', None, None), ('τέμνω', 'ciąć', None, None), ('φρύγω', 'smażyć', None, None), ('πέσσω', 'piec', None, None), ('μίγνυμι', 'mieszać', None, None), ('χέω', 'nalewać', None, None), ('καθαίρω', 'sprzątać', None, None), ('πλύνω', 'prać', None, None)], 'sentences': []}, {'id': 'v19b', 'title': 'Czasowniki dnia codziennego 2', 'icon': 'C', 'track': 'jezyk', 'words': [('ξυρέομαι', 'golić się', None, None), ('κτενίζω', 'czesać', None, None), ('λούομαι', 'kąpać się', None, None), ('ἐγείρομαι', 'budzić się', None, None), ('κοιμάομαι', 'zasypiać', None, None), ('ὀνειροπολέω', 'marzyć', None, None), ('ὀνειρώττω', 'śnić', None, None), ('ἀσκέω', 'ćwiczyć', None, None), ('γυμνάζομαι', 'trenować', None, None), ('ἡττάομαι', 'przegrywać', None, None), ('κινέω', 'ruszać', None, None), ('ἕλκω', 'ciągnąć', None, None), ('ὠθέω', 'pchać', None, None), ('αἴρω', 'podnosić', None, None), ('πίπτω', 'spadać', None, None), ('ἅλλομαι', 'skakać', None, None)], 'sentences': []}, {'id': 'v19c', 'title': 'Czasowniki dnia codziennego 3', 'icon': 'C', 'track': 'jezyk', 'words': [('ἀναρριχάομαι', 'wspinać się', None, None), ('κρύπτω', 'ukrywać', None, None), ('κλέπτω', 'kraść', None, None), ('κίχρημι', 'pożyczać', None, None), ('ἀναλίσκω', 'wydawać', None, None), ('φείδομαι', 'oszczędzać', None, None), ('ἀρόω', 'orać', None, None), ('σπείρω', 'siać', None, None), ('ἀμάω', 'żąć', None, None), ('συλλέγω', 'zbierać', None, None), ('φυτεύω', 'sadzić', None, None), ('ἄρδω', 'podlewać', None, None), ('νέμω', 'paść', None, None), ('ἀμέλγω', 'doić', None, None), ('κείρω', 'strzyc', None, None), ('ὑφαίνω', 'tkać', None, None)], 'sentences': []}, {'id': 'v19d', 'title': 'Czasowniki dnia codziennego 4', 'icon': 'C', 'track': 'jezyk', 'words': [('νήθω', 'prząść', None, None), ('ῥάπτω', 'szyć', None, None), ('ἀλέω', 'mleć', None, None), ('γλύφω', 'rzeźbić', None, None), ('χρωματίζω', 'malować', None, None), ('σφυρηλατέω', 'kuć', None, None), ('τήκω', 'topić', None, None), ('ὀρύσσω', 'kopać', None, None), ('δέω', 'wiązać', None, None), ('λύω', 'rozwiązywać', None, None), ('μοχλόω', 'zamykać na klucz', None, None), ('ἀνακλείω', 'odmykać', None, None), ('κατακλίνομαι', 'kłaść się', None, None), ('ἵζω', 'siadać', None, None), ('διαλέγομαι', 'rozmawiać', None, None), ('βοάω', 'krzyczeć', None, None)], 'sentences': []}, {'id': 'v19e', 'title': 'Czasowniki dnia codziennego 5', 'icon': 'C', 'track': 'jezyk', 'words': [('σιγάω', 'milczeć', None, None), ('ψιθυρίζω', 'szeptać', None, None), ('κιθαρίζω', 'grać na lirze', None, None), ('αὐλέω', 'grać na flecie', None, None), ('προσαγορεύω', 'pozdrawiać (kogoś)', None, None), ('ἀποχαιρετάω', 'żegnać', None, None), ('ὀνομάζω', 'nazywać', None, None), ('διηγέομαι', 'opowiadać', None, None), ('περιγράφω', 'opisywać', None, None), ('ἑρμηνεύω', 'tłumaczyć', None, None), ('ἐπαινέω', 'chwalić', None, None), ('ψέγω', 'ganić', None, None), ('συγχωρέω', 'wybaczać', None, None), ('κελεύω', 'rozkazywać', None, None), ('ἀπαγορεύω', 'zabraniać', None, None), ('στρατηγέω', 'dowodzić', None, None)], 'sentences': []}, {'id': 'v19f', 'title': 'Czasowniki dnia codziennego 6', 'icon': 'C', 'track': 'jezyk', 'words': [('πλέω', 'żeglować', None, None), ('ἐρέσσω', 'wiosłować', None, None), ('ὁρμίζω', 'rzucać kotwicę', None, None), ('μετέχω', 'brać udział', None, None), ('ἥκω', 'przybywać', None, None), ('ἄπειμι', 'odchodzić', None, None), ('οἴκαδε ἔρχομαι', 'wracać (do domu)', None, None), ('φαίνομαι', 'ukazywać się', None, None), ('ὑπάρχω', 'istnieć', None, None), ('γίγνομαι', 'stawać się', None, None), ('συμβαίνω', 'wydarzać się', None, None), ('δοκέω', 'wydawać się', None, None), ('λείπω', 'pozostawać', None, None), ('ἀπολείπω', 'porzucać', None, None)], 'sentences': []}, {'id': 'v20a', 'title': 'Słowa funkcyjne 1', 'icon': 'S', 'track': 'jezyk', 'words': [('οὗτος', 'ten', None, None), ('ἐκεῖνος', 'tamten', None, None), ('ὅδε', 'ten (tu)', None, None), ('αὐτός', 'ten sam', None, None), ('ἐνταῦθα', 'tutaj', None, None), ('ἐκεῖ', 'tam', None, None), ('ποῦ', 'gdzie', None, None), ('πῶς', 'jak', None, None), ('διὰ τί', 'dlaczego', None, None), ('τίς', 'kto', None, None), ('ὅς', 'który', None, None), ('ποῖος', 'jaki', None, None), ('ἀλλά', 'ale', None, None), ('ἤ', 'lub', None, None), ('γάρ', 'bo', None, None), ('εἰ', 'jeśli', None, None)], 'sentences': []}, {'id': 'v20b', 'title': 'Słowa funkcyjne 2', 'icon': 'S', 'track': 'jezyk', 'words': [('οὖν', 'więc', None, None), ('μόνον', 'tylko', None, None), ('ὀλίγον', 'trochę', None, None), ('πολύ', 'dużo', None, None), ('πᾶν', 'wszystko', None, None), ('τι', 'coś', None, None), ('ἕτερος', 'inny', None, None), ('ἴσως', 'może', None, None), ('δήπου', 'na pewno', None, None), ('ἅμα', 'razem', None, None), ('ἄνευ', 'bez', None, None), ('σύν', 'z', None, None), ('ἀπό', 'od', None, None), ('ὑπέρ', 'dla', None, None), ('διά', 'przez', None, None), ('μετά', 'po', None, None)], 'sentences': []}, {'id': 'v20c', 'title': 'Słowa funkcyjne 3', 'icon': 'S', 'track': 'jezyk', 'words': [('πρό', 'przed', None, None), ('ὀπίσω', 'za', None, None), ('ὑπό', 'pod', None, None), ('παρά', 'obok', None, None), ('μεταξύ', 'między', None, None), ('κατά', 'przeciw', None, None), ('περί', 'o', None, None), ('ἀμφί', 'około', None, None), ('σχεδόν', 'prawie', None, None), ('αὖθις', 'jeszcze raz', None, None), ('που', 'gdzieś', None, None), ('οὐδαμοῦ', 'nigdzie', None, None), ('πανταχοῦ', 'wszędzie', None, None), ('σφόδρα', 'bardzo', None, None), ('οὕτως', 'tak', None, None), ('οὐ', 'nie', None, None)], 'sentences': []}, {'id': 'v20d', 'title': 'Słowa funkcyjne 4', 'icon': 'S', 'track': 'jezyk', 'words': [('μή', 'nie (zakaz)', None, None), ('ἆρα', 'czy', None, None), ('μέντοι', 'jednak', None, None), ('καίπερ', 'chociaż', None, None), ('ὅτε', 'gdy', None, None), ('πρίν', 'zanim', None, None), ('ὁπότε', 'kiedykolwiek', None, None), ('οὐδέ', 'ani', None, None), ('τε', 'zarówno', None, None), ('ἤτοι', 'albo...albo', None, None), ('εἴθε', 'oby', None, None), ('δή', 'otóż', None, None), ('δέ', 'zaś', None, None), ('γε', 'przecież', None, None), ('ὄντως', 'rzeczywiście', None, None), ('ἀληθῶς', 'naprawdę', None, None)], 'sentences': []}, {'id': 'v20e', 'title': 'Słowa funkcyjne 5', 'icon': 'S', 'track': 'jezyk', 'words': [('δῆλον ὅτι', 'oczywiście', None, None), ('τουτέστι', 'mianowicie', None, None), ('ἄρα', 'zatem', None, None), ('διό', 'dlatego', None, None), ('μέν', 'natomiast', None, None), ('πόθεν', 'skąd', None, None), ('ποῖ', 'dokąd', None, None), ('ὅταν', 'kiedy (względne)', None, None), ('ποσάκις', 'ile razy', None, None), ('ἄμφω', 'obaj', None, None), ('ἀλλήλους', 'wzajemnie', None, None), ('ἑαυτόν', 'siebie', None, None), ('ἐμέ', 'mnie', None, None), ('σέ', 'ciebie', None, None), ('αὐτόν', 'jego', None, None), ('ἡμᾶς', 'nas', None, None)], 'sentences': []}, {'id': 'v20f', 'title': 'Słowa funkcyjne 6', 'icon': 'S', 'track': 'jezyk', 'words': [('ὑμᾶς', 'was', None, None), ('αὐτούς', 'ich', None, None)], 'sentences': []}, {'id': 'v21a', 'title': 'Świat i bogowie 1', 'icon': 'Ś', 'track': 'jezyk', 'words': [('χώρα', 'kraj', None, 'rodzaj żeński'), ('πατρίς', 'ojczyzna', None, 'rodzaj żeński'), ('ῥῆμα', 'słowo', None, 'rodzaj nijaki'), ('ὄνομα', 'imię', None, 'rodzaj nijaki'), ('ἡλικία', 'wiek', None, 'rodzaj żeński'), ('θρησκεία', 'religia', None, 'rodzaj żeński'), ('θεά', 'bogini', None, 'rodzaj żeński'), ('θεοί', 'bogowie', None, None), ('Ζεύς', 'Zeus', None, 'rodzaj męski'), ('Ἥρα', 'Hera', None, 'rodzaj żeński'), ('Ποσειδῶν', 'Posejdon', None, 'rodzaj męski'), ('ᾍδης', 'Hades', None, 'rodzaj męski'), ('Ἀθηνᾶ', 'Atena', None, 'rodzaj żeński'), ('Ἀπόλλων', 'Apollo', None, 'rodzaj męski'), ('Ἄρτεμις', 'Artemida', None, 'rodzaj żeński'), ('Ἀφροδίτη', 'Afrodyta', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v21b', 'title': 'Świat i bogowie 2', 'icon': 'Ś', 'track': 'jezyk', 'words': [('Ἄρης', 'Ares', None, 'rodzaj męski'), ('Ἑρμῆς', 'Hermes', None, 'rodzaj męski'), ('Ἥφαιστος', 'Hefajstos', None, 'rodzaj męski'), ('Δημήτηρ', 'Demeter', None, 'rodzaj żeński'), ('Διόνυσος', 'Dionizos', None, 'rodzaj męski'), ('Ἑστία', 'Hestia', None, 'rodzaj żeński'), ('Προμηθεύς', 'Prometeusz', None, 'rodzaj męski'), ('Ἡρακλῆς', 'Herakles', None, 'rodzaj męski'), ('Ὀδυσσεύς', 'Odyseusz', None, 'rodzaj męski'), ('Ἀχιλλεύς', 'Achilles', None, 'rodzaj męski'), ('Ἕκτωρ', 'Hektor', None, 'rodzaj męski'), ('Ἀγαμέμνων', 'Agamemnon', None, 'rodzaj męski'), ('Ἑλένη', 'Helena', None, 'rodzaj żeński'), ('Πηνελόπη', 'Penelopa', None, 'rodzaj żeński'), ('Ὀρφεύς', 'Orfeusz', None, 'rodzaj męski'), ('Οἰδίπους', 'Edyp', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v21c', 'title': 'Świat i bogowie 3', 'icon': 'Ś', 'track': 'jezyk', 'words': [('Ἀντιγόνη', 'Antygona', None, 'rodzaj żeński'), ('Θησεύς', 'Tezeusz', None, 'rodzaj męski'), ('Περσεύς', 'Perseusz', None, 'rodzaj męski'), ('Ἰάσων', 'Jazon', None, 'rodzaj męski'), ('μοῦσα', 'muza', None, 'rodzaj żeński'), ('τιτάν', 'tytan', None, 'rodzaj męski'), ('Ὄλυμπος', 'olimp', None, 'rodzaj męski'), ('Δελφοί', 'Delfy', None, 'rodzaj męski'), ('χρηστήριον', 'wyrocznia', None, 'rodzaj nijaki'), ('οἰωνός', 'wróżba', None, 'rodzaj męski'), ('μαντεία', 'proroctwo', None, 'rodzaj żeński'), ('θυσία', 'ofiara', None, 'rodzaj żeński'), ('εὐχή', 'modlitwa', None, 'rodzaj żeński'), ('τέμενος', 'świątynia (miejsce)', None, 'rodzaj nijaki'), ('ἱέρεια', 'kapłanka', None, 'rodzaj żeński'), ('εἴδωλον', 'dusza zmarłych', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v21d', 'title': 'Świat i bogowie 4', 'icon': 'Ś', 'track': 'jezyk', 'words': [('Ἅιδης', 'podziemie', None, 'rodzaj męski'), ('μακάρων νῆσοι', 'raj', None, 'rodzaj żeński'), ('Μοῖραι', 'losy', None, 'rodzaj żeński'), ('Ἐρινύες', 'furie', None, 'rodzaj żeński'), ('Γοργώ', 'gorgona', None, 'rodzaj żeński'), ('δαίμων', 'duch (daimon)', None, 'rodzaj męski'), ('θέμις', 'prawo boskie', None, 'rodzaj żeński'), ('Τρωϊκός πόλεμος', 'wojna trojańska', None, 'rodzaj męski'), ('ἀγών', 'igrzyska', None, 'rodzaj męski'), ('νικητής', 'zwycięzca', None, 'rodzaj męski'), ('δάφνη', 'wieniec laurowy', None, 'rodzaj żeński'), ('ἀποικία', 'kolonia', None, 'rodzaj żeński'), ('Ἄρειος πάγος', 'areopag', None, 'rodzaj męski'), ('ὀστρακισμός', 'ostracyzm', None, 'rodzaj męski'), ('ὁπλίτης', 'hoplita', None, 'rodzaj męski'), ('φάλαγξ', 'falanga', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v21e', 'title': 'Świat i bogowie 5', 'icon': 'Ś', 'track': 'jezyk', 'words': [('ναυτικόν', 'flota', None, 'rodzaj nijaki'), ('ἀσπίς', 'tarcza', None, 'rodzaj żeński'), ('δόρυ', 'włócznia', None, 'rodzaj nijaki'), ('ξίφος', 'miecz', None, 'rodzaj nijaki'), ('τόξον', 'łuk', None, 'rodzaj nijaki'), ('ὀϊστός', 'strzała', None, 'rodzaj męski'), ('κόρυς', 'hełm (bojowy)', None, 'rodzaj żeński'), ('θώραξ', 'pancerz', None, 'rodzaj męski'), ('σφενδόνη', 'proca', None, 'rodzaj żeński'), ('πολιορκία', 'oblężenie', None, 'rodzaj żeński'), ('προσβολή', 'szturm', None, 'rodzaj żeński'), ('φυγή', 'ucieczka', None, 'rodzaj żeński'), ('δίωξις', 'pogoń', None, 'rodzaj żeński'), ('ἐπινίκιον', 'triumf', None, 'rodzaj nijaki'), ('τρόπαιον', 'trofeum', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v22a', 'title': 'Geografia 1', 'icon': 'G', 'track': 'jezyk', 'words': [('βορέας', 'północ', None, 'rodzaj męski'), ('νότος', 'południe', None, 'rodzaj męski'), ('ἀνατολή', 'wschód', None, 'rodzaj żeński'), ('δύσις', 'zachód', None, 'rodzaj żeński'), ('Εὐρώπη', 'Europa', None, 'rodzaj żeński'), ('Ἀσία', 'Azja', None, 'rodzaj żeński'), ('Λιβύη', 'Afryka', None, 'rodzaj żeński'), ('Ἑλλάς', 'Grecja', None, 'rodzaj żeński'), ('Ἀθῆναι', 'Ateny', None, 'rodzaj żeński'), ('Σπάρτη', 'Sparta', None, 'rodzaj żeński'), ('Θῆβαι', 'Teby', None, 'rodzaj żeński'), ('Κόρινθος', 'Korynt', None, 'rodzaj żeński'), ('Τροία', 'Troja', None, 'rodzaj żeński'), ('Αἴγυπτος', 'Egipt', None, 'rodzaj żeński'), ('Περσίς', 'Persja', None, 'rodzaj żeński'), ('Βαβυλών', 'Babilon', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22b', 'title': 'Geografia 2', 'icon': 'G', 'track': 'jezyk', 'words': [('Συρία', 'Syria', None, 'rodzaj żeński'), ('Ἰουδαία', 'Judea', None, 'rodzaj żeński'), ('Ῥώμη', 'Rzym', None, 'rodzaj żeński'), ('Ἰταλία', 'Italia', None, 'rodzaj żeński'), ('Σικελία', 'Sycylia', None, 'rodzaj żeński'), ('Κρήτη', 'Kreta', None, 'rodzaj żeński'), ('Κύπρος', 'Cypr', None, 'rodzaj żeński'), ('Ῥόδος', 'Rodos', None, 'rodzaj żeński'), ('Δῆλος', 'Delos', None, 'rodzaj żeński'), ('Μακεδονία', 'Macedonia', None, 'rodzaj żeński'), ('Θρᾴκη', 'Tracja', None, 'rodzaj żeński'), ('Θεσσαλία', 'Tesalia', None, 'rodzaj żeński'), ('Ἀττική', 'Attyka', None, 'rodzaj żeński'), ('Πελοπόννησος', 'Peloponez', None, 'rodzaj żeński'), ('Αἰγαῖον πέλαγος', 'Morze Egejskie', None, 'rodzaj nijaki'), ('Πόντος', 'Morze Czarne', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v22c', 'title': 'Geografia 3', 'icon': 'G', 'track': 'jezyk', 'words': [('Ἑλλήσποντος', 'Hellespont', None, 'rodzaj męski'), ('Νεῖλος', 'Nil', None, 'rodzaj męski'), ('Εὐφράτης', 'Eufrat', None, 'rodzaj męski'), ('Ἴστρος', 'Dunaj', None, 'rodzaj męski'), ('Παρνασσός', 'Parnas', None, 'rodzaj męski'), ('Μαραθών', 'Marathon', None, 'rodzaj męski'), ('Θερμοπύλαι', 'Termopile', None, 'rodzaj żeński'), ('Σαλαμίς', 'Salamina', None, 'rodzaj żeński'), ('Ἔφεσος', 'Efez', None, 'rodzaj żeński'), ('Μίλητος', 'Milet', None, 'rodzaj żeński'), ('Σμύρνα', 'Smyrna', None, 'rodzaj żeński'), ('Ἱεροσόλυμα', 'Jerozolima', None, 'rodzaj nijaki'), ('Ἀντιόχεια', 'Antiochia', None, 'rodzaj żeński'), ('Ἀλεξάνδρεια', 'Aleksandria', None, 'rodzaj żeński'), ('Καρχηδών', 'Kartagina', None, 'rodzaj żeński'), ('Ἰβηρία', 'Hiszpania', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v22d', 'title': 'Geografia 4', 'icon': 'G', 'track': 'jezyk', 'words': [('Γαλατία', 'Galia', None, 'rodzaj żeński'), ('μητρόπολις', 'stolica', None, 'rodzaj żeński'), ('Ἰωνία', 'Jonia', None, 'rodzaj żeński'), ('Ἀρκαδία', 'Arkadia', None, 'rodzaj żeński'), ('Βοιωτία', 'Beocja', None, 'rodzaj żeński'), ('Ἤπειρος', 'Epir', None, 'rodzaj żeński'), ('Λυδία', 'Lidia', None, 'rodzaj żeński'), ('Φρυγία', 'Frygia', None, 'rodzaj żeński'), ('Καππαδοκία', 'Kapadocja', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v23a', 'title': 'Materiały i przedmioty 1', 'icon': 'M', 'track': 'jezyk', 'words': [('τμῆμα', 'kawałek', None, 'rodzaj nijaki'), ('σταγών', 'kropla', None, 'rodzaj żeński'), ('πυξίς', 'pudełko', None, 'rodzaj żeński'), ('θύλακος', 'worek', None, 'rodzaj męski'), ('στήμων', 'nić', None, 'rodzaj męski'), ('σύρμα', 'drut', None, 'rodzaj nijaki'), ('ῥάβδος', 'kij', None, 'rodzaj żeński'), ('βακτηρία', 'laska', None, 'rodzaj żeński'), ('κάλως', 'lina', None, 'rodzaj męski'), ('δεσμός', 'łańcuch (metalowy)', None, 'rodzaj męski'), ('κόλλα', 'klej', None, 'rodzaj żeński'), ('ὕαλος', 'szkło', None, 'rodzaj żeński'), ('ξύλον', 'drewno', None, 'rodzaj nijaki'), ('μέταλλον', 'metal', None, 'rodzaj nijaki'), ('χρυσός', 'złoto', None, 'rodzaj męski'), ('ἄργυρος', 'srebro', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v23b', 'title': 'Materiały i przedmioty 2', 'icon': 'M', 'track': 'jezyk', 'words': [('σίδηρος', 'żelazo', None, 'rodzaj męski'), ('χαλκός', 'miedź', None, 'rodzaj męski'), ('μόλυβδος', 'ołów', None, 'rodzaj męski'), ('κασσίτερος', 'cyna', None, 'rodzaj męski'), ('ἤλεκτρον', 'bursztyn', None, 'rodzaj nijaki'), ('ἄμμος', 'piasek', None, 'rodzaj żeński'), ('κόνις', 'kurz', None, 'rodzaj żeński'), ('ἄνθραξ', 'węgiel', None, 'rodzaj męski'), ('πίσσα', 'smoła', None, 'rodzaj żeński'), ('κηρός', 'wosk', None, 'rodzaj męski'), ('ἅλς θαλάσσιος', 'sól morska', None, 'rodzaj męski'), ('χόρτος', 'siano', None, 'rodzaj męski'), ('καλάμη', 'słoma', None, 'rodzaj żeński'), ('δόναξ', 'trzcina', None, 'rodzaj męski'), ('σφραγίς', 'pieczęć', None, 'rodzaj żeński'), ('κανών', 'miara (przedmiot)', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v23c', 'title': 'Materiały i przedmioty 3', 'icon': 'M', 'track': 'jezyk', 'words': [('ζυγός', 'waga', None, 'rodzaj męski'), ('βάρος', 'ciężar', None, 'rodzaj nijaki'), ('πλέγμα', 'kosz wiklinowy', None, 'rodzaj nijaki'), ('τήγανον', 'patelnia', None, 'rodzaj nijaki'), ('ληκύθος', 'flaszka', None, 'rodzaj żeński'), ('ὑδρία', 'urna', None, 'rodzaj żeński'), ('κέραμος', 'naczynie (gliniane)', None, 'rodzaj męski'), ('πυρίτης', 'krzemień', None, 'rodzaj męski'), ('μαργαρίτης', 'perła', None, 'rodzaj męski'), ('σμάραγδος', 'szmaragd', None, 'rodzaj męski'), ('σάπφειρος', 'szafir', None, 'rodzaj męski'), ('ἀδάμας', 'diament', None, 'rodzaj męski'), ('λευκὸς λίθος', 'marmur (biały)', None, 'rodzaj męski'), ('ἄσβεστος', 'wapno', None, 'rodzaj żeński'), ('γύψος', 'gips', None, 'rodzaj żeński'), ('κονία', 'zaprawa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v23d', 'title': 'Materiały i przedmioty 4', 'icon': 'M', 'track': 'jezyk', 'words': [('ὄργανον μουσικόν', 'instrument muzyczny', None, 'rodzaj nijaki'), ('λύρα', 'lira', None, 'rodzaj żeński'), ('αὐλός', 'flet', None, 'rodzaj męski'), ('κιθάρα', 'kithara', None, 'rodzaj żeński'), ('σῦριγξ', 'syrinks', None, 'rodzaj żeński'), ('τύμπανον', 'bęben', None, 'rodzaj nijaki'), ('σάλπιγξ', 'róg (instrument)', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v24a', 'title': 'Kierunki i miejsca 1', 'icon': 'K', 'track': 'jezyk', 'words': [('ἄνω', 'góra (kierunek)', None, None), ('κάτω', 'dół', None, None), ('ἔμπροσθεν', 'przód', None, None), ('ὄπισθεν', 'tył', None, None), ('μέσον', 'środek', None, 'rodzaj nijaki'), ('πλάγιον', 'bok', None, 'rodzaj nijaki'), ('ἔνδον', 'wewnątrz', None, None), ('ἔξω', 'na zewnątrz', None, None), ('μακράν', 'daleko', None, None), ('πλησίον', 'blisko', None, None), ('ὑψηλῶς', 'wysoko', None, None), ('χαμαί', 'nisko', None, None), ('ταχέως', 'szybko', None, None), ('βραδέως', 'wolno', None, None), ('εὖ', 'dobrze', None, None), ('κακῶς', 'źle', None, None)], 'sentences': []}, {'id': 'v24b', 'title': 'Kierunki i miejsca 2', 'icon': 'K', 'track': 'jezyk', 'words': [('ῥᾳδίως', 'łatwo', None, None), ('χαλεπῶς', 'trudno', None, None), ('χωρίς', 'osobno', None, None), ('ἀντίον', 'naprzeciw', None, None), ('πλάγιος', 'w poprzek', None, None), ('κύκλῳ', 'dokoła', None, None), ('δεξιά', 'na prawo', None, None), ('ἀριστερά', 'na lewo', None, None), ('εὐθεῖα', 'prosto', None, None), ('δεῦρο', 'tutaj (kierunek)', None, None), ('ἐκεῖσε', 'tam (kierunek)', None, None), ('οἴκαδε', 'do domu', None, None), ('οἴκοι', 'w domu', None, None), ('οἴκοθεν', 'z domu', None, None), ('ἔξω τῆς χώρας', 'za granicą', None, None), ('ἐν ἄστει', 'w mieście', None, None)], 'sentences': []}, {'id': 'v24c', 'title': 'Kierunki i miejsca 3', 'icon': 'K', 'track': 'jezyk', 'words': [('ἐν ἀγρῷ', 'na wsi', None, None), ('ἐν θαλάσσῃ', 'na morzu', None, None), ('ἐπὶ γῆς', 'na lądzie', None, None), ('ἄλλοθι', 'gdzie indziej', None, None), ('πάντοσε', 'wszędzie (kierunek)', None, None), ('Ἀθήναζε', 'do Aten', None, None), ('Ἀθήνησιν', 'w Atenach', None, None)], 'sentences': []}, {'id': 'v25a', 'title': 'Rodzina i obyczaje 1', 'icon': 'R', 'track': 'jezyk', 'words': [('πενθερός', 'teść', None, 'rodzaj męski'), ('πενθερά', 'teściowa', None, 'rodzaj żeński'), ('κηδεστής', 'szwagier', None, 'rodzaj męski'), ('ἀδελφιδοῦς', 'bratanek', None, 'rodzaj męski'), ('ἀνεψιός', 'siostrzeniec', None, 'rodzaj męski'), ('χῆρος', 'wdowiec', None, 'rodzaj męski'), ('μνηστήρ', 'narzeczony', None, 'rodzaj męski'), ('μνηστή', 'narzeczona', None, 'rodzaj żeński'), ('γάμος', 'ślub', None, 'rodzaj męski'), ('διαζύγιον', 'rozwód', None, 'rodzaj nijaki'), ('γένεσις', 'urodzenie', None, 'rodzaj żeński'), ('ἐκφορά', 'pogrzeb', None, 'rodzaj żeński'), ('καῦσις', 'kremacja', None, 'rodzaj żeński'), ('τάφος πατρῷος', 'grób rodzinny', None, 'rodzaj męski'), ('γένος', 'ród', None, 'rodzaj nijaki'), ('πρόγονος', 'przodek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v25b', 'title': 'Rodzina i obyczaje 2', 'icon': 'R', 'track': 'jezyk', 'words': [('ἀπόγονος', 'potomek', None, 'rodzaj męski'), ('συγγενής', 'krewny', None, 'rodzaj męski'), ('ἐπίτροπος', 'opiekun', None, 'rodzaj męski'), ('θετός', 'adoptowany', None, 'rodzaj męski'), ('νόθος', 'bękart', None, 'rodzaj męski'), ('οἰκέτης', 'niewolnik domowy', None, 'rodzaj męski'), ('παιδαγωγός', 'wychowawca', None, 'rodzaj męski'), ('τροφός', 'piastunka', None, 'rodzaj żeński'), ('βρέφος', 'noworodek', None, 'rodzaj nijaki'), ('κληρονομία', 'dziedzictwo', None, 'rodzaj żeński'), ('διαθήκη', 'testament', None, 'rodzaj żeński'), ('κληρονόμος', 'spadkobierca', None, 'rodzaj męski'), ('προίξ', 'posag', None, 'rodzaj żeński'), ('κυριεία πατρός', 'władza ojca', None, 'rodzaj żeński'), ('πρόγονοι', 'przodkowie', None, 'rodzaj męski'), ('θεοὶ πατρῷοι', 'bóstwa domowe', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v25c', 'title': 'Rodzina i obyczaje 3', 'icon': 'R', 'track': 'jezyk', 'words': [('ξενία', 'gościnność', None, 'rodzaj żeński'), ('προστάτης', 'opiekun (patron)', None, 'rodzaj męski'), ('σεμνότης', 'powaga', None, 'rodzaj żeński'), ('ἀξίωμα', 'godność', None, 'rodzaj nijaki'), ('ὥρα δείπνου', 'godzina uczty', None, 'rodzaj żeński')], 'sentences': []}]
# === /SŁOWNICTWO ===

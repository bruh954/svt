"""[en — wygenerowane przez tools/i18n.py, nie edytuj] Treść kursu: język koreański dla Polaków.

Słowo:     (forma hangulem, znaczenie po polsku, polski krewny lub None, skojarzenie lub None)
Litera:    (litera hangulu, wymowa w IPA z krótką podpowiedzią, przykładowa sylaba)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie, dział)

Koreański dokleja partykuły do słów (저는, 밥을), więc słowa w kursie to całe „klocki” z partykułą.
Transkrypcja (pole „tr”) powstaje automatycznie w engine.py według oficjalnej latynizacji
(Revised Romanization): 안녕하세요 → annyeonghaseyo.
"""

UNITS = [
    # --------------------------------------------------------------- hangul
    {
        "id": "hangul1", "title": 'Hangul I', "icon": "ㄱ", "track": "pismo",
        "letters": [
            ("ㄱ", '[k], between vowels [ɡ]', "가"),
            ("ㄴ", '[n]', "나"),
            ("ㄷ", '[t], between vowels [d]', "다"),
            ("ㄹ", '[ɾ] (a flap, like Spanish r), at the end of a syllable [l]', "라"),
            ("ㅁ", '[m]', "마"),
            ("ㅂ", '[p], between vowels [b]', "바"),
            ("ㅅ", '[s], before ㅣ [ɕ] (like Polish ś)', "사"),
            ("ㅇ", 'silent at the start of a syllable, [ŋ] at the end', "아"),
            ("ㅈ", '[tɕ], between vowels [dʑ] (like ch / j)', "자"),
            ("ㅎ", '[h]', "하"),
        ],
    },
    {
        "id": "hangul2", "title": 'Hangul II', "icon": "ㅏ", "track": "pismo",
        "letters": [
            ("ㅏ", '[a]', "아"),
            ("ㅓ", '[ʌ] (an open o without lip rounding)', "어"),
            ("ㅗ", '[o]', "오"),
            ("ㅜ", '[u]', "우"),
            ("ㅡ", '[ɯ] (u with spread lips)', "으"),
            ("ㅣ", '[i]', "이"),
            ("ㅐ", '[ɛ]', "애"),
            ("ㅔ", '[e]', "에"),
            ("ㅑ", '[ja]', "야"),
            ("ㅕ", '[jʌ]', "여"),
            ("ㅛ", '[jo]', "요"),
            ("ㅠ", '[ju]', "유"),
        ],
    },
    {
        "id": "hangul3", "title": 'Hangul III', "icon": "ㄲ", "track": "pismo",
        "letters": [
            ("ㅊ", '[tɕʰ] (ch with a puff of air)', "차"),
            ("ㅋ", '[kʰ] (k with a puff of air)', "카"),
            ("ㅌ", '[tʰ] (t with a puff of air)', "타"),
            ("ㅍ", '[pʰ] (p with a puff of air)', "파"),
            ("ㄲ", '[k͈] (tense k, no puff of air)', "까"),
            ("ㄸ", '[t͈] (tense t)', "따"),
            ("ㅃ", '[p͈] (tense p)', "빠"),
            ("ㅆ", '[s͈] (tense s)', "싸"),
            ("ㅉ", '[t͈ɕ] (tense ch)', "짜"),
            ("ㅘ", '[wa]', "와"),
            ("ㅝ", '[wʌ]', "워"),
            ("ㅢ", '[ɰi]', "의"),
        ],
    },
    {
        "id": 'hangul4', "title": 'Hangul IV: compound vowels', "icon": 'ㅒ', "track": "pismo",
        "letters": [
            ('ㅒ', '[jɛ]', '얘기'),
            ('ㅖ', '[je]', '예'),
            ('ㅙ', '[wɛ]', '왜'),
            ('ㅞ', '[we]', '웨이터'),
            ('ㅚ', '[we] (oe)', '외국'),
            ('ㅟ', '[wi]', '위'),
        ],
    },
    {
        "id": 'sylaby1', "title": 'Syllables I: ㅏ and ㅓ', "icon": '가', "track": "pismo",
        "letters": [
            ('가', '[ka] (ga)', '가방'),
            ('거', '[kʌ] (geo)', '거리'),
            ('나', '[na] (na)', '나라'),
            ('너', '[nʌ] (neo)', '너무'),
            ('다', '[ta] (da)', '다리'),
            ('더', '[tʌ] (deo)', '더워요'),
            ('라', '[ɾa] (ra)', '라면'),
            ('러', '[ɾʌ] (reo)', '러시아'),
            ('마', '[ma] (ma)', '마음'),
            ('머', '[mʌ] (meo)', '머리'),
            ('바', '[pa] (ba)', '바다'),
            ('버', '[pʌ] (beo)', '버스'),
        ],
    },
    {
        "id": 'sylaby2', "title": 'Syllables II: ㅏ and ㅓ', "icon": '사', "track": "pismo",
        "letters": [
            ('사', '[sa] (sa)', '사과'),
            ('서', '[sʌ] (seo)', '서울'),
            ('아', '[a] (a)', '아기'),
            ('어', '[ʌ] (eo)', '어머니'),
            ('자', '[tɕa] (ja)', '자동차'),
            ('저', '[tɕʌ] (jeo)', '저녁'),
            ('하', '[ha] (ha)', '하나'),
            ('허', '[hʌ] (heo)', '허리'),
            ('차', '[tɕʰa] (cha)', '차'),
            ('처', '[tɕʰʌ] (cheo)', '처음'),
            ('카', '[kʰa] (ka)', '카메라'),
            ('커', '[kʰʌ] (keo)', '커피'),
        ],
    },
    {
        "id": 'sylaby3', "title": 'Syllables III: ㅗ and ㅜ', "icon": '고', "track": "pismo",
        "letters": [
            ('고', '[ko] (go)', '고기'),
            ('구', '[ku] (gu)', '구두'),
            ('노', '[no] (no)', '노래'),
            ('누', '[nu] (nu)', '누나'),
            ('도', '[to] (do)', '도시'),
            ('두', '[tu] (du)', '두부'),
            ('로', '[ɾo] (ro)', '로봇'),
            ('루', '[ɾu] (ru)', '루비'),
            ('모', '[mo] (mo)', '모자'),
            ('무', '[mu] (mu)', '무게'),
            ('보', '[po] (bo)', '보리'),
            ('부', '[pu] (bu)', '부모'),
        ],
    },
    {
        "id": 'sylaby4', "title": 'Syllables IV: ㅗ ㅜ ㅡ ㅣ', "icon": '소', "track": "pismo",
        "letters": [
            ('소', '[so] (so)', '소리'),
            ('수', '[su] (su)', '수박'),
            ('오', '[o] (o)', '오이'),
            ('우', '[u] (u)', '우유'),
            ('조', '[tɕo] (jo)', '조용'),
            ('주', '[tɕu] (ju)', '주스'),
            ('호', '[ho] (ho)', '호수'),
            ('후', '[hu] (hu)', '후추'),
            ('으', '[ɯ] (eu)', '음악'),
            ('이', '[i] (i)', '이마'),
            ('그', '[kɯ] (geu)', '그림'),
            ('기', '[ki] (gi)', '기차'),
        ],
    },
    {
        "id": 'patchim1', "title": 'Patchim I: ㄴ ㅁ ㅇ ㄹ', "icon": '안', "track": "pismo",
        "letters": [
            ('안', '[an]', '안녕'),
            ('산', '[san]', '산'),
            ('문', '[mun]', '문'),
            ('밤', '[pam]', '밤'),
            ('곰', '[kom]', '곰'),
            ('강', '[kaŋ]', '강'),
            ('공', '[koŋ]', '공'),
            ('말', '[mal]', '말'),
            ('물', '[mul]', '물'),
            ('달', '[tal]', '달'),
            ('한', '[han]', '한국'),
            ('방', '[paŋ]', '방'),
        ],
    },
    {
        "id": 'patchim2', "title": 'Patchim II: ㄱ ㅂ ㅅ ㅌ', "icon": '책', "track": "pismo",
        "letters": [
            ('책', '[tɕʰɛk̚]', '책'),
            ('목', '[mok̚]', '목'),
            ('국', '[kuk̚]', '국'),
            ('밖', '[pak̚]', '밖'),
            ('집', '[tɕip̚]', '집'),
            ('밥', '[pap̚]', '밥'),
            ('입', '[ip̚]', '입'),
            ('옷', '[ot̚]', '옷'),
            ('낮', '[nat̚]', '낮'),
            ('꽃', '[k͈ot̚]', '꽃'),
            ('있', '[it̚]', '있어요'),
            ('앞', '[ap̚]', '앞'),
        ],
    },
    {
        "id": 'patchim3', "title": 'Patchim III: double', "icon": '닭', "track": "pismo",
        "letters": [
            ('닭', '[tak̚]', '닭'),
            ('읽', '[ik̚]', '읽어요'),
            ('앉', '[an]', '앉아요'),
            ('많', '[man]', '많아요'),
            ('없', '[ʌp̚]', '없어요'),
            ('값', '[kap̚]', '값'),
            ('넓', '[nʌl]', '넓어요'),
            ('삶', '[sam]', '삶'),
            ('젊', '[tɕʌm]', '젊어요'),
            ('흙', '[hɯk̚]', '흙'),
        ],
    },
    # ---------------------------------------------------------------- język
    {
        "id": "slowa", "title": 'First words', "icon": "안", "track": "jezyk", "requires": "hangul2",
        "words": [
            ("안녕하세요", 'hello; good day', None, 'Literally “are you in peace?”. Fits any time of day.'),
            ("감사합니다", 'thank you', None, 'A polite, formal form. 감사 means “gratitude”.'),
            ("네", 'yes', None, 'Careful: 네 means “yes”, even though it sounds like the Polish “nie” (no)!'),
            ("아니요", 'no', None, None),
            ("저", 'I (polite)', None, 'The polite “I”. To friends you say 나.'),
            ("저는", 'I (as the topic)', None, '는 is the topic particle: “as for me…”.'),
            ("학생", 'pupil; student', None, None),
            ("학생이에요", 'I am a student', None, '학생 + 이에요 (is / am). Context tells you who.'),
            ("선생님", 'teacher', None, '님 is a polite ending, like “Mr.” in “Mr. Professor”.'),
            ("선생님이에요", 'is a teacher', None, None),
            ("한국", 'Korea', None, None),
            ("폴란드", 'Poland', 'Poland', 'Poland in Korean: pollandeu.'),
            ("사람", 'person', None, None),
            ("사람이에요", 'am (someone); is a person', None, '사람 (person) + 이에요. 폴란드 사람 = a Pole.'),
        ],
        "sentences": [
            (["안녕하세요", "!"], 'Hello!', {"감사합니다": '감사합니다 means “thank you”.'}),
            (["저는", "학생이에요"], 'I am a student.', {"선생님이에요": '선생님이에요 means “is a teacher”.'}),
            (["저는", "폴란드", "사람이에요"], 'I am Polish.', {"한국": '한국 is Korea. Poland: 폴란드.'}),
            (["저는", "한국", "사람이에요"], 'I am Korean.', {"폴란드": '폴란드 is Poland. Korea: 한국.'}),
            (["네", ",", "감사합니다"], 'Yes, thank you.', {"아니요": '아니요 means “no”. Yes: 네.'}),
        ],
    },
    {
        "id": "rodzina", "title": 'Family', "icon": "엄", "track": "jezyk",
        "words": [
            ("엄마", 'mom', 'mama', 'Almost like the Polish “mama”!'),
            ("아빠", 'dad', 'papa', None),
            ("가족", 'family', None, None),
            ("친구", 'friend', None, None),
            ("제", 'my (polite)', None, '저 (I) + 의 (of) = 제: my.'),
            ("이름", 'name', None, None),
            ("이름이", 'name (subject)', None, '이 is the subject particle after a consonant. After a vowel: 가.'),
            ("뭐예요", 'what is it?', None, '뭐 (what) + 예요 (is).'),
            ("이", 'this', None, 'Stands before a noun, like the English “this”.'),
            ("누구예요", 'who is it?', None, '누구 (who) + 예요.'),
            ("엄마예요", 'is mom', None, 'After a vowel 예요, after a consonant 이에요.'),
            ("아빠예요", 'is dad', None, None),
            ("친구예요", 'is a friend', None, None),
        ],
        "sentences": [
            (["이름이", "뭐예요", "?"], 'What is your name?', {}),
            (["이", "사람", "누구예요", "?"], 'Who is that?', {}),
            (["제", "엄마예요"], 'This is my mom.', {"아빠예요": '아빠 means dad. Mom: 엄마.'}),
            (["제", "친구예요"], 'This is my friend.', {}),
            (["제", "아빠예요"], 'This is my dad.', {"엄마예요": '엄마 means mom. Dad: 아빠.'}),
        ],
    },
    {
        "id": "liczby", "title": 'Numbers', "icon": "하", "track": "jezyk",
        "words": [
            ("하나", 'one', None, None),
            ("둘", 'two', None, None),
            ("셋", 'three', None, None),
            ("넷", 'four', None, None),
            ("다섯", 'five', None, None),
            ("여섯", 'six', None, None),
            ("일곱", 'seven', None, None),
            ("여덟", 'eight', None, None),
            ("아홉", 'nine', None, None),
            ("열", 'ten', None, None),
            ("한", 'one (before a counter)', None, '하나 shortens before a counter: 한 개 = one item.'),
            ("두", 'two (before a counter)', None, '둘 → 두 before a counter.'),
            ("세", 'three (before a counter)', None, '셋 → 세 before a counter.'),
            ("개", 'item (counter)', None, 'Korean counts things with a “counter”, like the English “three pieces”.'),
            ("사과", 'apple', None, None),
            ("사과가", 'apple (subject)', None, 'After a vowel the subject particle is 가.'),
            ("있어요", 'there is; there are; I have', None, '있다 = to exist, to have. The ㅆ at the end moves to the next syllable: isseoyo.'),
        ],
        "sentences": [
            (["하나", ",", "둘", ",", "셋"], 'One, two, three.', {}),
            (["사과", "두", "개"], 'Two apples.', {"둘": 'Before a counter 둘 shortens to 두.'}),
            (["사과가", "세", "개", "있어요"], 'There are three apples.', {"셋": 'Before a counter 셋 shortens to 세.'}),
            (["사과", "한", "개"], 'One apple.', {"하나": 'Before a counter 하나 shortens to 한.'}),
        ],
    },
    {
        "id": "jedzenie", "title": 'Food', "icon": "밥", "track": "jezyk",
        "words": [
            ("밥", 'rice; meal', None, '밥 means both rice and a meal in general.'),
            ("물", 'water', None, None),
            ("김치", 'kimchi', None, 'Fermented cabbage with chili: the Korean answer to pickles.'),
            ("커피", 'coffee', 'coffee', 'Borrowed from English coffee.'),
            ("우유", 'milk', None, None),
            ("빵", 'bread', None, 'From Portuguese pão.'),
            ("뭐", 'what', None, None),
            ("먹어요", 'I eat; he eats', None, '먹다 = to eat. -어요 is the polite ending.'),
            ("마셔요", 'I drink; he drinks', None, None),
            ("좋아해요", 'I like; he likes', None, 'ㅎ between vowels almost disappears: read “joahaeyo”.'),
            ("밥을", 'rice (object)', None, '을 is the object particle after a consonant.'),
            ("물을", 'water (object)', None, None),
            ("커피를", 'coffee (object)', None, 'After a vowel the object particle is 를.'),
            ("김치를", 'kimchi (object)', None, None),
            ("맛있어요", 'is delicious', None, '맛 (taste) + 있어요 (there is): literally “has taste”.'),
        ],
        "sentences": [
            (["저는", "밥을", "먹어요"], 'I eat rice.', {"밥": 'What do I eat? The object with its particle: 밥을.'}),
            (["물을", "마셔요"], 'I drink water.', {"먹어요": '먹어요 means “I eat”. I drink: 마셔요.'}),
            (["커피를", "좋아해요"], 'I like coffee.', {"커피": 'What do I like? The object: 커피를.'}),
            (["김치", "맛있어요"], 'The kimchi is delicious.', {}),
            (["뭐", "먹어요", "?"], 'What are you eating?', {"마셔요": '마셔요 means “I drink”. You eat: 먹어요.'}),
        ],
    },
    {
        "id": "czasowniki", "title": 'Verbs', "icon": "가", "track": "jezyk",
        "words": [
            ("가요", 'I go; he goes', None, '가다 = to go. The same form for I, you, he: context tells you who.'),
            ("와요", 'I come; he comes', None, None),
            ("해요", 'I do; he does', None, '하다 = to do.'),
            ("공부해요", 'I study', None, '공부 (study) + 해요 (do).'),
            ("일해요", 'I work', None, '일 (work) + 해요.'),
            ("학교", 'school', None, None),
            ("집", 'home; house', None, None),
            ("어디에", 'where', None, '어디 (where) + 에 (to, at).'),
            ("학교에", 'to school; at school', None, '에 means both “to” and “at”.'),
            ("집에", 'to home; at home', None, None),
            ("한국어를", 'Korean (object)', None, '한국어 = the Korean language: 한국 (Korea) + 어 (language).'),
        ],
        "sentences": [
            (["뭐", "해요", "?"], 'What are you doing?', {"가요": '가요 means “I go”. You do: 해요.'}),
            (["학교에", "가요"], 'I am going to school.', {"와요": '와요 means “I come”. I go: 가요.'}),
            (["어디에", "가요", "?"], 'Where are you going?', {}),
            (["한국어를", "공부해요"], 'I study Korean.', {"일해요": '일해요 means “I work”. I study: 공부해요.'}),
            (["집에", "가요"], 'I am going home.', {}),
        ],
    },
    {
        "id": "czastki", "title": 'Also and not', "icon": "도", "track": "jezyk",
        "words": [
            ("나", 'I (to friends)', None, None),
            ("너", 'you (to friends)', None, 'To strangers, instead of “you” people use a name or title, e.g. 선생님.'),
            ("이거", 'this (thing)', None, '이 (this) + 거 (thing).'),
            ("책", 'book', None, None),
            ("책이에요", 'is a book', None, None),
            ("좋아요", 'good; is good', None, 'ㅎ between vowels disappears: read “joayo”.'),
            ("싫어요", "I don't want; I don't like", None, None),
            ("저도", 'me too', None, '도 = also. It replaces the particle 는: 저는 → 저도.'),
            ("안", 'not (before a verb)', None, "안 + verb = negation: 안 가요 = I don't go."),
        ],
        "sentences": [
            (["이거", "뭐예요", "?"], 'What is this?', {}),
            (["책이에요"], 'This is a book.', {}),
            (["저도", "학생이에요"], 'I am a student too.', {"저는": '“Also” is 도, instead of 는: 저도.'}),
            (["안", "가요"], 'I am not going.', {"아니요": '아니요 is the answer “no”. Before a verb: 안.'}),
            (["김치", "좋아요"], 'I like kimchi.', {"싫어요": "싫어요 means “I don't like”."}),
        ],
    },
    {
        "id": "przeszly", "title": 'Past tense', "icon": "었", "track": "jezyk",
        "words": [
            ("갔어요", 'I went; he went', None, '가 + 았어요 → 갔어요.'),
            ("먹었어요", 'I ate; he ate', None, '먹 + 었어요.'),
            ("했어요", 'I did; he did', None, '하다 → 했어요.'),
            ("공부했어요", 'I studied', None, None),
            ("마셨어요", 'I drank', None, None),
            ("어제", 'yesterday', None, None),
            ("오늘", 'today', None, None),
            ("내일", 'tomorrow', None, None),
        ],
        "sentences": [
            (["어제", "학교에", "갔어요"], 'Yesterday I went to school.', {"가요": 'Yesterday: past tense 갔어요.'}),
            (["오늘", "김치를", "먹었어요"], 'Today I ate kimchi.', {"먹어요": 'Already ate: 먹었어요.'}),
            (["어제", "한국어를", "공부했어요"], 'Yesterday I studied Korean.',
             {"공부해요": 'Yesterday: 공부했어요.'}),
            (["내일", "집에", "가요"], 'Tomorrow I am going home.', {"갔어요": 'Tomorrow: the present tense 가요 is enough.'}),
            (["뭐", "했어요", "?"], 'What did you do?', {"해요": 'A question about the past: 했어요.'}),
        ],
    },
]

TRACKS = {
    "pismo": '한글 · SCRIPT',
    "jezyk": '한국어 · LANGUAGE',
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "hangul4": [
        {"title": 'A vowel with a second vowel',
         "text": 'Compound vowels are two simple ones side by side: ㅗ + ㅐ = ㅙ [wɛ]. ㅐ and ㅔ sound almost the same today, which is why they are easy to confuse in writing. Practise them on words: 왜 (why), 위 (top).',
         "chain": []},
    ],
    "sylaby1": [
        {"title": 'A syllable is a square',
         "text": 'Letters do not stand in a row, they fit into a square. Vertical vowels (ㅏ ㅓ ㅣ) go to the right of the consonant: ㄱ + ㅏ = 가. Horizontal ones (ㅗ ㅜ ㅡ) go beneath it: ㄱ + ㅗ = 고. You read from top to bottom and from left to right.',
         "chain": []},
    ],
    "patchim1": [
        {"title": 'A consonant at the bottom',
         "text": 'The third, bottom letter of a syllable is the patchim (받침, “support”). ㄴ, ㅁ, ㅇ, ㄹ are read clearly at the end: 안 [an], 밤 [pam], 강 [kaŋ], 말 [mal]. ㅇ at the bottom is [ŋ] as in “bank”, while at the top it is silent.',
         "chain": []},
    ],
    "patchim2": [
        {"title": 'Seven sounds at the end',
         "text": 'At the end of a syllable Korean has only seven sounds: [k̚ n t̚ l m p̚ ŋ]. That is why different letters sound the same: ㅅ, ㅈ, ㅊ, ㅌ, ㅎ, ㅆ and ㄷ at the bottom are all [t̚]. They stop “unreleased”, without a puff of air. Only before a vowel (옷이) can you hear again which letter it is.',
         "chain": []},
    ],
    "patchim3": [
        {"title": 'Two letters, one sound',
         "text": 'Two consonants can stand under a syllable, but you usually read only one: 닭 [tak̚], 많 [man], 없 [ʌp̚]. When a vowel follows, the second letter moves to it: 읽어요 [il.gʌ.jo], 없어요 [ʌp̚.sʌ.jo].',
         "chain": []},
    ],
    "hangul1": [
        {"title": 'An alphabet designed from scratch',
         "text": 'King Sejong created Hangul in 1443 so that anyone could learn to read in a few days. The consonant shapes show how the mouth works: ㄱ is the tongue at the palate, ㄴ the tongue at the teeth, ㅁ closed lips. Letters are stacked into syllable blocks: ㅎ + ㅏ + ㄴ = 한.',
         "chain": []},
    ],
    "hangul2": [
        {"title": 'Vowels from a line and a dot',
         "text": 'Vowels are built from three signs: a vertical line (person), a horizontal line (earth) and a dot (sky), which today is a short stroke. ㅏ, ㅓ, ㅗ, ㅜ differ only in its position. A double stroke adds y: ㅏ → ㅑ (ya), ㅗ → ㅛ (yo). A vowel never stands alone: at the start of a syllable a silent ㅇ is written before it: 아.',
         "chain": []},
    ],
    "hangul3": [
        {"title": 'Three kinds of k',
         "text": 'English tells k and g apart. Korean tells apart three other sounds: ㄱ (plain), ㅋ (aspirated) and ㄲ (tense, no puff of air). 가, 카 and 까 are three different syllables. The same goes for t (ㄷ ㅌ ㄸ), p (ㅂ ㅍ ㅃ) and ch (ㅈ ㅊ ㅉ). An extra stroke = a puff of air, a doubled letter = tension.',
         "chain": []},
    ],
    "slowa": [
        {"title": 'Particles work like endings',
         "text": 'In some languages the role of a word is shown by an ending, as in Latin or Polish: Ala, Alę, Ali. In Korean a particle attached to the word does it: 저는 = “I” as the topic of the sentence. Like Polish, Korean has no articles. And the verb always comes last.',
         "chain": [
             ('I am a student.', ["저는", "학생이에요"], '저는 (I) + 학생이에요 (am a student).'),
             ('I am Polish.', ["저는", "폴란드", "사람이에요"], 'A Pole is “a person from Poland”: 폴란드 사람.'),
         ]},
        {"title": '네 means “yes”',
         "text": "The most common trap for Polish speakers: 네 (ne) means “yes”, and “no” is 아니요. You hear 네 in Korea all the time: it also means “I'm listening”, “uh-huh”, “agreed”.",
         "chain": [('Yes, thank you.', ["네", ",", "감사합니다"], '네 = yes.')]},
    ],
    "rodzina": [
        {"title": 'After a vowel, after a consonant',
         "text": 'Almost every particle has two forms, like “a” and “an” in English: one after a vowel, the other after a consonant. “Is” is 예요 after a vowel (엄마예요) and 이에요 after a consonant (학생이에요). This makes pronunciation easier: two vowels never collide.',
         "chain": [
             ('This is my mom.', ["제", "엄마예요"], '제 (my) + 엄마 + 예요 (after a vowel).'),
             ('What is your name?', ["이름이", "뭐예요", "?"], '이름이 (name) + 뭐예요 (what is it?).'),
         ]},
    ],
    "liczby": [
        {"title": 'Two sets of numbers',
         "text": 'Korean has native numbers (하나, 둘, 셋…) and Sino-Korean numbers (일, 이, 삼…). Native ones are used for counting things and age, Sino-Korean ones for dates, money and numbers. Counting things needs a counter, like the English “three pieces”: 사과 세 개 = apples three pieces.',
         "chain": [('Two apples.', ["사과", "두", "개"], 'thing + number + 개 (item). 둘 shortens to 두.')]},
    ],
    "jedzenie": [
        {"title": 'I rice eat',
         "text": 'Korean word order is: who, what, verb. “I eat rice” is “I rice eat”: 저는 밥을 먹어요. The particles show the roles: 을/를 marks “what?”, the object of the verb.',
         "chain": [
             ('I eat rice.', ["저는", "밥을", "먹어요"], '저는 (I) + 밥을 (rice, object) + 먹어요 (eat).'),
             ('I like coffee.', ["커피를", "좋아해요"], 'After a vowel 를.'),
         ]},
    ],
    "czasowniki": [
        {"title": 'One form for everyone',
         "text": 'An English verb changes a little: go, goes. Korean has one form: 가요. Who goes comes from the conversation, and 저 (I) or 친구 (friend) is added only when needed. The ending -요 does not mark a person, only politeness.',
         "chain": [
             ('I am going to school.', ["학교에", "가요"], '학교에 (to school) + 가요 (go).'),
             ('I study Korean.', ["한국어를", "공부해요"], '공부 (study) + 해요 (do).'),
         ]},
    ],
    "czastki": [
        {"title": '도 = also, 안 = not',
         "text": "도 replaces 는 and means “also”: 저도 = me too. Negation is simple: 안 before the verb, like “not”: 안 가요 = I don't go.",
         "chain": [('I am a student too.', ["저도", "학생이에요"], '저 + 도 (also).')]},
    ],
    "przeszly": [
        {"title": '-었- is the past',
         "text": 'The past tense goes in front of -요: 먹어요 (I eat) → 먹었어요 (I ate). After ㅏ and ㅗ it is -았-, and vowels often merge: 가 + 았어요 = 갔어요. 해요 becomes 했어요.',
         "chain": [
             ('Today I ate kimchi.', ["오늘", "김치를", "먹었어요"], '오늘 (today) + 김치를 + 먹었어요.'),
             ('Yesterday I went to school.', ["어제", "학교에", "갔어요"], '어제 (yesterday) + 갔어요.'),
         ]},
    ],
}

ENDINGS_INSIGHT = {
    "title": 'The particle depends on the sound',
    "text": 'Look at the end of the word. Does it end in a consonant (밥, 학생)? Then 은, 이, 을, 이에요. A vowel (저, 커피)? Then 는, 가, 를, 예요. Like “a” and “an” in English.',
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("", "저", "는", " 학생이에요", ["은", "는", "이", "가"], 'I am a student', 'Topic after a vowel: 는.', "slowa"),
    ("", "선생님", "은", " 한국 사람이에요", ["은", "는", "을", "를"], 'the teacher is Korean',
     'Topic after a consonant: 은.', "slowa"),
    ("저는 ", "학생", "이에요", "", ["이에요", "예요", "이", "가"], 'I am a student', 'After a consonant: 이에요.', "slowa"),
    ("제 ", "친구", "예요", "", ["이에요", "예요", "을", "는"], 'this is my friend', 'After a vowel: 예요.', "rodzina"),
    ("", "이름", "이", " 뭐예요?", ["이", "가", "을", "를"], 'what is your name?', 'Subject after a consonant: 이.', "rodzina"),
    ("", "사과", "가", " 세 개 있어요", ["이", "가", "을", "를"], 'there are three apples', 'Subject after a vowel: 가.', "liczby"),
    ("", "밥", "을", " 먹어요", ["을", "를", "이", "가"], 'I eat rice', 'Object after a consonant: 을.', "jedzenie"),
    ("", "커피", "를", " 좋아해요", ["을", "를", "은", "는"], 'I like coffee', 'Object after a vowel: 를.', "jedzenie"),
    ("", "학교", "에", " 가요", ["에", "을", "는", "가"], 'I am going to school', 'Where to? 에.', "czasowniki"),
    ("", "저", "도", " 학생이에요", ["도", "는", "를", "가"], 'I am a student too', '“Also”: 도.', "czastki"),
    ("어제 김치를 ", "먹", "었어요", "", ["어요", "었어요", "을", "는"], 'yesterday I ate kimchi',
     'Past: -었어요.', "przeszly"),
    ("오늘 김치를 ", "먹", "어요", "", ["어요", "었어요", "을", "는"], 'today I eat kimchi', 'Now: -어요.', "przeszly"),
]

# Kolorem wyróżniamy partykuły w ćwiczeniach z końcówkami (zob. ui.py); pole zostaje dla zgodności.
LONG_VOWELS = ""

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "spotkanie", "title": 'First meeting', "partner": "Minjun", "avatar": "민", "requires": "slowa",
        "turns": [
            {"bot": ["안녕하세요", "!"], "en": 'Hello!',
             "options": [(["안녕하세요", "!"], True, None),
                         (["감사합니다", "!"], False, '감사합니다 means “thank you”. Greet first.')]},
            {"bot": ["학생이에요", "?"], "en": 'Are you a student?', "note": 'Careful: 네 means “yes”!',
             "options": [(["네", ",", "저는", "학생이에요"], True, None),
                         (["아니요", ",", "저는", "학생이에요"], False, '아니요 means “no”, but you are confirming. Yes: 네.')]},
            {"bot": ["한국", "사람이에요", "?"], "en": 'Are you Korean?',
             "build": (["아니요", ",", "저는", "폴란드", "사람이에요"], 'No, I am Polish.')},
        ],
    },
    {
        "id": "rodzina", "title": 'Family photos', "partner": "Jiyeon", "avatar": "지", "requires": "rodzina",
        "turns": [
            {"bot": ["이", "사람", "누구예요", "?"], "en": 'Who is that?',
             "options": [(["제", "엄마예요"], True, None),
                         (["이름이", "뭐예요", "?"], False, 'That is a question about a name. Answer who it is: 제 엄마예요.')]},
            {"bot": ["친구예요", "?"], "en": 'Is that your friend?',
             "options": [(["네", ",", "제", "친구예요"], True, None),
                         (["네", ",", "제", "아빠예요"], False, '아빠 means dad. Friend: 친구.')]},
        ],
    },
    {
        "id": "kawiarnia", "title": 'At the café', "partner": "Barista", "avatar": "카", "requires": "jedzenie",
        "turns": [
            {"bot": ["뭐", "마셔요", "?"], "en": 'What are you drinking?',
             "options": [(["커피를", "마셔요"], True, None),
                         (["커피를", "먹어요"], False, '먹어요 means “I eat”. Coffee you drink: 마셔요.')]},
            {"bot": ["김치", "맛있어요", "?"], "en": 'Is the kimchi tasty?',
             "options": [(["네", ",", "맛있어요"], True, None),
                         (["아니요", ",", "맛있어요"], False, '아니요 means “no”, but you say it is delicious. Yes: 네.')]},
            {"bot": ["감사합니다", "!"], "en": 'Thank you!', "build": (["감사합니다"], 'Thank you.')},
        ],
    },
    {
        "id": "plany", "title": 'Yesterday and tomorrow', "partner": "Seojun", "avatar": "서", "requires": "przeszly",
        "turns": [
            {"bot": ["어제", "뭐", "했어요", "?"], "en": 'What did you do yesterday?',
             "options": [(["한국어를", "공부했어요"], True, None),
                         (["한국어를", "공부해요"], False, 'A question about yesterday: past tense 공부했어요.')]},
            {"bot": ["내일", "어디에", "가요", "?"], "en": 'Where are you going tomorrow?',
             "build": (["내일", "학교에", "가요"], 'Tomorrow I am going to school.')},
        ],
    },
]

CHAT_EXTRA = {}
PUNCT = set(",.!?:;")

"""Treść kursu: język kaszubski dla Polaków.

Słowo:     (forma, znaczenie po polsku, polski odpowiednik lub None, skojarzenie lub None)
Litera:    (litera lub dwuznak, jak czytać, przykład)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie, dział)

Wymowa (pole „tr”) powstaje automatycznie w engine.py, zapisana polskimi literami:
òwca → łewca, zëma → zyma.

Źródła: alfabet i wymowa wg Wikipedii (Kashubian alphabet); zaimki, odmiana bëc i robic,
liczebniki, rzeczowniki i przymiotniki wg Wikipedii (Kashubian grammar); słownictwo z podręcznika
języka kaszubskiego na zpe.gov.pl; zwroty wg omniglot.com; art. 1 Powszechnej Deklaracji Praw
Człowieka wg Wikipedii (Kashubian language); początek „Òjcze nasz” wg Wikipedii (Lechitic languages)
i kaszuby.info.pl.
"""

UNITS = [
    # ------------------------------------------------------------------ pismo
    {
        "id": "pismo1", "title": "Litery I", "icon": "Ò", "track": "pismo",
        "letters": [
            ("ò", "[wɛ]: òwca czytaj „łewca”, mòrze „młeże”", "òwca"),
            ("ù", "[wʉ]: kùńszt (sztuka) czytaj „kłuńszt”", "kùńszt"),
            ("ë", "[ə] (szwa); tam, gdzie polski ma i, y, u", "zëma"),
            ("ã", "[ã]; tam, gdzie polski ma ę", "jãzëk"),
        ],
    },
    {
        "id": "pismo2", "title": "Litery II", "icon": "Ô", "track": "pismo",
        "letters": [
            ("ô", "[ɞ] (w gwarach [o], [u] lub [ɛ]); tam, gdzie polskie a", "czwiôrtk"),
            ("é", "[e], na końcu słowa [ɨ]; tam, gdzie polskie e", "rzéka"),
            ("ó", "[o] (na południu Kaszub [u])", "zdrzódło"),
            ("ą", "[õ] (na południu [ũ])", "są"),
            ("cz", "[tʃ], miększe niż polskie cz", "czedë"),
        ],
    },
    # ------------------------------------------------------------------ język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "A", "track": "jezyk", "requires": "pismo1",
        "words": [
            ("Witôj", "witaj", "witaj", "ô w miejscu polskiego a: witaj → Witôj."),
            ("jo", "tak", None, "Uwaga: jo to „tak”, a jô to „ja”!"),
            ("nié", "nie (odpowiedź)", "nie", "nié to odpowiedź „nie”. Przed czasownikiem mówi się nie."),
            ("jô", "ja", "ja", "ô zamiast a: ja → jô."),
            ("të", "ty", "ty", "ë zamiast y: ty → të."),
            ("òn", "on", "on", "ò czytaj łe: „łen”."),
            ("òna", "ona", "ona", None),
            ("jem", "jestem", "jestem", None),
            ("jes", "jesteś", "jesteś", None),
            ("je", "jest", "jest", None),
            ("z", "z", "z", None),
            ("Kaszëb", "Kaszub (z Kaszub)", "Kaszuby", "Kaszëbë to Kaszuby; z Kaszëb = z Kaszub."),
            ("Proszã", "proszę", "proszę", "ã w miejscu polskiego ę."),
            ("Dzãkùjã", "dziękuję", "dziękuję", "ã za ę, ù to „łu”, a dz zamiast dzi."),
        ],
        "sentences": [
            (["jô", "jem", "z", "Kaszëb"], "Jestem z Kaszub.",
             {"jo": "jo to „tak”. Ja: jô.", "je": "je to „jest”. O sobie: jem."}),
            (["të", "jes", "z", "Kaszëb"], "Jesteś z Kaszub.", {"jem": "jem to „jestem”. Do „ty”: jes."}),
            (["òna", "je", "z", "Kaszëb"], "Ona jest z Kaszub.", {"jes": "jes to „jesteś”. O niej: je."}),
            (["jo", ",", "jô", "jem", "z", "Kaszëb"], "Tak, jestem z Kaszub.",
             {"nié": "nié to „nie”. Tutaj: jo (tak)."}),
            (["Dzãkùjã", "!"], "Dziękuję!", {}),
        ],
    },
    {
        "id": "kaszubienie", "title": "Kaszubienie", "icon": "B", "track": "jezyk",
        "words": [
            ("cëchò", "cicho", "cicho", "Polskie ci → c, a i → ë. Na końcu o → ò."),
            ("swiat", "świat", "świat", "Polskie ś → s."),
            ("zëma", "zima", "zima", "Polskie zi → zë."),
            ("lëpa", "lipa", "lipa", None),
            ("bëc", "być", "być", "Polskie -yć → -ëc."),
            ("chòdzëc", "chodzić", "chodzić", "dzi → dzë, a -ić → -ëc."),
            ("òwca", "owca", "owca", "Na początku słowa o → ò (łe)."),
            ("mòrze", "morze", "morze", None),
            ("kôłbasa", "kiełbasa", "kiełbasa", None),
            ("chto", "kto", "kto", None),
            ("czedë", "kiedy", "kiedy", "Polskie kie → cze."),
            ("nodżi", "nogi", "nogi", "Polskie gi → dżi."),
            ("baro", "bardzo", "bardzo", None),
            ("pierszi", "pierwszy", "pierwszy", None),
        ],
        "sentences": [
            (["je", "cëchò"], "Jest cicho.", {}),
            (["czedë", "je", "zëma", "?"], "Kiedy jest zima?", {"chto": "chto to „kto”. Kiedy: czedë."}),
            (["chto", "je", "z", "Kaszëb", "?"], "Kto jest z Kaszub?", {"czedë": "czedë to „kiedy”. Kto: chto."}),
            (["je", "baro", "cëchò"], "Jest bardzo cicho.", {}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "C", "track": "jezyk",
        "words": [
            ("mëma", "mama", "mama", "ë w miejscu a: mama → mëma."),
            ("tatk", "tata", "tatko", None),
            ("sostra", "siostra", "siostra", None),
            ("bratk", "brat", "bratek", None),
            ("starka", "babcia", "starka", "Starka, czyli „stara”: babcia."),
            ("dzecko", "dziecko", "dziecko", "dzie → dze."),
            ("knôp", "chłopiec", None, "Z dolnoniemieckiego, jak niemieckie Knabe."),
            ("dzéwczã", "dziewczyna", "dziewczę", None),
            ("mòja", "moja", "moja", None),
            ("mój", "mój", "mój", None),
            ("to", "to", "to", None),
            ("chëcz", "dom", "chyża", "Dawne polskie „chyża” to chata."),
            ("dobri", "dobry", "dobry", "Polskie -y → -i."),
            ("dobrô", "dobra", "dobra", "Polskie -a w przymiotniku → -ô."),
            ("stôri", "stary", "stary", None),
            ("młodi", "młody", "młody", None),
            ("młodô", "młoda", "młoda", None),
        ],
        "sentences": [
            (["to", "je", "mòja", "mëma"], "To jest moja mama.", {"mój": "mëma jest żeńska: mòja."}),
            (["mój", "tatk", "je", "dobri"], "Mój tata jest dobry.", {"dobrô": "tatk jest męski: dobri."}),
            (["mòja", "sostra", "je", "młodô"], "Moja siostra jest młoda.",
             {"młodi": "sostra jest żeńska: młodô."}),
            (["starka", "je", "dobrô"], "Babcia jest dobra.", {"dobri": "starka jest żeńska: dobrô."}),
            (["to", "je", "mòja", "chëcz"], "To jest mój dom.", {"mój": "chëcz jest żeńska: mòja chëcz."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "D", "track": "jezyk",
        "words": [
            ("jeden", "jeden", "jeden", None),
            ("dwa", "dwa", "dwa", None),
            ("trzë", "trzy", "trzy", None),
            ("sztërë", "cztery", "cztery", None),
            ("piãc", "pięć", "pięć", "ã za ę, c za ć."),
            ("szesc", "sześć", "sześć", None),
            ("sétmë", "siedem", "siódmy", None),
            ("òsmë", "osiem", "ósmy", None),
            ("dzewiãc", "dziewięć", "dziewięć", None),
            ("dzesãc", "dziesięć", "dziesięć", None),
            ("ë", "i", "i", "Spójnik „i” to po kaszubsku ë."),
            ("są", "są", "są", None),
        ],
        "sentences": [
            (["jeden", "ë", "jeden", "to", "dwa"], "Jeden i jeden to dwa.", {}),
            (["trzë", "ë", "sztërë", "to", "sétmë"], "Trzy i cztery to siedem.", {"sztërë": "sztërë to 4."}),
            (["piãc", "ë", "piãc", "to", "dzesãc"], "Pięć i pięć to dziesięć.", {}),
        ],
    },
    {
        "id": "swiat2", "title": "Przyroda", "icon": "E", "track": "jezyk",
        "words": [
            ("wòda", "woda", "woda", None),
            ("zemia", "ziemia", "ziemia", "zie → ze."),
            ("słuńce", "słońce", "słońce", None),
            ("rzéka", "rzeka", "rzeka", None),
            ("jezoro", "jezioro", "jezioro", None),
            ("deszcz", "deszcz", "deszcz", None),
            ("wiater", "wiatr", "wiatr", None),
            ("lato", "lato", "lato", None),
            ("dzéń", "dzień", "dzień", None),
            ("dzys", "dziś", "dziś", None),
            ("snôżi", "piękny", None, "Kaszubskie słowo na „piękny”."),
            ("wiôldżi", "wielki; duży", "wielki", None),
            ("wiôlgô", "wielka; duża", "wielka", "W rodzaju żeńskim wraca g: wiôlgô. Jak Wiôlgô Wies."),
            ("môłi", "mały", "mały", None),
        ],
        "sentences": [
            (["dzys", "je", "snôżi", "dzéń"], "Dziś jest piękny dzień.", {}),
            (["mòrze", "je", "wiôldżi"], "Morze jest wielkie.", {}),
            (["rzéka", "je", "wiôlgô"], "Rzeka jest wielka.", {"wiôldżi": "rzéka jest żeńska: wiôlgô."}),
            (["jezoro", "je", "môłi"], "Jezioro jest małe.", {}),
            (["dzys", "je", "lato"], "Dziś jest lato.", {}),
        ],
    },
    {
        "id": "zwierze", "title": "Zwierzęta", "icon": "F", "track": "jezyk",
        "words": [
            ("pies", "pies", "pies", None),
            ("kòt", "kot", "kot", "ò czytaj łe: „kłet”."),
            ("rëba", "ryba", "ryba", None),
            ("lës", "lis", "lis", None),
            ("ptôch", "ptak", "ptak", "ô za a, ch za k."),
            ("wilk", "wilk", "wilk", None),
            ("krowa", "krowa", "krowa", None),
            ("kaczka", "kaczka", "kaczka", None),
            ("kòń", "koń", "koń", None),
        ],
        "sentences": [
            (["kòt", "je", "môłi"], "Kot jest mały.", {}),
            (["kòń", "je", "wiôldżi"], "Koń jest duży.", {"wiôlgô": "kòń jest męski: wiôldżi."}),
            (["to", "je", "mój", "pies"], "To jest mój pies.", {"mòja": "pies jest męski: mój."}),
            (["chto", "to", "je", "?"], "Kto to jest?", {}),
        ],
    },
    {
        "id": "czasowniki", "title": "Czasowniki", "icon": "G", "track": "jezyk",
        "words": [
            ("czëtóm", "czytam", "czytam", "-óm jak polskie -am."),
            ("czëtôsz", "czytasz", "czytasz", "-ôsz jak polskie -asz."),
            ("czëtô", "czyta", "czyta", None),
            ("gôdóm", "mówię", "gadam", "gôdac znaczy „mówić”, jak polskie gadać."),
            ("gôdôsz", "mówisz", "gadasz", None),
            ("robiã", "robię; pracuję", "robię", None),
            ("robisz", "robisz", "robisz", None),
            ("robi", "robi", "robi", None),
            ("co", "co", "co", None),
            ("nie", "nie (przed czasownikiem)", "nie", "Przed czasownikiem: nie. Samo „nie” jako odpowiedź: nié."),
            ("pò", "po", "po", None),
            ("kaszëbskù", "kaszubsku (po kaszubsku)", "kaszubsku", "pò kaszëbskù, jak „gôdómë pò kaszëbskù”."),
            ("kąsk", "trochę", "kąsek", "Kąsk to „kąsek”, czyli trochę."),
        ],
        "sentences": [
            (["co", "robisz", "?"], "Co robisz?", {"robiã": "Pytasz kogoś: robisz."}),
            (["jô", "czëtóm"], "Czytam.", {"czëtô": "czëtô to „czyta”. Ja: czëtóm."}),
            (["gôdôsz", "pò", "kaszëbskù", "?"], "Mówisz po kaszubsku?",
             {"gôdóm": "gôdóm to „mówię”. Do „ty”: gôdôsz."}),
            (["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"], "Tak, mówię trochę po kaszubsku.",
             {"jô": "jô to „ja”. Tak: jo."}),
            (["mëma", "czëtô"], "Mama czyta.", {"czëtóm": "O mamie: czëtô (-ô jak polskie -a)."}),
            (["jô", "nie", "gôdóm", "pò", "kaszëbskù"], "Nie mówię po kaszubsku.",
             {"nié": "Przed czasownikiem: nie. nié to samo „nie” w odpowiedzi."}),
        ],
    },
    {
        "id": "be", "title": "My, wy, Wë", "icon": "H", "track": "jezyk",
        "words": [
            ("më", "my", "my", "ë zamiast y."),
            ("wa", "wy", "wy", "Wa to dawna liczba podwójna: „wy dwaj”. Dziś zwykłe „wy”."),
            ("Wë", "Pan; Pani (grzecznie)", "Wy", "Kaszubi zwracają się grzecznie przez Wë, jak dawniej „Wy”."),
            ("òni", "oni", "oni", None),
            ("jesmë", "jesteśmy", "jesteśmy", None),
            ("jesta", "jesteście", "jesteście", None),
            ("jesce", "jest Pan; jest Pani", None, "Do Wë: jesce."),
            ("robimë", "robimy", "robimy", "-më jak polskie -my."),
            ("gôdómë", "mówimy", "gadamy", "„Gôdómë pò kaszëbskù” to hasło akcji promującej kaszubski."),
            ("skądka", "skąd", "skąd", None),
        ],
        "sentences": [
            (["më", "jesmë", "z", "Kaszëb"], "Jesteśmy z Kaszub.", {"jesta": "jesta to „jesteście”. My: jesmë."}),
            (["wa", "jesta", "z", "Kaszëb"], "Jesteście z Kaszub.", {"jesce": "jesce to grzeczne „Pan jest”."}),
            (["skądka", "Wë", "jesce", "?"], "Skąd Pan jest?", {"jes": "Grzecznie: Wë jesce, nie të jes."}),
            (["òni", "są", "z", "Kaszëb"], "Oni są z Kaszub.", {}),
            (["gôdómë", "pò", "kaszëbskù"], "Mówimy po kaszubsku.", {"gôdóm": "My: gôdómë (-më)."}),
            (["më", "robimë"], "Pracujemy.", {"robiã": "My: robimë."}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "prawa", "title": "Prawa człowieka", "icon": "I", "track": "teksty", "requires": "be",
        "words": [
            ("wszëtczi", "wszyscy", "wszyscy", "szy → szë, scy → czi."),
            ("lëdze", "ludzie", "ludzie", None),
            ("rodzą", "rodzą", "rodzą", None),
            ("sã", "się", "się", "ã za ę: się → sã."),
            ("wòlny", "wolni", "wolny", None),
            ("równy", "równi", "równy", None),
        ],
        "sentences": [
            (["wszëtczi", "lëdze", "rodzą", "sã", "wòlny", "ë", "równy"],
             "Wszyscy ludzie rodzą się wolni i równi.", {}),
            (["lëdze", "są", "wòlny"], "Ludzie są wolni.", {}),
        ],
    },
    {
        "id": "ojcze", "title": "Òjcze nasz", "icon": "J", "track": "teksty",
        "words": [
            ("Òjcze", "Ojcze", "ojcze", "Wołacz, jak po polsku. Ò na początku: „Łejcze”."),
            ("nasz", "nasz", "nasz", None),
            ("jaczi", "który (dosł. jaki)", "jaki", "Kaszubski mówi „jaczi jes”: jaki jesteś."),
            ("w", "w", "w", None),
            ("niebie", "niebie", "niebie", None),
        ],
        "sentences": [
            (["Òjcze", "nasz", ",", "jaczi", "jes", "w", "niebie"], "Ojcze nasz, któryś jest w niebie.", {}),
        ],
    },
]

TRACKS = {
    "pismo": "PISMO",
    "jezyk": "JÃZËK · JĘZYK",
    "teksty": "TEKSTË · TEKSTY",
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "pismo1": [
        {"title": "Kreski mówią, jak czytać",
         "text": "Kaszubski pisze się prawie jak polski, ale ma swoje litery. Najważniejsza: ò czyta się "
                 "„łe”. Polskie „kot” po kaszubsku to kòt, czyli „kłet”. A ë to szwa: krótki, "
                 "przytłumiony dźwięk tam, gdzie polski ma i, y albo u.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Znasz już kaszubski",
         "text": "Kaszubski to język zachodniosłowiański, najbliższy krewny polskiego. Wiele słów różni "
                 "się jedną literą: ja → jô, ty → të, jestem → jem. Uważaj tylko na jo: to „tak”.",
         "chain": [
             ("Jestem z Kaszub.", ["jô", "jem", "z", "Kaszëb"], "jô (ja) + jem (jestem)."),
             ("Jesteś z Kaszub.", ["të", "jes", "z", "Kaszëb"], "Zmień osobę: të, jes."),
         ]},
    ],
    "kaszubienie": [
        {"title": "Kaszubienie: ci → c",
         "text": "Gdzie polski ma miękkie ci, si, zi, dzi, kaszubski ma twarde c, s, z, dz: cicho → cëchò, "
                 "świat → swiat, zima → zëma. A k, g przed e, i zmiękczają się w cz, dż: kiedy → czedë, "
                 "nogi → nodżi. Znając tę regułę, odgadniesz setki słów.",
         "chain": [
             ("Kiedy jest zima?", ["czedë", "je", "zëma", "?"], "kiedy → czedë, zima → zëma."),
         ]},
    ],
    "rodzina": [
        {"title": "-a w przymiotniku to -ô",
         "text": "Rodzaj działa jak po polsku, zmieniają się tylko samogłoski: dobry → dobri, "
                 "dobra → dobrô, moja → mòja. Polskie -a w przymiotniku to po kaszubsku -ô.",
         "chain": [
             ("To jest moja mama.", ["to", "je", "mòja", "mëma"], "to je + mòja (żeńska) + mëma."),
             ("Babcia jest dobra.", ["starka", "je", "dobrô"], "starka jest żeńska: dobrô."),
         ]},
    ],
    "liczby": [
        {"title": "Liczby prawie po polsku",
         "text": "Jeden, dwa: bez zmian. Dalej działają te same reguły: y → ë (trzë), ę → ã (piãc, "
                 "dzewiãc), ś → s (szesc). A spójnik „i” to ë.",
         "chain": [("Jeden i jeden to dwa.", ["jeden", "ë", "jeden", "to", "dwa"], "„i” to ë.")]},
    ],
    "swiat2": [
        {"title": "Wielki, wielka: wiôldżi, wiôlgô",
         "text": "Polskie „wielki” i „wielka” mają różne spółgłoski tylko w pisowni kaszubskiej: przed i "
                 "g zmiękcza się w dż (wiôldżi), a przed ô zostaje g (wiôlgô). To ta sama reguła co "
                 "nogi → nodżi.",
         "chain": [
             ("Dziś jest piękny dzień.", ["dzys", "je", "snôżi", "dzéń"], "dziś → dzys, dzień → dzéń."),
             ("Rzeka jest wielka.", ["rzéka", "je", "wiôlgô"], "Żeńska: wiôlgô."),
         ]},
    ],
    "zwierze": [
        {"title": "ò wszędzie po wargowych",
         "text": "Polskie o po p, b, m, w, k, g, ch i na początku słowa po kaszubsku zwykle ma kreskę: "
                 "kot → kòt, koń → kòń, morze → mòrze. Czytasz „łe”: kłet, kłeń, młeże.",
         "chain": [("Kot jest mały.", ["kòt", "je", "môłi"], "kot → kòt, mały → môłi.")]},
    ],
    "czasowniki": [
        {"title": "-am to -óm, -asz to -ôsz",
         "text": "Końcówki czasowników pasują do polskich: czytam → czëtóm, czytasz → czëtôsz, czyta → "
                 "czëtô. A robię → robiã, bo polskie ę to kaszubskie ã. Mówić to gôdac, jak polskie gadać.",
         "chain": [
             ("Czytam.", ["jô", "czëtóm"], "-am → -óm."),
             ("Tak, mówię trochę po kaszubsku.", ["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"],
              "jo (tak), gôdóm (gadam), kąsk (kąsek)."),
         ]},
    ],
    "be": [
        {"title": "Grzecznie: Wë",
         "text": "Kaszubi nie mówią „Pan, Pani”. Do starszych i obcych mówi się Wë, a czasownik ma "
                 "końcówkę -ce: Wë jesce = Pan jest / Pani jest. Do kilku osób: wa jesta (jesteście).",
         "chain": [
             ("Skąd Pan jest?", ["skądka", "Wë", "jesce", "?"], "skądka + Wë + jesce."),
             ("Jesteśmy z Kaszub.", ["më", "jesmë", "z", "Kaszëb"], "më, jesmë (-më jak -my)."),
         ]},
    ],
    "prawa": [
        {"title": "Pierwszy artykuł",
         "text": "Tak zaczyna się Powszechna Deklaracja Praw Człowieka po kaszubsku. Każde słowo "
                 "odgadniesz z polskiego: wszyscy → wszëtczi, ludzie → lëdze, się → sã.",
         "chain": [("Ludzie są wolni.", ["lëdze", "są", "wòlny"], "lëdze + są + wòlny.")]},
    ],
    "ojcze": [
        {"title": "Modlitwę już znasz",
         "text": "Kaszubskie „Òjcze nasz” brzmi bardzo podobnie do polskiego. Zamiast „któryś jest” "
                 "jest „jaczi jes”, czyli „jaki jesteś”.",
         "chain": [("Ojcze nasz, któryś jest w niebie.", ["Òjcze", "nasz", ",", "jaczi", "jes", "w", "niebie"],
                    "Òjcze nasz + jaczi jes + w niebie.")]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Końcówki jak po polsku",
    "text": "Kaszubskie końcówki to polskie końcówki z innymi samogłoskami: -ę → -ã, -a → -ô, "
            "-am → -óm, -my → -më. Gdy się wahasz, powiedz to po polsku i zamień samogłoskę.",
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("mòja mëma je ", "dobr", "ô", "", ["i", "ô", "é", "a"], "moja mama jest dobra", "Żeńska: -ô, jak polskie -a.", "rodzina"),
    ("mój tatk je ", "dobr", "i", "", ["i", "ô", "é", "y"], "mój tata jest dobry", "Męska: -i, jak polskie -y.", "rodzina"),
    ("", "m", "òja", " sostra", ["ój", "òja", "òje", "oja"], "moja siostra", "Żeńska: mòja.", "rodzina"),
    ("dzys je ", "snôż", "i", " dzéń", ["i", "ô", "é", "y"], "dziś jest piękny dzień", "dzéń jest męski: snôżi.", "swiat2"),
    ("rzéka je ", "wiôl", "gô", "", ["dżi", "gô", "dżé", "ga"], "rzeka jest wielka", "Żeńska: wiôlgô.", "swiat2"),
    ("jô ", "czët", "óm", "", ["óm", "ôsz", "ô", "ómë"], "ja czytam", "Ja: -óm, jak polskie -am.", "czasowniki"),
    ("të ", "czët", "ôsz", "", ["óm", "ôsz", "ô", "ómë"], "ty czytasz", "Ty: -ôsz, jak -asz.", "czasowniki"),
    ("mëma ", "czët", "ô", "", ["óm", "ôsz", "ô", "ómë"], "mama czyta", "Ona: -ô, jak -a.", "czasowniki"),
    ("jô ", "rob", "iã", "", ["iã", "isz", "i", "imë"], "ja robię", "Ja: -ã, jak polskie -ę.", "czasowniki"),
    ("më ", "rob", "imë", "", ["iã", "isz", "i", "imë"], "my robimy", "My: -më, jak polskie -my.", "be"),
    ("Wë ", "jes", "ce", " z Kaszëb?", ["m", "s", "ce", "ta"], "Pan jest z Kaszub?", "Grzecznie: Wë jesce.", "be"),
    ("wa ", "jes", "ta", " z Kaszëb", ["m", "s", "ce", "ta"], "wy jesteście z Kaszub", "Wy: wa jesta.", "be"),
    ("më ", "jes", "më", " z Kaszëb", ["m", "më", "ce", "ta"], "my jesteśmy z Kaszub", "My: jesmë.", "be"),
]

# Kolorem wyróżniamy litery, których nie ma w polskim alfabecie.
LONG_VOWELS = "ãëéòôùÃËÉÒÔÙ"

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "witaj", "title": "Na powitanie", "partner": "Kasia", "avatar": "K", "requires": "slowa",
        "turns": [
            {"bot": ["Witôj", "!"], "en": "Witaj!",
             "options": [(["Witôj", "!"], True, None),
                         (["Dzãkùjã", "!"], False, "Dzãkùjã to „dziękuję”. Najpierw się przywitaj!")]},
            {"bot": ["të", "jes", "z", "Kaszëb", "?"], "en": "Jesteś z Kaszub?",
             "options": [(["jo", ",", "jô", "jem", "z", "Kaszëb"], True, None),
                         (["jô", ",", "jô", "jem", "z", "Kaszëb"], False, "jô to „ja”. Tak: jo."),
                         (["jo", ",", "jô", "je", "z", "Kaszëb"], False, "je to „jest”. O sobie: jem.")]},
            {"bot": ["Do", "ùzdrzeniô", "!"], "en": "Do widzenia!", "build": (["Dzãkùjã", "!"], "Dziękuję!")},
        ],
    },
    {
        "id": "dom", "title": "W domu", "partner": "Starka", "avatar": "S", "requires": "rodzina",
        "turns": [
            {"bot": ["chto", "to", "je", "?"], "en": "Kto to jest?",
             "options": [(["to", "je", "mòja", "sostra"], True, None),
                         (["to", "je", "mój", "sostra"], False, "sostra jest żeńska: mòja."),
                         (["chto", "je", "mòja", "sostra"], False, "chto to „kto”. Odpowiadasz: to je…")]},
            {"bot": ["a", "tatk", "?"], "en": "A tata?",
             "build": (["mój", "tatk", "je", "dobri"], "Mój tata jest dobry.")},
        ],
    },
    {
        "id": "morze", "title": "Nad morzem", "partner": "Józef", "avatar": "J", "requires": "czasowniki",
        "turns": [
            {"bot": ["dzys", "je", "snôżi", "dzéń", "!"], "en": "Dziś jest piękny dzień!",
             "options": [(["jo", ",", "mòrze", "je", "baro", "snôżi"], True, None),
                         (["nié", ",", "mòrze", "je", "baro", "snôżi"], False, "nié to „nie”. Zgadzasz się: jo.")],
             "note": "baro to „bardzo”."},
            {"bot": ["gôdôsz", "pò", "kaszëbskù", "?"], "en": "Mówisz po kaszubsku?",
             "options": [(["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"], True, None),
                         (["jo", ",", "gôdôsz", "kąsk", "pò", "kaszëbskù"], False,
                          "gôdôsz to „mówisz”. O sobie: gôdóm.")]},
            {"bot": ["co", "robisz", "?"], "en": "Co robisz?", "build": (["jô", "czëtóm"], "Czytam.")},
        ],
    },
    {
        "id": "sasiedzi", "title": "U sąsiadów", "partner": "Pani Ana", "avatar": "A", "requires": "be",
        "turns": [
            {"bot": ["skądka", "Wë", "jesce", "?"], "en": "Skąd Pan jest?",
             "options": [(["jô", "jem", "z", "Kaszëb"], True, None),
                         (["jô", "jesce", "z", "Kaszëb"], False, "jesce to forma do Wë. O sobie: jem.")]},
            {"bot": ["a", "wa", "?"], "en": "A wy?", "note": "Pani pyta o całą rodzinę.",
             "build": (["më", "jesmë", "z", "Kaszëb"], "Jesteśmy z Kaszub.")},
            {"bot": ["Do", "ùzdrzeniô", "!"], "en": "Do widzenia!",
             "options": [(["Do", "ùzdrzeniô", "!"], True, None),
                         (["Witôj", "!"], False, "Witôj to powitanie. Teraz się żegnasz.")]},
        ],
    },
]

CHAT_EXTRA = {"Do": "do", "ùzdrzeniô": "widzenia", "a": "a"}
PUNCT = set(",.!?:;")

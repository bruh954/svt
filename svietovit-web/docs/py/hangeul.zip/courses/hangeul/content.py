"""Treść kursu: język koreański dla Polaków.

Słowo:     (forma hangulem, znaczenie po polsku, polski krewny lub None, skojarzenie lub None)
Litera:    (litera hangulu, wymowa w IPA z krótką podpowiedzią, przykładowa sylaba)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie, dział)

Koreański dokleja partykuły do słów (저는, 밥을), więc słowa w kursie to całe „klocki” z partykułą.
Transkrypcja (pole „tr”) powstaje automatycznie w engine.py według oficjalnej latynizacji
(Revised Romanization): 안녕하세요 → annyeonghaseyo.
"""

UNITS = [
    # --------------------------------------------------------------- hangul
    {
        "id": "hangul1", "title": "Hangul I", "icon": "ㄱ", "track": "pismo",
        "letters": [
            ("ㄱ", "[k], między samogłoskami [ɡ]", "가"),
            ("ㄴ", "[n]", "나"),
            ("ㄷ", "[t], między samogłoskami [d]", "다"),
            ("ㄹ", "[ɾ] (krótkie r), na końcu sylaby [l]", "라"),
            ("ㅁ", "[m]", "마"),
            ("ㅂ", "[p], między samogłoskami [b]", "바"),
            ("ㅅ", "[s], przed ㅣ [ɕ] (polskie ś)", "사"),
            ("ㅇ", "na początku sylaby niema, na końcu [ŋ]", "아"),
            ("ㅈ", "[tɕ], między samogłoskami [dʑ] (ć / dź)", "자"),
            ("ㅎ", "[h]", "하"),
        ],
    },
    {
        "id": "hangul2", "title": "Hangul II", "icon": "ㅏ", "track": "pismo",
        "letters": [
            ("ㅏ", "[a]", "아"),
            ("ㅓ", "[ʌ] (otwarte o bez zaokrąglania warg)", "어"),
            ("ㅗ", "[o]", "오"),
            ("ㅜ", "[u]", "우"),
            ("ㅡ", "[ɯ] (u z rozciągniętymi wargami)", "으"),
            ("ㅣ", "[i]", "이"),
            ("ㅐ", "[ɛ]", "애"),
            ("ㅔ", "[e]", "에"),
            ("ㅑ", "[ja]", "야"),
            ("ㅕ", "[jʌ]", "여"),
            ("ㅛ", "[jo]", "요"),
            ("ㅠ", "[ju]", "유"),
        ],
    },
    {
        "id": "hangul3", "title": "Hangul III", "icon": "ㄲ", "track": "pismo",
        "letters": [
            ("ㅊ", "[tɕʰ] (ć z wydechem)", "차"),
            ("ㅋ", "[kʰ] (k z wydechem)", "카"),
            ("ㅌ", "[tʰ] (t z wydechem)", "타"),
            ("ㅍ", "[pʰ] (p z wydechem)", "파"),
            ("ㄲ", "[k͈] (napięte k, bez wydechu)", "까"),
            ("ㄸ", "[t͈] (napięte t)", "따"),
            ("ㅃ", "[p͈] (napięte p)", "빠"),
            ("ㅆ", "[s͈] (napięte s)", "싸"),
            ("ㅉ", "[t͈ɕ] (napięte ć)", "짜"),
            ("ㅘ", "[wa]", "와"),
            ("ㅝ", "[wʌ]", "워"),
            ("ㅢ", "[ɰi]", "의"),
        ],
    },
    {
        "id": 'hangul4', "title": 'Hangul IV: samogłoski złożone', "icon": 'ㅒ', "track": "pismo",
        "letters": [
            ('ㅒ', '[jɛ]', '얘기'),
            ('ㅖ', '[je]', '예'),
            ('ㅙ', '[wɛ]', '왜'),
            ('ㅞ', '[we]', '웨이터'),
            ('ㅚ', '[we] (oe)', '외국'),
            ('ㅟ', '[wi]', '위'),
        ],
    },
    {
        "id": 'sylaby1', "title": 'Sylaby I: ㅏ i ㅓ', "icon": '가', "track": "pismo",
        "letters": [
            ('가', '[ka] (ga)', '가방'),
            ('거', '[kʌ] (geo)', '거리'),
            ('나', '[na] (na)', '나라'),
            ('너', '[nʌ] (neo)', '너무'),
            ('다', '[ta] (da)', '다리'),
            ('더', '[tʌ] (deo)', '더워요'),
            ('라', '[ɾa] (ra)', '라면'),
            ('러', '[ɾʌ] (reo)', '러시아'),
            ('마', '[ma] (ma)', '마음'),
            ('머', '[mʌ] (meo)', '머리'),
            ('바', '[pa] (ba)', '바다'),
            ('버', '[pʌ] (beo)', '버스'),
        ],
    },
    {
        "id": 'sylaby2', "title": 'Sylaby II: ㅏ i ㅓ', "icon": '사', "track": "pismo",
        "letters": [
            ('사', '[sa] (sa)', '사과'),
            ('서', '[sʌ] (seo)', '서울'),
            ('아', '[a] (a)', '아기'),
            ('어', '[ʌ] (eo)', '어머니'),
            ('자', '[tɕa] (ja)', '자동차'),
            ('저', '[tɕʌ] (jeo)', '저녁'),
            ('하', '[ha] (ha)', '하나'),
            ('허', '[hʌ] (heo)', '허리'),
            ('차', '[tɕʰa] (cha)', '차'),
            ('처', '[tɕʰʌ] (cheo)', '처음'),
            ('카', '[kʰa] (ka)', '카메라'),
            ('커', '[kʰʌ] (keo)', '커피'),
        ],
    },
    {
        "id": 'sylaby3', "title": 'Sylaby III: ㅗ i ㅜ', "icon": '고', "track": "pismo",
        "letters": [
            ('고', '[ko] (go)', '고기'),
            ('구', '[ku] (gu)', '구두'),
            ('노', '[no] (no)', '노래'),
            ('누', '[nu] (nu)', '누나'),
            ('도', '[to] (do)', '도시'),
            ('두', '[tu] (du)', '두부'),
            ('로', '[ɾo] (ro)', '로봇'),
            ('루', '[ɾu] (ru)', '루비'),
            ('모', '[mo] (mo)', '모자'),
            ('무', '[mu] (mu)', '무게'),
            ('보', '[po] (bo)', '보리'),
            ('부', '[pu] (bu)', '부모'),
        ],
    },
    {
        "id": 'sylaby4', "title": 'Sylaby IV: ㅗ ㅜ ㅡ ㅣ', "icon": '소', "track": "pismo",
        "letters": [
            ('소', '[so] (so)', '소리'),
            ('수', '[su] (su)', '수박'),
            ('오', '[o] (o)', '오이'),
            ('우', '[u] (u)', '우유'),
            ('조', '[tɕo] (jo)', '조용'),
            ('주', '[tɕu] (ju)', '주스'),
            ('호', '[ho] (ho)', '호수'),
            ('후', '[hu] (hu)', '후추'),
            ('으', '[ɯ] (eu)', '음악'),
            ('이', '[i] (i)', '이마'),
            ('그', '[kɯ] (geu)', '그림'),
            ('기', '[ki] (gi)', '기차'),
        ],
    },
    {
        "id": 'patchim1', "title": 'Patchim I: ㄴ ㅁ ㅇ ㄹ', "icon": '안', "track": "pismo",
        "letters": [
            ('안', '[an]', '안녕'),
            ('산', '[san]', '산'),
            ('문', '[mun]', '문'),
            ('밤', '[pam]', '밤'),
            ('곰', '[kom]', '곰'),
            ('강', '[kaŋ]', '강'),
            ('공', '[koŋ]', '공'),
            ('말', '[mal]', '말'),
            ('물', '[mul]', '물'),
            ('달', '[tal]', '달'),
            ('한', '[han]', '한국'),
            ('방', '[paŋ]', '방'),
        ],
    },
    {
        "id": 'patchim2', "title": 'Patchim II: ㄱ ㅂ ㅅ ㅌ', "icon": '책', "track": "pismo",
        "letters": [
            ('책', '[tɕʰɛk̚]', '책'),
            ('목', '[mok̚]', '목'),
            ('국', '[kuk̚]', '국'),
            ('밖', '[pak̚]', '밖'),
            ('집', '[tɕip̚]', '집'),
            ('밥', '[pap̚]', '밥'),
            ('입', '[ip̚]', '입'),
            ('옷', '[ot̚]', '옷'),
            ('낮', '[nat̚]', '낮'),
            ('꽃', '[k͈ot̚]', '꽃'),
            ('있', '[it̚]', '있어요'),
            ('앞', '[ap̚]', '앞'),
        ],
    },
    {
        "id": 'patchim3', "title": 'Patchim III: podwójne', "icon": '닭', "track": "pismo",
        "letters": [
            ('닭', '[tak̚]', '닭'),
            ('읽', '[ik̚]', '읽어요'),
            ('앉', '[an]', '앉아요'),
            ('많', '[man]', '많아요'),
            ('없', '[ʌp̚]', '없어요'),
            ('값', '[kap̚]', '값'),
            ('넓', '[nʌl]', '넓어요'),
            ('삶', '[sam]', '삶'),
            ('젊', '[tɕʌm]', '젊어요'),
            ('흙', '[hɯk̚]', '흙'),
        ],
    },
    # ---------------------------------------------------------------- język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "안", "track": "jezyk", "requires": "hangul2",
        "words": [
            ("안녕하세요", "dzień dobry; cześć", None, "Dosłownie „czy jest pan w spokoju?”. Pasuje o każdej porze dnia."),
            ("감사합니다", "dziękuję", None, "Grzeczna, oficjalna forma. 감사 to „wdzięczność”."),
            ("네", "tak", None, "Uwaga: 네 znaczy „tak”, choć brzmi jak polskie „nie”!"),
            ("아니요", "nie", None, None),
            ("저", "ja (grzecznie)", None, "Grzeczne „ja”. Do przyjaciół mówi się 나."),
            ("저는", "ja (jako temat)", None, "는 to partykuła tematu: „jeśli chodzi o mnie…”."),
            ("학생", "uczeń; student", None, None),
            ("학생이에요", "jestem studentem", None, "학생 + 이에요 (jest / jestem). Osobę mówi kontekst."),
            ("선생님", "nauczyciel", None, "님 to grzecznościowa końcówka, jak „pan” w „panie profesorze”."),
            ("선생님이에요", "to nauczyciel", None, None),
            ("한국", "Korea", None, None),
            ("폴란드", "Polska", "Polska", "Polska po koreańsku: pollandeu."),
            ("사람", "człowiek", None, None),
            ("사람이에요", "jestem (kimś); to człowiek", None, "사람 (człowiek) + 이에요. 폴란드 사람 = Polak."),
        ],
        "sentences": [
            (["안녕하세요", "!"], "Dzień dobry!", {"감사합니다": "감사합니다 to „dziękuję”."}),
            (["저는", "학생이에요"], "Jestem studentem.", {"선생님이에요": "선생님이에요 to „to nauczyciel”."}),
            (["저는", "폴란드", "사람이에요"], "Jestem Polakiem.", {"한국": "한국 to Korea. Polska: 폴란드."}),
            (["저는", "한국", "사람이에요"], "Jestem Koreańczykiem.", {"폴란드": "폴란드 to Polska. Korea: 한국."}),
            (["네", ",", "감사합니다"], "Tak, dziękuję.", {"아니요": "아니요 to „nie”. Tak: 네."}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "엄", "track": "jezyk",
        "words": [
            ("엄마", "mama", "mama", "Prawie jak polskie „mama”!"),
            ("아빠", "tata", "papa", None),
            ("가족", "rodzina", None, None),
            ("친구", "przyjaciel; przyjaciółka", None, None),
            ("제", "mój (grzecznie)", None, "저 (ja) + 의 (czyj?) = 제: mój."),
            ("이름", "imię", None, None),
            ("이름이", "imię (podmiot)", None, "이 to partykuła podmiotu po spółgłosce. Po samogłosce: 가."),
            ("뭐예요", "co to jest?", None, "뭐 (co) + 예요 (jest)."),
            ("이", "ten; ta; to", None, "Stoi przed rzeczownikiem, jak polskie „ten”."),
            ("누구예요", "kto to jest?", None, "누구 (kto) + 예요."),
            ("엄마예요", "to mama", None, "Po samogłosce 예요, po spółgłosce 이에요."),
            ("아빠예요", "to tata", None, None),
            ("친구예요", "to przyjaciel", None, None),
        ],
        "sentences": [
            (["이름이", "뭐예요", "?"], "Jak masz na imię?", {}),
            (["이", "사람", "누구예요", "?"], "Kto to jest?", {}),
            (["제", "엄마예요"], "To moja mama.", {"아빠예요": "아빠 to tata. Mama: 엄마."}),
            (["제", "친구예요"], "To mój przyjaciel.", {}),
            (["제", "아빠예요"], "To mój tata.", {"엄마예요": "엄마 to mama. Tata: 아빠."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "하", "track": "jezyk",
        "words": [
            ("하나", "jeden", None, None),
            ("둘", "dwa", None, None),
            ("셋", "trzy", None, None),
            ("넷", "cztery", None, None),
            ("다섯", "pięć", None, None),
            ("여섯", "sześć", None, None),
            ("일곱", "siedem", None, None),
            ("여덟", "osiem", None, None),
            ("아홉", "dziewięć", None, None),
            ("열", "dziesięć", None, None),
            ("한", "jeden (przed licznikiem)", None, "하나 skraca się przed licznikiem: 한 개 = jedna sztuka."),
            ("두", "dwa (przed licznikiem)", None, "둘 → 두 przed licznikiem."),
            ("세", "trzy (przed licznikiem)", None, "셋 → 세 przed licznikiem."),
            ("개", "sztuka (licznik)", None, "Koreański liczy rzeczy z „licznikiem”, jak polskie „trzy sztuki”."),
            ("사과", "jabłko", None, None),
            ("사과가", "jabłko (podmiot)", None, "Po samogłosce partykuła podmiotu to 가."),
            ("있어요", "jest; są; mam", None, "있다 = istnieć, mieć. ㅆ na końcu przechodzi do następnej sylaby: isseoyo."),
        ],
        "sentences": [
            (["하나", ",", "둘", ",", "셋"], "Raz, dwa, trzy.", {}),
            (["사과", "두", "개"], "Dwa jabłka.", {"둘": "Przed licznikiem 둘 skraca się do 두."}),
            (["사과가", "세", "개", "있어요"], "Są trzy jabłka.", {"셋": "Przed licznikiem 셋 skraca się do 세."}),
            (["사과", "한", "개"], "Jedno jabłko.", {"하나": "Przed licznikiem 하나 skraca się do 한."}),
        ],
    },
    {
        "id": "jedzenie", "title": "Jedzenie", "icon": "밥", "track": "jezyk",
        "words": [
            ("밥", "ryż; posiłek", None, "밥 to i ryż, i posiłek w ogóle."),
            ("물", "woda", None, None),
            ("김치", "kimchi", "kimchi", "Kiszona kapusta z papryką: koreański odpowiednik kiszonek."),
            ("커피", "kawa", "kawa", "Z angielskiego coffee."),
            ("우유", "mleko", None, None),
            ("빵", "chleb", None, "Z portugalskiego pão."),
            ("뭐", "co", None, None),
            ("먹어요", "jem; je", None, "먹다 = jeść. -어요 to grzeczna końcówka."),
            ("마셔요", "piję; pije", None, None),
            ("좋아해요", "lubię; lubi", None, "ㅎ między samogłoskami prawie znika: czytaj „joahaeyo”."),
            ("밥을", "ryż (dopełnienie)", None, "을 to partykuła dopełnienia po spółgłosce."),
            ("물을", "wodę", None, None),
            ("커피를", "kawę", None, "Po samogłosce partykuła dopełnienia to 를."),
            ("김치를", "kimchi (dopełnienie)", None, None),
            ("맛있어요", "jest pyszne", None, "맛 (smak) + 있어요 (jest): dosłownie „ma smak”."),
        ],
        "sentences": [
            (["저는", "밥을", "먹어요"], "Jem ryż.", {"밥": "Co jem? Dopełnienie z partykułą: 밥을."}),
            (["물을", "마셔요"], "Piję wodę.", {"먹어요": "먹어요 to „jem”. Piję: 마셔요."}),
            (["커피를", "좋아해요"], "Lubię kawę.", {"커피": "Co lubię? Dopełnienie: 커피를."}),
            (["김치", "맛있어요"], "Kimchi jest pyszne.", {}),
            (["뭐", "먹어요", "?"], "Co jesz?", {"마셔요": "마셔요 to „piję”. Jesz: 먹어요."}),
        ],
    },
    {
        "id": "czasowniki", "title": "Czasowniki", "icon": "가", "track": "jezyk",
        "words": [
            ("가요", "idę; jadę", None, "가다 = iść. Ta sama forma dla ja, ty, on: osobę mówi kontekst."),
            ("와요", "przychodzę; przychodzi", None, None),
            ("해요", "robię; robi", None, "하다 = robić."),
            ("공부해요", "uczę się", None, "공부 (nauka) + 해요 (robię)."),
            ("일해요", "pracuję", None, "일 (praca) + 해요."),
            ("학교", "szkoła", None, None),
            ("집", "dom", None, None),
            ("어디에", "dokąd; gdzie", None, "어디 (gdzie) + 에 (do, w)."),
            ("학교에", "do szkoły; w szkole", None, "에 znaczy „do” i „w”, jak polskie „w” z biernikiem i miejscownikiem."),
            ("집에", "do domu; w domu", None, None),
            ("한국어를", "koreański (dopełnienie)", None, "한국어 = język koreański: 한국 (Korea) + 어 (język)."),
        ],
        "sentences": [
            (["뭐", "해요", "?"], "Co robisz?", {"가요": "가요 to „idę”. Robisz: 해요."}),
            (["학교에", "가요"], "Idę do szkoły.", {"와요": "와요 to „przychodzę”. Idę: 가요."}),
            (["어디에", "가요", "?"], "Dokąd idziesz?", {}),
            (["한국어를", "공부해요"], "Uczę się koreańskiego.", {"일해요": "일해요 to „pracuję”. Uczę się: 공부해요."}),
            (["집에", "가요"], "Idę do domu.", {}),
        ],
    },
    {
        "id": "czastki", "title": "Też i nie", "icon": "도", "track": "jezyk",
        "words": [
            ("나", "ja (do przyjaciół)", None, None),
            ("너", "ty (do przyjaciół)", None, "Do obcych zamiast „ty” mówi się imię albo tytuł, np. 선생님."),
            ("이거", "to (ta rzecz)", None, "이 (ten) + 거 (rzecz)."),
            ("책", "książka", None, None),
            ("책이에요", "to książka", None, None),
            ("좋아요", "dobrze; jest dobre", None, "ㅎ między samogłoskami znika: czytaj „joayo”."),
            ("싫어요", "nie chcę; nie lubię", None, None),
            ("저도", "ja też", None, "도 = też. Zastępuje partykułę 는: 저는 → 저도."),
            ("안", "nie (przed czasownikiem)", None, "안 + czasownik = przeczenie: 안 가요 = nie idę."),
        ],
        "sentences": [
            (["이거", "뭐예요", "?"], "Co to jest?", {}),
            (["책이에요"], "To książka.", {}),
            (["저도", "학생이에요"], "Ja też jestem studentem.", {"저는": "„Też” to 도, zamiast 는: 저도."}),
            (["안", "가요"], "Nie idę.", {"아니요": "아니요 to odpowiedź „nie”. Przed czasownikiem: 안."}),
            (["김치", "좋아요"], "Lubię kimchi.", {"싫어요": "싫어요 to „nie lubię”."}),
        ],
    },
    {
        "id": "przeszly", "title": "Czas przeszły", "icon": "었", "track": "jezyk",
        "words": [
            ("갔어요", "poszedłem; poszedł", None, "가 + 았어요 → 갔어요."),
            ("먹었어요", "zjadłem; zjadł", None, "먹 + 었어요."),
            ("했어요", "zrobiłem; zrobił", None, "하다 → 했어요."),
            ("공부했어요", "uczyłem się", None, None),
            ("마셨어요", "wypiłem", None, None),
            ("어제", "wczoraj", None, None),
            ("오늘", "dzisiaj", None, None),
            ("내일", "jutro", None, None),
        ],
        "sentences": [
            (["어제", "학교에", "갔어요"], "Wczoraj poszedłem do szkoły.", {"가요": "Wczoraj: czas przeszły 갔어요."}),
            (["오늘", "김치를", "먹었어요"], "Dziś zjadłem kimchi.", {"먹어요": "Już zjadłeś: 먹었어요."}),
            (["어제", "한국어를", "공부했어요"], "Wczoraj uczyłem się koreańskiego.",
             {"공부해요": "Wczoraj: 공부했어요."}),
            (["내일", "집에", "가요"], "Jutro jadę do domu.", {"갔어요": "Jutro: wystarczy czas teraźniejszy 가요."}),
            (["뭐", "했어요", "?"], "Co robiłeś?", {"해요": "Pytanie o przeszłość: 했어요."}),
        ],
    },
]

TRACKS = {
    "pismo": "한글 · PISMO",
    "jezyk": "한국어 · JĘZYK",
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "hangul4": [
        {"title": "Samogłoska z drugą samogłoską",
         "text": "Złożone samogłoski to dwie proste obok siebie: ㅗ + ㅐ = ㅙ [wɛ]. ㅐ i ㅔ brzmią dziś prawie tak samo, "
                 "dlatego w piśmie łatwo je pomylić. Ćwicz je na słowach: 왜 (dlaczego), 위 (góra).",
         "chain": []},
    ],
    "sylaby1": [
        {"title": "Sylaba to kwadrat",
         "text": "Litery nie stoją w rzędzie, tylko składają się w kwadrat. Samogłoski pionowe (ㅏ ㅓ ㅣ) stają po prawej "
                 "stronie spółgłoski: ㄱ + ㅏ = 가. Poziome (ㅗ ㅜ ㅡ) stają pod nią: ㄱ + ㅗ = 고. "
                 "Czytasz od góry do dołu i od lewej do prawej.",
         "chain": []},
    ],
    "patchim1": [
        {"title": "Spółgłoska na dole",
         "text": "Trzecia, dolna litera sylaby to patchim (받침, „podpora”). ㄴ, ㅁ, ㅇ, ㄹ czytasz na końcu "
                 "wyraźnie: 안 [an], 밤 [pam], 강 [kaŋ], 말 [mal]. ㅇ na dole to [ŋ] jak w „bank”, a na górze jest niema.",
         "chain": []},
    ],
    "patchim2": [
        {"title": "Siedem dźwięków na końcu",
         "text": "Na końcu sylaby koreański ma tylko siedem dźwięków: [k̚ n t̚ l m p̚ ŋ]. Dlatego różne litery brzmią tak samo: "
                 "ㅅ, ㅈ, ㅊ, ㅌ, ㅎ, ㅆ i ㄷ na dole to wszystkie [t̚]. Opadają „niewybuchowo”, bez wydechu. "
                 "Dopiero przed samogłoską (옷이) znów słychać, o którą literę chodzi.",
         "chain": []},
    ],
    "patchim3": [
        {"title": "Dwie litery, jeden dźwięk",
         "text": "Pod sylabą mogą stać dwie spółgłoski, ale zwykle czytasz tylko jedną: 닭 [tak̚], 많 [man], 없 [ʌp̚]. "
                 "Gdy dalej jest samogłoska, druga litera przechodzi do niej: 읽어요 [il.gʌ.jo], 없어요 [ʌp̚.sʌ.jo].",
         "chain": []},
    ],
    "hangul1": [
        {"title": "Alfabet zaprojektowany od zera",
         "text": "Hangul ułożył król Sejong w 1443 roku, żeby każdy mógł nauczyć się czytać w kilka dni. "
                 "Kształty spółgłosek pokazują, jak układają się usta: ㄱ to język przy podniebieniu, "
                 "ㄴ język przy zębach, ㅁ zamknięte usta. Litery składa się w kratki-sylaby: ㅎ + ㅏ + ㄴ = 한.",
         "chain": []},
    ],
    "hangul2": [
        {"title": "Samogłoski z kreski i kropki",
         "text": "Samogłoski zbudowano z trzech znaków: pionowej kreski (człowiek), poziomej (ziemia) i kropki "
                 "(niebo), z której dziś zrobiła się krótka kreska. ㅏ, ㅓ, ㅗ, ㅜ różnią się tylko jej "
                 "położeniem. Podwójna kreska dodaje j: ㅏ → ㅑ (ja), ㅗ → ㅛ (jo). Samogłoska nigdy nie stoi "
                 "sama: na początku sylaby pisze się przed nią niemą ㅇ: 아.",
         "chain": []},
    ],
    "hangul3": [
        {"title": "Trzy rodzaje k",
         "text": "Polski odróżnia k i g. Koreański odróżnia trzy inne: ㄱ (zwykłe), ㅋ (z wydechem) i ㄲ "
                 "(napięte, bez wydechu). 가, 카 i 까 to trzy różne sylaby. Tak samo t (ㄷ ㅌ ㄸ), p (ㅂ ㅍ ㅃ) "
                 "i ć (ㅈ ㅊ ㅉ). Dodatkowa kreska = wydech, podwójna litera = napięcie.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Partykuły jak polskie końcówki",
         "text": "Po polsku rolę słowa mówi końcówka: Ala, Alę, Ali. Po koreańsku robi to partykuła "
                 "doklejona do słowa: 저는 = „ja” jako temat zdania. Koreański, jak polski, nie ma "
                 "rodzajników. A czasownik zawsze stoi na końcu.",
         "chain": [
             ("Jestem studentem.", ["저는", "학생이에요"], "저는 (ja) + 학생이에요 (jestem studentem)."),
             ("Jestem Polakiem.", ["저는", "폴란드", "사람이에요"], "Polak to „człowiek z Polski”: 폴란드 사람."),
         ]},
        {"title": "네 to „tak”",
         "text": "Najczęstsza pułapka dla Polaków: 네 (ne) znaczy „tak”, a „nie” to 아니요. "
                 "네 słychać w Korei co chwilę: to też „słucham”, „aha”, „zgoda”.",
         "chain": [("Tak, dziękuję.", ["네", ",", "감사합니다"], "네 = tak.")]},
    ],
    "rodzina": [
        {"title": "Po samogłosce, po spółgłosce",
         "text": "Prawie każda partykuła ma dwie formy, jak polskie „w” i „we”: jedną po samogłosce, drugą po "
                 "spółgłosce. „Jest” to 예요 po samogłosce (엄마예요) i 이에요 po spółgłosce (학생이에요). "
                 "Ułatwia to wymowę: nie zbiegają się dwie samogłoski.",
         "chain": [
             ("To moja mama.", ["제", "엄마예요"], "제 (mój) + 엄마 + 예요 (po samogłosce)."),
             ("Jak masz na imię?", ["이름이", "뭐예요", "?"], "이름이 (imię) + 뭐예요 (co jest?)."),
         ]},
    ],
    "liczby": [
        {"title": "Dwa zestawy liczb",
         "text": "Koreański ma liczby rodzime (하나, 둘, 셋…) i chińsko-koreańskie (일, 이, 삼…). Rodzimych "
                 "używa się do liczenia rzeczy i wieku, chińskich do dat, pieniędzy i numerów. Przy liczeniu "
                 "rzeczy potrzebny jest licznik, jak polskie „trzy sztuki”: 사과 세 개 = jabłka trzy sztuki.",
         "chain": [("Dwa jabłka.", ["사과", "두", "개"], "rzecz + liczba + 개 (sztuka). 둘 skraca się do 두.")]},
    ],
    "jedzenie": [
        {"title": "Ja ryż jem",
         "text": "Koreański szyk to: kto, co, czasownik. „Jem ryż” brzmi „ja ryż jem”: 저는 밥을 먹어요. "
                 "Po polsku też możesz tak powiedzieć, bo końcówki pokazują role. Po koreańsku robią to "
                 "partykuły: 을/를 oznacza „co?”, tak jak polski biernik.",
         "chain": [
             ("Jem ryż.", ["저는", "밥을", "먹어요"], "저는 (ja) + 밥을 (ryż, biernik) + 먹어요 (jem)."),
             ("Lubię kawę.", ["커피를", "좋아해요"], "Po samogłosce 를."),
         ]},
    ],
    "czasowniki": [
        {"title": "Jedna forma dla wszystkich",
         "text": "Polski czasownik ma osobne formy: idę, idziesz, idzie. Koreański ma jedną: 가요. "
                 "Kto idzie, wynika z rozmowy, a 저 (ja) czy 친구 (przyjaciel) dodaje się tylko w razie "
                 "potrzeby. Końcówka -요 nie oznacza osoby, tylko grzeczność.",
         "chain": [
             ("Idę do szkoły.", ["학교에", "가요"], "학교에 (do szkoły) + 가요 (idę)."),
             ("Uczę się koreańskiego.", ["한국어를", "공부해요"], "공부 (nauka) + 해요 (robię)."),
         ]},
    ],
    "czastki": [
        {"title": "도 = też, 안 = nie",
         "text": "도 zastępuje 는 i znaczy „też”: 저도 = ja też. Przeczenie robi się prosto: 안 przed "
                 "czasownikiem, jak polskie „nie”: 안 가요 = nie idę.",
         "chain": [("Ja też jestem studentem.", ["저도", "학생이에요"], "저 + 도 (też).")]},
    ],
    "przeszly": [
        {"title": "-었- to przeszłość",
         "text": "Czas przeszły wstawia się przed -요: 먹어요 (jem) → 먹었어요 (zjadłem). Po ㅏ i ㅗ jest "
                 "-았-, a samogłoski często się zlewają: 가 + 았어요 = 갔어요. 해요 zmienia się w 했어요.",
         "chain": [
             ("Dziś zjadłem kimchi.", ["오늘", "김치를", "먹었어요"], "오늘 (dziś) + 김치를 + 먹었어요."),
             ("Wczoraj poszedłem do szkoły.", ["어제", "학교에", "갔어요"], "어제 (wczoraj) + 갔어요."),
         ]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Partykuła zależy od głoski",
    "text": "Patrz na koniec słowa. Kończy się spółgłoską (밥, 학생)? Wtedy 은, 이, 을, 이에요. "
            "Samogłoską (저, 커피)? Wtedy 는, 가, 를, 예요. Jak polskie „w domu” i „we wsi”.",
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("", "저", "는", " 학생이에요", ["은", "는", "이", "가"], "ja jestem studentem", "Temat po samogłosce: 는.", "slowa"),
    ("", "선생님", "은", " 한국 사람이에요", ["은", "는", "을", "를"], "nauczyciel jest Koreańczykiem",
     "Temat po spółgłosce: 은.", "slowa"),
    ("저는 ", "학생", "이에요", "", ["이에요", "예요", "이", "가"], "jestem studentem", "Po spółgłosce: 이에요.", "slowa"),
    ("제 ", "친구", "예요", "", ["이에요", "예요", "을", "는"], "to mój przyjaciel", "Po samogłosce: 예요.", "rodzina"),
    ("", "이름", "이", " 뭐예요?", ["이", "가", "을", "를"], "jak masz na imię?", "Podmiot po spółgłosce: 이.", "rodzina"),
    ("", "사과", "가", " 세 개 있어요", ["이", "가", "을", "를"], "są trzy jabłka", "Podmiot po samogłosce: 가.", "liczby"),
    ("", "밥", "을", " 먹어요", ["을", "를", "이", "가"], "jem ryż", "Dopełnienie po spółgłosce: 을.", "jedzenie"),
    ("", "커피", "를", " 좋아해요", ["을", "를", "은", "는"], "lubię kawę", "Dopełnienie po samogłosce: 를.", "jedzenie"),
    ("", "학교", "에", " 가요", ["에", "을", "는", "가"], "idę do szkoły", "Dokąd? 에.", "czasowniki"),
    ("", "저", "도", " 학생이에요", ["도", "는", "를", "가"], "ja też jestem studentem", "„Też”: 도.", "czastki"),
    ("어제 김치를 ", "먹", "었어요", "", ["어요", "었어요", "을", "는"], "wczoraj zjadłem kimchi",
     "Przeszłość: -었어요.", "przeszly"),
    ("오늘 김치를 ", "먹", "어요", "", ["어요", "었어요", "을", "는"], "dziś jem kimchi", "Teraz: -어요.", "przeszly"),
]

# Kolorem wyróżniamy partykuły w ćwiczeniach z końcówkami (zob. ui.py); pole zostaje dla zgodności.
LONG_VOWELS = ""

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "spotkanie", "title": "Pierwsze spotkanie", "partner": "Minjun", "avatar": "민", "requires": "slowa",
        "turns": [
            {"bot": ["안녕하세요", "!"], "en": "Dzień dobry!",
             "options": [(["안녕하세요", "!"], True, None),
                         (["감사합니다", "!"], False, "감사합니다 to „dziękuję”. Najpierw się przywitaj.")]},
            {"bot": ["학생이에요", "?"], "en": "Jesteś studentem?", "note": "Uwaga: 네 znaczy „tak”!",
             "options": [(["네", ",", "저는", "학생이에요"], True, None),
                         (["아니요", ",", "저는", "학생이에요"], False, "아니요 to „nie”, a potwierdzasz. Tak: 네.")]},
            {"bot": ["한국", "사람이에요", "?"], "en": "Jesteś Koreańczykiem?",
             "build": (["아니요", ",", "저는", "폴란드", "사람이에요"], "Nie, jestem Polakiem.")},
        ],
    },
    {
        "id": "rodzina", "title": "Zdjęcia rodzinne", "partner": "Jiyeon", "avatar": "지", "requires": "rodzina",
        "turns": [
            {"bot": ["이", "사람", "누구예요", "?"], "en": "Kto to jest?",
             "options": [(["제", "엄마예요"], True, None),
                         (["이름이", "뭐예요", "?"], False, "To pytanie o imię. Odpowiedz, kto to jest: 제 엄마예요.")]},
            {"bot": ["친구예요", "?"], "en": "To twój przyjaciel?",
             "options": [(["네", ",", "제", "친구예요"], True, None),
                         (["네", ",", "제", "아빠예요"], False, "아빠 to tata. Przyjaciel: 친구.")]},
        ],
    },
    {
        "id": "kawiarnia", "title": "W kawiarni", "partner": "Barista", "avatar": "카", "requires": "jedzenie",
        "turns": [
            {"bot": ["뭐", "마셔요", "?"], "en": "Co pijesz?",
             "options": [(["커피를", "마셔요"], True, None),
                         (["커피를", "먹어요"], False, "먹어요 to „jem”. Kawę się pije: 마셔요.")]},
            {"bot": ["김치", "맛있어요", "?"], "en": "Kimchi smakuje?",
             "options": [(["네", ",", "맛있어요"], True, None),
                         (["아니요", ",", "맛있어요"], False, "아니요 to „nie”, a mówisz, że jest pyszne. Tak: 네.")]},
            {"bot": ["감사합니다", "!"], "en": "Dziękuję!", "build": (["감사합니다"], "Dziękuję.")},
        ],
    },
    {
        "id": "plany", "title": "Wczoraj i jutro", "partner": "Seojun", "avatar": "서", "requires": "przeszly",
        "turns": [
            {"bot": ["어제", "뭐", "했어요", "?"], "en": "Co robiłeś wczoraj?",
             "options": [(["한국어를", "공부했어요"], True, None),
                         (["한국어를", "공부해요"], False, "Pytanie o wczoraj: czas przeszły 공부했어요.")]},
            {"bot": ["내일", "어디에", "가요", "?"], "en": "Dokąd jutro idziesz?",
             "build": (["내일", "학교에", "가요"], "Jutro idę do szkoły.")},
        ],
    },
]

CHAT_EXTRA = {}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Gramatyka. PITFALLS: typowe trudności uczących się, (tytuł, opis).
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------
PITFALLS = [
    ('Trzy serie spółgłosek', 'Koreański odróżnia spółgłoskę zwykłą, przydechową i napiętą: ㄱ, ㅋ, ㄲ; ㄷ, ㅌ, ㄸ; ㅂ, ㅍ, ㅃ. Polskie ucho słyszy je jako jedno k, t, p.'),
    ('Samogłoski ㅓ i ㅗ, ㅡ i ㅜ', 'ㅓ to otwarte o, ㅗ zaokrąglone o; ㅡ to u bez zaokrąglenia ust, ㅜ zwykłe u. Pomyłka zmienia słowo.'),
    ('Spółgłoska na końcu sylaby', 'Na końcu sylaby (batchim) wiele spółgłosek brzmi tak samo, a przed następną sylabą zmienia się lub przechodzi do niej: 한국어 czyta się han-gu-geo.'),
    ('Partykuły zależą od końca słowa', 'Po spółgłosce: 은, 이, 을; po samogłosce: 는, 가, 를. Temat (은/는) i podmiot (이/가) to dwie różne rzeczy.'),
    ('Poziomy grzeczności', 'Końcówka czasownika zależy od tego, do kogo mówisz: 가요 (grzecznie), 갑니다 (oficjalnie), 가 (do bliskich).'),
]

PARADIGM_LABELS = {
    't_part': ['책 (temat)', '나 (temat)', '물 (dopełnienie)', '커피 (dopełnienie)', '집 (podmiot)', '친구 (podmiot)'],
}

PARADIGMS = [
    ('form', 'Typowe trudności', 'Partykuła po spółgłosce czy samogłosce?', 't_part', '책은; 나는; 물을; 커피를; 집이; 친구가', None),
]

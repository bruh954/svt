"""Treść kursu: język koreański dla Polaków.

Słowo:     (forma hangulem, znaczenie po polsku, polski krewny lub None, skojarzenie lub None)
Litera:    (litera hangulu, wymowa w IPA z krótką podpowiedzią, przykładowa sylaba)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie, dział)

Koreański dokleja partykuły do słów (저는, 밥을), więc słowa w kursie to całe „klocki” z partykułą.
Transkrypcja (pole „tr”) powstaje automatycznie w engine.py według oficjalnej latynizacji
(Revised Romanization): 안녕하세요 → annyeonghaseyo.
"""

UNITS = [
    # --------------------------------------------------------------- hangul
    {
        "id": "hangul1", "title": "Hangul I", "icon": "ㄱ", "track": "pismo",
        "letters": [
            ("ㄱ", "[k], między samogłoskami [ɡ]", "가"),
            ("ㄴ", "[n]", "나"),
            ("ㄷ", "[t], między samogłoskami [d]", "다"),
            ("ㄹ", "[ɾ] (krótkie r), na końcu sylaby [l]", "라"),
            ("ㅁ", "[m]", "마"),
            ("ㅂ", "[p], między samogłoskami [b]", "바"),
            ("ㅅ", "[s], przed ㅣ [ɕ] (polskie ś)", "사"),
            ("ㅇ", "na początku sylaby niema, na końcu [ŋ]", "아"),
            ("ㅈ", "[tɕ], między samogłoskami [dʑ] (ć / dź)", "자"),
            ("ㅎ", "[h]", "하"),
        ],
    },
    {
        "id": "hangul2", "title": "Hangul II", "icon": "ㅏ", "track": "pismo",
        "letters": [
            ("ㅏ", "[a]", "아"),
            ("ㅓ", "[ʌ] (otwarte o bez zaokrąglania warg)", "어"),
            ("ㅗ", "[o]", "오"),
            ("ㅜ", "[u]", "우"),
            ("ㅡ", "[ɯ] (u z rozciągniętymi wargami)", "으"),
            ("ㅣ", "[i]", "이"),
            ("ㅐ", "[ɛ]", "애"),
            ("ㅔ", "[e]", "에"),
            ("ㅑ", "[ja]", "야"),
            ("ㅕ", "[jʌ]", "여"),
            ("ㅛ", "[jo]", "요"),
            ("ㅠ", "[ju]", "유"),
        ],
    },
    {
        "id": "hangul3", "title": "Hangul III", "icon": "ㄲ", "track": "pismo",
        "letters": [
            ("ㅊ", "[tɕʰ] (ć z wydechem)", "차"),
            ("ㅋ", "[kʰ] (k z wydechem)", "카"),
            ("ㅌ", "[tʰ] (t z wydechem)", "타"),
            ("ㅍ", "[pʰ] (p z wydechem)", "파"),
            ("ㄲ", "[k͈] (napięte k, bez wydechu)", "까"),
            ("ㄸ", "[t͈] (napięte t)", "따"),
            ("ㅃ", "[p͈] (napięte p)", "빠"),
            ("ㅆ", "[s͈] (napięte s)", "싸"),
            ("ㅉ", "[t͈ɕ] (napięte ć)", "짜"),
            ("ㅘ", "[wa]", "와"),
            ("ㅝ", "[wʌ]", "워"),
            ("ㅢ", "[ɰi]", "의"),
        ],
    },
    {
        "id": 'hangul4', "title": 'Hangul IV: samogłoski złożone', "icon": 'ㅒ', "track": "pismo",
        "letters": [
            ('ㅒ', '[jɛ]', '얘기'),
            ('ㅖ', '[je]', '예'),
            ('ㅙ', '[wɛ]', '왜'),
            ('ㅞ', '[we]', '웨이터'),
            ('ㅚ', '[we] (oe)', '외국'),
            ('ㅟ', '[wi]', '위'),
        ],
    },
    {
        "id": 'sylaby1', "title": 'Sylaby I: ㅏ i ㅓ', "icon": '가', "track": "pismo",
        "letters": [
            ('가', '[ka] (ga)', '가방'),
            ('거', '[kʌ] (geo)', '거리'),
            ('나', '[na] (na)', '나라'),
            ('너', '[nʌ] (neo)', '너무'),
            ('다', '[ta] (da)', '다리'),
            ('더', '[tʌ] (deo)', '더워요'),
            ('라', '[ɾa] (ra)', '라면'),
            ('러', '[ɾʌ] (reo)', '러시아'),
            ('마', '[ma] (ma)', '마음'),
            ('머', '[mʌ] (meo)', '머리'),
            ('바', '[pa] (ba)', '바다'),
            ('버', '[pʌ] (beo)', '버스'),
        ],
    },
    {
        "id": 'sylaby2', "title": 'Sylaby II: ㅏ i ㅓ', "icon": '사', "track": "pismo",
        "letters": [
            ('사', '[sa] (sa)', '사과'),
            ('서', '[sʌ] (seo)', '서울'),
            ('아', '[a] (a)', '아기'),
            ('어', '[ʌ] (eo)', '어머니'),
            ('자', '[tɕa] (ja)', '자동차'),
            ('저', '[tɕʌ] (jeo)', '저녁'),
            ('하', '[ha] (ha)', '하나'),
            ('허', '[hʌ] (heo)', '허리'),
            ('차', '[tɕʰa] (cha)', '차'),
            ('처', '[tɕʰʌ] (cheo)', '처음'),
            ('카', '[kʰa] (ka)', '카메라'),
            ('커', '[kʰʌ] (keo)', '커피'),
        ],
    },
    {
        "id": 'sylaby3', "title": 'Sylaby III: ㅗ i ㅜ', "icon": '고', "track": "pismo",
        "letters": [
            ('고', '[ko] (go)', '고기'),
            ('구', '[ku] (gu)', '구두'),
            ('노', '[no] (no)', '노래'),
            ('누', '[nu] (nu)', '누나'),
            ('도', '[to] (do)', '도시'),
            ('두', '[tu] (du)', '두부'),
            ('로', '[ɾo] (ro)', '로봇'),
            ('루', '[ɾu] (ru)', '루비'),
            ('모', '[mo] (mo)', '모자'),
            ('무', '[mu] (mu)', '무게'),
            ('보', '[po] (bo)', '보리'),
            ('부', '[pu] (bu)', '부모'),
        ],
    },
    {
        "id": 'sylaby4', "title": 'Sylaby IV: ㅗ ㅜ ㅡ ㅣ', "icon": '소', "track": "pismo",
        "letters": [
            ('소', '[so] (so)', '소리'),
            ('수', '[su] (su)', '수박'),
            ('오', '[o] (o)', '오이'),
            ('우', '[u] (u)', '우유'),
            ('조', '[tɕo] (jo)', '조용'),
            ('주', '[tɕu] (ju)', '주스'),
            ('호', '[ho] (ho)', '호수'),
            ('후', '[hu] (hu)', '후추'),
            ('으', '[ɯ] (eu)', '음악'),
            ('이', '[i] (i)', '이마'),
            ('그', '[kɯ] (geu)', '그림'),
            ('기', '[ki] (gi)', '기차'),
        ],
    },
    {
        "id": 'patchim1', "title": 'Patchim I: ㄴ ㅁ ㅇ ㄹ', "icon": '안', "track": "pismo",
        "letters": [
            ('안', '[an]', '안녕'),
            ('산', '[san]', '산'),
            ('문', '[mun]', '문'),
            ('밤', '[pam]', '밤'),
            ('곰', '[kom]', '곰'),
            ('강', '[kaŋ]', '강'),
            ('공', '[koŋ]', '공'),
            ('말', '[mal]', '말'),
            ('물', '[mul]', '물'),
            ('달', '[tal]', '달'),
            ('한', '[han]', '한국'),
            ('방', '[paŋ]', '방'),
        ],
    },
    {
        "id": 'patchim2', "title": 'Patchim II: ㄱ ㅂ ㅅ ㅌ', "icon": '책', "track": "pismo",
        "letters": [
            ('책', '[tɕʰɛk̚]', '책'),
            ('목', '[mok̚]', '목'),
            ('국', '[kuk̚]', '국'),
            ('밖', '[pak̚]', '밖'),
            ('집', '[tɕip̚]', '집'),
            ('밥', '[pap̚]', '밥'),
            ('입', '[ip̚]', '입'),
            ('옷', '[ot̚]', '옷'),
            ('낮', '[nat̚]', '낮'),
            ('꽃', '[k͈ot̚]', '꽃'),
            ('있', '[it̚]', '있어요'),
            ('앞', '[ap̚]', '앞'),
        ],
    },
    {
        "id": 'patchim3', "title": 'Patchim III: podwójne', "icon": '닭', "track": "pismo",
        "letters": [
            ('닭', '[tak̚]', '닭'),
            ('읽', '[ik̚]', '읽어요'),
            ('앉', '[an]', '앉아요'),
            ('많', '[man]', '많아요'),
            ('없', '[ʌp̚]', '없어요'),
            ('값', '[kap̚]', '값'),
            ('넓', '[nʌl]', '넓어요'),
            ('삶', '[sam]', '삶'),
            ('젊', '[tɕʌm]', '젊어요'),
            ('흙', '[hɯk̚]', '흙'),
        ],
    },
    # ---------------------------------------------------------------- język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "안", "track": "jezyk", "requires": "hangul2",
        "words": [
            ("안녕하세요", "dzień dobry; cześć", None, "Dosłownie „czy jest pan w spokoju?”. Pasuje o każdej porze dnia."),
            ("감사합니다", "dziękuję", None, "Grzeczna, oficjalna forma. 감사 to „wdzięczność”."),
            ("네", "tak", None, "Uwaga: 네 znaczy „tak”, choć brzmi jak polskie „nie”!"),
            ("아니요", "nie", None, None),
            ("저", "ja (grzecznie)", None, "Grzeczne „ja”. Do przyjaciół mówi się 나."),
            ("저는", "ja (jako temat)", None, "는 to partykuła tematu: „jeśli chodzi o mnie…”."),
            ("학생", "uczeń; student", None, None),
            ("학생이에요", "jestem studentem", None, "학생 + 이에요 (jest / jestem). Osobę mówi kontekst."),
            ("선생님", "nauczyciel", None, "님 to grzecznościowa końcówka, jak „pan” w „panie profesorze”."),
            ("선생님이에요", "to nauczyciel", None, None),
            ("한국", "Korea", None, None),
            ("폴란드", "Polska", "Polska", "Polska po koreańsku: pollandeu."),
            ("사람", "człowiek", None, None),
            ("사람이에요", "jestem (kimś); to człowiek", None, "사람 (człowiek) + 이에요. 폴란드 사람 = Polak."),
        ],
        "sentences": [
            (["안녕하세요", "!"], "Dzień dobry!", {"감사합니다": "감사합니다 to „dziękuję”."}),
            (["저는", "학생이에요"], "Jestem studentem.", {"선생님이에요": "선생님이에요 to „to nauczyciel”."}),
            (["저는", "폴란드", "사람이에요"], "Jestem Polakiem.", {"한국": "한국 to Korea. Polska: 폴란드."}),
            (["저는", "한국", "사람이에요"], "Jestem Koreańczykiem.", {"폴란드": "폴란드 to Polska. Korea: 한국."}),
            (["네", ",", "감사합니다"], "Tak, dziękuję.", {"아니요": "아니요 to „nie”. Tak: 네."}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "엄", "track": "jezyk",
        "words": [
            ("엄마", "mama", "mama", "Prawie jak polskie „mama”!"),
            ("아빠", "tata", "papa", None),
            ("가족", "rodzina", None, None),
            ("친구", "przyjaciel; przyjaciółka", None, None),
            ("제", "mój (grzecznie)", None, "저 (ja) + 의 (czyj?) = 제: mój."),
            ("이름", "imię", None, None),
            ("이름이", "imię (podmiot)", None, "이 to partykuła podmiotu po spółgłosce. Po samogłosce: 가."),
            ("뭐예요", "co to jest?", None, "뭐 (co) + 예요 (jest)."),
            ("이", "ten; ta; to", None, "Stoi przed rzeczownikiem, jak polskie „ten”."),
            ("누구예요", "kto to jest?", None, "누구 (kto) + 예요."),
            ("엄마예요", "to mama", None, "Po samogłosce 예요, po spółgłosce 이에요."),
            ("아빠예요", "to tata", None, None),
            ("친구예요", "to przyjaciel", None, None),
        ],
        "sentences": [
            (["이름이", "뭐예요", "?"], "Jak masz na imię?", {}),
            (["이", "사람", "누구예요", "?"], "Kto to jest?", {}),
            (["제", "엄마예요"], "To moja mama.", {"아빠예요": "아빠 to tata. Mama: 엄마."}),
            (["제", "친구예요"], "To mój przyjaciel.", {}),
            (["제", "아빠예요"], "To mój tata.", {"엄마예요": "엄마 to mama. Tata: 아빠."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "하", "track": "jezyk",
        "words": [
            ("하나", "jeden", None, None),
            ("둘", "dwa", None, None),
            ("셋", "trzy", None, None),
            ("넷", "cztery", None, None),
            ("다섯", "pięć", None, None),
            ("여섯", "sześć", None, None),
            ("일곱", "siedem", None, None),
            ("여덟", "osiem", None, None),
            ("아홉", "dziewięć", None, None),
            ("열", "dziesięć", None, None),
            ("한", "jeden (przed licznikiem)", None, "하나 skraca się przed licznikiem: 한 개 = jedna sztuka."),
            ("두", "dwa (przed licznikiem)", None, "둘 → 두 przed licznikiem."),
            ("세", "trzy (przed licznikiem)", None, "셋 → 세 przed licznikiem."),
            ("개", "sztuka (licznik)", None, "Koreański liczy rzeczy z „licznikiem”, jak polskie „trzy sztuki”."),
            ("사과", "jabłko", None, None),
            ("사과가", "jabłko (podmiot)", None, "Po samogłosce partykuła podmiotu to 가."),
            ("있어요", "jest; są; mam", None, "있다 = istnieć, mieć. ㅆ na końcu przechodzi do następnej sylaby: isseoyo."),
        ],
        "sentences": [
            (["하나", ",", "둘", ",", "셋"], "Raz, dwa, trzy.", {}),
            (["사과", "두", "개"], "Dwa jabłka.", {"둘": "Przed licznikiem 둘 skraca się do 두."}),
            (["사과가", "세", "개", "있어요"], "Są trzy jabłka.", {"셋": "Przed licznikiem 셋 skraca się do 세."}),
            (["사과", "한", "개"], "Jedno jabłko.", {"하나": "Przed licznikiem 하나 skraca się do 한."}),
        ],
    },
    {
        "id": "jedzenie", "title": "Jedzenie", "icon": "밥", "track": "jezyk",
        "words": [
            ("밥", "ryż; posiłek", None, "밥 to i ryż, i posiłek w ogóle."),
            ("물", "woda", None, None),
            ("김치", "kimchi", "kimchi", "Kiszona kapusta z papryką: koreański odpowiednik kiszonek."),
            ("커피", "kawa", "kawa", "Z angielskiego coffee."),
            ("우유", "mleko", None, None),
            ("빵", "chleb", None, "Z portugalskiego pão."),
            ("뭐", "co", None, None),
            ("먹어요", "jem; je", None, "먹다 = jeść. -어요 to grzeczna końcówka."),
            ("마셔요", "piję; pije", None, None),
            ("좋아해요", "lubię; lubi", None, "ㅎ między samogłoskami prawie znika: czytaj „joahaeyo”."),
            ("밥을", "ryż (dopełnienie)", None, "을 to partykuła dopełnienia po spółgłosce."),
            ("물을", "wodę", None, None),
            ("커피를", "kawę", None, "Po samogłosce partykuła dopełnienia to 를."),
            ("김치를", "kimchi (dopełnienie)", None, None),
            ("맛있어요", "jest pyszne", None, "맛 (smak) + 있어요 (jest): dosłownie „ma smak”."),
        ],
        "sentences": [
            (["저는", "밥을", "먹어요"], "Jem ryż.", {"밥": "Co jem? Dopełnienie z partykułą: 밥을."}),
            (["물을", "마셔요"], "Piję wodę.", {"먹어요": "먹어요 to „jem”. Piję: 마셔요."}),
            (["커피를", "좋아해요"], "Lubię kawę.", {"커피": "Co lubię? Dopełnienie: 커피를."}),
            (["김치", "맛있어요"], "Kimchi jest pyszne.", {}),
            (["뭐", "먹어요", "?"], "Co jesz?", {"마셔요": "마셔요 to „piję”. Jesz: 먹어요."}),
        ],
    },
    {
        "id": "czasowniki", "title": "Czasowniki", "icon": "가", "track": "jezyk",
        "words": [
            ("가요", "idę; jadę", None, "가다 = iść. Ta sama forma dla ja, ty, on: osobę mówi kontekst."),
            ("와요", "przychodzę; przychodzi", None, None),
            ("해요", "robię; robi", None, "하다 = robić."),
            ("공부해요", "uczę się", None, "공부 (nauka) + 해요 (robię)."),
            ("일해요", "pracuję", None, "일 (praca) + 해요."),
            ("학교", "szkoła", None, None),
            ("집", "dom", None, None),
            ("어디에", "dokąd; gdzie", None, "어디 (gdzie) + 에 (do, w)."),
            ("학교에", "do szkoły; w szkole", None, "에 znaczy „do” i „w”, jak polskie „w” z biernikiem i miejscownikiem."),
            ("집에", "do domu; w domu", None, None),
            ("한국어를", "koreański (dopełnienie)", None, "한국어 = język koreański: 한국 (Korea) + 어 (język)."),
        ],
        "sentences": [
            (["뭐", "해요", "?"], "Co robisz?", {"가요": "가요 to „idę”. Robisz: 해요."}),
            (["학교에", "가요"], "Idę do szkoły.", {"와요": "와요 to „przychodzę”. Idę: 가요."}),
            (["어디에", "가요", "?"], "Dokąd idziesz?", {}),
            (["한국어를", "공부해요"], "Uczę się koreańskiego.", {"일해요": "일해요 to „pracuję”. Uczę się: 공부해요."}),
            (["집에", "가요"], "Idę do domu.", {}),
        ],
    },
    {
        "id": "czastki", "title": "Też i nie", "icon": "도", "track": "jezyk",
        "words": [
            ("나", "ja (do przyjaciół)", None, None),
            ("너", "ty (do przyjaciół)", None, "Do obcych zamiast „ty” mówi się imię albo tytuł, np. 선생님."),
            ("이거", "to (ta rzecz)", None, "이 (ten) + 거 (rzecz)."),
            ("책", "książka", None, None),
            ("책이에요", "to książka", None, None),
            ("좋아요", "dobrze; jest dobre", None, "ㅎ między samogłoskami znika: czytaj „joayo”."),
            ("싫어요", "nie chcę; nie lubię", None, None),
            ("저도", "ja też", None, "도 = też. Zastępuje partykułę 는: 저는 → 저도."),
            ("안", "nie (przed czasownikiem)", None, "안 + czasownik = przeczenie: 안 가요 = nie idę."),
        ],
        "sentences": [
            (["이거", "뭐예요", "?"], "Co to jest?", {}),
            (["책이에요"], "To książka.", {}),
            (["저도", "학생이에요"], "Ja też jestem studentem.", {"저는": "„Też” to 도, zamiast 는: 저도."}),
            (["안", "가요"], "Nie idę.", {"아니요": "아니요 to odpowiedź „nie”. Przed czasownikiem: 안."}),
            (["김치", "좋아요"], "Lubię kimchi.", {"싫어요": "싫어요 to „nie lubię”."}),
        ],
    },
    {
        "id": "przeszly", "title": "Czas przeszły", "icon": "었", "track": "jezyk",
        "words": [
            ("갔어요", "poszedłem; poszedł", None, "가 + 았어요 → 갔어요."),
            ("먹었어요", "zjadłem; zjadł", None, "먹 + 었어요."),
            ("했어요", "zrobiłem; zrobił", None, "하다 → 했어요."),
            ("공부했어요", "uczyłem się", None, None),
            ("마셨어요", "wypiłem", None, None),
            ("어제", "wczoraj", None, None),
            ("오늘", "dzisiaj", None, None),
            ("내일", "jutro", None, None),
        ],
        "sentences": [
            (["어제", "학교에", "갔어요"], "Wczoraj poszedłem do szkoły.", {"가요": "Wczoraj: czas przeszły 갔어요."}),
            (["오늘", "김치를", "먹었어요"], "Dziś zjadłem kimchi.", {"먹어요": "Już zjadłeś: 먹었어요."}),
            (["어제", "한국어를", "공부했어요"], "Wczoraj uczyłem się koreańskiego.",
             {"공부해요": "Wczoraj: 공부했어요."}),
            (["내일", "집에", "가요"], "Jutro jadę do domu.", {"갔어요": "Jutro: wystarczy czas teraźniejszy 가요."}),
            (["뭐", "했어요", "?"], "Co robiłeś?", {"해요": "Pytanie o przeszłość: 했어요."}),
        ],
    },
]

TRACKS = {
    "pismo": "한글 · PISMO",
    "jezyk": "한국어 · JĘZYK",
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "hangul4": [
        {"title": "Samogłoska z drugą samogłoską",
         "text": "Złożone samogłoski to dwie proste obok siebie: ㅗ + ㅐ = ㅙ [wɛ]. ㅐ i ㅔ brzmią dziś prawie tak samo, "
                 "dlatego w piśmie łatwo je pomylić. Ćwicz je na słowach: 왜 (dlaczego), 위 (góra).",
         "chain": []},
    ],
    "sylaby1": [
        {"title": "Sylaba to kwadrat",
         "text": "Litery nie stoją w rzędzie, tylko składają się w kwadrat. Samogłoski pionowe (ㅏ ㅓ ㅣ) stają po prawej "
                 "stronie spółgłoski: ㄱ + ㅏ = 가. Poziome (ㅗ ㅜ ㅡ) stają pod nią: ㄱ + ㅗ = 고. "
                 "Czytasz od góry do dołu i od lewej do prawej.",
         "chain": []},
    ],
    "patchim1": [
        {"title": "Spółgłoska na dole",
         "text": "Trzecia, dolna litera sylaby to patchim (받침, „podpora”). ㄴ, ㅁ, ㅇ, ㄹ czytasz na końcu "
                 "wyraźnie: 안 [an], 밤 [pam], 강 [kaŋ], 말 [mal]. ㅇ na dole to [ŋ] jak w „bank”, a na górze jest niema.",
         "chain": []},
    ],
    "patchim2": [
        {"title": "Siedem dźwięków na końcu",
         "text": "Na końcu sylaby koreański ma tylko siedem dźwięków: [k̚ n t̚ l m p̚ ŋ]. Dlatego różne litery brzmią tak samo: "
                 "ㅅ, ㅈ, ㅊ, ㅌ, ㅎ, ㅆ i ㄷ na dole to wszystkie [t̚]. Opadają „niewybuchowo”, bez wydechu. "
                 "Dopiero przed samogłoską (옷이) znów słychać, o którą literę chodzi.",
         "chain": []},
    ],
    "patchim3": [
        {"title": "Dwie litery, jeden dźwięk",
         "text": "Pod sylabą mogą stać dwie spółgłoski, ale zwykle czytasz tylko jedną: 닭 [tak̚], 많 [man], 없 [ʌp̚]. "
                 "Gdy dalej jest samogłoska, druga litera przechodzi do niej: 읽어요 [il.gʌ.jo], 없어요 [ʌp̚.sʌ.jo].",
         "chain": []},
    ],
    "hangul1": [
        {"title": "Alfabet zaprojektowany od zera",
         "text": "Hangul ułożył król Sejong w 1443 roku, żeby każdy mógł nauczyć się czytać w kilka dni. "
                 "Kształty spółgłosek pokazują, jak układają się usta: ㄱ to język przy podniebieniu, "
                 "ㄴ język przy zębach, ㅁ zamknięte usta. Litery składa się w kratki-sylaby: ㅎ + ㅏ + ㄴ = 한.",
         "chain": []},
    ],
    "hangul2": [
        {"title": "Samogłoski z kreski i kropki",
         "text": "Samogłoski zbudowano z trzech znaków: pionowej kreski (człowiek), poziomej (ziemia) i kropki "
                 "(niebo), z której dziś zrobiła się krótka kreska. ㅏ, ㅓ, ㅗ, ㅜ różnią się tylko jej "
                 "położeniem. Podwójna kreska dodaje j: ㅏ → ㅑ (ja), ㅗ → ㅛ (jo). Samogłoska nigdy nie stoi "
                 "sama: na początku sylaby pisze się przed nią niemą ㅇ: 아.",
         "chain": []},
    ],
    "hangul3": [
        {"title": "Trzy rodzaje k",
         "text": "Polski odróżnia k i g. Koreański odróżnia trzy inne: ㄱ (zwykłe), ㅋ (z wydechem) i ㄲ "
                 "(napięte, bez wydechu). 가, 카 i 까 to trzy różne sylaby. Tak samo t (ㄷ ㅌ ㄸ), p (ㅂ ㅍ ㅃ) "
                 "i ć (ㅈ ㅊ ㅉ). Dodatkowa kreska = wydech, podwójna litera = napięcie.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Partykuły jak polskie końcówki",
         "text": "Po polsku rolę słowa mówi końcówka: Ala, Alę, Ali. Po koreańsku robi to partykuła "
                 "doklejona do słowa: 저는 = „ja” jako temat zdania. Koreański, jak polski, nie ma "
                 "rodzajników. A czasownik zawsze stoi na końcu.",
         "chain": [
             ("Jestem studentem.", ["저는", "학생이에요"], "저는 (ja) + 학생이에요 (jestem studentem)."),
             ("Jestem Polakiem.", ["저는", "폴란드", "사람이에요"], "Polak to „człowiek z Polski”: 폴란드 사람."),
         ]},
        {"title": "네 to „tak”",
         "text": "Najczęstsza pułapka dla Polaków: 네 (ne) znaczy „tak”, a „nie” to 아니요. "
                 "네 słychać w Korei co chwilę: to też „słucham”, „aha”, „zgoda”.",
         "chain": [("Tak, dziękuję.", ["네", ",", "감사합니다"], "네 = tak.")]},
    ],
    "rodzina": [
        {"title": "Po samogłosce, po spółgłosce",
         "text": "Prawie każda partykuła ma dwie formy, jak polskie „w” i „we”: jedną po samogłosce, drugą po "
                 "spółgłosce. „Jest” to 예요 po samogłosce (엄마예요) i 이에요 po spółgłosce (학생이에요). "
                 "Ułatwia to wymowę: nie zbiegają się dwie samogłoski.",
         "chain": [
             ("To moja mama.", ["제", "엄마예요"], "제 (mój) + 엄마 + 예요 (po samogłosce)."),
             ("Jak masz na imię?", ["이름이", "뭐예요", "?"], "이름이 (imię) + 뭐예요 (co jest?)."),
         ]},
    ],
    "liczby": [
        {"title": "Dwa zestawy liczb",
         "text": "Koreański ma liczby rodzime (하나, 둘, 셋…) i chińsko-koreańskie (일, 이, 삼…). Rodzimych "
                 "używa się do liczenia rzeczy i wieku, chińskich do dat, pieniędzy i numerów. Przy liczeniu "
                 "rzeczy potrzebny jest licznik, jak polskie „trzy sztuki”: 사과 세 개 = jabłka trzy sztuki.",
         "chain": [("Dwa jabłka.", ["사과", "두", "개"], "rzecz + liczba + 개 (sztuka). 둘 skraca się do 두.")]},
    ],
    "jedzenie": [
        {"title": "Ja ryż jem",
         "text": "Koreański szyk to: kto, co, czasownik. „Jem ryż” brzmi „ja ryż jem”: 저는 밥을 먹어요. "
                 "Po polsku też możesz tak powiedzieć, bo końcówki pokazują role. Po koreańsku robią to "
                 "partykuły: 을/를 oznacza „co?”, tak jak polski biernik.",
         "chain": [
             ("Jem ryż.", ["저는", "밥을", "먹어요"], "저는 (ja) + 밥을 (ryż, biernik) + 먹어요 (jem)."),
             ("Lubię kawę.", ["커피를", "좋아해요"], "Po samogłosce 를."),
         ]},
    ],
    "czasowniki": [
        {"title": "Jedna forma dla wszystkich",
         "text": "Polski czasownik ma osobne formy: idę, idziesz, idzie. Koreański ma jedną: 가요. "
                 "Kto idzie, wynika z rozmowy, a 저 (ja) czy 친구 (przyjaciel) dodaje się tylko w razie "
                 "potrzeby. Końcówka -요 nie oznacza osoby, tylko grzeczność.",
         "chain": [
             ("Idę do szkoły.", ["학교에", "가요"], "학교에 (do szkoły) + 가요 (idę)."),
             ("Uczę się koreańskiego.", ["한국어를", "공부해요"], "공부 (nauka) + 해요 (robię)."),
         ]},
    ],
    "czastki": [
        {"title": "도 = też, 안 = nie",
         "text": "도 zastępuje 는 i znaczy „też”: 저도 = ja też. Przeczenie robi się prosto: 안 przed "
                 "czasownikiem, jak polskie „nie”: 안 가요 = nie idę.",
         "chain": [("Ja też jestem studentem.", ["저도", "학생이에요"], "저 + 도 (też).")]},
    ],
    "przeszly": [
        {"title": "-었- to przeszłość",
         "text": "Czas przeszły wstawia się przed -요: 먹어요 (jem) → 먹었어요 (zjadłem). Po ㅏ i ㅗ jest "
                 "-았-, a samogłoski często się zlewają: 가 + 았어요 = 갔어요. 해요 zmienia się w 했어요.",
         "chain": [
             ("Dziś zjadłem kimchi.", ["오늘", "김치를", "먹었어요"], "오늘 (dziś) + 김치를 + 먹었어요."),
             ("Wczoraj poszedłem do szkoły.", ["어제", "학교에", "갔어요"], "어제 (wczoraj) + 갔어요."),
         ]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Partykuła zależy od głoski",
    "text": "Patrz na koniec słowa. Kończy się spółgłoską (밥, 학생)? Wtedy 은, 이, 을, 이에요. "
            "Samogłoską (저, 커피)? Wtedy 는, 가, 를, 예요. Jak polskie „w domu” i „we wsi”.",
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("", "저", "는", " 학생이에요", ["은", "는", "이", "가"], "ja jestem studentem", "Temat po samogłosce: 는.", "slowa"),
    ("", "선생님", "은", " 한국 사람이에요", ["은", "는", "을", "를"], "nauczyciel jest Koreańczykiem",
     "Temat po spółgłosce: 은.", "slowa"),
    ("저는 ", "학생", "이에요", "", ["이에요", "예요", "이", "가"], "jestem studentem", "Po spółgłosce: 이에요.", "slowa"),
    ("제 ", "친구", "예요", "", ["이에요", "예요", "을", "는"], "to mój przyjaciel", "Po samogłosce: 예요.", "rodzina"),
    ("", "이름", "이", " 뭐예요?", ["이", "가", "을", "를"], "jak masz na imię?", "Podmiot po spółgłosce: 이.", "rodzina"),
    ("", "사과", "가", " 세 개 있어요", ["이", "가", "을", "를"], "są trzy jabłka", "Podmiot po samogłosce: 가.", "liczby"),
    ("", "밥", "을", " 먹어요", ["을", "를", "이", "가"], "jem ryż", "Dopełnienie po spółgłosce: 을.", "jedzenie"),
    ("", "커피", "를", " 좋아해요", ["을", "를", "은", "는"], "lubię kawę", "Dopełnienie po samogłosce: 를.", "jedzenie"),
    ("", "학교", "에", " 가요", ["에", "을", "는", "가"], "idę do szkoły", "Dokąd? 에.", "czasowniki"),
    ("", "저", "도", " 학생이에요", ["도", "는", "를", "가"], "ja też jestem studentem", "„Też”: 도.", "czastki"),
    ("어제 김치를 ", "먹", "었어요", "", ["어요", "었어요", "을", "는"], "wczoraj zjadłem kimchi",
     "Przeszłość: -었어요.", "przeszly"),
    ("오늘 김치를 ", "먹", "어요", "", ["어요", "었어요", "을", "는"], "dziś jem kimchi", "Teraz: -어요.", "przeszly"),
]

# Kolorem wyróżniamy partykuły w ćwiczeniach z końcówkami (zob. ui.py); pole zostaje dla zgodności.
LONG_VOWELS = ""

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "spotkanie", "title": "Pierwsze spotkanie", "partner": "Minjun", "avatar": "민", "requires": "slowa",
        "turns": [
            {"bot": ["안녕하세요", "!"], "en": "Dzień dobry!",
             "options": [(["안녕하세요", "!"], True, None),
                         (["감사합니다", "!"], False, "감사합니다 to „dziękuję”. Najpierw się przywitaj.")]},
            {"bot": ["학생이에요", "?"], "en": "Jesteś studentem?", "note": "Uwaga: 네 znaczy „tak”!",
             "options": [(["네", ",", "저는", "학생이에요"], True, None),
                         (["아니요", ",", "저는", "학생이에요"], False, "아니요 to „nie”, a potwierdzasz. Tak: 네.")]},
            {"bot": ["한국", "사람이에요", "?"], "en": "Jesteś Koreańczykiem?",
             "build": (["아니요", ",", "저는", "폴란드", "사람이에요"], "Nie, jestem Polakiem.")},
        ],
    },
    {
        "id": "rodzina", "title": "Zdjęcia rodzinne", "partner": "Jiyeon", "avatar": "지", "requires": "rodzina",
        "turns": [
            {"bot": ["이", "사람", "누구예요", "?"], "en": "Kto to jest?",
             "options": [(["제", "엄마예요"], True, None),
                         (["이름이", "뭐예요", "?"], False, "To pytanie o imię. Odpowiedz, kto to jest: 제 엄마예요.")]},
            {"bot": ["친구예요", "?"], "en": "To twój przyjaciel?",
             "options": [(["네", ",", "제", "친구예요"], True, None),
                         (["네", ",", "제", "아빠예요"], False, "아빠 to tata. Przyjaciel: 친구.")]},
        ],
    },
    {
        "id": "kawiarnia", "title": "W kawiarni", "partner": "Barista", "avatar": "카", "requires": "jedzenie",
        "turns": [
            {"bot": ["뭐", "마셔요", "?"], "en": "Co pijesz?",
             "options": [(["커피를", "마셔요"], True, None),
                         (["커피를", "먹어요"], False, "먹어요 to „jem”. Kawę się pije: 마셔요.")]},
            {"bot": ["김치", "맛있어요", "?"], "en": "Kimchi smakuje?",
             "options": [(["네", ",", "맛있어요"], True, None),
                         (["아니요", ",", "맛있어요"], False, "아니요 to „nie”, a mówisz, że jest pyszne. Tak: 네.")]},
            {"bot": ["감사합니다", "!"], "en": "Dziękuję!", "build": (["감사합니다"], "Dziękuję.")},
        ],
    },
    {
        "id": "plany", "title": "Wczoraj i jutro", "partner": "Seojun", "avatar": "서", "requires": "przeszly",
        "turns": [
            {"bot": ["어제", "뭐", "했어요", "?"], "en": "Co robiłeś wczoraj?",
             "options": [(["한국어를", "공부했어요"], True, None),
                         (["한국어를", "공부해요"], False, "Pytanie o wczoraj: czas przeszły 공부했어요.")]},
            {"bot": ["내일", "어디에", "가요", "?"], "en": "Dokąd jutro idziesz?",
             "build": (["내일", "학교에", "가요"], "Jutro idę do szkoły.")},
        ],
    },
]

CHAT_EXTRA = {}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    't_part': ['책 (temat)', '나 (temat)', '물 (dopełnienie)', '커피 (dopełnienie)', '집 (podmiot)', '친구 (podmiot)'],
}

PARADIGMS = [
    ('form', 'Typowe trudności', 'Partykuła po spółgłosce czy samogłosce?', 't_part', '책은; 나는; 물을; 커피를; 집이; 친구가', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['g (zwykłe)', 'k (z przydechem)', 'kk (napięte)', 'd (zwykłe)', 't (z przydechem)', 'tt (napięte)', 'b (zwykłe)', 'p (z przydechem)', 'pp (napięte)'],
    't_m1': ['eo (otwarte o)', 'o', 'eu (u bez zaokrąglenia)', 'u', 'ae', 'e'],
    't_m2': ['가다 (iść)', '먹다 (jeść)', '하다 (robić)', '보다 (widzieć)', '있다 (być, mieć)', '마시다 (pić)'],
    't_m3': ['한국어', '음악', '있어요', '먹어요', '책이', '꽃'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Trzy serie spółgłosek', 't_m0', 'ㄱ; ㅋ; ㄲ; ㄷ; ㅌ; ㄸ; ㅂ; ㅍ; ㅃ', 'Dodatkowa kreska oznacza przydech, podwojenie litery napięcie.'),
    ('form', 'Typowe trudności', 'Samogłoski łatwe do pomylenia', 't_m1', 'ㅓ; ㅗ; ㅡ; ㅜ; ㅐ; ㅔ', None),
    ('form', 'Typowe trudności', 'Forma grzeczna (-요)', 't_m2', '가요; 먹어요; 해요; 봐요; 있어요; 마셔요', 'Po ㅏ, ㅗ w temacie: -아요; po innych: -어요; 하다 → 해요.'),
    ('form', 'Typowe trudności', 'Batchim: jak to się czyta?', 't_m3', 'han-gu-geo; eu-mak; i-sseo-yo; meo-geo-yo; chae-gi; kkot', 'Końcowa spółgłoska przechodzi do następnej sylaby, jeśli ta zaczyna się od ㅇ.'),
]

# Klasyfikatory i liczba mnoga
PARADIGM_LABELS.update({
    't_k0': ['사과 (jabłko)', '학생 (uczeń)', '고양이 (kot)', '책 (książka)', '커피 (kawa, filiżanka)', '물 (woda, butelka)', '종이 (papier, kartka)', '자동차 (samochód)'],
    't_k1': ['하나 (1)', '둘 (2)', '셋 (3)', '넷 (4)', '다섯 (5)', '스물 (20)'],
    't_k2': ['godzina (시)', 'minuta (분)', 'wiek (살)', 'data: dzień (일)', 'pieniądze (원)', 'sztuki (개)', 'osoby (명)', 'miesiąc w dacie (월)'],
})
PARADIGMS += [
    ('form', 'Klasyfikatory', 'Klasyfikator: który pasuje?', 't_k0', '개; 명; 마리; 권; 잔; 병; 장; 대', 'Szyk: rzeczownik + liczebnik rodzimy + klasyfikator: 사과 한 개, 학생 두 명.'),
    ('form', 'Klasyfikatory', 'Liczebnik przed klasyfikatorem', 't_k1', '한 개; 두 개; 세 개; 네 개; 다섯 개; 스무 개', 'Przed klasyfikatorem 하나, 둘, 셋, 넷 i 스물 mają krótszą formę.'),
    ('form', 'Klasyfikatory', 'Rodzimy czy sinokoreański?', 't_k2', 'rodzimy; sinokoreański; rodzimy; sinokoreański; sinokoreański; rodzimy; rodzimy; sinokoreański', 'Godziny, wiek, sztuki i osoby liczy się liczebnikami rodzimymi (한 시, 한 살); minuty, daty i pieniądze sinokoreańskimi (일 분, 일 월).'),
]

# Szyk zdania
PARADIGM_LABELS.update({
    't_s0': ['Jem chleb.', 'Idę do szkoły.', 'Dziś piję kawę.', 'To jest książka.'],
})
PARADIGMS += [
    ('form', 'Szyk zdania', 'Szyk: orzeczenie na końcu', 't_s0', '저는 빵을 먹어요.|저는 먹어요 빵을.|먹어요 저는 빵을.|빵을 먹어요 저는.; 저는 학교에 가요.|저는 가요 학교에.|가요 저는 학교에.|학교에 가요 저는.; 오늘 커피를 마셔요.|오늘 마셔요 커피를.|마셔요 오늘 커피를.|커피를 마셔요 오늘.; 이것은 책이에요.|이것은 이에요 책.|책이에요 이것은.|이에요 책 이것은.', 'Czasownik na końcu. Partykuły (은/는, 을/를, 에) wiszą na rzeczowniku.'),
]

# === SŁOWNICTWO (generowane z langs/vocab, nie edytuj ręcznie) ===
UNITS += [{'id': 'v01a', 'title': 'Ludzie 1', 'icon': 'L', 'track': 'jezyk', 'words': [('남자', 'mężczyzna', None, None), ('여자', 'kobieta', None, None), ('아이', 'dziecko', None, None), ('소년', 'chłopiec', None, None), ('소녀', 'dziewczynka', None, None), ('어머니', 'matka', None, None), ('아버지', 'ojciec', None, None), ('아들', 'syn', None, None), ('딸', 'córka', None, None), ('형', 'starszy brat (dla chłopca)', None, None), ('오빠', 'starszy brat (dla dziewczyny)', None, None), ('누나', 'starsza siostra (dla chłopca)', None, None), ('언니', 'starsza siostra (dla dziewczyny)', None, None), ('동생', 'młodsze rodzeństwo', None, None), ('할아버지', 'dziadek', None, None), ('할머니', 'babcia', None, None)], 'sentences': []}, {'id': 'v01b', 'title': 'Ludzie 2', 'icon': 'L', 'track': 'jezyk', 'words': [('손자', 'wnuk', None, None), ('삼촌', 'wuj', None, None), ('이모', 'ciotka', None, None), ('이웃', 'sąsiad', None, None), ('손님', 'gość', None, None), ('적', 'wróg', None, None), ('왕', 'król', None, None), ('여왕', 'królowa', None, None), ('대통령', 'prezydent', None, None), ('의사', 'lekarz', None, None), ('군인', 'żołnierz', None, None), ('농부', 'rolnik', None, None), ('상인', 'kupiec', None, None), ('어부', 'rybak', None, None), ('요리사', 'kucharz', None, None), ('경찰', 'policjant', None, None)], 'sentences': []}, {'id': 'v01c', 'title': 'Ludzie 3', 'icon': 'L', 'track': 'jezyk', 'words': [('소방관', 'strażak', None, None), ('간호사', 'pielęgniarka', None, None), ('변호사', 'prawnik', None, None), ('기술자', 'inżynier', None, None), ('공무원', 'urzędnik', None, None), ('직원', 'pracownik', None, None), ('사장', 'szef', None, None), ('남편', 'mąż', None, None), ('아내', 'żona', None, None), ('약혼자', 'narzeczony', None, None), ('장인', 'teść', None, None), ('장모', 'teściowa', None, None), ('사위', 'zięć', None, None), ('며느리', 'synowa', None, None), ('고아', 'sierota', None, None), ('외국인', 'cudzoziemiec', None, None)], 'sentences': []}, {'id': 'v01d', 'title': 'Ludzie 4', 'icon': 'L', 'track': 'jezyk', 'words': [('도둑', 'złodziej', None, None), ('시인', 'poeta', None, None), ('작가', 'pisarz', None, None), ('화가', 'malarz', None, None), ('가수', 'piosenkarz', None, None), ('배우', 'aktor', None, None), ('운동선수', 'sportowiec', None, None), ('대학생', 'student', None, None), ('교수', 'profesor', None, None), ('스님', 'mnich', None, None), ('신부', 'ksiądz', None, None), ('목사', 'pastor', None, None), ('성인', 'święty', None, None), ('천사', 'anioł', None, None), ('노인', 'starzec', None, None), ('청년', 'młodzieniec', None, None)], 'sentences': []}, {'id': 'v01e', 'title': 'Ludzie 5', 'icon': 'L', 'track': 'jezyk', 'words': [('아가씨', 'dziewczyna', None, None), ('아저씨', 'pan', None, None), ('아주머니', 'pani', None, None), ('어른', 'dorosły', None, None), ('군중', 'tłum', None, None), ('민족', 'naród', None, None), ('국민', 'lud', None, None), ('시민', 'obywatel', None, None), ('주인', 'gospodarz', None, None), ('승객', 'pasażer', None, None), ('운전사', 'kierowca', None, None), ('기자', 'dziennikarz', None, None), ('통역사', 'tłumacz', None, None), ('건축가', 'architekt', None, None), ('과학자', 'naukowiec', None, None)], 'sentences': []}, {'id': 'v02a', 'title': 'Ciało 1', 'icon': 'C', 'track': 'jezyk', 'words': [('머리', 'głowa', None, None), ('얼굴', 'twarz', None, None), ('눈', 'oko', None, None), ('귀', 'ucho', None, None), ('코', 'nos', None, None), ('입', 'usta', None, None), ('혀', 'język (narząd)', None, None), ('머리카락', 'włosy', None, None), ('목', 'szyja', None, None), ('어깨', 'ramię', None, None), ('손', 'ręka', None, None), ('팔', 'ramię (ręka)', None, None), ('손가락', 'palec', None, None), ('다리', 'noga', None, None), ('발', 'stopa', None, None), ('무릎', 'kolano', None, None)], 'sentences': []}, {'id': 'v02b', 'title': 'Ciało 2', 'icon': 'C', 'track': 'jezyk', 'words': [('등', 'plecy', None, None), ('배', 'brzuch', None, None), ('심장', 'serce', None, None), ('피', 'krew', None, None), ('뼈', 'kość', None, None), ('피부', 'skóra', None, None), ('몸', 'ciało', None, None), ('위', 'żołądek', None, None), ('턱', 'broda', None, None), ('입술', 'warga', None, None), ('손톱', 'paznokieć', None, None), ('가슴', 'pierś', None, None), ('뇌', 'mózg', None, None), ('팔꿈치', 'łokieć', None, None), ('이마', 'czoło', None, None), ('볼', 'policzek', None, None)], 'sentences': []}, {'id': 'v02c', 'title': 'Ciało 3', 'icon': 'C', 'track': 'jezyk', 'words': [('발뒤꿈치', 'pięta', None, None), ('간', 'wątroba', None, None), ('폐', 'płuco', None, None), ('땀', 'pot', None, None), ('눈물', 'łza', None, None), ('혈관', 'żyła', None, None), ('지방', 'tłuszcz', None, None), ('날개', 'skrzydło', None, None), ('뿔', 'róg', None, None), ('꼬리', 'ogon', None, None), ('눈썹', 'brew', None, None), ('속눈썹', 'rzęsa', None, None), ('목덜미', 'kark', None, None), ('손목', 'nadgarstek', None, None), ('발목', 'kostka', None, None), ('허리', 'talia', None, None)], 'sentences': []}, {'id': 'v02d', 'title': 'Ciało 4', 'icon': 'C', 'track': 'jezyk', 'words': [('엉덩이', 'biodro', None, None), ('허벅지', 'udo', None, None), ('목소리', 'głos', None, None), ('숨', 'oddech', None, None), ('잠', 'sen (spanie)', None, None), ('영혼', 'duch', None, None), ('마음', 'dusza', None, None), ('미소', 'uśmiech', None, None), ('주먹', 'pięść', None, None), ('손바닥', 'dłoń', None, None), ('발가락', 'palec u nogi', None, None), ('척추', 'kręgosłup', None, None), ('갈비뼈', 'żebro', None, None), ('목구멍', 'gardło', None, None)], 'sentences': []}, {'id': 'v03a', 'title': 'Jedzenie 1', 'icon': 'J', 'track': 'jezyk', 'words': [('버터', 'masło', None, None), ('치즈', 'ser', None, None), ('계란', 'jajko', None, None), ('고기', 'mięso', None, None), ('소고기', 'wołowina', None, None), ('돼지고기', 'wieprzowina', None, None), ('닭고기', 'kurczak', None, None), ('생선', 'ryba', None, None), ('국', 'zupa', None, None), ('쌀', 'ryż (surowy)', None, None), ('밀가루', 'mąka', None, None), ('양파', 'cebula', None, None), ('마늘', 'czosnek', None, None), ('포도', 'winogrono', None, None), ('복숭아', 'brzoskwinia', None, None), ('딸기', 'truskawka', None, None)], 'sentences': []}, {'id': 'v03b', 'title': 'Jedzenie 2', 'icon': 'J', 'track': 'jezyk', 'words': [('수박', 'arbuz', None, None), ('귤', 'mandarynka', None, None), ('바나나', 'banan', None, None), ('오렌지', 'pomarańcza', None, None), ('레몬', 'cytryna', None, None), ('견과류', 'orzech', None, None), ('꿀', 'miód', None, None), ('소금', 'sól', None, None), ('후추', 'pieprz', None, None), ('설탕', 'cukier', None, None), ('기름', 'olej', None, None), ('식초', 'ocet', None, None), ('간장', 'sos sojowy', None, None), ('고추장', 'pasta chili', None, None), ('김', 'algi', None, None), ('두부', 'tofu', None, None)], 'sentences': []}, {'id': 'v03c', 'title': 'Jedzenie 3', 'icon': 'J', 'track': 'jezyk', 'words': [('국수', 'makaron', None, None), ('아침 식사', 'śniadanie', None, None), ('점심 식사', 'obiad', None, None), ('저녁 식사', 'kolacja', None, None), ('배고픔', 'głód', None, None), ('음식', 'jedzenie', None, None), ('음료', 'napój', None, None), ('차', 'herbata', None, None), ('맥주', 'piwo', None, None), ('와인', 'wino', None, None), ('주스', 'sok', None, None), ('술', 'alkohol', None, None), ('과일', 'owoc', None, None), ('채소', 'warzywo', None, None), ('배추', 'kapusta', None, None), ('오이', 'ogórek', None, None)], 'sentences': []}, {'id': 'v03d', 'title': 'Jedzenie 4', 'icon': 'J', 'track': 'jezyk', 'words': [('감자', 'ziemniak', None, None), ('고구마', 'batat', None, None), ('당근', 'marchew', None, None), ('토마토', 'pomidor', None, None), ('고추', 'papryka', None, None), ('콩', 'fasola', None, None), ('옥수수', 'kukurydza', None, None), ('버섯', 'grzyb', None, None), ('상추', 'sałata', None, None), ('시금치', 'szpinak', None, None), ('참깨', 'sezam', None, None), ('케이크', 'ciasto', None, None), ('과자', 'ciastko', None, None), ('아이스크림', 'lody', None, None), ('초콜릿', 'czekolada', None, None), ('사탕', 'cukierek', None, None)], 'sentences': []}, {'id': 'v03e', 'title': 'Jedzenie 5', 'icon': 'J', 'track': 'jezyk', 'words': [('된장국', 'zupa miso', None, None), ('볶음밥', 'smażony ryż', None, None), ('비빔밥', 'mieszany ryż', None, None), ('불고기', 'grillowane mięso', None, None), ('만두', 'pierogi (koreańskie)', None, None), ('전', 'naleśnik', None, None), ('떡', 'kopytka ryżowe', None, None), ('매운 음식', 'ostra potrawa', None, None), ('요리', 'danie', None, None), ('인분', 'porcja', None, None), ('메뉴', 'menu', None, None), ('계산서', 'rachunek', None, None), ('숟가락', 'łyżka', None, None), ('젓가락', 'pałeczki', None, None), ('포크', 'widelec', None, None), ('칼', 'nóż', None, None)], 'sentences': []}, {'id': 'v03f', 'title': 'Jedzenie 6', 'icon': 'J', 'track': 'jezyk', 'words': [('접시', 'talerz', None, None), ('그릇', 'miska', None, None), ('컵', 'kubek', None, None), ('유리잔', 'szklanka', None, None), ('병', 'butelka', None, None), ('주전자', 'czajnik', None, None), ('프라이팬', 'patelnia', None, None), ('냄비', 'garnek', None, None)], 'sentences': []}, {'id': 'v04a', 'title': 'Dom 1', 'icon': 'D', 'track': 'jezyk', 'words': [('아파트', 'mieszkanie', None, None), ('방', 'pokój', None, None), ('부엌', 'kuchnia', None, None), ('욕실', 'łazienka', None, None), ('화장실', 'toaleta', None, None), ('침실', 'sypialnia', None, None), ('거실', 'salon', None, None), ('정원', 'ogród', None, None), ('문', 'drzwi', None, None), ('대문', 'brama', None, None), ('창문', 'okno', None, None), ('벽', 'ściana', None, None), ('바닥', 'podłoga', None, None), ('지붕', 'dach', None, None), ('계단', 'schody', None, None), ('엘리베이터', 'winda', None, None)], 'sentences': []}, {'id': 'v04b', 'title': 'Dom 2', 'icon': 'D', 'track': 'jezyk', 'words': [('열쇠', 'klucz', None, None), ('자물쇠', 'zamek', None, None), ('탁자', 'stół', None, None), ('의자', 'krzesło', None, None), ('침대', 'łóżko', None, None), ('옷장', 'szafa', None, None), ('전등', 'lampa', None, None), ('카펫', 'dywan', None, None), ('거울', 'lustro', None, None), ('베개', 'poduszka', None, None), ('담요', 'koc', None, None), ('이불', 'kołdra', None, None), ('불', 'ogień', None, None), ('난로', 'piec', None, None), ('우물', 'studnia', None, None), ('발코니', 'balkon', None, None)], 'sentences': []}, {'id': 'v04c', 'title': 'Dom 3', 'icon': 'D', 'track': 'jezyk', 'words': [('지하실', 'piwnica', None, None), ('다락방', 'strych', None, None), ('차고', 'garaż', None, None), ('울타리', 'płot', None, None), ('벽돌', 'cegła', None, None), ('돌', 'kamień', None, None), ('나무', 'drewno', None, None), ('유리', 'szkło', None, None), ('빗자루', 'miotła', None, None), ('비누', 'mydło', None, None), ('수건', 'ręcznik', None, None), ('칫솔', 'szczoteczka do zębów', None, None), ('치약', 'pasta do zębów', None, None), ('샴푸', 'szampon', None, None), ('빗', 'grzebień', None, None), ('시계', 'zegar', None, None)], 'sentences': []}, {'id': 'v04d', 'title': 'Dom 4', 'icon': 'D', 'track': 'jezyk', 'words': [('텔레비전', 'telewizor', None, None), ('냉장고', 'lodówka', None, None), ('세탁기', 'pralka', None, None), ('청소기', 'odkurzacz', None, None), ('에어컨', 'klimatyzator', None, None), ('온돌', 'ogrzewanie podłogowe', None, None), ('소파', 'sofa', None, None), ('선반', 'półka', None, None), ('서랍', 'szuflada', None, None), ('책상', 'biurko', None, None), ('칠판', 'tablica', None, None), ('스탠드', 'lampka', None, None), ('초', 'świeca', None, None), ('쓰레기', 'śmieci', None, None), ('쓰레기통', 'kosz na śmieci', None, None), ('동네', 'sąsiedztwo', None, None)], 'sentences': []}, {'id': 'v04e', 'title': 'Dom 5', 'icon': 'D', 'track': 'jezyk', 'words': [('주소', 'adres', None, None), ('월세', 'czynsz', None, None), ('전세', 'wynajem', None, None), ('집주인', 'właściciel', None, None), ('세입자', 'lokator', None, None), ('가구', 'meble', None, None), ('설비', 'wyposażenie', None, None), ('창고', 'komórka', None, None), ('가스레인지', 'kuchenka', None, None), ('전자레인지', 'mikrofalówka', None, None), ('싱크대', 'zlew', None, None), ('수도꼭지', 'kran', None, None), ('욕조', 'wanna', None, None), ('샤워', 'prysznic', None, None), ('콘센트', 'gniazdko', None, None), ('플러그', 'wtyczka', None, None)], 'sentences': []}, {'id': 'v04f', 'title': 'Dom 6', 'icon': 'D', 'track': 'jezyk', 'words': [('전구', 'żarówka', None, None), ('건전지', 'bateria', None, None)], 'sentences': []}, {'id': 'v05a', 'title': 'Ubrania 1', 'icon': 'U', 'track': 'jezyk', 'words': [('옷', 'ubranie', None, None), ('셔츠', 'koszula', None, None), ('바지', 'spodnie', None, None), ('원피스', 'sukienka', None, None), ('치마', 'spódnica', None, None), ('코트', 'płaszcz', None, None), ('재킷', 'kurtka', None, None), ('스웨터', 'sweter', None, None), ('신발', 'but', None, None), ('샌들', 'sandał', None, None), ('모자', 'kapelusz', None, None), ('목도리', 'szalik', None, None), ('장갑', 'rękawiczka', None, None), ('양말', 'skarpetka', None, None), ('벨트', 'pas', None, None), ('반지', 'pierścień', None, None)], 'sentences': []}, {'id': 'v05b', 'title': 'Ubrania 2', 'icon': 'U', 'track': 'jezyk', 'words': [('목걸이', 'naszyjnik', None, None), ('귀걸이', 'kolczyk', None, None), ('팔찌', 'bransoleta', None, None), ('천', 'tkanina', None, None), ('양모', 'wełna', None, None), ('비단', 'jedwab', None, None), ('가죽', 'skóra (wyprawiona)', None, None), ('스카프', 'chusta', None, None), ('의복', 'szata', None, None), ('한복', 'tradycyjny strój koreański', None, None), ('속옷', 'bielizna', None, None), ('앞치마', 'fartuch', None, None), ('넥타이', 'krawat', None, None), ('양복', 'garnitur', None, None), ('안경', 'okulary', None, None), ('가방', 'torba', None, None)], 'sentences': []}, {'id': 'v05c', 'title': 'Ubrania 3', 'icon': 'U', 'track': 'jezyk', 'words': [('배낭', 'plecak', None, None), ('손목시계', 'zegarek', None, None), ('우산', 'parasol', None, None), ('지갑', 'portfel', None, None), ('운동화', 'buty sportowe', None, None), ('부츠', 'kozaki', None, None), ('슬리퍼', 'klapki', None, None), ('잠옷', 'piżama', None, None), ('교복', 'mundur', None, None), ('칼라', 'kołnierz', None, None), ('소매', 'rękaw', None, None), ('주머니', 'kieszeń', None, None), ('단추', 'guzik', None, None), ('지퍼', 'zamek błyskawiczny', None, None), ('실', 'nić', None, None), ('바늘', 'igła', None, None)], 'sentences': []}, {'id': 'v05d', 'title': 'Ubrania 4', 'icon': 'U', 'track': 'jezyk', 'words': [('사이즈', 'rozmiar', None, None), ('패션', 'moda', None, None), ('화장', 'makijaż', None, None), ('향수', 'perfumy', None, None)], 'sentences': []}, {'id': 'v06a', 'title': 'Kolory i kształty 1', 'icon': 'K', 'track': 'jezyk', 'words': [('빨간색', 'czerwony', None, None), ('파란색', 'niebieski', None, None), ('초록색', 'zielony', None, None), ('노란색', 'żółty', None, None), ('검은색', 'czarny', None, None), ('하얀색', 'biały', None, None), ('회색', 'szary', None, None), ('갈색', 'brązowy', None, None), ('분홍색', 'różowy', None, None), ('보라색', 'fioletowy', None, None), ('주황색', 'pomarańczowy', None, None), ('금색', 'złoty', None, None), ('은색', 'srebrny', None, None), ('밝다', 'jasny', None, None), ('어둡다', 'ciemny', None, None), ('색', 'kolor', None, None)], 'sentences': []}, {'id': 'v06b', 'title': 'Kolory i kształty 2', 'icon': 'K', 'track': 'jezyk', 'words': [('둥글다', 'okrągły', None, None), ('네모', 'kwadrat', None, None), ('삼각형', 'trójkąt', None, None), ('원', 'koło', None, None), ('선', 'linia', None, None), ('점', 'punkt', None, None), ('모양', 'kształt', None, None), ('공', 'kula', None, None), ('각도', 'kąt', None, None), ('옆', 'bok', None, None), ('가운데', 'środek', None, None), ('높이', 'wysokość', None, None), ('길이', 'długość', None, None), ('너비', 'szerokość', None, None), ('깊이', 'głębokość', None, None), ('크기', 'wielkość', None, None)], 'sentences': []}, {'id': 'v06c', 'title': 'Kolory i kształty 3', 'icon': 'K', 'track': 'jezyk', 'words': [('단위', 'miara', None, None), ('곧다', 'prosty', None, None), ('구부러지다', 'krzywy', None, None), ('날카롭다', 'ostry', None, None), ('무디다', 'tępy', None, None), ('매끄럽다', 'gładki', None, None), ('거칠다', 'szorstki', None, None), ('줄무늬', 'pasiasty', None, None), ('물방울무늬', 'kropkowany', None, None), ('알록달록하다', 'kolorowy', None, None)], 'sentences': []}, {'id': 'v07a', 'title': 'Liczby i ilości 1', 'icon': 'L', 'track': 'jezyk', 'words': [('영', 'zero', None, None), ('일', 'jeden', None, None), ('삼', 'trzy', None, None), ('사', 'cztery', None, None), ('오', 'pięć', None, None), ('육', 'sześć', None, None), ('칠', 'siedem', None, None), ('구', 'dziewięć', None, None), ('십', 'dziesięć', None, None), ('백', 'sto', None, None), ('만', 'dziesięć tysięcy', None, None), ('백만', 'milion', None, None), ('스물', 'dwadzieścia (rodzimy)', None, None), ('서른', 'trzydzieści (rodzimy)', None, None), ('마흔', 'czterdzieści (rodzimy)', None, None), ('쉰', 'pięćdziesiąt (rodzimy)', None, None)], 'sentences': []}, {'id': 'v07b', 'title': 'Liczby i ilości 2', 'icon': 'L', 'track': 'jezyk', 'words': [('첫째', 'pierwszy', None, None), ('둘째', 'drugi', None, None), ('셋째', 'trzeci', None, None), ('반', 'połowa', None, None), ('쌍', 'para', None, None), ('몇', 'kilka', None, None), ('많이', 'wiele', None, None), ('조금', 'mało', None, None), ('전체', 'cały', None, None), ('모두', 'wszyscy', None, None), ('다', 'wszystko', None, None), ('아무', 'żaden', None, None), ('두 번', 'dwa razy', None, None), ('한 번', 'raz', None, None), ('얼마', 'ile', None, None), ('그만큼', 'tyle', None, None)], 'sentences': []}, {'id': 'v07c', 'title': 'Liczby i ilości 3', 'icon': 'L', 'track': 'jezyk', 'words': [('더', 'więcej', None, None), ('덜', 'mniej', None, None), ('충분히', 'dość', None, None), ('너무', 'zbyt', None, None), ('이중', 'podwójny', None, None), ('백 개', 'setka', None, None), ('열 개', 'dziesiątka', None, None), ('사분의 일', 'ćwierć', None, None), ('퍼센트', 'procent', None, None), ('숫자', 'liczba', None, None), ('합계', 'suma', None, None), ('차이', 'różnica', None, None), ('평균', 'średnia', None, None), ('최대', 'maksimum', None, None), ('최소', 'minimum', None, None), ('번호', 'numer', None, None)], 'sentences': []}, {'id': 'v07d', 'title': 'Liczby i ilości 4', 'icon': 'L', 'track': 'jezyk', 'words': [('줄', 'rząd', None, None), ('더미', 'stos', None, None), ('십여', 'kilkanaście', None, None)], 'sentences': []}, {'id': 'v08a', 'title': 'Czas 1', 'icon': 'C', 'track': 'jezyk', 'words': [('분', 'minuta', None, None), ('시간', 'godzina', None, None), ('날', 'dzień', None, None), ('밤', 'noc', None, None), ('주', 'tydzień', None, None), ('달', 'miesiąc', None, None), ('해', 'rok', None, None), ('봄', 'wiosna', None, None), ('여름', 'lato', None, None), ('가을', 'jesień', None, None), ('겨울', 'zima', None, None), ('아침', 'rano', None, None), ('정오', 'południe', None, None), ('오후', 'popołudnie', None, None), ('저녁', 'wieczór', None, None), ('항상', 'zawsze', None, None)], 'sentences': []}, {'id': 'v08b', 'title': 'Czas 2', 'icon': 'C', 'track': 'jezyk', 'words': [('절대', 'nigdy', None, None), ('가끔', 'czasem', None, None), ('자주', 'często', None, None), ('벌써', 'już', None, None), ('아직', 'jeszcze', None, None), ('곧', 'wkrótce', None, None), ('나중에', 'później', None, None), ('일찍', 'wcześnie', None, None), ('늦게', 'późno', None, None), ('언제', 'kiedy', None, None), ('과거', 'przeszłość', None, None), ('미래', 'przyszłość', None, None), ('현재', 'teraźniejszość', None, None), ('명절', 'święto', None, None), ('모레', 'pojutrze', None, None), ('지금', 'teraz', None, None)], 'sentences': []}, {'id': 'v08c', 'title': 'Czas 3', 'icon': 'C', 'track': 'jezyk', 'words': [('그때', 'wtedy', None, None), ('세기', 'wiek', None, None), ('잠시', 'chwila', None, None), ('젊음', 'młodość', None, None), ('늙음', 'starość', None, None), ('어린 시절', 'dzieciństwo', None, None), ('새벽', 'świt', None, None), ('해질녘', 'zmierzch', None, None), ('자정', 'północ', None, None), ('오래전에', 'dawno', None, None), ('얼마 전에', 'niedawno', None, None), ('즉시', 'natychmiast', None, None), ('그동안', 'tymczasem', None, None), ('먼저', 'najpierw', None, None), ('그 다음에', 'potem', None, None), ('드디어', 'wreszcie', None, None)], 'sentences': []}, {'id': 'v08d', 'title': 'Czas 4', 'icon': 'C', 'track': 'jezyk', 'words': [('월요일', 'poniedziałek', None, None), ('화요일', 'wtorek', None, None), ('수요일', 'środa', None, None), ('목요일', 'czwartek', None, None), ('금요일', 'piątek', None, None), ('토요일', 'sobota', None, None), ('일요일', 'niedziela', None, None), ('일월', 'styczeń', None, None), ('이월', 'luty', None, None), ('삼월', 'marzec', None, None), ('사월', 'kwiecień', None, None), ('오월', 'maj', None, None), ('유월', 'czerwiec', None, None), ('칠월', 'lipiec', None, None), ('팔월', 'sierpień', None, None), ('구월', 'wrzesień', None, None)], 'sentences': []}, {'id': 'v08e', 'title': 'Czas 5', 'icon': 'C', 'track': 'jezyk', 'words': [('시월', 'październik', None, None), ('십일월', 'listopad', None, None), ('십이월', 'grudzień', None, None), ('설날', 'Nowy Rok', None, None), ('추석', 'Święto Dziękczynienia', None, None), ('방학', 'wakacje', None, None), ('주말', 'weekend', None, None), ('평일', 'dzień powszedni', None, None), ('매일', 'codziennie', None, None), ('매주', 'co tydzień', None, None), ('매달', 'co miesiąc', None, None), ('매년', 'co roku', None, None), ('올해', 'tego roku', None, None), ('작년', 'w zeszłym roku', None, None), ('내년', 'w przyszłym roku', None, None), ('이번 달', 'w tym miesiącu', None, None)], 'sentences': []}, {'id': 'v08f', 'title': 'Czas 6', 'icon': 'C', 'track': 'jezyk', 'words': [('다음 주', 'w przyszłym tygodniu', None, None), ('최근', 'ostatnio', None, None), ('계속', 'ciągle', None, None), ('갑자기', 'nagle', None, None), ('천천히', 'powoli', None, None), ('기한', 'termin', None, None), ('날짜', 'data', None, None), ('달력', 'kalendarz', None, None), ('생일', 'urodziny', None, None)], 'sentences': []}, {'id': 'v09a', 'title': 'Przyroda i pogoda 1', 'icon': 'P', 'track': 'jezyk', 'words': [('별', 'gwiazda', None, None), ('하늘', 'niebo', None, None), ('구름', 'chmura', None, None), ('비', 'deszcz', None, None), ('바람', 'wiatr', None, None), ('폭풍', 'burza', None, None), ('안개', 'mgła', None, None), ('얼음', 'lód', None, None), ('땅', 'ziemia', None, None), ('바다', 'morze', None, None), ('강', 'rzeka', None, None), ('호수', 'jezioro', None, None), ('산', 'góra', None, None), ('숲', 'las', None, None), ('꽃', 'kwiat', None, None), ('풀', 'trawa', None, None)], 'sentences': []}, {'id': 'v09b', 'title': 'Przyroda i pogoda 2', 'icon': 'P', 'track': 'jezyk', 'words': [('잎', 'liść', None, None), ('밭', 'pole', None, None), ('초원', 'łąka', None, None), ('섬', 'wyspa', None, None), ('해안', 'brzeg', None, None), ('해변', 'plaża', None, None), ('바위', 'skała', None, None), ('더위', 'upał', None, None), ('추위', 'zimno (pogoda)', None, None), ('따뜻함', 'ciepło', None, None), ('서리', 'mróz', None, None), ('우박', 'grad', None, None), ('천둥', 'grzmot', None, None), ('번개', 'błyskawica', None, None), ('무지개', 'tęcza', None, None), ('진흙', 'błoto', None, None)], 'sentences': []}, {'id': 'v09c', 'title': 'Przyroda i pogoda 3', 'icon': 'P', 'track': 'jezyk', 'words': [('모래', 'piasek', None, None), ('계곡', 'dolina', None, None), ('언덕', 'wzgórze', None, None), ('동굴', 'jaskinia', None, None), ('샘', 'źródło', None, None), ('늪', 'bagno', None, None), ('덤불', 'krzak', None, None), ('뿌리', 'korzeń', None, None), ('가지', 'gałąź', None, None), ('파도', 'fala', None, None), ('이슬', 'rosa', None, None), ('홍수', 'powódź', None, None), ('지진', 'trzęsienie ziemi', None, None), ('어둠', 'ciemność', None, None), ('빛', 'światło', None, None), ('그림자', 'cień', None, None)], 'sentences': []}, {'id': 'v09d', 'title': 'Przyroda i pogoda 4', 'icon': 'P', 'track': 'jezyk', 'words': [('세계', 'świat', None, None), ('줄기', 'pień', None, None), ('나무껍질', 'kora', None, None), ('오솔길', 'ścieżka', None, None), ('공기', 'powietrze', None, None), ('날씨', 'pogoda', None, None), ('강풍', 'wichura', None, None), ('물방울', 'kropla', None, None), ('대나무', 'bambus', None, None), ('소나무', 'sosna', None, None), ('버드나무', 'wierzba', None, None), ('매화', 'śliwa', None, None), ('국화', 'chryzantema', None, None), ('장미', 'róża', None, None), ('백합', 'lilia', None, None), ('벚꽃', 'wiśnia', None, None)], 'sentences': []}, {'id': 'v09e', 'title': 'Przyroda i pogoda 5', 'icon': 'P', 'track': 'jezyk', 'words': [('이끼', 'mech', None, None), ('반도', 'półwysep', None, None), ('대양', 'ocean', None, None), ('하구', 'ujście', None, None), ('화산', 'wulkan', None, None), ('사막', 'pustynia', None, None), ('대륙', 'kontynent', None, None), ('평야', 'równina', None, None), ('장마', 'deszczowa pora', None, None), ('흐림', 'mglisto', None, None), ('맑음', 'słonecznie', None, None), ('흐리다', 'pochmurno', None, None), ('눈보라', 'śnieżyca', None, None), ('가뭄', 'susza', None, None), ('태풍', 'huragan', None, None), ('황사', 'żółty pył', None, None)], 'sentences': []}, {'id': 'v09f', 'title': 'Przyroda i pogoda 6', 'icon': 'P', 'track': 'jezyk', 'words': [('오염', 'zanieczyszczenie', None, None), ('환경', 'środowisko', None, None), ('자연', 'natura', None, None), ('생태', 'przyroda', None, None)], 'sentences': []}, {'id': 'v10a', 'title': 'Zwierzęta 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('고양이', 'kot', None, None), ('말', 'koń', None, None), ('소', 'krowa', None, None), ('황소', 'byk', None, None), ('돼지', 'świnia', None, None), ('양', 'owca', None, None), ('염소', 'koza', None, None), ('닭', 'kura', None, None), ('수탉', 'kogut', None, None), ('오리', 'kaczka', None, None), ('새', 'ptak', None, None), ('쥐', 'mysz', None, None), ('뱀', 'wąż', None, None), ('개구리', 'żaba', None, None), ('사자', 'lew', None, None), ('호랑이', 'tygrys', None, None)], 'sentences': []}, {'id': 'v10b', 'title': 'Zwierzęta 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('곰', 'niedźwiedź', None, None), ('늑대', 'wilk', None, None), ('여우', 'lis', None, None), ('토끼', 'zając', None, None), ('사슴', 'jeleń', None, None), ('당나귀', 'osioł', None, None), ('낙타', 'wielbłąd', None, None), ('독수리', 'orzeł', None, None), ('부엉이', 'sowa', None, None), ('비둘기', 'gołąb', None, None), ('까마귀', 'wrona', None, None), ('백조', 'łabędź', None, None), ('거위', 'gęś', None, None), ('까치', 'sroka', None, None), ('제비', 'jaskółka', None, None), ('매', 'sokół', None, None)], 'sentences': []}, {'id': 'v10c', 'title': 'Zwierzęta 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('멧돼지', 'dzik', None, None), ('거북이', 'żółw', None, None), ('달팽이', 'ślimak', None, None), ('벌레', 'robak', None, None), ('개미', 'mrówka', None, None), ('모기', 'komar', None, None), ('말벌', 'osa', None, None), ('벌', 'pszczoła', None, None), ('나비', 'motyl', None, None), ('파리', 'mucha', None, None), ('거미', 'pająk', None, None), ('게', 'rak', None, None), ('떼', 'stado', None, None), ('둥지', 'gniazdo', None, None), ('발굽', 'kopyto', None, None), ('털', 'futro', None, None)], 'sentences': []}, {'id': 'v10d', 'title': 'Zwierzęta 4', 'icon': 'Z', 'track': 'jezyk', 'words': [('우리', 'klatka', None, None), ('송곳니', 'kieł', None, None), ('발톱', 'pazur', None, None), ('용', 'smok', None, None), ('동물', 'zwierzę', None, None), ('연어', 'łosoś', None, None), ('장어', 'węgorz', None, None), ('문어', 'ośmiornica', None, None), ('오징어', 'kałamarnica', None, None), ('고래', 'wieloryb', None, None), ('물개', 'foka', None, None), ('돌고래', 'delfin', None, None), ('상어', 'rekin', None, None), ('새우', 'krewetka', None, None), ('조개', 'małż', None, None), ('두루미', 'żuraw', None, None)], 'sentences': []}, {'id': 'v10e', 'title': 'Zwierzęta 5', 'icon': 'Z', 'track': 'jezyk', 'words': [('뻐꾸기', 'kukułka', None, None), ('참새', 'wróbel', None, None), ('찌르레기', 'szpak', None, None), ('비버', 'bóbr', None, None), ('다람쥐', 'wiewiórka', None, None), ('박쥐', 'nietoperz', None, None), ('고슴도치', 'jeż', None, None), ('두더지', 'kret', None, None), ('오소리', 'borsuk', None, None), ('판다', 'panda', None, None), ('원숭이', 'małpa', None, None), ('코끼리', 'słoń', None, None), ('기린', 'żyrafa', None, None), ('얼룩말', 'zebra', None, None), ('악어', 'krokodyl', None, None), ('도마뱀', 'jaszczurka', None, None)], 'sentences': []}, {'id': 'v10f', 'title': 'Zwierzęta 6', 'icon': 'Z', 'track': 'jezyk', 'words': [('캥거루', 'kangur', None, None), ('펭귄', 'pingwin', None, None), ('앵무새', 'papuga', None, None), ('강아지', 'szczeniak', None, None), ('새끼 고양이', 'kociak', None, None), ('새끼 양', 'jagnię', None, None), ('송아지', 'cielę', None, None), ('망아지', 'źrebię', None, None), ('물고기', 'rybka', None, None), ('어항', 'akwarium', None, None), ('동물원', 'zoo', None, None), ('사육', 'hodowla', None, None)], 'sentences': []}, {'id': 'v11a', 'title': 'Miasto i budynki 1', 'icon': 'M', 'track': 'jezyk', 'words': [('도시', 'miasto', None, None), ('시골', 'wieś', None, None), ('거리', 'ulica', None, None), ('길', 'droga', None, None), ('광장', 'plac', None, None), ('가게', 'sklep', None, None), ('시장', 'targ', None, None), ('은행', 'bank', None, None), ('우체국', 'poczta', None, None), ('병원', 'szpital', None, None), ('대학교', 'uniwersytet', None, None), ('도서관', 'biblioteka', None, None), ('박물관', 'muzeum', None, None), ('절', 'świątynia', None, None), ('교회', 'kościół', None, None), ('성당', 'katedra', None, None)], 'sentences': []}, {'id': 'v11b', 'title': 'Miasto i budynki 2', 'icon': 'M', 'track': 'jezyk', 'words': [('식당', 'restauracja', None, None), ('카페', 'kawiarnia', None, None), ('항구', 'port', None, None), ('역', 'dworzec', None, None), ('공항', 'lotnisko', None, None), ('탑', 'wieża', None, None), ('궁궐', 'pałac', None, None), ('야영지', 'obóz', None, None), ('감옥', 'więzienie', None, None), ('무덤', 'grób', None, None), ('묘지', 'cmentarz', None, None), ('기념비', 'pomnik', None, None), ('유치원', 'przedszkole', None, None), ('방앗간', 'młyn', None, None), ('관공서', 'urząd', None, None), ('시청', 'ratusz', None, None)], 'sentences': []}, {'id': 'v11c', 'title': 'Miasto i budynki 3', 'icon': 'M', 'track': 'jezyk', 'words': [('마을', 'osada', None, None), ('교외', 'przedmieście', None, None), ('공장', 'fabryka', None, None), ('경기장', 'stadion', None, None), ('영화관', 'kino', None, None), ('극장', 'teatr', None, None), ('약국', 'apteka', None, None), ('빵집', 'piekarnia', None, None), ('호텔', 'hotel', None, None), ('여관', 'pensjonat', None, None), ('선착장', 'przystań', None, None), ('지하철역', 'stacja metra', None, None), ('정류장', 'przystanek', None, None), ('주차장', 'parking', None, None), ('사거리', 'skrzyżowanie', None, None), ('인도', 'chodnik', None, None)], 'sentences': []}, {'id': 'v11d', 'title': 'Miasto i budynki 4', 'icon': 'M', 'track': 'jezyk', 'words': [('공원', 'park', None, None), ('놀이터', 'plac zabaw', None, None), ('백화점', 'centrum handlowe', None, None), ('마트', 'supermarket', None, None), ('야시장', 'targ nocny', None, None), ('경찰서', 'komenda', None, None), ('소방서', 'straż pożarna', None, None), ('대사관', 'ambasada', None, None), ('학원', 'uczelnia', None, None), ('헬스장', 'siłownia', None, None), ('수영장', 'basen', None, None), ('목욕탕', 'łaźnia', None, None), ('진료소', 'gabinet', None, None), ('서점', 'księgarnia', None, None), ('매점', 'kiosk', None, None), ('상점가', 'dom towarowy', None, None)], 'sentences': []}, {'id': 'v11e', 'title': 'Miasto i budynki 5', 'icon': 'M', 'track': 'jezyk', 'words': [('고층 건물', 'wieżowiec', None, None), ('공사장', 'budowa', None, None), ('터널', 'tunel', None, None), ('고가도로', 'wiadukt', None, None), ('로터리', 'rondo', None, None), ('가로등', 'latarnia', None, None), ('신호등', 'światła', None, None), ('횡단보도', 'przejście dla pieszych', None, None), ('지하철', 'metro', None, None), ('택시', 'taksówka', None, None)], 'sentences': []}, {'id': 'v12a', 'title': 'Podróż i transport 1', 'icon': 'P', 'track': 'jezyk', 'words': [('자동차', 'samochód', None, None), ('버스', 'autobus', None, None), ('기차', 'pociąg', None, None), ('고속열차', 'szybki pociąg', None, None), ('전차', 'tramwaj', None, None), ('자전거', 'rower', None, None), ('오토바이', 'motocykl', None, None), ('비행기', 'samolot', None, None), ('보트', 'łódź', None, None), ('노', 'wiosło', None, None), ('돛', 'żagiel', None, None), ('여행', 'podróż', None, None), ('원정', 'wyprawa', None, None), ('국경', 'granica', None, None), ('기사', 'kierowca (zawód)', None, None), ('표', 'bilet', None, None)], 'sentences': []}, {'id': 'v12b', 'title': 'Podróż i transport 2', 'icon': 'P', 'track': 'jezyk', 'words': [('여권', 'paszport', None, None), ('비자', 'wiza', None, None), ('짐', 'bagaż', None, None), ('여행 가방', 'walizka', None, None), ('지도', 'mapa', None, None), ('육지', 'ląd', None, None), ('해안선', 'wybrzeże', None, None), ('폭풍우', 'sztorm', None, None), ('함대', 'flota', None, None), ('선장', 'kapitan', None, None), ('선원', 'marynarz', None, None), ('운전', 'jazda', None, None), ('통과', 'przejazd', None, None), ('우회로', 'objazd', None, None), ('휘발유', 'benzyna', None, None), ('브레이크', 'hamulec', None, None)], 'sentences': []}, {'id': 'v12c', 'title': 'Podróż i transport 3', 'icon': 'P', 'track': 'jezyk', 'words': [('바퀴', 'koło', None, None), ('엔진', 'silnik', None, None), ('핸들', 'kierownica', None, None), ('운전면허증', 'prawo jazdy', None, None), ('범칙금', 'mandat', None, None), ('사고', 'wypadek', None, None), ('교통체증', 'korek', None, None), ('경로', 'trasa', None, None), ('출발', 'odjazd', None, None), ('도착', 'przyjazd', None, None), ('지연', 'opóźnienie', None, None), ('승강장', 'peron', None, None), ('객차', 'wagon', None, None), ('자리', 'miejsce', None, None), ('예약', 'rezerwacja', None, None), ('편도', 'w jedną stronę', None, None)], 'sentences': []}, {'id': 'v12d', 'title': 'Podróż i transport 4', 'icon': 'P', 'track': 'jezyk', 'words': [('왕복', 'w obie strony', None, None), ('소풍', 'wycieczka', None, None), ('관광객', 'turysta', None, None), ('안내원', 'przewodnik', None, None), ('게스트하우스', 'hostel', None, None), ('텐트', 'namiot', None, None), ('등산 배낭', 'plecak turystyczny', None, None), ('나침반', 'kompas', None, None), ('등산로', 'szlak', None, None), ('하산', 'zejście', None, None), ('등산', 'wejście', None, None)], 'sentences': []}, {'id': 'v13a', 'title': 'Praca i szkoła 1', 'icon': 'P', 'track': 'jezyk', 'words': [('직업', 'zawód', None, None), ('돈', 'pieniądze', None, None), ('월급', 'pensja', None, None), ('계약', 'umowa', None, None), ('수업', 'lekcja', None, None), ('시험', 'egzamin', None, None), ('공책', 'zeszyt', None, None), ('볼펜', 'długopis', None, None), ('연필', 'ołówek', None, None), ('지우개', 'gumka', None, None), ('자', 'linijka', None, None), ('가위', 'nożyczki', None, None), ('종이', 'papier', None, None), ('사전', 'słownik', None, None), ('질문', 'pytanie', None, None), ('대답', 'odpowiedź', None, None)], 'sentences': []}, {'id': 'v13b', 'title': 'Praca i szkoła 2', 'icon': 'P', 'track': 'jezyk', 'words': [('숙제', 'zadanie', None, None), ('공부', 'nauka', None, None), ('지식', 'wiedza', None, None), ('지혜', 'mądrość', None, None), ('조언', 'rada', None, None), ('지시', 'polecenie', None, None), ('명령', 'rozkaz', None, None), ('법', 'ustawa', None, None), ('상', 'nagroda', None, None), ('의무', 'obowiązek', None, None), ('도구', 'narzędzie', None, None), ('망치', 'młot', None, None), ('톱', 'piła', None, None), ('도끼', 'siekiera', None, None), ('쟁기', 'pług', None, None), ('밧줄', 'lina', None, None)], 'sentences': []}, {'id': 'v13c', 'title': 'Praca i szkoła 3', 'icon': 'P', 'track': 'jezyk', 'words': [('글', 'pismo', None, None), ('글자', 'litera', None, None), ('단어', 'słowo', None, None), ('문장', 'zdanie', None, None), ('언어', 'język', None, None), ('문법', 'gramatyka', None, None), ('발음', 'wymowa', None, None), ('기도', 'modlitwa', None, None), ('노래', 'pieśń', None, None), ('이야기', 'bajka', None, None), ('역사', 'historia', None, None), ('법원', 'sąd', None, None), ('증인', 'świadek', None, None), ('맹세', 'przysięga', None, None), ('세금', 'podatek', None, None), ('무역', 'handel', None, None)], 'sentences': []}, {'id': 'v13d', 'title': 'Praca i szkoła 4', 'icon': 'P', 'track': 'jezyk', 'words': [('빚', 'dług', None, None), ('가격', 'cena', None, None), ('이익', 'zysk', None, None), ('손해', 'strata', None, None), ('부', 'bogactwo', None, None), ('가난', 'ubóstwo', None, None), ('선물', 'dar', None, None), ('전쟁', 'wojna', None, None), ('평화', 'pokój (stan)', None, None), ('전투', 'bitwa', None, None), ('승리', 'zwycięstwo', None, None), ('군대', 'wojsko', None, None), ('검', 'miecz', None, None), ('활', 'łuk', None, None), ('회사', 'firma', None, None), ('사무실', 'biuro', None, None)], 'sentences': []}, {'id': 'v13e', 'title': 'Praca i szkoła 5', 'icon': 'P', 'track': 'jezyk', 'words': [('회의', 'zebranie', None, None), ('경력', 'kariera', None, None), ('실업', 'bezrobocie', None, None), ('연금', 'emerytura', None, None), ('휴가', 'urlop', None, None), ('급여', 'wypłata', None, None), ('보너스', 'premia', None, None), ('교실', 'klasa', None, None), ('성적표', 'świadectwo', None, None), ('수능', 'matura', None, None), ('강의', 'wykład', None, None), ('논문', 'praca dyplomowa', None, None), ('장학금', 'stypendium', None, None), ('인턴', 'praktyki', None, None), ('채용', 'rekrutacja', None, None), ('면접', 'rozmowa kwalifikacyjna', None, None)], 'sentences': []}, {'id': 'v13f', 'title': 'Praca i szkoła 6', 'icon': 'P', 'track': 'jezyk', 'words': [('이력서', 'życiorys', None, None), ('직책', 'stanowisko', None, None), ('승진', 'awans', None, None), ('해고', 'zwolnienie', None, None), ('파업', 'strajk', None, None), ('노동조합', 'związek zawodowy', None, None), ('고객', 'klient', None, None), ('서비스', 'usługa', None, None), ('상품', 'produkt', None, None), ('광고', 'reklama', None, None), ('주문', 'zamówienie', None, None), ('배달', 'dostawa', None, None), ('영수증', 'faktura', None, None), ('할인', 'rabat', None, None)], 'sentences': []}, {'id': 'v14a', 'title': 'Zdrowie 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('건강', 'zdrowie', None, None), ('통증', 'ból', None, None), ('기침', 'kaszel', None, None), ('콧물', 'katar', None, None), ('약', 'lekarstwo', None, None), ('상처', 'rana', None, None), ('건강하다', 'zdrowy', None, None), ('아프다', 'chory', None, None), ('피곤하다', 'zmęczony', None, None), ('졸리다', 'śpiący', None, None), ('강하다', 'silny', None, None), ('약하다', 'słaby', None, None), ('귀먹다', 'głuchy', None, None), ('눈멀다', 'ślepy', None, None), ('독', 'trucizna', None, None), ('죽음', 'śmierć', None, None)], 'sentences': []}, {'id': 'v14b', 'title': 'Zdrowie 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('시체', 'trup', None, None), ('회복', 'uzdrowienie', None, None), ('도움', 'pomoc', None, None), ('전염병', 'zaraza', None, None), ('흉터', 'blizna', None, None), ('휴식', 'odpoczynek', None, None), ('다이어트', 'dieta', None, None), ('약초', 'zioło', None, None), ('연고', 'maść', None, None), ('목욕', 'kąpiel', None, None), ('치료', 'leczenie', None, None), ('병동', 'oddział', None, None), ('알약', 'tabletka', None, None), ('주사', 'zastrzyk', None, None), ('체온계', 'termometr', None, None), ('치통', 'ból zęba', None, None)], 'sentences': []}, {'id': 'v14c', 'title': 'Zdrowie 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('독감', 'grypa', None, None), ('감기', 'przeziębienie', None, None), ('알레르기', 'alergia', None, None), ('당뇨병', 'cukrzyca', None, None), ('골절', 'złamanie', None, None), ('붕대', 'opatrunek', None, None), ('수술', 'operacja', None, None), ('검사', 'badanie', None, None), ('진료', 'wizyta', None, None), ('처방전', 'recepta', None, None), ('메스꺼움', 'mdłości', None, None), ('두통', 'ból głowy', None, None), ('복통', 'ból brzucha', None, None), ('설사', 'biegunka', None, None), ('식중독', 'zatrucie', None, None), ('혈액', 'krew (badanie)', None, None)], 'sentences': []}, {'id': 'v14d', 'title': 'Zdrowie 4', 'icon': 'Z', 'track': 'jezyk', 'words': [('혈압', 'ciśnienie', None, None), ('맥박', 'tętno', None, None), ('백신', 'szczepionka', None, None), ('구급차', 'karetka', None, None), ('응급실', 'pogotowie', None, None), ('응급', 'nagły wypadek', None, None), ('보험', 'ubezpieczenie', None, None), ('치과', 'stomatolog', None, None), ('안과', 'okulista', None, None), ('목발', 'kule', None, None), ('휠체어', 'wózek inwalidzki', None, None), ('장애', 'niepełnosprawność', None, None), ('재활', 'rehabilitacja', None, None), ('스트레스', 'stres', None, None), ('우울증', 'depresja', None, None), ('불면증', 'bezsenność', None, None)], 'sentences': []}, {'id': 'v14e', 'title': 'Zdrowie 5', 'icon': 'Z', 'track': 'jezyk', 'words': [('개운하다', 'wypoczęty', None, None)], 'sentences': []}, {'id': 'v15a', 'title': 'Uczucia i charakter 1', 'icon': 'U', 'track': 'jezyk', 'words': [('기쁨', 'radość', None, None), ('슬픔', 'smutek', None, None), ('두려움', 'strach', None, None), ('분노', 'gniew', None, None), ('사랑', 'miłość', None, None), ('우정', 'przyjaźń', None, None), ('미움', 'nienawiść', None, None), ('희망', 'nadzieja', None, None), ('꿈', 'marzenie', None, None), ('행복', 'szczęście', None, None), ('부끄러움', 'wstyd', None, None), ('놀라움', 'zdziwienie', None, None), ('호기심', 'ciekawość', None, None), ('인내', 'cierpliwość', None, None), ('솔직하다', 'szczery', None, None), ('친절하다', 'miły', None, None)], 'sentences': []}, {'id': 'v15b', 'title': 'Uczucia i charakter 2', 'icon': 'U', 'track': 'jezyk', 'words': [('예의 바르다', 'grzeczny', None, None), ('어리석다', 'głupi', None, None), ('똑똑하다', 'mądry', None, None), ('게으르다', 'leniwy', None, None), ('부지런하다', 'pracowity', None, None), ('즐겁다', 'wesoły', None, None), ('슬프다', 'smutny', None, None), ('화나다', 'zły', None, None), ('행복하다', 'szczęśliwy', None, None), ('사랑에 빠지다', 'zakochany', None, None), ('외롭다', 'samotny', None, None), ('조용하다', 'spokojny', None, None), ('자랑스럽다', 'dumny', None, None), ('질투하다', 'zazdrosny', None, None), ('고맙다', 'wdzięczny', None, None), ('용감하다', 'odważny', None, None)], 'sentences': []}, {'id': 'v15c', 'title': 'Uczucia i charakter 3', 'icon': 'U', 'track': 'jezyk', 'words': [('충실하다', 'wierny', None, None), ('인색하다', 'skąpy', None, None), ('후하다', 'hojny', None, None), ('겸손하다', 'pokorny', None, None), ('고집스럽다', 'uparty', None, None), ('자비롭다', 'litościwy', None, None), ('잔인하다', 'okrutny', None, None), ('공정하다', 'sprawiedliwy', None, None), ('정직하다', 'uczciwy', None, None), ('독실하다', 'pobożny', None, None), ('고귀하다', 'szlachetny', None, None), ('연민', 'litość', None, None), ('후회', 'żal', None, None), ('그리움', 'tęsknota', None, None), ('질투', 'zazdrość', None, None), ('복수', 'zemsta', None, None)], 'sentences': []}, {'id': 'v15d', 'title': 'Uczucia i charakter 4', 'icon': 'U', 'track': 'jezyk', 'words': [('운명', 'los', None, None), ('은혜', 'łaska', None, None), ('믿음', 'wiara', None, None), ('겸손', 'pokora', None, None), ('덕', 'cnota', None, None), ('교만', 'pycha', None, None), ('진실', 'prawda', None, None), ('거짓말', 'kłamstwo', None, None), ('자유', 'wolność', None, None), ('명예', 'honor', None, None), ('명성', 'sława', None, None), ('의지', 'wola', None, None), ('이성', 'rozum', None, None), ('기억', 'pamięć', None, None), ('생각', 'myśl', None, None), ('양심', 'sumienie', None, None)], 'sentences': []}, {'id': 'v15e', 'title': 'Uczucia i charakter 5', 'icon': 'U', 'track': 'jezyk', 'words': [('짜증', 'złość', None, None), ('경악', 'zdumienie', None, None), ('지루함', 'nuda', None, None), ('안도', 'ulga', None, None), ('불안', 'niepokój', None, None), ('만족', 'zadowolenie', None, None), ('궁금하다', 'ciekawy', None, None), ('초조하다', 'nerwowy', None, None), ('실망하다', 'rozczarowany', None, None), ('놀라다', 'zaskoczony', None, None), ('당황하다', 'zakłopotany', None, None), ('서운하다', 'z żalem', None, None), ('감동하다', 'wzruszony', None, None), ('그립다', 'tęskny', None, None), ('상냥하다', 'sympatyczny', None, None), ('수줍다', 'nieśmiały', None, None)], 'sentences': []}, {'id': 'v15f', 'title': 'Uczucia i charakter 6', 'icon': 'U', 'track': 'jezyk', 'words': [('사교적이다', 'towarzyski', None, None), ('야심 차다', 'ambitny', None, None), ('창의적이다', 'kreatywny', None, None), ('책임감 있다', 'odpowiedzialny', None, None)], 'sentences': []}, {'id': 'v16a', 'title': 'Przymiotniki 1', 'icon': 'P', 'track': 'jezyk', 'words': [('크다', 'duży', None, None), ('작다', 'mały', None, None), ('길다', 'długi', None, None), ('짧다', 'krótki', None, None), ('높다', 'wysoki', None, None), ('낮다', 'niski', None, None), ('넓다', 'szeroki', None, None), ('좁다', 'wąski', None, None), ('두껍다', 'gruby', None, None), ('마르다', 'chudy', None, None), ('무겁다', 'ciężki', None, None), ('가볍다', 'lekki', None, None), ('빠르다', 'szybki', None, None), ('느리다', 'wolny', None, None), ('단단하다', 'twardy', None, None), ('부드럽다', 'miękki', None, None)], 'sentences': []}, {'id': 'v16b', 'title': 'Przymiotniki 2', 'icon': 'P', 'track': 'jezyk', 'words': [('젖다', 'mokry', None, None), ('깨끗하다', 'czysty', None, None), ('더럽다', 'brudny', None, None), ('가득 차다', 'pełny', None, None), ('비어 있다', 'pusty', None, None), ('시끄럽다', 'głośny', None, None), ('젊다', 'młody', None, None), ('늙다', 'stary', None, None), ('새롭다', 'nowy', None, None), ('좋다', 'dobry', None, None), ('나쁘다', 'zły (jakość)', None, None), ('예쁘다', 'ładny', None, None), ('못생기다', 'brzydki', None, None), ('쉽다', 'łatwy', None, None), ('어렵다', 'trudny', None, None), ('중요하다', 'ważny', None, None)], 'sentences': []}, {'id': 'v16c', 'title': 'Przymiotniki 3', 'icon': 'P', 'track': 'jezyk', 'words': [('가능하다', 'możliwy', None, None), ('진짜', 'prawdziwy', None, None), ('가짜', 'fałszywy', None, None), ('자신의', 'własny', None, None), ('낯설다', 'obcy', None, None), ('거룩하다', 'święty', None, None), ('강력하다', 'potężny', None, None), ('유명하다', 'sławny', None, None), ('가깝다', 'bliski', None, None), ('멀다', 'daleki', None, None), ('확실하다', 'pewny', None, None), ('준비되다', 'gotowy', None, None), ('비슷하다', 'podobny', None, None), ('다르다', 'inny', None, None), ('모든', 'każdy', None, None), ('깊다', 'głęboki', None, None)], 'sentences': []}, {'id': 'v16d', 'title': 'Przymiotniki 4', 'icon': 'P', 'track': 'jezyk', 'words': [('얕다', 'płytki', None, None), ('달다', 'słodki', None, None), ('쓰다', 'gorzki', None, None), ('시다', 'kwaśny', None, None), ('짜다', 'słony', None, None), ('맵다', 'ostry (smak)', None, None), ('뜨겁다', 'gorący', None, None), ('차갑다', 'zimny', None, None), ('따뜻하다', 'ciepły', None, None), ('시원하다', 'chłodny', None, None), ('아름답다', 'piękny', None, None), ('드물다', 'rzadki', None, None), ('부유하다', 'bogaty', None, None), ('가난하다', 'ubogi', None, None), ('안전하다', 'bezpieczny', None, None), ('위험하다', 'niebezpieczny', None, None)], 'sentences': []}, {'id': 'v16e', 'title': 'Przymiotniki 5', 'icon': 'P', 'track': 'jezyk', 'words': [('공통의', 'wspólny', None, None), ('별도의', 'osobny', None, None), ('마지막', 'ostatni', None, None), ('다음', 'następny', None, None), ('옛', 'dawny', None, None), ('영원하다', 'wieczny', None, None), ('비싸다', 'drogi', None, None), ('싸다', 'tani', None, None), ('세다', 'mocny', None, None), ('얇다', 'cienki', None, None), ('유능하다', 'zdolny', None, None), ('영리하다', 'sprytny', None, None), ('지루하다', 'nudny', None, None), ('재미있다', 'ciekawy (interesujący)', None, None), ('맛있다', 'smaczny', None, None), ('맛없다', 'niesmaczny', None, None)], 'sentences': []}, {'id': 'v16f', 'title': 'Przymiotniki 6', 'icon': 'P', 'track': 'jezyk', 'words': [('편하다', 'wygodny', None, None), ('불편하다', 'niewygodny', None, None), ('바쁘다', 'zajęty', None, None), ('한가하다', 'wolny (nie zajęty)', None, None), ('배고프다', 'głodny', None, None), ('목마르다', 'spragniony', None, None), ('배부르다', 'syty', None, None), ('혼자', 'sam', None, None), ('많다', 'duża liczba', None, None), ('적다', 'mało (przymiotnik)', None, None), ('같다', 'taki sam', None, None), ('연하다', 'jasny (kolor)', None, None), ('진하다', 'ciemny (kolor)', None, None), ('기름지다', 'tłusty', None, None), ('담백하다', 'lekkostrawny', None, None), ('바삭하다', 'chrupiący', None, None)], 'sentences': []}, {'id': 'v17a', 'title': 'Czasowniki podstawowe 1', 'icon': 'C', 'track': 'jezyk', 'words': [('이다', 'być', None, None), ('있다', 'istnieć', None, None), ('없다', 'nie istnieć', None, None), ('가지다', 'mieć', None, None), ('하다', 'robić', None, None), ('가다', 'iść', None, None), ('오다', 'przyjść', None, None), ('나가다', 'wyjść', None, None), ('들어가다', 'wejść', None, None), ('돌아가다', 'wrócić', None, None), ('달리다', 'biec', None, None), ('서다', 'stać', None, None), ('앉다', 'siedzieć', None, None), ('눕다', 'leżeć', None, None), ('자다', 'spać', None, None), ('일어나다', 'wstać', None, None)], 'sentences': []}, {'id': 'v17b', 'title': 'Czasowniki podstawowe 2', 'icon': 'C', 'track': 'jezyk', 'words': [('먹다', 'jeść', None, None), ('마시다', 'pić', None, None), ('끓이다', 'gotować', None, None), ('씻다', 'myć', None, None), ('말하다', 'mówić', None, None), ('이야기하다', 'powiedzieć', None, None), ('묻다', 'pytać', None, None), ('대답하다', 'odpowiadać', None, None), ('듣다', 'słyszeć', None, None), ('보다', 'widzieć', None, None), ('쳐다보다', 'patrzeć', None, None), ('읽다', 'czytać', None, None), ('배우다', 'uczyć się', None, None), ('가르치다', 'uczyć', None, None), ('이해하다', 'rozumieć', None, None), ('알다', 'wiedzieć', None, None)], 'sentences': []}, {'id': 'v17c', 'title': 'Czasowniki podstawowe 3', 'icon': 'C', 'track': 'jezyk', 'words': [('모르다', 'nie wiedzieć', None, None), ('생각하다', 'myśleć', None, None), ('기억하다', 'pamiętać', None, None), ('잊다', 'zapominać', None, None), ('원하다', 'chcieć', None, None), ('좋아하다', 'lubić', None, None), ('사랑하다', 'kochać', None, None), ('필요하다', 'potrzebować', None, None), ('할 수 있다', 'móc', None, None), ('주다', 'dawać', None, None), ('받다', 'brać', None, None), ('사다', 'kupować', None, None), ('팔다', 'sprzedawać', None, None), ('내다', 'płacić', None, None), ('열다', 'otwierać', None, None), ('닫다', 'zamykać', None, None)], 'sentences': []}, {'id': 'v17d', 'title': 'Czasowniki podstawowe 4', 'icon': 'C', 'track': 'jezyk', 'words': [('시작하다', 'zaczynać', None, None), ('끝내다', 'kończyć', None, None), ('일하다', 'pracować', None, None), ('놀다', 'grać', None, None), ('부르다', 'śpiewać', None, None), ('춤추다', 'tańczyć', None, None), ('수영하다', 'pływać', None, None), ('날다', 'latać', None, None), ('놓다', 'kłaść', None, None), ('찾다', 'szukać', None, None), ('기다리다', 'czekać', None, None), ('돕다', 'pomagać', None, None), ('부탁하다', 'prosić', None, None), ('사과하다', 'przepraszać', None, None), ('허락하다', 'pozwalać', None, None), ('시도하다', 'próbować', None, None)], 'sentences': []}, {'id': 'v17e', 'title': 'Czasowniki podstawowe 5', 'icon': 'C', 'track': 'jezyk', 'words': [('바꾸다', 'zmieniać', None, None), ('들다', 'nosić', None, None), ('잡다', 'trzymać', None, None), ('던지다', 'rzucać', None, None), ('때리다', 'bić', None, None), ('죽이다', 'zabijać', None, None), ('죽다', 'umierać', None, None), ('살다', 'żyć', None, None), ('만나다', 'spotykać', None, None), ('보내다', 'wysyłać', None, None), ('보여 주다', 'pokazywać', None, None), ('초대하다', 'zapraszać', None, None), ('방문하다', 'odwiedzać', None, None), ('울다', 'płakać', None, None), ('웃다', 'śmiać się', None, None), ('무서워하다', 'bać się', None, None)], 'sentences': []}, {'id': 'v17f', 'title': 'Czasowniki podstawowe 6', 'icon': 'C', 'track': 'jezyk', 'words': [('기뻐하다', 'cieszyć się', None, None), ('믿다', 'wierzyć', None, None), ('동의하다', 'zgadzać się', None, None), ('고르다', 'wybierać', None, None), ('결정하다', 'decydować', None, None), ('다스리다', 'rządzić', None, None), ('이끌다', 'prowadzić', None, None), ('이기다', 'zwyciężać', None, None), ('지다', 'przegrywać', None, None), ('싸우다', 'walczyć', None, None), ('지키다', 'bronić', None, None), ('파괴하다', 'niszczyć', None, None), ('짓다', 'budować', None, None), ('무너뜨리다', 'burzyć', None, None), ('태우다', 'palić', None, None), ('끄다', 'gasić', None, None)], 'sentences': []}, {'id': 'v17g', 'title': 'Czasowniki podstawowe 7', 'icon': 'C', 'track': 'jezyk', 'words': [('갈망하다', 'pragnąć', None, None), ('후회하다', 'żałować', None, None), ('구하다', 'ratować', None, None), ('숭배하다', 'czcić', None, None), ('기도하다', 'modlić się', None, None), ('약속하다', 'obiecywać', None, None), ('거짓말하다', 'kłamać', None, None), ('고발하다', 'oskarżać', None, None), ('벌주다', 'karać', None, None), ('감사하다', 'dziękować', None, None), ('인사하다', 'pozdrawiać', None, None), ('죄짓다', 'grzeszyć', None, None), ('창조하다', 'stworzyć', None, None), ('태어나다', 'narodzić się', None, None), ('의심하다', 'wątpić', None, None), ('꿈꾸다', 'śnić', None, None)], 'sentences': []}, {'id': 'v17h', 'title': 'Czasowniki podstawowe 8', 'icon': 'C', 'track': 'jezyk', 'words': [('틀리다', 'mylić się', None, None), ('남다', 'pozostawać', None, None), ('도착하다', 'przybywać', None, None)], 'sentences': []}, {'id': 'v18a', 'title': 'Czasowniki dnia codziennego 1', 'icon': 'C', 'track': 'jezyk', 'words': [('걷다', 'chodzić', None, None), ('타다', 'jeździć', None, None), ('올라타다', 'wsiadać', None, None), ('내리다', 'wysiadać', None, None), ('돌다', 'skręcać', None, None), ('멈추다', 'zatrzymywać się', None, None), ('늦다', 'spóźniać się', None, None), ('서두르다', 'spieszyć się', None, None), ('쉬다', 'odpoczywać', None, None), ('고치다', 'naprawiać', None, None), ('자르다', 'ciąć', None, None), ('굽다', 'smażyć', None, None), ('구워내다', 'piec', None, None), ('섞다', 'mieszać', None, None), ('붓다', 'nalewać', None, None), ('청소하다', 'sprzątać', None, None)], 'sentences': []}, {'id': 'v18b', 'title': 'Czasowniki dnia codziennego 2', 'icon': 'C', 'track': 'jezyk', 'words': [('빨다', 'prać', None, None), ('면도하다', 'golić się', None, None), ('빗다', 'czesać', None, None), ('목욕하다', 'kąpać się', None, None), ('깨다', 'budzić się', None, None), ('잠들다', 'zasypiać', None, None), ('운동하다', 'ćwiczyć', None, None), ('움직이다', 'ruszać', None, None), ('당기다', 'ciągnąć', None, None), ('밀다', 'pchać', None, None), ('들어 올리다', 'podnosić', None, None), ('떨어지다', 'spadać', None, None), ('뛰다', 'skakać', None, None), ('오르다', 'wspinać się', None, None), ('숨기다', 'ukrywać', None, None), ('훔치다', 'kraść', None, None)], 'sentences': []}, {'id': 'v18c', 'title': 'Czasowniki dnia codziennego 3', 'icon': 'C', 'track': 'jezyk', 'words': [('돌려주다', 'oddawać', None, None), ('빌리다', 'pożyczać', None, None), ('아끼다', 'oszczędzać', None, None), ('갈다', 'orać', None, None), ('뿌리다', 'siać', None, None), ('모으다', 'zbierać', None, None), ('심다', 'sadzić', None, None), ('물을 주다', 'podlewać', None, None), ('깎다', 'strzyc', None, None), ('꿰매다', 'szyć', None, None), ('그리다', 'malować', None, None), ('파다', 'kopać', None, None), ('묶다', 'wiązać', None, None), ('풀다', 'rozwiązywać', None, None), ('앉아 있다', 'siadać', None, None), ('대화하다', 'rozmawiać', None, None)], 'sentences': []}, {'id': 'v18d', 'title': 'Czasowniki dnia codziennego 4', 'icon': 'C', 'track': 'jezyk', 'words': [('소리치다', 'krzyczeć', None, None), ('침묵하다', 'milczeć', None, None), ('속삭이다', 'szeptać', None, None), ('작별하다', 'żegnać', None, None), ('맞이하다', 'witać', None, None), ('말해 주다', 'opowiadać', None, None), ('묘사하다', 'opisywać', None, None), ('설명하다', 'tłumaczyć', None, None), ('칭찬하다', 'chwalić', None, None), ('꾸짖다', 'ganić', None, None), ('용서하다', 'wybaczać', None, None), ('명령하다', 'rozkazywać', None, None), ('금지하다', 'zabraniać', None, None), ('참여하다', 'brać udział', None, None), ('떠나다', 'odchodzić', None, None), ('돌아오다', 'wracać', None, None)], 'sentences': []}, {'id': 'v18e', 'title': 'Czasowniki dnia codziennego 5', 'icon': 'C', 'track': 'jezyk', 'words': [('나타나다', 'ukazywać się', None, None), ('되다', 'stawać się', None, None), ('보이다', 'wydawać się', None, None), ('버리다', 'porzucać', None, None), ('귀 기울이다', 'słuchać', None, None), ('만지다', 'dotykać', None, None), ('느끼다', 'czuć', None, None), ('냄새 맡다', 'wąchać', None, None), ('맛보다', 'smakować', None, None), ('힘들어하다', 'męczyć się', None, None), ('고통받다', 'cierpieć', None, None), ('자라다', 'rosnąć', None, None), ('낳다', 'rodzić', None, None), ('먹이다', 'karmić', None, None), ('키우다', 'wychowywać', None, None), ('물다', 'gryźć', None, None)], 'sentences': []}, {'id': 'v18f', 'title': 'Czasowniki dnia codziennego 6', 'icon': 'C', 'track': 'jezyk', 'words': [('박다', 'wbijać', None, None), ('싣다', 'ładować', None, None), ('전화하다', 'dzwonić', None, None), ('통화하다', 'rozmawiać przez telefon', None, None), ('문자하다', 'pisać wiadomość', None, None), ('로그인하다', 'logować się', None, None), ('다운로드하다', 'pobierać', None, None), ('인쇄하다', 'drukować', None, None), ('사진 찍다', 'fotografować', None, None), ('녹음하다', 'nagrywać', None, None), ('구경하다', 'oglądać', None, None), ('구경 다니다', 'zwiedzać', None, None)], 'sentences': []}, {'id': 'v19a', 'title': 'Słowa funkcyjne 1', 'icon': 'S', 'track': 'jezyk', 'words': [('여기', 'tutaj', None, None), ('거기', 'tam', None, None), ('여기서', 'stąd', None, None), ('어디', 'gdzie', None, None), ('어떻게', 'jak', None, None), ('왜', 'dlaczego', None, None), ('무엇', 'co', None, None), ('누구', 'kto', None, None), ('어느', 'który', None, None), ('어떤', 'jaki', None, None), ('하지만', 'ale', None, None), ('또는', 'lub', None, None), ('왜냐하면', 'bo', None, None), ('때문에', 'ponieważ', None, None), ('만약', 'jeśli', None, None), ('라고', 'że', None, None)], 'sentences': []}, {'id': 'v19b', 'title': 'Słowa funkcyjne 2', 'icon': 'S', 'track': 'jezyk', 'words': [('그래서', 'więc', None, None), ('도', 'też', None, None), ('아무것도', 'nic', None, None), ('무언가', 'coś', None, None), ('누군가', 'ktoś', None, None), ('아무도', 'nikt', None, None), ('누구나', 'każdy', None, None), ('아마', 'może', None, None), ('반드시', 'na pewno', None, None), ('함께', 'razem', None, None), ('직접', 'sam', None, None), ('없이', 'bez', None, None), ('와', 'z', None, None), ('에', 'w', None, None), ('위에', 'na', None, None), ('까지', 'do', None, None)], 'sentences': []}, {'id': 'v19c', 'title': 'Słowa funkcyjne 3', 'icon': 'S', 'track': 'jezyk', 'words': [('부터', 'od', None, None), ('위해', 'dla', None, None), ('통해', 'przez', None, None), ('후에', 'po', None, None), ('전에', 'przed', None, None), ('뒤에', 'za', None, None), ('아래', 'pod', None, None), ('옆에', 'obok', None, None), ('사이에', 'między', None, None), ('반대로', 'przeciw', None, None), ('에 대해', 'o', None, None), ('쯤', 'około', None, None), ('거의', 'prawie', None, None), ('심지어', 'nawet', None, None), ('어딘가', 'gdzieś', None, None), ('아무 데도', 'nigdzie', None, None)], 'sentences': []}, {'id': 'v19d', 'title': 'Słowa funkcyjne 4', 'icon': 'S', 'track': 'jezyk', 'words': [('어디나', 'wszędzie', None, None), ('아주', 'bardzo', None, None), ('그렇게', 'tak', None, None), ('아니', 'nie', None, None), ('인지', 'czy', None, None), ('그러나', 'jednak', None, None), ('비록', 'chociaż', None, None), ('때', 'gdy', None, None), ('동안', 'dopóki', None, None), ('하기 전에', 'zanim', None, None), ('도 아니', 'ani', None, None), ('그리고', 'a', None, None), ('그', 'on', None, None), ('그녀', 'ona', None, None), ('너희', 'wy', None, None), ('그들', 'oni', None, None)], 'sentences': []}, {'id': 'v19e', 'title': 'Słowa funkcyjne 5', 'icon': 'S', 'track': 'jezyk', 'words': [('나를', 'mnie', None, None), ('자기', 'siebie', None, None), ('내', 'mój', None, None), ('우리의', 'nasz', None, None), ('누구의', 'czyj', None, None), ('부탁드립니다', 'proszę', None, None), ('죄송합니다', 'przepraszam', None, None), ('안녕히 주무세요', 'dobranoc', None, None), ('안녕히 가세요', 'do widzenia', None, None), ('안녕', 'cześć', None, None), ('이에요', 'jest', None, None), ('없어요', 'nie ma', None, None), ('아쉽게도', 'niestety', None, None), ('솔직히', 'szczerze', None, None), ('물론', 'oczywiście', None, None), ('정말', 'naprawdę', None, None)], 'sentences': []}, {'id': 'v19f', 'title': 'Słowa funkcyjne 6', 'icon': 'S', 'track': 'jezyk', 'words': [('꽤', 'całkiem', None, None), ('완전히', 'zupełnie', None, None), ('별로', 'prawie nic', None, None), ('다시', 'jeszcze raz', None, None), ('또', 'znowu', None, None), ('바로', 'od razu', None, None), ('대신', 'zamiast', None, None), ('외에', 'oprócz', None, None), ('에 따르면', 'według', None, None), ('에도 불구하고', 'wbrew', None, None), ('에도', 'mimo', None, None), ('덕분에', 'dzięki', None, None), ('가능한 한 빨리', 'jak najszybciej', None, None)], 'sentences': []}, {'id': 'v20a', 'title': 'Korea i kultura 1', 'icon': 'K', 'track': 'jezyk', 'words': [('대한민국', 'Korea Południowa', None, None), ('북한', 'Korea Północna', None, None), ('서울', 'Seul', None, None), ('부산', 'Pusan', None, None), ('인천', 'Inczon', None, None), ('대구', 'Daegu', None, None), ('대전', 'Daejeon', None, None), ('광주', 'Kwangdżu', None, None), ('제주도', 'Czedżu', None, None), ('한강', 'Han', None, None), ('백두산', 'Pekdusan', None, None), ('한라산', 'Hallasan', None, None), ('동해', 'Morze Wschodnie', None, None), ('서해', 'Morze Żółte', None, None), ('한국어', 'język koreański', None, None), ('한글', 'pismo koreańskie', None, None)], 'sentences': []}, {'id': 'v20b', 'title': 'Korea i kultura 2', 'icon': 'K', 'track': 'jezyk', 'words': [('세종대왕', 'król Sedżong', None, None), ('전통', 'tradycja', None, None), ('문화', 'kultura', None, None), ('한국 역사', 'historia Korei', None, None), ('태권도', 'taekwondo', None, None), ('케이팝', 'K-pop', None, None), ('드라마', 'drama', None, None), ('영화', 'film', None, None), ('음악', 'muzyka', None, None), ('춤', 'taniec', None, None), ('판소리', 'teatr tradycyjny', None, None), ('미역국', 'zupa na urodziny', None, None), ('다도', 'ceremonia herbaty', None, None), ('사찰', 'świątynia buddyjska', None, None), ('예술', 'sztuka', None, None), ('그림', 'malarstwo', None, None)], 'sentences': []}, {'id': 'v20c', 'title': 'Korea i kultura 3', 'icon': 'K', 'track': 'jezyk', 'words': [('도자기', 'ceramika', None, None), ('김밥', 'kimbap', None, None), ('소주', 'soju', None, None), ('막걸리', 'makkoli', None, None), ('찌개', 'jjigae', None, None), ('떡볶이', 'tteokbokki', None, None), ('라면', 'ramyeon', None, None), ('삼겹살', 'samgyeopsal', None, None), ('피시방', 'PC bang', None, None), ('노래방', 'norebang', None, None), ('찜질방', 'jjimjilbang', None, None), ('선배', 'sunbae', None, None), ('후배', 'hubae', None, None), ('애교', 'aegyo', None, None), ('화이팅', 'hwaiting', None, None), ('괜찮아요', 'gwaenchanayo', None, None)], 'sentences': []}, {'id': 'v20d', 'title': 'Korea i kultura 4', 'icon': 'K', 'track': 'jezyk', 'words': [('정', 'jeong', None, None), ('눈치', 'nunchi', None, None), ('빨리빨리', 'bali bali', None, None)], 'sentences': []}]
# === /SŁOWNICTWO ===

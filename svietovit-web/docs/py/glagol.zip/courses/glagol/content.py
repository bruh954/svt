"""Treść kursu: język staro-cerkiewno-słowiański (SCS) dla Polaków.

Słowo:   (forma cyrylicą, znaczenie po polsku, polski krewny lub None, skojarzenie lub None)
         Transliteracja i zapis głagolicą powstają automatycznie (engine.py).
Litera:  (litera, opis dźwięku po polsku, nazwa litery)
Zdanie:  (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
         Każde słowo w zdaniu musi występować w kursie.

Pisownia znormalizowana, jak w podręcznikach (np. Leskien). Każde słowo
w kursie musi mieć niepowtarzalną formę.
"""

UNITS = [
    # ------------------------------------------------------------------ pismo
    {
        "id": "cyr1", "title": "Cyrylica I", "icon": "А", "color": "#12B886", "track": "pismo",
        "letters": [
            ("а", "[a]", "азъ"), ("б", "[b]", "боукꙑ"), ("в", "[v]", "вѣдѣ"),
            ("г", "[ɡ]", "глаголи"), ("д", "[d]", "добро"), ("е", "[ɛ]", "ѥсть"),
            ("ж", "[ʒ] (ż)", "живѣте"), ("з", "[z]", "землꙗ"), ("и", "[i]", "иже"),
            ("к", "[k]", "како"), ("л", "[l]", "людиѥ"), ("м", "[m]", "мꙑслите"),
            ("н", "[n]", "нашь"), ("о", "[ɔ]", "онъ"),
        ],
    },
    {
        "id": "cyr2", "title": "Cyrylica II", "icon": "Ш", "color": "#20C997", "track": "pismo",
        "letters": [
            ("п", "[p]", "покои"), ("р", "[r]", "рьци"), ("с", "[s]", "слово"),
            ("т", "[t]", "тврьдо"), ("оу", "[u]", "оукъ"),
            ("ф", "[f]", "фрьтъ"), ("х", "[x] (ch)", "хѣръ"), ("ц", "[ts] (c)", "ци"),
            ("ч", "[tʃ] (cz)", "чрьвь"), ("ш", "[ʃ] (sz)", "ша"), ("щ", "[ʃt] (szt)", "шта"),
            ("ъ", "[ŭ] (jer twardy)", "ѥръ"),
            ("ь", "[ĭ] (jer miękki)", "ѥрь"),
            ("ꙑ", "[ɨ] (y)", "ѥрꙑ"),
        ],
    },
    {
        "id": "cyr3", "title": "Cyrylica III", "icon": "Ѫ", "color": "#0CA678", "track": "pismo",
        "letters": [
            ("ѣ", "[æ] lub [ja] (jać)", "ѣть"),
            ("ѧ", "[ɛ̃] (ę)", "ѧсъ малъ"),
            ("ѫ", "[ɔ̃] (ǫ)", "ѫсъ голѣмъ"),
            ("ѩ", "[jɛ̃] (ję)", "ѩсъ"),
            ("ѭ", "[jɔ̃] (jǫ)", "ѭсъ"),
            ("ѥ", "[jɛ]", "ѥ"), ("ꙗ", "[ja]", "ꙗ"), ("ю", "[ju]", "ю"),
            ("ꙃ", "[dz] (dzěło)", "ꙃѣло"), ("і", "[i] (zapis grecki)", "і"),
            ("ѳ", "[θ] (słowa greckie)", "ѳита"), ("ѵ", "[i] / [y] (słowa greckie)", "ижица"),
            ("ѡ", "[ɔ] (słowa greckie)", "отъ"), ("ѯ", "[ks]", "кси"), ("ѱ", "[ps]", "пси"),
        ],
    },
    # --------------------------------------------------------------- język
    {
        "id": 'cyr4', "title": 'Cyrylica IV: warianty', "icon": 'ѹ', "color": '#0CA678', "track": 'pismo',
        "letters": [
            ('ѹ', '[u] (= оу), jedna litera zamiast dwóch', 'оукъ'),
            ('ꙋ', '[u] (= оу), monogram „uk” z rękopisów', 'оукъ'),
            ('ѻ', '[ɔ] (= о), okrągłe o ze starych rękopisów', 'онъ'),
            ('ѿ', '[ɔt] (= ѡ + т), ligatura „ot”', 'отъ'),
            ('ѽ', '[ɔ] okrzyk „och!”', 'ѽ'),
            ('ꙁ', '[z] (= з), wariant z dawnych rękopisów', 'землꙗ'),
            ('є', '[ɛ] (= е), wariant z rękopisów', 'ѥсть'),
        ],
    },
    {
        "id": 'cyr5', "title": 'Liczby cyrylickie I', "icon": 'а҃', "color": '#0CA678', "track": 'pismo', "kind": "number",
        "letters": [
            ('а҃', '1', 'азъ'),
            ('в҃', '2', 'вѣдѣ'),
            ('г҃', '3', 'глаголи'),
            ('д҃', '4', 'добро'),
            ('є҃', '5', 'ѥсть'),
            ('ꙃ҃', '6', 'ꙃѣло'),
            ('з҃', '7', 'землꙗ'),
            ('и҃', '8', 'иже'),
            ('ѳ҃', '9', 'ѳита'),
        ],
    },
    {
        "id": 'cyr6', "title": 'Liczby cyrylickie II', "icon": 'к҃', "color": '#0CA678', "track": 'pismo', "kind": "number",
        "letters": [
            ('і҃', '10', 'ижеи'),
            ('к҃', '20', 'како'),
            ('л҃', '30', 'людиѥ'),
            ('м҃', '40', 'мꙑслите'),
            ('н҃', '50', 'нашь'),
            ('ѯ҃', '60', 'кси'),
            ('ѻ҃', '70', 'онъ'),
            ('п҃', '80', 'покои'),
            ('ч҃', '90', 'чрьвь'),
        ],
    },
    {
        "id": 'cyr7', "title": 'Liczby cyrylickie III', "icon": 'р҃', "color": '#0CA678', "track": 'pismo', "kind": "number",
        "letters": [
            ('р҃', '100', 'рьци'),
            ('с҃', '200', 'слово'),
            ('т҃', '300', 'тврьдо'),
            ('у҃', '400', 'оукъ'),
            ('ф҃', '500', 'фрьтъ'),
            ('х҃', '600', 'хѣръ'),
            ('ѱ҃', '700', 'пси'),
            ('ѡ҃', '800', 'отъ'),
            ('ц҃', '900', 'ци'),
            ('҂а', '1000', 'азъ'),
        ],
    },
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "Азъ", "color": "#4DABF7", "track": "jezyk",
        "requires": "cyr2",
        "words": [
            ("азъ", "ja", "jaźń", "Stąd staropolskie „jaźń”. Także nazwa pierwszej litery."),
            ("тꙑ", "ty", "ty", None),
            ("онъ", "on", "on", None),
            ("мꙑ", "my", "my", None),
            ("и", "i; także", "i", None),
            ("не", "nie", "nie", None),
            ("да", "tak; niech", "da (ros.)", "Ten sam wyraz co rosyjskie „da”."),
            ("радоуи", "raduj (się)", "raduj", "„Радоуи сѧ” to powitanie: dosłownie „raduj się”."),
            ("сѧ", "się", "się", "ѧ = ę, więc сѧ to dosłownie „sę”: polskie „się”."),
            ("миръ", "pokój; świat", "mir", "Staropolskie „mir” to pokój i poważanie."),
            ("богъ", "Bóg", "Bóg", None),
            ("чловѣкъ", "człowiek", "człowiek", "ѣ to tu polskie „ie”: člověkъ → człowiek."),
            ("слово", "słowo", "słowo", None),
            ("добръ", "dobry", "dobry", None),
            ("добро", "dobre; dobro", "dobro", "Rodzaj nijaki, do „слово”."),
            ("ѥсмь", "jestem", "jeśm (stpol.)", "Staropolski miał „jeśm” = jestem."),
            ("ѥси", "jesteś", "jeś (stpol.)", None),
            ("ѥсть", "jest", "jest", None),
            ("нѣсть", "nie jest; nie ma", "nie jest", "Ściągnięte „не ѥсть”."),
        ],
        "sentences": [
            (["азъ", "ѥсмь", "чловѣкъ"], "Jestem człowiekiem.",
             {"ѥси": "ѥси to „jesteś”. O sobie: ѥсмь (staropolskie „jeśm”).",
              "ѥсть": "ѥсть to „jest” (on). O sobie: ѥсмь."}),
            (["тꙑ", "ѥси", "добръ"], "Jesteś dobry.",
             {"ѥсмь": "ѥсмь to „jestem”. Do „ty”: ѥси (jak staropolskie „jeś”)."}),
            (["богъ", "ѥсть", "добръ"], "Bóg jest dobry.", {}),
            (["слово", "ѥсть", "добро"], "Słowo jest dobre.",
             {"добръ": "слово jest rodzaju nijakiego, jak po polsku: „dobre słowo”, więc добро."}),
            (["онъ", "нѣсть", "богъ"], "On nie jest Bogiem.",
             {"не": "„Nie jest” to w SCS jedno słowo: нѣсть (z „не ѥсть”)."}),
            (["радоуи", "сѧ"], "Witaj! (dosł. raduj się)", {}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "Домъ", "color": "#CC5DE8", "track": "jezyk",
        "words": [
            ("отьць", "ojciec", "ojciec", "ь to krótkie i, które w polskim zmieniło się w „e” lub znikło."),
            ("мати", "matka", "mać (stpol.)", None),
            ("сꙑнъ", "syn", "syn", None),
            ("дъшти", "córka", None, "Polski poszedł tu inną drogą (córka); por. rosyjskie „doč”."),
            ("братъ", "brat", "brat", None),
            ("сестра", "siostra", "siostra", None),
            ("мѫжь", "mąż; mężczyzna", "mąż", "ѫ = ą! мѫжь to dosłownie „mąż”."),
            ("жена", "kobieta; żona", "żona", None),
            ("дѣва", "dziewica; panna", "dziewa (stpol.)", "ѣ → ie: děva → dziewa, dziewica."),
            ("домъ", "dom", "dom", None),
            ("домоу", "(w) domu", "domu", "Miejscownik: въ домоу = w domu. Dokładnie jak po polsku!"),
            ("въ", "w; do", "w", "ъ na końcu się nie wymawia (później zanikł)."),
            ("людиѥ", "ludzie", "ludzie", None),
            ("мои", "mój", "mój", None),
            ("моꙗ", "moja", "moja", None),
            ("твои", "twój", "twój", None),
            ("твоꙗ", "twoja", "twoja", None),
        ],
        "sentences": [
            (["отьць", "мои", "добръ", "ѥсть"], "Mój ojciec jest dobry.",
             {"моꙗ": "отьць jest rodzaju męskiego: мои (mój), nie моꙗ (moja)."}),
            (["тꙑ", "ѥси", "братъ", "мои"], "Jesteś moim bratem.", {}),
            (["сестра", "моꙗ", "ѥсть", "въ", "домоу"], "Moja siostra jest w domu.",
             {"мои": "сестра jest rodzaju żeńskiego: моꙗ (moja).",
              "домъ": "„W domu” to miejscownik: въ домоу, jak polskie „w domu”."}),
            (["мати", "твоꙗ", "ѥсть", "въ", "домоу"], "Twoja matka jest w domu.", {}),
            (["онъ", "ѥсть", "мѫжь", "добръ"], "On jest dobrym mężem.", {}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "Пѧть", "color": "#FF922B", "track": "jezyk",
        "words": [
            ("ѥдинъ", "jeden", "jeden", None),
            ("дъва", "dwa", "dwa", "ъ (krótkie u) zanikło: dъva → dwa."),
            ("триѥ", "trzy", "trzy", None),
            ("четꙑре", "cztery", "cztery", None),
            ("пѧть", "pięć", "pięć", "ѧ = ę: pętь → pięć."),
            ("шесть", "sześć", "sześć", None),
            ("седмь", "siedem", "siedem", "Jer ь zmienił się w polskie „e”: sedmь → siedem."),
            ("осмь", "osiem", "osiem", None),
            ("девѧть", "dziewięć", "dziewięć", "ѧ = ę: devętь → dziewięć."),
            ("десѧть", "dziesięć", "dziesięć", "ѧ = ę: desętь → dziesięć."),
            ("имамь", "mam", "mam", None),
            ("иматъ", "ma", "ma", None),
            ("сꙑновъ", "synów", "synów", "Dopełniacz l.mn. Ta sama końcówka co polskie „-ów”!"),
        ],
        "sentences": [
            (["азъ", "имамь", "ѥдинъ", "домъ"], "Mam jeden dom.",
             {"иматъ": "иматъ to „ma” (on). O sobie: имамь (mam)."}),
            (["отьць", "иматъ", "пѧть", "сꙑновъ"], "Ojciec ma pięciu synów.",
             {"сꙑнъ": "Po „pięć” dopełniacz, jak po polsku „pięciu synów”: сꙑновъ."}),
            (["мати", "иматъ", "шесть", "сꙑновъ"], "Matka ma sześciu synów.", {}),
        ],
    },
    {
        "id": "swiat", "title": "Ciało i świat", "icon": "Рѫка", "color": "#F25F5C", "track": "jezyk",
        "words": [
            ("глава", "głowa", "głowa", "SCS -ra-/-la- = polskie -ro-/-ło-: глава → głowa."),
            ("рѫка", "ręka", "ręka", "ѫ = ą/ę: rǫka → ręka."),
            ("нога", "noga", "noga", None),
            ("око", "oko", "oko", None),
            ("оухо", "ucho", "ucho", None),
            ("зѫбъ", "ząb", "ząb", "ѫ = ą: zǫbъ → ząb."),
            ("срьдьце", "serce", "serce", None),
            ("небо", "niebo", "niebo", None),
            ("небеси", "na niebie (miejscownik)", "niebiosa", "Temat небес-: stąd polskie „niebiosa”."),
            ("на", "na", "na", None),
            ("землꙗ", "ziemia", "ziemia", None),
            ("земли", "(na) ziemi", "ziemi", None),
            ("вода", "woda", "woda", None),
            ("огнь", "ogień", "ogień", None),
            ("дьнь", "dzień", "dzień", "Dwa jery: dьnь. Pierwszy dał polskie „e” (dzień), drugi zniknął."),
            ("ношть", "noc", "noc", "SCS щ (št) = polskie c: noštь → noc."),
            ("слъньце", "słońce", "słońce", None),
            ("лѣсъ", "las", "las", "ѣ → a: lěsъ → las."),
            ("мѣсѧць", "księżyc; miesiąc", "miesiąc", "ѣ → ie, ѧ → ą: měsęcь → miesiąc."),
            ("градъ", "gród; miasto", "gród", "-ra- = polskie -ro-: градъ → gród."),
            ("злато", "złoto", "złoto", "-la- = polskie -ło-: злато → złoto."),
        ],
        "sentences": [
            (["небо", "и", "землꙗ"], "Niebo i ziemia.", {}),
            (["дьнь", "и", "ношть"], "Dzień i noc.", {}),
            (["слъньце", "ѥсть", "на", "небеси"], "Słońce jest na niebie.",
             {"небо": "„Na niebie” to miejscownik: на небеси."}),
            (["градъ", "мои", "ѥсть", "добръ"], "Mój gród jest dobry.", {}),
        ],
    },
    {
        "id": "czas", "title": "Czasowniki", "icon": "Пишѫ", "color": "#5C7CFA", "track": "jezyk",
        "words": [
            ("пишѫ", "piszę", "piszę", "Końcówka -ѫ (ǫ) = polskie -ę: pišǫ → piszę."),
            ("пишеши", "piszesz", "piszesz", None),
            ("пишетъ", "pisze", "pisze", None),
            ("глаголѭ", "mówię", "głagoł", "глаголати = mówić. Stąd nazwa głagolicy!"),
            ("глаголетъ", "mówi", None, None),
            ("знаѭ", "znam; wiem", "znam", None),
            ("знаѥтъ", "zna; wie", "zna", None),
            ("идѫ", "idę", "idę", "ѫ = ę: idǫ → idę."),
            ("идетъ", "idzie", "idzie", None),
            ("виждѫ", "widzę", "widzę", "жд to polskie dz: viždǫ → widzę."),
            ("видитъ", "widzi", "widzi", None),
            ("вѣроуѭ", "wierzę", "wierzę", "ѣ → ie: věrujǫ → wierzę."),
            ("чьто", "co", "co", "Polskie „co” powstało z čьto."),
            ("къто", "kto", "kto", None),
            ("бога", "Boga (biernik)", "Boga", "Jak po polsku: „wierzę w Boga”."),
            ("добрѫ", "dobrą (biernik)", "dobrą", None),
            ("рѫкѫ", "rękę (biernik)", "rękę", None),
        ],
        "sentences": [
            (["азъ", "пишѫ", "слово"], "Piszę słowo.",
             {"пишетъ": "пишетъ to „pisze” (on). O sobie: пишѫ, jak „piszę”.",
              "пишеши": "пишеши to „piszesz”. O sobie: пишѫ."}),
            (["онъ", "идетъ", "въ", "домъ"], "On idzie do domu.",
             {"идѫ": "идѫ to „idę”. O nim: идетъ (idzie).",
              "домоу": "„Do domu” = въ + biernik: въ домъ. домоу to „w domu”."}),
            (["вѣроуѭ", "въ", "бога"], "Wierzę w Boga.",
             {"богъ": "Po „въ” (w) biernik, jak po polsku: въ бога = w Boga."}),
            (["къто", "глаголетъ"], "Kto mówi?", {}),
            (["азъ", "не", "знаѭ"], "Nie wiem.", {}),
            (["чьто", "пишеши"], "Co piszesz?", {"пишѫ": "Pytasz kogoś: пишеши (piszesz)."}),
            (["имамь", "добрѫ", "рѫкѫ"], "Mam dobrą rękę.",
             {"рѫка": "Co mam? Biernik: рѫкѫ (rękę). ѫ na końcu to polskie -ę!"}),
            (["виждѫ", "слъньце"], "Widzę słońce.", {"видитъ": "видитъ to „widzi”. O sobie: виждѫ (widzę)."}),
        ],
    },
    {
        "id": "przypadki", "title": "Przypadki", "icon": "Отьче", "color": "#E64980", "track": "jezyk",
        "words": [
            ("отьче", "ojcze! (wołacz)", "ojcze", "Wołacz przetrwał w polskim: ojcze, Boże, człowiecze."),
            ("боже", "Boże! (wołacz)", "Boże", None),
            ("чловѣче", "człowieku! (wołacz)", "człowiecze", None),
            ("господь", "Pan", "gospodarz", "Stąd polskie „gospodarz” i „gospoda”."),
            ("господи", "Panie! (wołacz)", None, None),
            ("помилоуи", "zmiłuj się", "zmiłuj", None),
            ("нашь", "nasz", "nasz", None),
            ("имѧ", "imię", "imię", "ѧ = ę: imę → imię."),
            ("твоѥ", "twoje", "twoje", None),
            ("свѧтъ", "święty", "święty", "ѧ = ę: svętъ → święty."),
            ("свѧто", "święte", "święte", None),
            ("хлѣбъ", "chleb", "chleb", "х = ch, ѣ = e: chlěbъ → chleb."),
            ("даждь", "daj!", "daj", None),
            ("намъ", "nam", "nam", None),
            ("богоу", "Bogu (celownik)", "Bogu", None),
            ("слава", "chwała; sława", "sława", None),
        ],
        "sentences": [
            (["отьче", "нашь"], "Ojcze nasz.", {"отьць": "Zwracasz się do kogoś: wołacz отьче (ojcze!)."}),
            (["боже", "мои"], "Boże mój.", {"богъ": "Do Boga mówisz wołaczem: боже, jak polskie „Boże!”."}),
            (["господи", "помилоуи"], "Panie, zmiłuj się.",
             {"господь": "Do Pana wołacz: господи."}),
            (["даждь", "намъ", "хлѣбъ"], "Daj nam chleb.", {}),
            (["слава", "богоу"], "Chwała Bogu.", {"бога": "„Komu?” Celownik: богоу (Bogu)."}),
            (["имѧ", "твоѥ", "свѧто"], "Imię twoje święte.", {"свѧтъ": "имѧ jest nijakie, więc свѧто."}),
        ],
    },
    {
        "id": "aoryst", "title": "Czas przeszły", "icon": "Рече", "color": "#7950F2", "track": "jezyk",
        "words": [
            ("рече", "rzekł", "rzecze", "Biblijne „rzecze” to właśnie ta forma!"),
            ("бѣ", "był; była; było", None, "Aoryst (3. osoba) od бꙑти."),
            ("бꙑстъ", "stał się; stało się", "by (w „zrobiłbym”)", "Polskie „by” w trybie przypuszczającym to stary aoryst od „być”!"),
            ("видѣ", "ujrzał", "widział", None),
            ("приде", "przyszedł", "przyjdzie", None),
            ("сътвори", "stworzył; uczynił", "stworzył", None),
            ("глагола", "powiedział", None, None),
            ("свѣтъ", "światło; światłość", "świat; światło", "ѣ → ia: světъ → świat."),
            ("искони", "na początku; od zawsza", None, "Tak zaczyna się Ewangelia Jana. Według Żywota Konstantyna to pierwsze słowa zapisane po słowiańsku."),
            ("землю", "ziemię (biernik)", "ziemię", None),
        ],
        "sentences": [
            (["богъ", "рече"], "Bóg rzekł.", {}),
            (["и", "бꙑстъ", "свѣтъ"], "I stała się światłość.",
             {"ѥсть": "To się stało w przeszłości: бꙑстъ (stało się), nie ѥсть (jest)."}),
            (["онъ", "приде", "въ", "домъ"], "Przyszedł do domu.",
             {"идетъ": "идетъ to „idzie” (teraz). W przeszłości: приде (przyszedł)."}),
            (["искони", "бѣ", "слово"], "Na początku było Słowo.",
             {"ѥсть": "Mowa o przeszłości: бѣ (było), nie ѥсть (jest)."}),
            (["богъ", "сътвори", "небо", "и", "землю"], "Bóg stworzył niebo i ziemię.",
             {"землꙗ": "Co stworzył? Biernik: землю (ziemię), jak po polsku."}),
        ],
    },
    {
        "id": "dualis", "title": "Liczba podwójna", "icon": "Дъва", "color": "#FAB005", "track": "jezyk",
        "words": [
            ("рѫцѣ", "dwie ręce", "ręce", "Polskie „ręce” to dawna liczba podwójna!"),
            ("очи", "dwoje oczu", "oczy", "Polskie „oczy” to też dawna liczba podwójna."),
            ("оуши", "dwoje uszu", "uszy", "I polskie „uszy”."),
            ("нозѣ", "dwie nogi", "nodze (stpol.)", None),
            ("брата", "dwaj bracia; brata", "brata", "Ta sama forma: liczba podwójna albo biernik „brata”."),
            ("двѣ", "dwie", "dwie", "ѣ → ie: dvě → dwie."),
            ("сестрѣ", "dwie siostry", None, None),
            ("вѣ", "my dwaj", None, "Osobny zaimek na „my we dwóch”!"),
            ("ѥсвѣ", "jesteśmy (we dwóch)", None, None),
            ("добрѣ", "dobre (o dwóch, rodzaj nijaki)", None, "Przymiotnik też ma liczbę podwójną: nijaki -ѣ."),
        ],
        "sentences": [
            (["дъва", "брата"], "Dwaj bracia.", {"братъ": "Dwóch? Liczba podwójna: брата."}),
            (["двѣ", "сестрѣ"], "Dwie siostry.", {"сестра": "Dwie? Liczba podwójna: сестрѣ."}),
            (["имамь", "двѣ", "рѫцѣ"], "Mam dwie ręce.", {"рѫка": "Dwie ręce: рѫцѣ, jak polskie „ręce”."}),
            (["вѣ", "ѥсвѣ", "брата"], "My dwaj jesteśmy braćmi.",
             {"мꙑ": "Gdy jest was dwóch: вѣ (my dwaj), nie мꙑ.",
              "ѥсмь": "„Jesteśmy we dwóch”: ѥсвѣ."}),
            (["онъ", "иматъ", "очи", "добрѣ"], "On ma dobre oczy.", {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "ojcze1", "title": "Ojcze nasz I", "icon": "Ⱁ", "color": "#495057", "track": "teksty",
        "requires": "przypadki",
        "words": [
            ("иже", "który", "iże (stpol.)", "Staropolskie „iże” znaczyło „który”."),
            ("небесехъ", "niebiosach", "niebiosach", None),
            ("свѧтитъ", "święci", "święci", None),
            ("придетъ", "przyjdzie", "przyjdzie", None),
            ("цѣсарьствиѥ", "królestwo", "cesarstwo", "Od цѣсарь (cesarz). Dosłownie „cesarstwo”."),
            ("бѫдетъ", "będzie", "będzie", "ѫ = ę: bǫdetъ → będzie."),
            ("волꙗ", "wola", "wola", None),
            ("ꙗко", "jako; jak", "jako", None),
            ("земи", "(na) ziemi", "ziemi", "Tak w Kodeksie Mariańskim, bez -л-. Inne teksty mają земли."),
        ],
        "sentences": [
            (["отьче", "нашь", "иже", "ѥси", "на", "небесехъ"], "Ojcze nasz, któryś jest w niebiosach.", {}),
            (["да", "свѧтитъ", "сѧ", "имѧ", "твоѥ"], "Niech się święci imię twoje.", {}),
            (["да", "придетъ", "цѣсарьствиѥ", "твоѥ"], "Niech przyjdzie królestwo twoje.", {}),
            (["да", "бѫдетъ", "волꙗ", "твоꙗ"], "Niech będzie wola twoja.", {}),
            (["ꙗко", "на", "небеси", "и", "на", "земи"], "Jako w niebie, tak i na ziemi.", {}),
        ],
    },
    {
        "id": "ojcze2", "title": "Ojcze nasz II", "icon": "Ⱈ", "color": "#343A40", "track": "teksty",
        "words": [
            ("наставъшааго", "nadchodzącego", "nastać", "Kodeks Mariański mówi o chlebie „nadchodzącego dnia”. Inne rękopisy mają насѫщьнꙑи (powszedni)."),
            ("дьне", "dnia", "dnia", None),
            ("дьньсь", "dzisiaj", "dziś", "„Ten dzień”: dьnь + sь → dziś."),
            ("отъпоусти", "odpuść", "odpuść", None),
            ("длъгꙑ", "długi; winy", "długi", None),
            ("нашѧ", "nasze (biernik)", "nasze", None),
            ("въведи", "wwódź", "wwiedź", None),
            ("насъ", "nas", "nas", None),
            ("напасть", "pokusa", "napaść", None),
            ("нъ", "ale", None, None),
            ("избави", "zbaw", "zbaw", None),
            ("нꙑ", "nas (krótko)", None, None),
            ("отъ", "od; ode", "od", None),
            ("неприꙗзни", "złego", "nieprzyjaźni", "Dosłownie „nieprzyjaźń”."),
        ],
        "sentences": [
            (["хлѣбъ", "нашь", "наставъшааго", "дьне", "даждь", "намъ", "дьньсь"],
             "Chleba naszego na nadchodzący dzień daj nam dzisiaj.", {}),
            (["и", "отъпоусти", "намъ", "длъгꙑ", "нашѧ"], "I odpuść nam nasze winy.", {}),
            (["и", "не", "въведи", "насъ", "въ", "напасть"], "I nie wódź nas na pokuszenie.", {}),
            (["нъ", "избави", "нꙑ", "отъ", "неприꙗзни"], "Ale nas zbaw ode złego.", {}),
        ],
    },
    {
        "id": "jan", "title": "Ewangelia Jana", "icon": "Ⱄ", "color": "#212529", "track": "teksty",
        "words": [
            ("тьмѣ", "(w) ciemności", "ćma; ciemność", "тьма = ciemność (por. polskie „ćma”)."),
            ("свьтитъ", "świeci", "świeci", "Tak w Kodeksie Zografskim i Ewangeliarzu Ostromira."),
            ("оу", "u; przy", "u", None),
            ("се", "to; ono; oto", None, None),
        ],
        "sentences": [
            (["искони", "бѣ", "слово"], "Na początku było Słowo.", {}),
            (["и", "слово", "бѣ", "оу", "бога"], "A Słowo było u Boga.", {}),
            (["и", "богъ", "бѣ", "слово"], "I Bogiem było Słowo.", {}),
            (["се", "бѣ", "искони", "отъ", "бога"], "Ono było na początku u Boga.",
             {"оу": "W J 1,2 Kodeks Zografski ma tu отъ бога (dosł. „od Boga”, w znaczeniu „u Boga”)."}),
            (["и", "свѣтъ", "въ", "тьмѣ", "свьтитъ", "сѧ"], "A światłość w ciemności świeci.", {}),
        ],
    },
    # -------------------------------------------------------------- głagolica
    {
        "id": "glag1", "title": "Głagolica I", "icon": "Ⰰ", "color": "#F76707", "track": "glagolica",
        "requires": "cyr3",
        "letters": [
            ("ⰰ", "[a] (= а)", "азъ"), ("ⰱ", "[b] (= б)", "боукꙑ"), ("ⰲ", "[v] (= в)", "вѣдѣ"),
            ("ⰳ", "[ɡ] (= г)", "глаголи"), ("ⰴ", "[d] (= д)", "добро"), ("ⰵ", "[ɛ] (= е)", "ѥсть"),
            ("ⰶ", "[ʒ] (= ж)", "живѣте"), ("ⰷ", "[dz] (= ꙃ)", "ꙃѣло"), ("ⰸ", "[z] (= з)", "землꙗ"),
            ("ⰹ", "[i] (= і)", "ижеи"), ("ⰻ", "[i] (= и)", "и"), ("ⰽ", "[k] (= к)", "како"),
            ("ⰾ", "[l] (= л)", "людиѥ"), ("ⰿ", "[m] (= м)", "мꙑслите"),
        ],
    },
    {
        "id": "glag2", "title": "Głagolica II", "icon": "Ⱎ", "color": "#D9480F", "track": "glagolica",
        "letters": [
            ("ⱀ", "[n] (= н)", "нашь"), ("ⱁ", "[ɔ] (= о)", "онъ"), ("ⱂ", "[p] (= п)", "покои"),
            ("ⱃ", "[r] (= р)", "рьци"), ("ⱄ", "[s] (= с)", "слово"), ("ⱅ", "[t] (= т)", "тврьдо"),
            ("ⱆ", "[u] (= оу)", "оукъ"), ("ⱈ", "[x] (= х)", "хѣръ"), ("ⱋ", "[ʃt] (= щ)", "шта"),
            ("ⱌ", "[ts] (= ц)", "ци"), ("ⱍ", "[tʃ] (= ч)", "чрьвь"), ("ⱎ", "[ʃ] (= ш)", "ша"),
            ("ⱏ", "[ŭ] (= ъ)", "ѥръ"), ("ⱐ", "[ĭ] (= ь)", "ѥрь"),
            ("ⱑ", "[æ] / [ja] (= ѣ, ꙗ)", "ѣть"), ("ⱔ", "[ɛ̃] (= ѧ)", "ѧсъ"), ("ⱘ", "[ɔ̃] (= ѫ)", "ѫсъ"),
        ],
    },
    {
        "id": 'glag3', "title": 'Głagolica III', "icon": 'ⱚ', "color": '#D9480F', "track": 'glagolica',
        "letters": [
            ('ⱇ', '[f] (= ф)', 'фрьтъ'),
            ('ⱉ', '[ɔ] (= ѡ)', 'отъ'),
            ('ⱓ', '[ju] (= ю)', 'ю'),
            ('ⱗ', '[jɛ̃] (= ѩ)', 'ѩсъ'),
            ('ⱙ', '[jɔ̃] (= ѭ)', 'ѭсъ'),
            ('ⱚ', '[θ] (= ѳ)', 'ѳита'),
            ('ⱛ', '[i] / [y] (= ѵ)', 'ижица'),
        ],
    },
]

TRACKS = {
    "pismo": "Pismo: cyrylica",
    "jezyk": "Język",
    "teksty": "Teksty: modlitwa i Ewangelia",
    "glagolica": "Ⰳⰾⰰⰳⱁⰾⰹⱌⰰ  Głagolica",
}

# ---------------------------------------------------------------------------
# Wglądy w stylu Language Transfer: wyjaśnienie „dlaczego”, oparte na polskim,
# a potem kroki, w których uczeń sam buduje zdania: (polski, słowa, podpowiedź).
# ---------------------------------------------------------------------------
INSIGHTS = {
    "cyr4": [
        {"title": "Ta sama litera, kilka kształtów",
         "text": "Dawni pisarze skracali i łączyli litery, więc spotkasz kilka postaci tego samego dźwięku: оу, ѹ i ꙋ to wszystko [u]. "
                 "ѻ to okrągłe о, a ѿ to „от” zrośnięte w jedną literę. Nie musisz pisać wszystkich wariantów, ale czytając rękopisy musisz je poznawać.",
         "chain": []},
    ],
    "cyr5": [
        {"title": "Litery jako cyfry",
         "text": "Słowianie pożyczyli od Greków liczenie literami. Kreska nad literą (titło) mówi: to liczba. "
                 "а҃ = 1, в҃ = 2, г҃ = 3. Kolejność jest grecka, dlatego б i ж nie mają wartości: nie ma ich w greckim alfabecie. "
                 "Za to liczą się ꙃ (6) i ѳ (9), też z greckiego (stigma i theta).",
         "chain": []},
    ],
    "cyr6": [
        {"title": "Dziesiątki",
         "text": "Po dziewiątce idą dziesiątki: і҃ = 10, к҃ = 20, л҃ = 30. W liczbach 11–19 jedności stoją przed dziesiątką: "
                 "а҃і = 11, в҃і = 12. W pozostałych kolejność jest taka, jak mówisz: od większej do mniejszej.",
         "chain": []},
    ],
    "cyr7": [
        {"title": "Setki i tysiące",
         "text": "Setki zaczynają się od р҃ = 100. Tysiące oznacza znak ҂ przed literą: ҂а = 1000, ҂в = 2000. "
                 "Rok pisano więc literami, np. od stworzenia świata (według Bizantyńczyków).",
         "chain": []},
    ],
    "glag3": [
        {"title": "Litery z greckich słów",
         "text": "Głagolica miała też litery do słów greckich: ⱚ (fita, ѳ) i ⱛ (iżica, ѵ), jak cyrylica. "
                 "Ⱉ (ot) odpowiada ѡ, a ⱗ i ⱙ to nosówki z j: ѩ i ѭ.",
         "chain": []},
    ],
    "cyr1": [
        {"title": "Znasz więcej, niż myślisz",
         "text": "Połowa cyrylicy wygląda jak litery łacińskie: а, е, к, м, о, т czyta się prawie tak "
                 "samo. Uważaj tylko na „fałszywych przyjaciół”: в to w, н to n, а nie h.",
         "chain": []},
    ],
    "cyr2": [
        {"title": "Fałszywi przyjaciele",
         "text": "р to r, nie p. с to s, nie c. х to ch, nie x. Gdy tylko zobaczysz takie słowo, "
                 "przeczytaj je powoli, a zwykle wyjdzie znane polskie: слово = słowo, сꙑнъ = syn.",
         "chain": []},
        {"title": "Jery: ъ i ь",
         "text": "ъ i ь to bardzo krótkie samogłoski. W polskim jedne zniknęły (дъва → dwa), "
                 "a inne zmieniły się w „e” (дьнь → dzień, седмь → siedem). Na końcu słowa ъ "
                 "się nie wymawia: богъ czytaj „bog”.",
         "chain": []},
    ],
    "cyr3": [
        {"title": "Polski pamięta nosówki",
         "text": "ѫ i ѧ to samogłoski nosowe. Większość języków słowiańskich je straciła. "
                 "Polski je zachował! ѫ to zwykle nasze ą/ę (рѫка → ręka, зѫбъ → ząb), "
                 "a ѧ to ę (пѧть → pięć, имѧ → imię).",
         "chain": []},
        {"title": "ѣ: ie albo ia",
         "text": "ѣ (jać) to dawne długie e. W polskim dało „ie” (чловѣкъ → człowiek, хлѣбъ → chleb) "
                 "albo, przed twardą spółgłoską, „ia” lub „a” (вѣра → wiara, лѣсъ → las). Gdy "
                 "widzisz ѣ, spróbuj obu wersji: od razu rozpoznasz słowo.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Staropolski już to miał",
         "text": "SCS to najstarszy zapisany język słowiański, kuzyn polskiego. Staropolski "
                 "mówił „jeśm” (jestem) i „jeś” (jesteś). W SCS to ѥсмь i ѥси. Nie uczysz się "
                 "od zera, tylko cofasz się w czasie.",
         "chain": [
             ("Jestem człowiekiem.", ["азъ", "ѥсмь", "чловѣкъ"],
              "азъ = ja, ѥсмь = jestem (stpol. jeśm). Na końcu чловѣкъ."),
             ("Jesteś dobry.", ["тꙑ", "ѥси", "добръ"], "Zmień osobę: тꙑ (ty) i ѥси (jesteś)."),
             ("Bóg jest dobry.", ["богъ", "ѥсть", "добръ"], "O kimś trzecim: ѥсть, jak polskie „jest”."),
         ]},
        {"title": "„Nie jest” to jedno słowo",
         "text": "Zamiast „не ѥсть” SCS mówi нѣсть. To jak polskie „nie ma” ściągnięte w jedno. "
                 "Reszta zaprzeczeń działa jak w polskim: не przed słowem.",
         "chain": [
             ("On nie jest Bogiem.", ["онъ", "нѣсть", "богъ"], "онъ + нѣсть (nie jest) + богъ."),
         ]},
    ],
    "rodzina": [
        {"title": "Zaimek po rzeczowniku",
         "text": "Znasz „Ojcze nasz”. W SCS to normalny szyk: najpierw rzecz, potem „mój/nasz”: "
                 "отьць мои = mój ojciec. Rodzaj zgadza się jak po polsku: мои brat, моꙗ siostra.",
         "chain": [
             ("Mój ojciec jest dobry.", ["отьць", "мои", "добръ", "ѥсть"],
              "отьць мои, potem cecha i ѥсть na końcu: szyk jest swobodny, jak po polsku."),
             ("Moja siostra jest w domu.", ["сестра", "моꙗ", "ѥсть", "въ", "домоу"],
              "сестра → моꙗ (żeński). „W domu” = въ домоу, dokładnie jak polskie."),
         ]},
    ],
    "liczby": [
        {"title": "Liczby jak po polsku",
         "text": "пѧть, девѧть, десѧть: ѧ to ę, więc to pięć, dziewięć, dziesięć. I jak w "
                 "polskim, po „pięć” idzie dopełniacz: пѧть сꙑновъ = pięciu synów.",
         "chain": [
             ("Mam jeden dom.", ["азъ", "имамь", "ѥдинъ", "домъ"], "имамь = mam."),
             ("Ojciec ma pięciu synów.", ["отьць", "иматъ", "пѧть", "сꙑновъ"],
              "иматъ = ma. Po пѧть dopełniacz: сꙑновъ (synów)."),
         ]},
    ],
    "swiat": [
        {"title": "-ra- zamiast -ro-",
         "text": "Tam, gdzie polski ma -ro-, -ło-, SCS ma -ra-, -la-: глава = głowa, градъ = gród, "
                 "злато = złoto. Gdy słowo wydaje się obce, zamień -ra- na -ro- i przeczytaj jeszcze raz.",
         "chain": [
             ("Mój gród jest dobry.", ["градъ", "мои", "ѥсть", "добръ"], "градъ = gród."),
             ("Słońce jest na niebie.", ["слъньце", "ѥсть", "на", "небеси"],
              "„Na niebie” = на небеси (miejscownik). Pomyśl o „niebiosach”."),
         ]},
        {"title": "щ to polskie c",
         "text": "SCS щ (št) często odpowiada polskiemu c: ношть = noc, свѣща = świeca. "
                 "To jedna z cech „południowych” SCS: język powstał z dialektu okolic Salonik.",
         "chain": [("Dzień i noc.", ["дьнь", "и", "ношть"], "дьнь (dzień) и ношть (noc).")]},
    ],
    "czas": [
        {"title": "-ѫ to polskie -ę",
         "text": "Czasownik w 1. osobie kończy się na -ѫ: пишѫ, идѫ, виждѫ. Ponieważ ѫ to "
                 "nasze ę, to dosłownie piszę, idę, widzę! „Ty” ma -еши (piszesz), "
                 "„on” ma -етъ / -итъ (pisze, widzi).",
         "chain": [
             ("Piszę słowo.", ["азъ", "пишѫ", "слово"], "O sobie: -ѫ, jak „piszę”."),
             ("Co piszesz?", ["чьто", "пишеши"], "чьто = co. Do „ty”: пишеши."),
             ("On idzie do domu.", ["онъ", "идетъ", "въ", "домъ"], "„Do domu” = въ + biernik: въ домъ."),
         ]},
        {"title": "Przypadki działają jak w polskim",
         "text": "Po „w” z ruchem stoi biernik, bez ruchu miejscownik, dokładnie jak w polskim: "
                 "въ домъ (do domu), въ домоу (w domu). „Wierzę w Boga” to въ бога.",
         "chain": [("Wierzę w Boga.", ["вѣроуѭ", "въ", "бога"], "вѣроуѭ (wierzę) + въ бога.")]},
    ],
    "przypadki": [
        {"title": "Wołacz: polski go zachował",
         "text": "Większość języków słowiańskich zgubiła wołacz. Polski nie: „Ojcze!”, „Boże!”, "
                 "„człowiecze!”. SCS ma te same formy: отьче, боже, чловѣче. Siedem przypadków, "
                 "jak u nas.",
         "chain": [
             ("Ojcze nasz.", ["отьче", "нашь"], "Wołacz отьче, potem нашь (szyk jak w modlitwie)."),
             ("Panie, zmiłuj się.", ["господи", "помилоуи"], "господи = Panie! (wołacz)."),
             ("Chwała Bogu.", ["слава", "богоу"], "Komu? Celownik: богоу, jak „Bogu”."),
         ]},
    ],
    "aoryst": [
        {"title": "Czas, który polski zgubił",
         "text": "SCS ma aoryst: krótki czas przeszły. рече = rzekł (biblijne „rzecze”). "
                 "Polski go zgubił, ale zostawił ślad: „by” w „zrobiłbym” to stary aoryst od "
                 "„być” (бꙑ). A бѣ to „był/było”.",
         "chain": [
             ("Bóg rzekł.", ["богъ", "рече"], "богъ + рече."),
             ("Na początku było Słowo.", ["искони", "бѣ", "слово"],
              "искони = na początku, бѣ = było."),
             ("I stała się światłość.", ["и", "бꙑстъ", "свѣтъ"], "бꙑстъ = stało się."),
         ]},
    ],
    "dualis": [
        {"title": "Liczba podwójna: ślad w polskim",
         "text": "SCS ma osobną liczbę dla dwóch rzeczy. Polski ją zgubił, ale nie całkiem: "
                 "„ręce”, „oczy”, „uszy” to dawne formy podwójne! Dlatego mówimy „ręce”, a nie "
                 "„ręki”. Jest nawet zaimek вѣ: „my dwaj”.",
         "chain": [
             ("Mam dwie ręce.", ["имамь", "двѣ", "рѫцѣ"], "двѣ (dwie) + рѫцѣ (jak „ręce”)."),
             ("Dwaj bracia.", ["дъва", "брата"], "Liczba podwójna od братъ: брата."),
             ("My dwaj jesteśmy braćmi.", ["вѣ", "ѥсвѣ", "брата"], "вѣ (my dwaj) + ѥсвѣ (jesteśmy)."),
         ]},
    ],
    "ojcze1": [
        {"title": "Modlitwę już znasz",
         "text": "„Ojcze nasz” po polsku i w SCS to prawie ten sam tekst: zostawiliśmy nawet "
                 "szyk i wołacz. Tekst według Kodeksu Mariańskiego (XI w.), w pisowni znormalizowanej. Czytaj słowo po słowie.",
         "chain": [
             ("Ojcze nasz, któryś jest w niebiosach.", ["отьче", "нашь", "иже", "ѥси", "на", "небесехъ"],
              "иже = który (stpol. „iże”), ѥси = jesteś."),
             ("Niech się święci imię twoje.", ["да", "свѧтитъ", "сѧ", "имѧ", "твоѥ"],
              "да = niech, сѧ = się."),
         ]},
    ],
    "ojcze2": [
        {"title": "Dług to wina",
         "text": "„Odpuść nam nasze winy” w SCS to dosłownie „odpuść nam nasze długi” (длъгꙑ). "
                 "Stąd polskie „dłużnik” w starszych przekładach. Tekst czyta się jak staropolski.",
         "chain": [
             ("I odpuść nam nasze winy.", ["и", "отъпоусти", "намъ", "длъгꙑ", "нашѧ"],
              "отъпоусти = odpuść, длъгꙑ = długi."),
         ]},
    ],
    "jan": [
        {"title": "Pierwsze zdanie przekładu",
         "text": "Według Żywota Konstantyna (Cyryla), gdy powstało pismo, zaczął on pisać od słów "
                 "„Искони бѣ слово и слово бѣ оу бога”. To więc prawdopodobnie pierwsze zdanie "
                 "zapisane po słowiańsku.",
         "chain": [
             ("Na początku było Słowo.", ["искони", "бѣ", "слово"], "Już to znasz z „czasu przeszłego”."),
             ("A światłość w ciemności świeci.", ["и", "свѣтъ", "въ", "тьмѣ", "свьтитъ", "сѧ"],
              "свѣтъ = światło, тьмѣ = w ciemności, свьтитъ сѧ = świeci się."),
         ]},
    ],
    "glag1": [
        {"title": "Alfabet, który jest zdaniem",
         "text": "Nazwy liter to słowa: азъ боукꙑ вѣдѣ = „ja litery znam”, глаголи добро ѥсть = "
                 "„mów, dobro jest”. Głagolicę ułożył Konstanty ok. 863 r. Litery są nowe, "
                 "ale dźwięki znasz już z cyrylicy.",
         "chain": []},
    ],
    "glag2": [
        {"title": "Z głagolicy do cyrylicy",
         "text": "Cyrylica powstała później i zastąpiła głagolicę prawie wszędzie. Kolejność "
                 "liter jest ta sama, więc gdy znasz nazwę litery, wiesz, jak ją przeczytać.",
         "chain": []},
    ],
}

SOUND_INSIGHT = {
    "title": "Słuchaj polskim uchem",
    "text": "Każda „dziwna” litera SCS ma swój ślad w polskim. ѫ i ѧ to nasze ą/ę, ѣ to ie/ia, "
            "ъ i ь zniknęły albo dały „e”, щ to c. Gdy zgadujesz brakującą literę, pomyśl o "
            "polskim słowie.",
}

# Litery, które wyróżniamy kolorem w całej aplikacji.
SPECIAL_COLORS = {
    "ѫ": "A8321E", "ѧ": "A8321E", "ѭ": "A8321E", "ѩ": "A8321E",
    "ѣ": "6B3F5E",
    "ъ": "97846A", "ь": "97846A", "ꙑ": "2E4A7A",
    "щ": "3D6B4F",
}

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "powitanie", "title": "Powitanie", "partner": "Brat Gorazd", "avatar": "Г",
        "requires": "slowa",
        "turns": [
            {"bot": ["радоуи", "сѧ", "!"], "en": "Witaj! (raduj się)",
             "options": [(["радоуи", "сѧ", "!"], True, None),
                         (["не", "!"], False, "не to „nie”. Odpowiedz pozdrowieniem: радоуи сѧ."),
                         (["нѣсть"], False, "нѣсть to „nie jest”. Spróbuj odpowiedzieć tym samym pozdrowieniem.")]},
            {"bot": ["богъ", "ѥсть", "добръ", "."], "en": "Bóg jest dobry.",
             "options": [(["да", ",", "богъ", "ѥсть", "добръ"], True, None),
                         (["да", ",", "богъ", "ѥси", "добръ"], False, "ѥси to „jesteś”. O Bogu (on): ѥсть."),
                         (["да", ",", "богъ", "ѥсмь", "добръ"], False, "ѥсмь to „jestem”. O Bogu: ѥсть.")]},
            {"bot": ["тꙑ", "ѥси", "чловѣкъ", "добръ", "."], "en": "Jesteś dobrym człowiekiem.",
             "options": [(["и", "тꙑ", "ѥси", "добръ"], True, None),
                         (["и", "тꙑ", "ѥсть", "добръ"], False, "Do „ty”: ѥси (jesteś), nie ѥсть (jest).")]},
            {"bot": ["миръ", "тебѣ", "!"], "en": "Pokój tobie!",
             "build": (["миръ", "тебѣ"], "Pokój tobie!")},
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "partner": "Mnich Naum", "avatar": "Н",
        "requires": "rodzina",
        "turns": [
            {"bot": ["къто", "ѥсть", "онъ", "?"], "en": "Kim on jest?",
             "options": [(["онъ", "ѥсть", "братъ", "мои"], True, None),
                         (["онъ", "ѥсмь", "братъ", "мои"], False, "ѥсмь to „jestem”. O nim: ѥсть."),
                         (["онъ", "ѥсть", "братъ", "моꙗ"], False, "братъ jest męski: мои, nie моꙗ.")]},
            {"bot": ["а", "сестра", "твоꙗ", "?"], "en": "A twoja siostra?",
             "build": (["сестра", "моꙗ", "ѥсть", "въ", "домоу"], "Moja siostra jest w domu.")},
            {"bot": ["добро", "!"], "en": "Dobrze!",
             "options": [(["радоуи", "сѧ"], True, None),
                         (["не", "знаѭ"], False, "Nie musisz niczego wiedzieć, to pożegnanie. Spróbuj: радоуи сѧ.")]},
        ],
    },
    {
        "id": "skryptorium", "title": "W skryptorium", "partner": "Konstanty", "avatar": "К",
        "requires": "czas",
        "turns": [
            {"bot": ["чьто", "пишеши", "?"], "en": "Co piszesz?",
             "options": [(["пишѫ", "слово"], True, None),
                         (["пишетъ", "слово"], False, "пишетъ to „pisze” (on). O sobie: пишѫ, jak „piszę”."),
                         (["пишеши", "слово"], False, "пишеши to „piszesz”. Odpowiadasz o sobie: пишѫ.")]},
            {"bot": ["знаѥши", "ли", "боукꙑ", "?"], "en": "Czy znasz litery?",
             "options": [(["знаѭ"], True, None),
                         (["знаѥтъ"], False, "знаѥтъ to „zna” (on). O sobie: знаѭ."),
                         (["не", "знаѥши"], False, "знаѥши to „znasz”. O sobie: знаѭ.")],
             "note": "ли to partykuła pytajna, jak staropolskie „-li” (np. „znaszli?”)."},
            {"bot": ["къто", "глаголетъ", "?"], "en": "Kto mówi?",
             "build": (["азъ", "глаголѭ"], "Ja mówię.")},
            {"bot": ["добро", "!", "вѣроуѥши", "ли", "?"], "en": "Dobrze! Czy wierzysz?",
             "options": [(["вѣроуѭ", "въ", "бога"], True, None),
                         (["вѣроуѭ", "въ", "богъ"], False, "Po „въ” biernik: въ бога, jak „w Boga”.")]},
        ],
    },
    {
        "id": "modlitwa", "title": "Modlitwa", "partner": "Biskup Metody", "avatar": "М",
        "requires": "przypadki",
        "turns": [
            {"bot": ["къто", "ѥсть", "отьць", "нашь", "?"], "en": "Kto jest naszym ojcem?",
             "options": [(["богъ", "ѥсть", "отьць", "нашь"], True, None),
                         (["бога", "ѥсть", "отьць", "нашь"], False,
                          "бога to „Boga” (biernik). Podmiot w mianowniku: богъ.")]},
            {"bot": ["чьто", "глаголеши", "богоу", "?"], "en": "Co mówisz do Boga?",
             "options": [(["боже", ",", "помилоуи"], True, None),
                         (["богъ", ",", "помилоуи"], False, "Zwracasz się do Boga: wołacz боже, jak „Boże!”."),
                         (["бога", ",", "помилоуи"], False, "Zwracasz się do kogoś: wołacz боже.")]},
            {"bot": ["добрѣ", "!"], "en": "Dobrze!",
             "build": (["слава", "богоу"], "Chwała Bogu.")},
        ],
    },
    {
        "id": "ewangelia", "title": "Lekcja Ewangelii", "partner": "Konstanty", "avatar": "К",
        "requires": "jan",
        "turns": [
            {"bot": ["чьто", "бѣ", "искони", "?"], "en": "Co było na początku?",
             "options": [(["искони", "бѣ", "слово"], True, None),
                         (["искони", "ѥсть", "слово"], False, "Mowa o przeszłości: бѣ (było), nie ѥсть (jest).")]},
            {"bot": ["а", "чьто", "свьтитъ", "сѧ", "въ", "тьмѣ", "?"], "en": "A co świeci w ciemności?",
             "build": (["свѣтъ", "свьтитъ", "сѧ", "въ", "тьмѣ"], "Światłość świeci w ciemności.")},
            {"bot": ["добрѣ", "глаголеши", "!"], "en": "Dobrze mówisz!",
             "options": [(["слава", "богоу"], True, None),
                         (["слава", "бога"], False, "Komu chwała? Celownik: богоу.")]},
        ],
    },
]

# Słowa, które są tylko w rozmowach: forma → znaczenie.
CHAT_EXTRA = {
    "тебѣ": "tobie",
    "а": "a",
    "знаѥши": "znasz",
    "ли": "czy (partykuła pytajna)",
    "боукꙑ": "litery",
    "вѣроуѥши": "wierzysz",
    "глаголеши": "mówisz",
    "добрѣ": "dobrze",
}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Gramatyka: wzory odmian. Wpis: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje i zaimki, form = imiesłowy, formy podstawowe, stopniowanie itp.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------
PARADIGM_LABELS = {
    'os': ['азъ', 'тꙑ', 'онъ', 'мꙑ', 'вꙑ', 'они'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'narzędnik lp.', 'miejscownik lp.', 'wołacz lp.'],
    'im': ['im. teraźniejszy czynny (m.)', 'im. teraźniejszy bierny', 'im. przeszły czynny I', 'im. przeszły czynny II (na -лъ)', 'im. przeszły bierny'],
    'przyp6': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'narzędnik', 'miejscownik'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'нести (nieść): I koniugacja', 'os', 'несѫ; несеши; несетъ; несемъ; несете; несѫтъ', 'Liczbę podwójną pomijamy. Końcówki: -ѫ, -еши, -етъ, -емъ, -ете, -ѫтъ.'),
    ('conj', 'Wzory koniugacji', 'знати (znać): III koniugacja', 'os', 'знаѭ; знаѥши; знаѥтъ; знаѥмъ; знаѥте; знаѭтъ', None),
    ('conj', 'Wzory koniugacji', 'хвалити (chwalić): IV koniugacja', 'os', 'хвалѭ; хвалиши; хвалитъ; хвалимъ; хвалите; хвалѧтъ', 'IV koniugacja: -и- w temacie, 3. osoba lm. -ѧтъ.'),
    ('conj', 'Czasowniki nieregularne', 'бꙑти (być)', 'os', 'ѥсмь; ѥси; ѥстъ; ѥсмъ; ѥсте; сѫтъ', 'Czasownik atematyczny: końcówka -мь w 1. osobie.'),
    ('conj', 'Czasowniki nieregularne', 'дати (dać)', 'os', 'дамь; даси; дастъ; дамъ; дасте; дадѧтъ', None),
    ('conj', 'Czasowniki nieregularne', 'вѣдѣти (wiedzieć)', 'os', 'вѣмь; вѣси; вѣстъ; вѣмъ; вѣсте; вѣдѧтъ', None),
    ('conj', 'Czasowniki nieregularne', 'ꙗсти (jeść)', 'os', 'ꙗмь; ꙗси; ꙗстъ; ꙗмъ; ꙗсте; ꙗдѧтъ', None),
    ('conj', 'Czasowniki nieregularne', 'имѣти (mieć)', 'os', 'имамь; имаши; иматъ; имамъ; имате; имѫтъ', None),
    ('decl', 'Wzory deklinacji', 'рабъ (sługa): temat na -o-', 'przyp', 'рабъ; раба; рабоу; рабъ; рабомь; рабѣ; рабе', None),
    ('decl', 'Wzory deklinacji', 'мѫжь (mąż): temat na -jo-', 'przyp', 'мѫжь; мѫжа; мѫжоу; мѫжь; мѫжемь; мѫжи; мѫжоу', 'Odmiana miękka: -емь, -и.'),
    ('decl', 'Wzory deklinacji', 'жена (kobieta): temat na -a-', 'przyp', 'жена; женꙑ; женѣ; женѫ; женоѭ; женѣ; жено', None),
    ('decl', 'Wzory deklinacji', 'село (wieś): nijaki', 'przyp', 'село; села; селоу; село; селомь; селѣ; село', None),
    ('decl', 'Wzory deklinacji', 'кость (kość): temat na -i-', 'przyp', 'кость; кости; кости; кость; костиѭ; кости; кости', None),
    ('decl', 'Wyjątki', 'сꙑнъ (syn): temat na -u-', 'przyp', 'сꙑнъ; сꙑноу; сꙑнови; сꙑнъ; сꙑнъмь; сꙑноу; сꙑноу', 'Stara odmiana na -u-: dopełniacz -оу, celownik -ови.'),
    ('form', 'Imiesłowy', 'нести (nieść)', 'im', 'несꙑ; несомъ; несъ; неслъ; несенъ', None),
    ('form', 'Imiesłowy', 'хвалити (chwalić)', 'im', 'хвалѧ; хвалимъ; хваль; хвалилъ; хвалѥнъ', None),
    ('form', 'Imiesłowy', 'знати (znać)', 'im', 'знаѩ; знаѥмъ; знавъ; зналъ; знанъ', None),
    ('conj', 'Czas przeszły', 'нести: aoryst', 'os', 'несохъ; несе; несе; несохомъ; несосте; несошѧ', None),
    ('conj', 'Czas przeszły', 'бꙑти: aoryst', 'os', 'бꙑхъ; бꙑ; бꙑ; бꙑхомъ; бꙑсте; бꙑшѧ', None),
    ('decl', 'Zaimki', 'азъ (ja)', 'przyp6', 'азъ; мене; мьнѣ; мѧ; мъноѭ; мьнѣ', None),
]

"""Treść kursu: język staro-cerkiewno-słowiański (SCS) dla Polaków.

Słowo:   (forma cyrylicą, znaczenie po polsku, polski krewny lub None, skojarzenie lub None)
         Transliteracja i zapis głagolicą powstają automatycznie (engine.py).
Litera:  (litera, opis dźwięku po polsku, nazwa litery)
Zdanie:  (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
         Każde słowo w zdaniu musi występować w kursie.

Pisownia znormalizowana, jak w podręcznikach (np. Leskien). Każde słowo
w kursie musi mieć niepowtarzalną formę.
"""

UNITS = [
    # ------------------------------------------------------------------ pismo
    {
        "id": "cyr1", "title": "Cyrylica I", "icon": "А", "color": "#12B886", "track": "pismo",
        "letters": [
            ("а", "[a]", "азъ"), ("б", "[b]", "боукꙑ"), ("в", "[v]", "вѣдѣ"),
            ("г", "[ɡ]", "глаголи"), ("д", "[d]", "добро"), ("е", "[ɛ]", "ѥсть"),
            ("ж", "[ʒ] (ż)", "живѣте"), ("з", "[z]", "землꙗ"), ("и", "[i]", "иже"),
            ("к", "[k]", "како"), ("л", "[l]", "людиѥ"), ("м", "[m]", "мꙑслите"),
            ("н", "[n]", "нашь"), ("о", "[ɔ]", "онъ"),
        ],
    },
    {
        "id": "cyr2", "title": "Cyrylica II", "icon": "Ш", "color": "#20C997", "track": "pismo",
        "letters": [
            ("п", "[p]", "покои"), ("р", "[r]", "рьци"), ("с", "[s]", "слово"),
            ("т", "[t]", "тврьдо"), ("оу", "[u]", "оукъ"),
            ("ф", "[f]", "фрьтъ"), ("х", "[x] (ch)", "хѣръ"), ("ц", "[ts] (c)", "ци"),
            ("ч", "[tʃ] (cz)", "чрьвь"), ("ш", "[ʃ] (sz)", "ша"), ("щ", "[ʃt] (szt)", "шта"),
            ("ъ", "[ŭ] (jer twardy)", "ѥръ"),
            ("ь", "[ĭ] (jer miękki)", "ѥрь"),
            ("ꙑ", "[ɨ] (y)", "ѥрꙑ"),
        ],
    },
    {
        "id": "cyr3", "title": "Cyrylica III", "icon": "Ѫ", "color": "#0CA678", "track": "pismo",
        "letters": [
            ("ѣ", "[æ] lub [ja] (jać)", "ѣть"),
            ("ѧ", "[ɛ̃] (ę)", "ѧсъ малъ"),
            ("ѫ", "[ɔ̃] (ǫ)", "ѫсъ голѣмъ"),
            ("ѩ", "[jɛ̃] (ję)", "ѩсъ"),
            ("ѭ", "[jɔ̃] (jǫ)", "ѭсъ"),
            ("ѥ", "[jɛ]", "ѥ"), ("ꙗ", "[ja]", "ꙗ"), ("ю", "[ju]", "ю"),
            ("ꙃ", "[dz] (dzěło)", "ꙃѣло"), ("і", "[i] (zapis grecki)", "і"),
            ("ѳ", "[θ] (słowa greckie)", "ѳита"), ("ѵ", "[i] / [y] (słowa greckie)", "ижица"),
            ("ѡ", "[ɔ] (słowa greckie)", "отъ"), ("ѯ", "[ks]", "кси"), ("ѱ", "[ps]", "пси"),
        ],
    },
    # --------------------------------------------------------------- język
    {
        "id": 'cyr4', "title": 'Cyrylica IV: warianty', "icon": 'ѹ', "color": '#0CA678', "track": 'pismo',
        "letters": [
            ('ѹ', '[u] (= оу), jedna litera zamiast dwóch', 'оукъ'),
            ('ꙋ', '[u] (= оу), monogram „uk” z rękopisów', 'оукъ'),
            ('ѻ', '[ɔ] (= о), okrągłe o ze starych rękopisów', 'онъ'),
            ('ѿ', '[ɔt] (= ѡ + т), ligatura „ot”', 'отъ'),
            ('ѽ', '[ɔ] okrzyk „och!”', 'ѽ'),
            ('ꙁ', '[z] (= з), wariant z dawnych rękopisów', 'землꙗ'),
            ('є', '[ɛ] (= е), wariant z rękopisów', 'ѥсть'),
        ],
    },
    {
        "id": 'cyr5', "title": 'Liczby cyrylickie I', "icon": 'а҃', "color": '#0CA678', "track": 'pismo', "kind": "number",
        "letters": [
            ('а҃', '1', 'азъ'),
            ('в҃', '2', 'вѣдѣ'),
            ('г҃', '3', 'глаголи'),
            ('д҃', '4', 'добро'),
            ('є҃', '5', 'ѥсть'),
            ('ꙃ҃', '6', 'ꙃѣло'),
            ('з҃', '7', 'землꙗ'),
            ('и҃', '8', 'иже'),
            ('ѳ҃', '9', 'ѳита'),
        ],
    },
    {
        "id": 'cyr6', "title": 'Liczby cyrylickie II', "icon": 'к҃', "color": '#0CA678', "track": 'pismo', "kind": "number",
        "letters": [
            ('і҃', '10', 'ижеи'),
            ('к҃', '20', 'како'),
            ('л҃', '30', 'людиѥ'),
            ('м҃', '40', 'мꙑслите'),
            ('н҃', '50', 'нашь'),
            ('ѯ҃', '60', 'кси'),
            ('ѻ҃', '70', 'онъ'),
            ('п҃', '80', 'покои'),
            ('ч҃', '90', 'чрьвь'),
        ],
    },
    {
        "id": 'cyr7', "title": 'Liczby cyrylickie III', "icon": 'р҃', "color": '#0CA678', "track": 'pismo', "kind": "number",
        "letters": [
            ('р҃', '100', 'рьци'),
            ('с҃', '200', 'слово'),
            ('т҃', '300', 'тврьдо'),
            ('у҃', '400', 'оукъ'),
            ('ф҃', '500', 'фрьтъ'),
            ('х҃', '600', 'хѣръ'),
            ('ѱ҃', '700', 'пси'),
            ('ѡ҃', '800', 'отъ'),
            ('ц҃', '900', 'ци'),
            ('҂а', '1000', 'азъ'),
        ],
    },
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "Азъ", "color": "#4DABF7", "track": "jezyk",
        "requires": "cyr2",
        "words": [
            ("азъ", "ja", "jaźń", "Stąd staropolskie „jaźń”. Także nazwa pierwszej litery."),
            ("тꙑ", "ty", "ty", None),
            ("онъ", "on", "on", None),
            ("мꙑ", "my", "my", None),
            ("и", "i; także", "i", None),
            ("не", "nie", "nie", None),
            ("да", "tak; niech", "da (ros.)", "Ten sam wyraz co rosyjskie „da”."),
            ("радоуи", "raduj (się)", "raduj", "„Радоуи сѧ” to powitanie: dosłownie „raduj się”."),
            ("сѧ", "się", "się", "ѧ = ę, więc сѧ to dosłownie „sę”: polskie „się”."),
            ("миръ", "pokój; świat", "mir", "Staropolskie „mir” to pokój i poważanie."),
            ("богъ", "Bóg", "Bóg", None),
            ("чловѣкъ", "człowiek", "człowiek", "ѣ to tu polskie „ie”: člověkъ → człowiek."),
            ("слово", "słowo", "słowo", None),
            ("добръ", "dobry", "dobry", None),
            ("добро", "dobre; dobro", "dobro", "Rodzaj nijaki, do „слово”."),
            ("ѥсмь", "jestem", "jeśm (stpol.)", "Staropolski miał „jeśm” = jestem."),
            ("ѥси", "jesteś", "jeś (stpol.)", None),
            ("ѥсть", "jest", "jest", None),
            ("нѣсть", "nie jest; nie ma", "nie jest", "Ściągnięte „не ѥсть”."),
        ],
        "sentences": [
            (["азъ", "ѥсмь", "чловѣкъ"], "Jestem człowiekiem.",
             {"ѥси": "ѥси to „jesteś”. O sobie: ѥсмь (staropolskie „jeśm”).",
              "ѥсть": "ѥсть to „jest” (on). O sobie: ѥсмь."}),
            (["тꙑ", "ѥси", "добръ"], "Jesteś dobry.",
             {"ѥсмь": "ѥсмь to „jestem”. Do „ty”: ѥси (jak staropolskie „jeś”)."}),
            (["богъ", "ѥсть", "добръ"], "Bóg jest dobry.", {}),
            (["слово", "ѥсть", "добро"], "Słowo jest dobre.",
             {"добръ": "слово jest rodzaju nijakiego, jak po polsku: „dobre słowo”, więc добро."}),
            (["онъ", "нѣсть", "богъ"], "On nie jest Bogiem.",
             {"не": "„Nie jest” to w SCS jedno słowo: нѣсть (z „не ѥсть”)."}),
            (["радоуи", "сѧ"], "Witaj! (dosł. raduj się)", {}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "Домъ", "color": "#CC5DE8", "track": "jezyk",
        "words": [
            ("отьць", "ojciec", "ojciec", "ь to krótkie i, które w polskim zmieniło się w „e” lub znikło."),
            ("мати", "matka", "mać (stpol.)", None),
            ("сꙑнъ", "syn", "syn", None),
            ("дъшти", "córka", None, "Polski poszedł tu inną drogą (córka); por. rosyjskie „doč”."),
            ("братъ", "brat", "brat", None),
            ("сестра", "siostra", "siostra", None),
            ("мѫжь", "mąż; mężczyzna", "mąż", "ѫ = ą! мѫжь to dosłownie „mąż”."),
            ("жена", "kobieta; żona", "żona", None),
            ("дѣва", "dziewica; panna", "dziewa (stpol.)", "ѣ → ie: děva → dziewa, dziewica."),
            ("домъ", "dom", "dom", None),
            ("домоу", "(w) domu · miejscownik", "domu", "Miejscownik: въ домоу = w domu. Dokładnie jak po polsku!"),
            ("въ", "w; do", "w", "ъ na końcu się nie wymawia (później zanikł)."),
            ("людиѥ", "ludzie", "ludzie", None),
            ("мои", "mój", "mój", None),
            ("моꙗ", "moja", "moja", None),
            ("твои", "twój", "twój", None),
            ("твоꙗ", "twoja", "twoja", None),
        ],
        "sentences": [
            (["отьць", "мои", "добръ", "ѥсть"], "Mój ojciec jest dobry.",
             {"моꙗ": "отьць jest rodzaju męskiego: мои (mój), nie моꙗ (moja)."}),
            (["тꙑ", "ѥси", "братъ", "мои"], "Jesteś moim bratem.", {}),
            (["сестра", "моꙗ", "ѥсть", "въ", "домоу"], "Moja siostra jest w domu.",
             {"мои": "сестра jest rodzaju żeńskiego: моꙗ (moja).",
              "домъ": "„W domu” to miejscownik: въ домоу, jak polskie „w domu”."}),
            (["мати", "твоꙗ", "ѥсть", "въ", "домоу"], "Twoja matka jest w domu.", {}),
            (["онъ", "ѥсть", "мѫжь", "добръ"], "On jest dobrym mężem.", {}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "Пѧть", "color": "#FF922B", "track": "jezyk",
        "words": [
            ("ѥдинъ", "jeden", "jeden", None),
            ("дъва", "dwa", "dwa", "ъ (krótkie u) zanikło: dъva → dwa."),
            ("триѥ", "trzy", "trzy", None),
            ("четꙑре", "cztery", "cztery", None),
            ("пѧть", "pięć", "pięć", "ѧ = ę: pętь → pięć."),
            ("шесть", "sześć", "sześć", None),
            ("седмь", "siedem", "siedem", "Jer ь zmienił się w polskie „e”: sedmь → siedem."),
            ("осмь", "osiem", "osiem", None),
            ("девѧть", "dziewięć", "dziewięć", "ѧ = ę: devętь → dziewięć."),
            ("десѧть", "dziesięć", "dziesięć", "ѧ = ę: desętь → dziesięć."),
            ("имамь", "mam", "mam", None),
            ("иматъ", "ma", "ma", None),
            ("сꙑновъ", "synów", "synów", "Dopełniacz l.mn. Ta sama końcówka co polskie „-ów”!"),
        ],
        "sentences": [
            (["азъ", "имамь", "ѥдинъ", "домъ"], "Mam jeden dom.",
             {"иматъ": "иматъ to „ma” (on). O sobie: имамь (mam)."}),
            (["отьць", "иматъ", "пѧть", "сꙑновъ"], "Ojciec ma pięciu synów.",
             {"сꙑнъ": "Po „pięć” dopełniacz, jak po polsku „pięciu synów”: сꙑновъ."}),
            (["мати", "иматъ", "шесть", "сꙑновъ"], "Matka ma sześciu synów.", {}),
        ],
    },
    {
        "id": "swiat", "title": "Ciało i świat", "icon": "Рѫка", "color": "#F25F5C", "track": "jezyk",
        "words": [
            ("глава", "głowa", "głowa", "SCS -ra-/-la- = polskie -ro-/-ło-: глава → głowa."),
            ("рѫка", "ręka", "ręka", "ѫ = ą/ę: rǫka → ręka."),
            ("нога", "noga", "noga", None),
            ("око", "oko", "oko", None),
            ("оухо", "ucho", "ucho", None),
            ("зѫбъ", "ząb", "ząb", "ѫ = ą: zǫbъ → ząb."),
            ("срьдьце", "serce", "serce", None),
            ("небо", "niebo", "niebo", None),
            ("небеси", "na niebie (miejscownik)", "niebiosa", "Temat небес-: stąd polskie „niebiosa”."),
            ("на", "na", "na", None),
            ("землꙗ", "ziemia", "ziemia", None),
            ("земли", "(na) ziemi · miejscownik", "ziemi", None),
            ("вода", "woda", "woda", None),
            ("огнь", "ogień", "ogień", None),
            ("дьнь", "dzień", "dzień", "Dwa jery: dьnь. Pierwszy dał polskie „e” (dzień), drugi zniknął."),
            ("ношть", "noc", "noc", "SCS щ (št) = polskie c: noštь → noc."),
            ("слъньце", "słońce", "słońce", None),
            ("лѣсъ", "las", "las", "ѣ → a: lěsъ → las."),
            ("мѣсѧць", "księżyc; miesiąc", "miesiąc", "ѣ → ie, ѧ → ą: měsęcь → miesiąc."),
            ("градъ", "gród; miasto", "gród", "-ra- = polskie -ro-: градъ → gród."),
            ("злато", "złoto", "złoto", "-la- = polskie -ło-: злато → złoto."),
        ],
        "sentences": [
            (["небо", "и", "землꙗ"], "Niebo i ziemia.", {}),
            (["дьнь", "и", "ношть"], "Dzień i noc.", {}),
            (["слъньце", "ѥсть", "на", "небеси"], "Słońce jest na niebie.",
             {"небо": "„Na niebie” to miejscownik: на небеси."}),
            (["градъ", "мои", "ѥсть", "добръ"], "Mój gród jest dobry.", {}),
        ],
    },
    {
        "id": "czas", "title": "Czasowniki", "icon": "Пишѫ", "color": "#5C7CFA", "track": "jezyk",
        "words": [
            ("пишѫ", "piszę", "piszę", "Końcówka -ѫ (ǫ) = polskie -ę: pišǫ → piszę."),
            ("пишеши", "piszesz", "piszesz", None),
            ("пишетъ", "pisze", "pisze", None),
            ("глаголѭ", "mówię", "głagoł", "глаголати = mówić. Stąd nazwa głagolicy!"),
            ("глаголетъ", "mówi", None, None),
            ("знаѭ", "znam; wiem", "znam", None),
            ("знаѥтъ", "zna; wie", "zna", None),
            ("идѫ", "idę", "idę", "ѫ = ę: idǫ → idę."),
            ("идетъ", "idzie", "idzie", None),
            ("виждѫ", "widzę", "widzę", "жд to polskie dz: viždǫ → widzę."),
            ("видитъ", "widzi", "widzi", None),
            ("вѣроуѭ", "wierzę", "wierzę", "ѣ → ie: věrujǫ → wierzę."),
            ("чьто", "co", "co", "Polskie „co” powstało z čьto."),
            ("къто", "kto", "kto", None),
            ("бога", "Boga (biernik)", "Boga", "Jak po polsku: „wierzę w Boga”."),
            ("добрѫ", "dobrą (biernik)", "dobrą", None),
            ("рѫкѫ", "rękę (biernik)", "rękę", None),
        ],
        "sentences": [
            (["азъ", "пишѫ", "слово"], "Piszę słowo.",
             {"пишетъ": "пишетъ to „pisze” (on). O sobie: пишѫ, jak „piszę”.",
              "пишеши": "пишеши to „piszesz”. O sobie: пишѫ."}),
            (["онъ", "идетъ", "въ", "домъ"], "On idzie do domu.",
             {"идѫ": "идѫ to „idę”. O nim: идетъ (idzie).",
              "домоу": "„Do domu” = въ + biernik: въ домъ. домоу to „w domu”."}),
            (["вѣроуѭ", "въ", "бога"], "Wierzę w Boga.",
             {"богъ": "Po „въ” (w) biernik, jak po polsku: въ бога = w Boga."}),
            (["къто", "глаголетъ"], "Kto mówi?", {}),
            (["азъ", "не", "знаѭ"], "Nie wiem.", {}),
            (["чьто", "пишеши"], "Co piszesz?", {"пишѫ": "Pytasz kogoś: пишеши (piszesz)."}),
            (["имамь", "добрѫ", "рѫкѫ"], "Mam dobrą rękę.",
             {"рѫка": "Co mam? Biernik: рѫкѫ (rękę). ѫ na końcu to polskie -ę!"}),
            (["виждѫ", "слъньце"], "Widzę słońce.", {"видитъ": "видитъ to „widzi”. O sobie: виждѫ (widzę)."}),
        ],
    },
    {
        "id": "przypadki", "title": "Przypadki", "icon": "Отьче", "color": "#E64980", "track": "jezyk",
        "words": [
            ("отьче", "ojcze! (wołacz)", "ojcze", "Wołacz przetrwał w polskim: ojcze, Boże, człowiecze."),
            ("боже", "Boże! (wołacz)", "Boże", None),
            ("чловѣче", "człowieku! (wołacz)", "człowiecze", None),
            ("господь", "Pan", "gospodarz", "Stąd polskie „gospodarz” i „gospoda”."),
            ("господи", "Panie! (wołacz)", None, None),
            ("помилоуи", "zmiłuj się", "zmiłuj", None),
            ("нашь", "nasz", "nasz", None),
            ("имѧ", "imię", "imię", "ѧ = ę: imę → imię."),
            ("твоѥ", "twoje", "twoje", None),
            ("свѧтъ", "święty", "święty", "ѧ = ę: svętъ → święty."),
            ("свѧто", "święte", "święte", None),
            ("хлѣбъ", "chleb", "chleb", "х = ch, ѣ = e: chlěbъ → chleb."),
            ("даждь", "daj!", "daj", None),
            ("намъ", "nam", "nam", None),
            ("богоу", "Bogu (celownik)", "Bogu", None),
            ("слава", "chwała; sława", "sława", None),
        ],
        "sentences": [
            (["отьче", "нашь"], "Ojcze nasz.", {"отьць": "Zwracasz się do kogoś: wołacz отьче (ojcze!)."}),
            (["боже", "мои"], "Boże mój.", {"богъ": "Do Boga mówisz wołaczem: боже, jak polskie „Boże!”."}),
            (["господи", "помилоуи"], "Panie, zmiłuj się.",
             {"господь": "Do Pana wołacz: господи."}),
            (["даждь", "намъ", "хлѣбъ"], "Daj nam chleb.", {}),
            (["слава", "богоу"], "Chwała Bogu.", {"бога": "„Komu?” Celownik: богоу (Bogu)."}),
            (["имѧ", "твоѥ", "свѧто"], "Imię twoje święte.", {"свѧтъ": "имѧ jest nijakie, więc свѧто."}),
        ],
    },
    {
        "id": "aoryst", "title": "Czas przeszły", "icon": "Рече", "color": "#7950F2", "track": "jezyk",
        "words": [
            ("рече", "rzekł", "rzecze", "Biblijne „rzecze” to właśnie ta forma!"),
            ("бѣ", "był; była; było", None, "Aoryst (3. osoba) od бꙑти."),
            ("бꙑстъ", "stał się; stało się", "by (w „zrobiłbym”)", "Polskie „by” w trybie przypuszczającym to stary aoryst od „być”!"),
            ("видѣ", "ujrzał", "widział", None),
            ("приде", "przyszedł", "przyjdzie", None),
            ("сътвори", "stworzył; uczynił", "stworzył", None),
            ("глагола", "powiedział", None, None),
            ("свѣтъ", "światło; światłość", "świat; światło", "ѣ → ia: světъ → świat."),
            ("искони", "na początku; od zawsza", None, "Tak zaczyna się Ewangelia Jana. Według Żywota Konstantyna to pierwsze słowa zapisane po słowiańsku."),
            ("землю", "ziemię (biernik)", "ziemię", None),
        ],
        "sentences": [
            (["богъ", "рече"], "Bóg rzekł.", {}),
            (["и", "бꙑстъ", "свѣтъ"], "I stała się światłość.",
             {"ѥсть": "To się stało w przeszłości: бꙑстъ (stało się), nie ѥсть (jest)."}),
            (["онъ", "приде", "въ", "домъ"], "Przyszedł do domu.",
             {"идетъ": "идетъ to „idzie” (teraz). W przeszłości: приде (przyszedł)."}),
            (["искони", "бѣ", "слово"], "Na początku było Słowo.",
             {"ѥсть": "Mowa o przeszłości: бѣ (było), nie ѥсть (jest)."}),
            (["богъ", "сътвори", "небо", "и", "землю"], "Bóg stworzył niebo i ziemię.",
             {"землꙗ": "Co stworzył? Biernik: землю (ziemię), jak po polsku."}),
        ],
    },
    {
        "id": "dualis", "title": "Liczba podwójna", "icon": "Дъва", "color": "#FAB005", "track": "jezyk",
        "words": [
            ("рѫцѣ", "dwie ręce", "ręce", "Polskie „ręce” to dawna liczba podwójna!"),
            ("очи", "dwoje oczu", "oczy", "Polskie „oczy” to też dawna liczba podwójna."),
            ("оуши", "dwoje uszu", "uszy", "I polskie „uszy”."),
            ("нозѣ", "dwie nogi", "nodze (stpol.)", None),
            ("брата", "dwaj bracia; brata", "brata", "Ta sama forma: liczba podwójna albo biernik „brata”."),
            ("двѣ", "dwie", "dwie", "ѣ → ie: dvě → dwie."),
            ("сестрѣ", "dwie siostry", None, None),
            ("вѣ", "my dwaj", None, "Osobny zaimek na „my we dwóch”!"),
            ("ѥсвѣ", "jesteśmy (we dwóch)", None, None),
            ("добрѣ", "dobre (o dwóch, rodzaj nijaki)", None, "Przymiotnik też ma liczbę podwójną: nijaki -ѣ."),
        ],
        "sentences": [
            (["дъва", "брата"], "Dwaj bracia.", {"братъ": "Dwóch? Liczba podwójna: брата."}),
            (["двѣ", "сестрѣ"], "Dwie siostry.", {"сестра": "Dwie? Liczba podwójna: сестрѣ."}),
            (["имамь", "двѣ", "рѫцѣ"], "Mam dwie ręce.", {"рѫка": "Dwie ręce: рѫцѣ, jak polskie „ręce”."}),
            (["вѣ", "ѥсвѣ", "брата"], "My dwaj jesteśmy braćmi.",
             {"мꙑ": "Gdy jest was dwóch: вѣ (my dwaj), nie мꙑ.",
              "ѥсмь": "„Jesteśmy we dwóch”: ѥсвѣ."}),
            (["онъ", "иматъ", "очи", "добрѣ"], "On ma dobre oczy.", {}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "ojcze1", "title": "Ojcze nasz I", "icon": "Ⱁ", "color": "#495057", "track": "teksty",
        "requires": "przypadki",
        "words": [
            ("иже", "który", "iże (stpol.)", "Staropolskie „iże” znaczyło „który”."),
            ("небесехъ", "niebiosach", "niebiosach", None),
            ("свѧтитъ", "święci", "święci", None),
            ("придетъ", "przyjdzie", "przyjdzie", None),
            ("цѣсарьствиѥ", "królestwo", "cesarstwo", "Od цѣсарь (cesarz). Dosłownie „cesarstwo”."),
            ("бѫдетъ", "będzie", "będzie", "ѫ = ę: bǫdetъ → będzie."),
            ("волꙗ", "wola", "wola", None),
            ("ꙗко", "jako; jak", "jako", None),
            ("земи", "(na) ziemi · miejscownik", "ziemi", "Tak w Kodeksie Mariańskim, bez -л-. Inne teksty mają земли."),
        ],
        "sentences": [
            (["отьче", "нашь", "иже", "ѥси", "на", "небесехъ"], "Ojcze nasz, któryś jest w niebiosach.", {}),
            (["да", "свѧтитъ", "сѧ", "имѧ", "твоѥ"], "Niech się święci imię twoje.", {}),
            (["да", "придетъ", "цѣсарьствиѥ", "твоѥ"], "Niech przyjdzie królestwo twoje.", {}),
            (["да", "бѫдетъ", "волꙗ", "твоꙗ"], "Niech będzie wola twoja.", {}),
            (["ꙗко", "на", "небеси", "и", "на", "земи"], "Jako w niebie, tak i na ziemi.", {}),
        ],
    },
    {
        "id": "ojcze2", "title": "Ojcze nasz II", "icon": "Ⱈ", "color": "#343A40", "track": "teksty",
        "words": [
            ("наставъшааго", "nadchodzącego", "nastać", "Kodeks Mariański mówi o chlebie „nadchodzącego dnia”. Inne rękopisy mają насѫщьнꙑи (powszedni)."),
            ("дьне", "dnia", "dnia", None),
            ("дьньсь", "dzisiaj", "dziś", "„Ten dzień”: dьnь + sь → dziś."),
            ("отъпоусти", "odpuść", "odpuść", None),
            ("длъгꙑ", "długi; winy", "długi", None),
            ("нашѧ", "nasze (biernik)", "nasze", None),
            ("въведи", "wwódź", "wwiedź", None),
            ("насъ", "nas", "nas", None),
            ("напасть", "pokusa", "napaść", None),
            ("нъ", "ale", None, None),
            ("избави", "zbaw", "zbaw", None),
            ("нꙑ", "nas (krótko)", None, None),
            ("отъ", "od; ode", "od", None),
            ("неприꙗзни", "złego", "nieprzyjaźni", "Dosłownie „nieprzyjaźń”."),
        ],
        "sentences": [
            (["хлѣбъ", "нашь", "наставъшааго", "дьне", "даждь", "намъ", "дьньсь"],
             "Chleba naszego na nadchodzący dzień daj nam dzisiaj.", {}),
            (["и", "отъпоусти", "намъ", "длъгꙑ", "нашѧ"], "I odpuść nam nasze winy.", {}),
            (["и", "не", "въведи", "насъ", "въ", "напасть"], "I nie wódź nas na pokuszenie.", {}),
            (["нъ", "избави", "нꙑ", "отъ", "неприꙗзни"], "Ale nas zbaw ode złego.", {}),
        ],
    },
    {
        "id": "jan", "title": "Ewangelia Jana", "icon": "Ⱄ", "color": "#212529", "track": "teksty",
        "words": [
            ("тьмѣ", "(w) ciemności", "ćma; ciemność", "тьма = ciemność (por. polskie „ćma”)."),
            ("свьтитъ", "świeci", "świeci", "Tak w Kodeksie Zografskim i Ewangeliarzu Ostromira."),
            ("оу", "u; przy", "u", None),
            ("се", "to; ono; oto", None, None),
        ],
        "sentences": [
            (["искони", "бѣ", "слово"], "Na początku było Słowo.", {}),
            (["и", "слово", "бѣ", "оу", "бога"], "A Słowo było u Boga.", {}),
            (["и", "богъ", "бѣ", "слово"], "I Bogiem było Słowo.", {}),
            (["се", "бѣ", "искони", "отъ", "бога"], "Ono było na początku u Boga.",
             {"оу": "W J 1,2 Kodeks Zografski ma tu отъ бога (dosł. „od Boga”, w znaczeniu „u Boga”)."}),
            (["и", "свѣтъ", "въ", "тьмѣ", "свьтитъ", "сѧ"], "A światłość w ciemności świeci.", {}),
        ],
    },
    # -------------------------------------------------------------- głagolica
    {
        "id": "glag1", "title": "Głagolica I", "icon": "Ⰰ", "color": "#F76707", "track": "glagolica",
        "requires": "cyr3",
        "letters": [
            ("ⰰ", "[a] (= а)", "азъ"), ("ⰱ", "[b] (= б)", "боукꙑ"), ("ⰲ", "[v] (= в)", "вѣдѣ"),
            ("ⰳ", "[ɡ] (= г)", "глаголи"), ("ⰴ", "[d] (= д)", "добро"), ("ⰵ", "[ɛ] (= е)", "ѥсть"),
            ("ⰶ", "[ʒ] (= ж)", "живѣте"), ("ⰷ", "[dz] (= ꙃ)", "ꙃѣло"), ("ⰸ", "[z] (= з)", "землꙗ"),
            ("ⰹ", "[i] (= і)", "ижеи"), ("ⰻ", "[i] (= и)", "и"), ("ⰽ", "[k] (= к)", "како"),
            ("ⰾ", "[l] (= л)", "людиѥ"), ("ⰿ", "[m] (= м)", "мꙑслите"),
        ],
    },
    {
        "id": "glag2", "title": "Głagolica II", "icon": "Ⱎ", "color": "#D9480F", "track": "glagolica",
        "letters": [
            ("ⱀ", "[n] (= н)", "нашь"), ("ⱁ", "[ɔ] (= о)", "онъ"), ("ⱂ", "[p] (= п)", "покои"),
            ("ⱃ", "[r] (= р)", "рьци"), ("ⱄ", "[s] (= с)", "слово"), ("ⱅ", "[t] (= т)", "тврьдо"),
            ("ⱆ", "[u] (= оу)", "оукъ"), ("ⱈ", "[x] (= х)", "хѣръ"), ("ⱋ", "[ʃt] (= щ)", "шта"),
            ("ⱌ", "[ts] (= ц)", "ци"), ("ⱍ", "[tʃ] (= ч)", "чрьвь"), ("ⱎ", "[ʃ] (= ш)", "ша"),
            ("ⱏ", "[ŭ] (= ъ)", "ѥръ"), ("ⱐ", "[ĭ] (= ь)", "ѥрь"),
            ("ⱑ", "[æ] / [ja] (= ѣ, ꙗ)", "ѣть"), ("ⱔ", "[ɛ̃] (= ѧ)", "ѧсъ"), ("ⱘ", "[ɔ̃] (= ѫ)", "ѫсъ"),
        ],
    },
    {
        "id": 'glag3', "title": 'Głagolica III', "icon": 'ⱚ', "color": '#D9480F', "track": 'glagolica',
        "letters": [
            ('ⱇ', '[f] (= ф)', 'фрьтъ'),
            ('ⱉ', '[ɔ] (= ѡ)', 'отъ'),
            ('ⱓ', '[ju] (= ю)', 'ю'),
            ('ⱗ', '[jɛ̃] (= ѩ)', 'ѩсъ'),
            ('ⱙ', '[jɔ̃] (= ѭ)', 'ѭсъ'),
            ('ⱚ', '[θ] (= ѳ)', 'ѳита'),
            ('ⱛ', '[i] / [y] (= ѵ)', 'ижица'),
        ],
    },
]

TRACKS = {
    "pismo": "Pismo: cyrylica",
    "jezyk": "Język",
    "teksty": "Teksty: modlitwa i Ewangelia",
    "glagolica": "Ⰳⰾⰰⰳⱁⰾⰹⱌⰰ  Głagolica",
}

# ---------------------------------------------------------------------------
# Wglądy w stylu Language Transfer: wyjaśnienie „dlaczego”, oparte na polskim,
# a potem kroki, w których uczeń sam buduje zdania: (polski, słowa, podpowiedź).
# ---------------------------------------------------------------------------
INSIGHTS = {
    "cyr4": [
        {"title": "Ta sama litera, kilka kształtów",
         "text": "Dawni pisarze skracali i łączyli litery, więc spotkasz kilka postaci tego samego dźwięku: оу, ѹ i ꙋ to wszystko [u]. "
                 "ѻ to okrągłe о, a ѿ to „от” zrośnięte w jedną literę. Nie musisz pisać wszystkich wariantów, ale czytając rękopisy musisz je poznawać.",
         "chain": []},
    ],
    "cyr5": [
        {"title": "Litery jako cyfry",
         "text": "Słowianie pożyczyli od Greków liczenie literami. Kreska nad literą (titło) mówi: to liczba. "
                 "а҃ = 1, в҃ = 2, г҃ = 3. Kolejność jest grecka, dlatego б i ж nie mają wartości: nie ma ich w greckim alfabecie. "
                 "Za to liczą się ꙃ (6) i ѳ (9), też z greckiego (stigma i theta).",
         "chain": []},
    ],
    "cyr6": [
        {"title": "Dziesiątki",
         "text": "Po dziewiątce idą dziesiątki: і҃ = 10, к҃ = 20, л҃ = 30. W liczbach 11–19 jedności stoją przed dziesiątką: "
                 "а҃і = 11, в҃і = 12. W pozostałych kolejność jest taka, jak mówisz: od większej do mniejszej.",
         "chain": []},
    ],
    "cyr7": [
        {"title": "Setki i tysiące",
         "text": "Setki zaczynają się od р҃ = 100. Tysiące oznacza znak ҂ przed literą: ҂а = 1000, ҂в = 2000. "
                 "Rok pisano więc literami, np. od stworzenia świata (według Bizantyńczyków).",
         "chain": []},
    ],
    "glag3": [
        {"title": "Litery z greckich słów",
         "text": "Głagolica miała też litery do słów greckich: ⱚ (fita, ѳ) i ⱛ (iżica, ѵ), jak cyrylica. "
                 "Ⱉ (ot) odpowiada ѡ, a ⱗ i ⱙ to nosówki z j: ѩ i ѭ.",
         "chain": []},
    ],
    "cyr1": [
        {"title": "Znasz więcej, niż myślisz",
         "text": "Połowa cyrylicy wygląda jak litery łacińskie: а, е, к, м, о, т czyta się prawie tak "
                 "samo. Uważaj tylko na „fałszywych przyjaciół”: в to w, н to n, а nie h.",
         "chain": []},
    ],
    "cyr2": [
        {"title": "Fałszywi przyjaciele",
         "text": "р to r, nie p. с to s, nie c. х to ch, nie x. Gdy tylko zobaczysz takie słowo, "
                 "przeczytaj je powoli, a zwykle wyjdzie znane polskie: слово = słowo, сꙑнъ = syn.",
         "chain": []},
        {"title": "Jery: ъ i ь",
         "text": "ъ i ь to bardzo krótkie samogłoski. W polskim jedne zniknęły (дъва → dwa), "
                 "a inne zmieniły się w „e” (дьнь → dzień, седмь → siedem). Na końcu słowa ъ "
                 "się nie wymawia: богъ czytaj „bog”.",
         "chain": []},
    ],
    "cyr3": [
        {"title": "Polski pamięta nosówki",
         "text": "ѫ i ѧ to samogłoski nosowe. Większość języków słowiańskich je straciła. "
                 "Polski je zachował! ѫ to zwykle nasze ą/ę (рѫка → ręka, зѫбъ → ząb), "
                 "a ѧ to ę (пѧть → pięć, имѧ → imię).",
         "chain": []},
        {"title": "ѣ: ie albo ia",
         "text": "ѣ (jać) to dawne długie e. W polskim dało „ie” (чловѣкъ → człowiek, хлѣбъ → chleb) "
                 "albo, przed twardą spółgłoską, „ia” lub „a” (вѣра → wiara, лѣсъ → las). Gdy "
                 "widzisz ѣ, spróbuj obu wersji: od razu rozpoznasz słowo.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Staropolski już to miał",
         "text": "SCS to najstarszy zapisany język słowiański, kuzyn polskiego. Staropolski "
                 "mówił „jeśm” (jestem) i „jeś” (jesteś). W SCS to ѥсмь i ѥси. Nie uczysz się "
                 "od zera, tylko cofasz się w czasie.",
         "chain": [
             ("Jestem człowiekiem.", ["азъ", "ѥсмь", "чловѣкъ"],
              "азъ = ja, ѥсмь = jestem (stpol. jeśm). Na końcu чловѣкъ."),
             ("Jesteś dobry.", ["тꙑ", "ѥси", "добръ"], "Zmień osobę: тꙑ (ty) i ѥси (jesteś)."),
             ("Bóg jest dobry.", ["богъ", "ѥсть", "добръ"], "O kimś trzecim: ѥсть, jak polskie „jest”."),
         ]},
        {"title": "„Nie jest” to jedno słowo",
         "text": "Zamiast „не ѥсть” SCS mówi нѣсть. To jak polskie „nie ma” ściągnięte w jedno. "
                 "Reszta zaprzeczeń działa jak w polskim: не przed słowem.",
         "chain": [
             ("On nie jest Bogiem.", ["онъ", "нѣсть", "богъ"], "онъ + нѣсть (nie jest) + богъ."),
         ]},
    ],
    "rodzina": [
        {"title": "Zaimek po rzeczowniku",
         "text": "Znasz „Ojcze nasz”. W SCS to normalny szyk: najpierw rzecz, potem „mój/nasz”: "
                 "отьць мои = mój ojciec. Rodzaj zgadza się jak po polsku: мои brat, моꙗ siostra.",
         "chain": [
             ("Mój ojciec jest dobry.", ["отьць", "мои", "добръ", "ѥсть"],
              "отьць мои, potem cecha i ѥсть na końcu: szyk jest swobodny, jak po polsku."),
             ("Moja siostra jest w domu.", ["сестра", "моꙗ", "ѥсть", "въ", "домоу"],
              "сестра → моꙗ (żeński). „W domu” = въ домоу, dokładnie jak polskie."),
         ]},
    ],
    "liczby": [
        {"title": "Liczby jak po polsku",
         "text": "пѧть, девѧть, десѧть: ѧ to ę, więc to pięć, dziewięć, dziesięć. I jak w "
                 "polskim, po „pięć” idzie dopełniacz: пѧть сꙑновъ = pięciu synów.",
         "chain": [
             ("Mam jeden dom.", ["азъ", "имамь", "ѥдинъ", "домъ"], "имамь = mam."),
             ("Ojciec ma pięciu synów.", ["отьць", "иматъ", "пѧть", "сꙑновъ"],
              "иматъ = ma. Po пѧть dopełniacz: сꙑновъ (synów)."),
         ]},
    ],
    "swiat": [
        {"title": "-ra- zamiast -ro-",
         "text": "Tam, gdzie polski ma -ro-, -ło-, SCS ma -ra-, -la-: глава = głowa, градъ = gród, "
                 "злато = złoto. Gdy słowo wydaje się obce, zamień -ra- na -ro- i przeczytaj jeszcze raz.",
         "chain": [
             ("Mój gród jest dobry.", ["градъ", "мои", "ѥсть", "добръ"], "градъ = gród."),
             ("Słońce jest na niebie.", ["слъньце", "ѥсть", "на", "небеси"],
              "„Na niebie” = на небеси (miejscownik). Pomyśl o „niebiosach”."),
         ]},
        {"title": "щ to polskie c",
         "text": "SCS щ (št) często odpowiada polskiemu c: ношть = noc, свѣща = świeca. "
                 "To jedna z cech „południowych” SCS: język powstał z dialektu okolic Salonik.",
         "chain": [("Dzień i noc.", ["дьнь", "и", "ношть"], "дьнь (dzień) и ношть (noc).")]},
    ],
    "czas": [
        {"title": "-ѫ to polskie -ę",
         "text": "Czasownik w 1. osobie kończy się na -ѫ: пишѫ, идѫ, виждѫ. Ponieważ ѫ to "
                 "nasze ę, to dosłownie piszę, idę, widzę! „Ty” ma -еши (piszesz), "
                 "„on” ma -етъ / -итъ (pisze, widzi).",
         "chain": [
             ("Piszę słowo.", ["азъ", "пишѫ", "слово"], "O sobie: -ѫ, jak „piszę”."),
             ("Co piszesz?", ["чьто", "пишеши"], "чьто = co. Do „ty”: пишеши."),
             ("On idzie do domu.", ["онъ", "идетъ", "въ", "домъ"], "„Do domu” = въ + biernik: въ домъ."),
         ]},
        {"title": "Przypadki działają jak w polskim",
         "text": "Po „w” z ruchem stoi biernik, bez ruchu miejscownik, dokładnie jak w polskim: "
                 "въ домъ (do domu), въ домоу (w domu). „Wierzę w Boga” to въ бога.",
         "chain": [("Wierzę w Boga.", ["вѣроуѭ", "въ", "бога"], "вѣроуѭ (wierzę) + въ бога.")]},
    ],
    "przypadki": [
        {"title": "Wołacz: polski go zachował",
         "text": "Większość języków słowiańskich zgubiła wołacz. Polski nie: „Ojcze!”, „Boże!”, "
                 "„człowiecze!”. SCS ma te same formy: отьче, боже, чловѣче. Siedem przypadków, "
                 "jak u nas.",
         "chain": [
             ("Ojcze nasz.", ["отьче", "нашь"], "Wołacz отьче, potem нашь (szyk jak w modlitwie)."),
             ("Panie, zmiłuj się.", ["господи", "помилоуи"], "господи = Panie! (wołacz)."),
             ("Chwała Bogu.", ["слава", "богоу"], "Komu? Celownik: богоу, jak „Bogu”."),
         ]},
    ],
    "aoryst": [
        {"title": "Czas, który polski zgubił",
         "text": "SCS ma aoryst: krótki czas przeszły. рече = rzekł (biblijne „rzecze”). "
                 "Polski go zgubił, ale zostawił ślad: „by” w „zrobiłbym” to stary aoryst od "
                 "„być” (бꙑ). A бѣ to „był/było”.",
         "chain": [
             ("Bóg rzekł.", ["богъ", "рече"], "богъ + рече."),
             ("Na początku było Słowo.", ["искони", "бѣ", "слово"],
              "искони = na początku, бѣ = było."),
             ("I stała się światłość.", ["и", "бꙑстъ", "свѣтъ"], "бꙑстъ = stało się."),
         ]},
    ],
    "dualis": [
        {"title": "Liczba podwójna: ślad w polskim",
         "text": "SCS ma osobną liczbę dla dwóch rzeczy. Polski ją zgubił, ale nie całkiem: "
                 "„ręce”, „oczy”, „uszy” to dawne formy podwójne! Dlatego mówimy „ręce”, a nie "
                 "„ręki”. Jest nawet zaimek вѣ: „my dwaj”.",
         "chain": [
             ("Mam dwie ręce.", ["имамь", "двѣ", "рѫцѣ"], "двѣ (dwie) + рѫцѣ (jak „ręce”)."),
             ("Dwaj bracia.", ["дъва", "брата"], "Liczba podwójna od братъ: брата."),
             ("My dwaj jesteśmy braćmi.", ["вѣ", "ѥсвѣ", "брата"], "вѣ (my dwaj) + ѥсвѣ (jesteśmy)."),
         ]},
    ],
    "ojcze1": [
        {"title": "Modlitwę już znasz",
         "text": "„Ojcze nasz” po polsku i w SCS to prawie ten sam tekst: zostawiliśmy nawet "
                 "szyk i wołacz. Tekst według Kodeksu Mariańskiego (XI w.), w pisowni znormalizowanej. Czytaj słowo po słowie.",
         "chain": [
             ("Ojcze nasz, któryś jest w niebiosach.", ["отьче", "нашь", "иже", "ѥси", "на", "небесехъ"],
              "иже = który (stpol. „iże”), ѥси = jesteś."),
             ("Niech się święci imię twoje.", ["да", "свѧтитъ", "сѧ", "имѧ", "твоѥ"],
              "да = niech, сѧ = się."),
         ]},
    ],
    "ojcze2": [
        {"title": "Dług to wina",
         "text": "„Odpuść nam nasze winy” w SCS to dosłownie „odpuść nam nasze długi” (длъгꙑ). "
                 "Stąd polskie „dłużnik” w starszych przekładach. Tekst czyta się jak staropolski.",
         "chain": [
             ("I odpuść nam nasze winy.", ["и", "отъпоусти", "намъ", "длъгꙑ", "нашѧ"],
              "отъпоусти = odpuść, длъгꙑ = długi."),
         ]},
    ],
    "jan": [
        {"title": "Pierwsze zdanie przekładu",
         "text": "Według Żywota Konstantyna (Cyryla), gdy powstało pismo, zaczął on pisać od słów "
                 "„Искони бѣ слово и слово бѣ оу бога”. To więc prawdopodobnie pierwsze zdanie "
                 "zapisane po słowiańsku.",
         "chain": [
             ("Na początku było Słowo.", ["искони", "бѣ", "слово"], "Już to znasz z „czasu przeszłego”."),
             ("A światłość w ciemności świeci.", ["и", "свѣтъ", "въ", "тьмѣ", "свьтитъ", "сѧ"],
              "свѣтъ = światło, тьмѣ = w ciemności, свьтитъ сѧ = świeci się."),
         ]},
    ],
    "glag1": [
        {"title": "Alfabet, który jest zdaniem",
         "text": "Nazwy liter to słowa: азъ боукꙑ вѣдѣ = „ja litery znam”, глаголи добро ѥсть = "
                 "„mów, dobro jest”. Głagolicę ułożył Konstanty ok. 863 r. Litery są nowe, "
                 "ale dźwięki znasz już z cyrylicy.",
         "chain": []},
    ],
    "glag2": [
        {"title": "Z głagolicy do cyrylicy",
         "text": "Cyrylica powstała później i zastąpiła głagolicę prawie wszędzie. Kolejność "
                 "liter jest ta sama, więc gdy znasz nazwę litery, wiesz, jak ją przeczytać.",
         "chain": []},
    ],
}

SOUND_INSIGHT = {
    "title": "Słuchaj polskim uchem",
    "text": "Każda „dziwna” litera SCS ma swój ślad w polskim. ѫ i ѧ to nasze ą/ę, ѣ to ie/ia, "
            "ъ i ь zniknęły albo dały „e”, щ to c. Gdy zgadujesz brakującą literę, pomyśl o "
            "polskim słowie.",
}

# Litery, które wyróżniamy kolorem w całej aplikacji.
SPECIAL_COLORS = {
    "ѫ": "A8321E", "ѧ": "A8321E", "ѭ": "A8321E", "ѩ": "A8321E",
    "ѣ": "6B3F5E",
    "ъ": "97846A", "ь": "97846A", "ꙑ": "2E4A7A",
    "щ": "3D6B4F",
}

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "powitanie", "title": "Powitanie", "partner": "Brat Gorazd", "avatar": "Г",
        "requires": "slowa",
        "turns": [
            {"bot": ["радоуи", "сѧ", "!"], "en": "Witaj! (raduj się)",
             "options": [(["радоуи", "сѧ", "!"], True, None),
                         (["не", "!"], False, "не to „nie”. Odpowiedz pozdrowieniem: радоуи сѧ."),
                         (["нѣсть"], False, "нѣсть to „nie jest”. Spróbuj odpowiedzieć tym samym pozdrowieniem.")]},
            {"bot": ["богъ", "ѥсть", "добръ", "."], "en": "Bóg jest dobry.",
             "options": [(["да", ",", "богъ", "ѥсть", "добръ"], True, None),
                         (["да", ",", "богъ", "ѥси", "добръ"], False, "ѥси to „jesteś”. O Bogu (on): ѥсть."),
                         (["да", ",", "богъ", "ѥсмь", "добръ"], False, "ѥсмь to „jestem”. O Bogu: ѥсть.")]},
            {"bot": ["тꙑ", "ѥси", "чловѣкъ", "добръ", "."], "en": "Jesteś dobrym człowiekiem.",
             "options": [(["и", "тꙑ", "ѥси", "добръ"], True, None),
                         (["и", "тꙑ", "ѥсть", "добръ"], False, "Do „ty”: ѥси (jesteś), nie ѥсть (jest).")]},
            {"bot": ["миръ", "тебѣ", "!"], "en": "Pokój tobie!",
             "build": (["миръ", "тебѣ"], "Pokój tobie!")},
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "partner": "Mnich Naum", "avatar": "Н",
        "requires": "rodzina",
        "turns": [
            {"bot": ["къто", "ѥсть", "онъ", "?"], "en": "Kim on jest?",
             "options": [(["онъ", "ѥсть", "братъ", "мои"], True, None),
                         (["онъ", "ѥсмь", "братъ", "мои"], False, "ѥсмь to „jestem”. O nim: ѥсть."),
                         (["онъ", "ѥсть", "братъ", "моꙗ"], False, "братъ jest męski: мои, nie моꙗ.")]},
            {"bot": ["а", "сестра", "твоꙗ", "?"], "en": "A twoja siostra?",
             "build": (["сестра", "моꙗ", "ѥсть", "въ", "домоу"], "Moja siostra jest w domu.")},
            {"bot": ["добро", "!"], "en": "Dobrze!",
             "options": [(["радоуи", "сѧ"], True, None),
                         (["не", "знаѭ"], False, "Nie musisz niczego wiedzieć, to pożegnanie. Spróbuj: радоуи сѧ.")]},
        ],
    },
    {
        "id": "skryptorium", "title": "W skryptorium", "partner": "Konstanty", "avatar": "К",
        "requires": "czas",
        "turns": [
            {"bot": ["чьто", "пишеши", "?"], "en": "Co piszesz?",
             "options": [(["пишѫ", "слово"], True, None),
                         (["пишетъ", "слово"], False, "пишетъ to „pisze” (on). O sobie: пишѫ, jak „piszę”."),
                         (["пишеши", "слово"], False, "пишеши to „piszesz”. Odpowiadasz o sobie: пишѫ.")]},
            {"bot": ["знаѥши", "ли", "боукꙑ", "?"], "en": "Czy znasz litery?",
             "options": [(["знаѭ"], True, None),
                         (["знаѥтъ"], False, "знаѥтъ to „zna” (on). O sobie: знаѭ."),
                         (["не", "знаѥши"], False, "знаѥши to „znasz”. O sobie: знаѭ.")],
             "note": "ли to partykuła pytajna, jak staropolskie „-li” (np. „znaszli?”)."},
            {"bot": ["къто", "глаголетъ", "?"], "en": "Kto mówi?",
             "build": (["азъ", "глаголѭ"], "Ja mówię.")},
            {"bot": ["добро", "!", "вѣроуѥши", "ли", "?"], "en": "Dobrze! Czy wierzysz?",
             "options": [(["вѣроуѭ", "въ", "бога"], True, None),
                         (["вѣроуѭ", "въ", "богъ"], False, "Po „въ” biernik: въ бога, jak „w Boga”.")]},
        ],
    },
    {
        "id": "modlitwa", "title": "Modlitwa", "partner": "Biskup Metody", "avatar": "М",
        "requires": "przypadki",
        "turns": [
            {"bot": ["къто", "ѥсть", "отьць", "нашь", "?"], "en": "Kto jest naszym ojcem?",
             "options": [(["богъ", "ѥсть", "отьць", "нашь"], True, None),
                         (["бога", "ѥсть", "отьць", "нашь"], False,
                          "бога to „Boga” (biernik). Podmiot w mianowniku: богъ.")]},
            {"bot": ["чьто", "глаголеши", "богоу", "?"], "en": "Co mówisz do Boga?",
             "options": [(["боже", ",", "помилоуи"], True, None),
                         (["богъ", ",", "помилоуи"], False, "Zwracasz się do Boga: wołacz боже, jak „Boże!”."),
                         (["бога", ",", "помилоуи"], False, "Zwracasz się do kogoś: wołacz боже.")]},
            {"bot": ["добрѣ", "!"], "en": "Dobrze!",
             "build": (["слава", "богоу"], "Chwała Bogu.")},
        ],
    },
    {
        "id": "ewangelia", "title": "Lekcja Ewangelii", "partner": "Konstanty", "avatar": "К",
        "requires": "jan",
        "turns": [
            {"bot": ["чьто", "бѣ", "искони", "?"], "en": "Co było na początku?",
             "options": [(["искони", "бѣ", "слово"], True, None),
                         (["искони", "ѥсть", "слово"], False, "Mowa o przeszłości: бѣ (było), nie ѥсть (jest).")]},
            {"bot": ["а", "чьто", "свьтитъ", "сѧ", "въ", "тьмѣ", "?"], "en": "A co świeci w ciemności?",
             "build": (["свѣтъ", "свьтитъ", "сѧ", "въ", "тьмѣ"], "Światłość świeci w ciemności.")},
            {"bot": ["добрѣ", "глаголеши", "!"], "en": "Dobrze mówisz!",
             "options": [(["слава", "богоу"], True, None),
                         (["слава", "бога"], False, "Komu chwała? Celownik: богоу.")]},
        ],
    },
]

# Słowa, które są tylko w rozmowach: forma → znaczenie.
CHAT_EXTRA = {
    "тебѣ": "tobie",
    "а": "a",
    "знаѥши": "znasz",
    "ли": "czy (partykuła pytajna)",
    "боукꙑ": "litery",
    "вѣроуѥши": "wierzysz",
    "глаголеши": "mówisz",
    "добрѣ": "dobrze",
}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['азъ', 'тꙑ', 'онъ', 'мꙑ', 'вꙑ', 'они'],
    'przyp': ['mianownik lp.', 'dopełniacz lp.', 'celownik lp.', 'biernik lp.', 'narzędnik lp.', 'miejscownik lp.', 'wołacz lp.'],
    'im': ['im. teraźniejszy czynny (m.)', 'im. teraźniejszy bierny', 'im. przeszły czynny I', 'im. przeszły czynny II (na -лъ)', 'im. przeszły bierny'],
    'przyp6': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'narzędnik', 'miejscownik'],
    't_nos': ['рѫка', 'пѧть', 'мѫжь', 'ѩзꙑкъ', 'сѫтъ', 'имѧ'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'нести (nieść): I koniugacja', 'os', 'несѫ; несеши; несетъ; несемъ; несете; несѫтъ', 'Liczbę podwójną pomijamy. Końcówki: -ѫ, -еши, -етъ, -емъ, -ете, -ѫтъ.'),
    ('conj', 'Wzory koniugacji', 'знати (znać): III koniugacja', 'os', 'знаѭ; знаѥши; знаѥтъ; знаѥмъ; знаѥте; знаѭтъ', None),
    ('conj', 'Wzory koniugacji', 'хвалити (chwalić): IV koniugacja', 'os', 'хвалѭ; хвалиши; хвалитъ; хвалимъ; хвалите; хвалѧтъ', 'IV koniugacja: -и- w temacie, 3. osoba lm. -ѧтъ.'),
    ('conj', 'Czasowniki nieregularne', 'бꙑти (być)', 'os', 'ѥсмь; ѥси; ѥстъ; ѥсмъ; ѥсте; сѫтъ', 'Czasownik atematyczny: końcówka -мь w 1. osobie.'),
    ('conj', 'Czasowniki nieregularne', 'дати (dać)', 'os', 'дамь; даси; дастъ; дамъ; дасте; дадѧтъ', None),
    ('conj', 'Czasowniki nieregularne', 'вѣдѣти (wiedzieć)', 'os', 'вѣмь; вѣси; вѣстъ; вѣмъ; вѣсте; вѣдѧтъ', None),
    ('conj', 'Czasowniki nieregularne', 'ꙗсти (jeść)', 'os', 'ꙗмь; ꙗси; ꙗстъ; ꙗмъ; ꙗсте; ꙗдѧтъ', None),
    ('conj', 'Czasowniki nieregularne', 'имѣти (mieć)', 'os', 'имамь; имаши; иматъ; имамъ; имате; имѫтъ', None),
    ('decl', 'Wzory deklinacji', 'рабъ (sługa): temat na -o-', 'przyp', 'рабъ; раба; рабоу; рабъ; рабомь; рабѣ; рабе', None),
    ('decl', 'Wzory deklinacji', 'мѫжь (mąż): temat na -jo-', 'przyp', 'мѫжь; мѫжа; мѫжоу; мѫжь; мѫжемь; мѫжи; мѫжоу', 'Odmiana miękka: -емь, -и.'),
    ('decl', 'Wzory deklinacji', 'жена (kobieta): temat na -a-', 'przyp', 'жена; женꙑ; женѣ; женѫ; женоѭ; женѣ; жено', None),
    ('decl', 'Wzory deklinacji', 'село (wieś): nijaki', 'przyp', 'село; села; селоу; село; селомь; селѣ; село', None),
    ('decl', 'Wzory deklinacji', 'кость (kość): temat na -i-', 'przyp', 'кость; кости; кости; кость; костиѭ; кости; кости', None),
    ('decl', 'Wyjątki', 'сꙑнъ (syn): temat na -u-', 'przyp', 'сꙑнъ; сꙑноу; сꙑнови; сꙑнъ; сꙑнъмь; сꙑноу; сꙑноу', 'Stara odmiana na -u-: dopełniacz -оу, celownik -ови.'),
    ('form', 'Imiesłowy', 'нести (nieść)', 'im', 'несꙑ; несомъ; несъ; неслъ; несенъ', None),
    ('form', 'Imiesłowy', 'хвалити (chwalić)', 'im', 'хвалѧ; хвалимъ; хваль; хвалилъ; хвалѥнъ', None),
    ('form', 'Imiesłowy', 'знати (znać)', 'im', 'знаѩ; знаѥмъ; знавъ; зналъ; знанъ', None),
    ('conj', 'Czas przeszły', 'нести: aoryst', 'os', 'несохъ; несе; несе; несохомъ; несосте; несошѧ', None),
    ('conj', 'Czas przeszły', 'бꙑти: aoryst', 'os', 'бꙑхъ; бꙑ; бꙑ; бꙑхомъ; бꙑсте; бꙑшѧ', None),
    ('decl', 'Zaimki', 'азъ (ja)', 'przyp6', 'азъ; мене; мьнѣ; мѧ; мъноѭ; мьнѣ', None),
    ('decl', 'Liczebniki', 'ѥдинъ (jeden)', 'przyp6', 'ѥдинъ; ѥдиного; ѥдиномоу; ѥдинъ; ѥдинѣмь; ѥдиномь', 'Odmiana zaimkowa.'),
    ('decl', 'Liczebniki', 'дъва (dwa)', 'przyp6', 'дъва; дъвою; дъвѣма; дъва; дъвѣма; дъвою', 'Liczba podwójna: tylko trzy różne formy.'),
    ('decl', 'Liczebniki', 'триѥ (trzy)', 'przyp6', 'триѥ; трии; трьмъ; три; трьми; трьхъ', 'Odmiana jak rzeczowniki na -i- w liczbie mnogiej.'),
    ('decl', 'Liczebniki', 'четꙑре (cztery)', 'przyp6', 'четꙑре; четꙑръ; четꙑрьмъ; четꙑри; четꙑрьми; четꙑрьхъ', None),
    ('decl', 'Liczebniki', 'пѧть (pięć)', 'przyp6', 'пѧть; пѧти; пѧти; пѧть; пѧтиѭ; пѧти', '5–10 to rzeczowniki żeńskie; liczony przedmiot stoi w dopełniaczu lm.'),
    ('decl', 'Liczebniki', 'десѧть (dziesięć)', 'przyp6', 'десѧть; десѧте; десѧти; десѧть; десѧтиѭ; десѧте', None),
    ('form', 'Typowe trudności', 'Nosówki: polski odpowiednik', 't_nos', 'ręka; pięć; mąż; język; są; imię', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['животъ', 'страна', 'градъ', 'врѣмѧ', 'лѣто', 'миръ'],
    't_m1': ['дьнь', 'сънъ', 'отьць', 'пьсъ', 'мъхъ', 'льнъ'],
    't_m2': ['рѫка (jedna)', 'рѫцѣ (dwie)', 'рѫкꙑ (wiele)', 'око (jedno)', 'очи (dwoje)', 'братъ (jeden)', 'брата (dwaj)'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Pozorna bliskość: co to znaczy?', 't_m0', 'życie; kraj; miasto; czas; rok; świat, pokój', 'Słowa wyglądają znajomo, ale znaczą co innego niż po polsku.'),
    ('form', 'Typowe trudności', 'Jery: polski odpowiednik', 't_m1', 'dzień; sen; ojciec; pies; mech; len', 'ь i ъ w mocnej pozycji dały w polskim e, w słabej zanikły.'),
    ('form', 'Typowe trudności', 'Liczba podwójna', 't_m2', 'pojedyncza; podwójna; mnoga; pojedyncza; podwójna; pojedyncza; podwójna', 'Dla dwóch rzeczy jest osobna liczba. Polskie „rękoma” i „oczyma” to jej ślady.'),
]

# === PRONOUNS (generowane, nie edytuj ręcznie) ===
PARADIGMS += [
    ('decl', 'Zaimki', 'тꙑ (ty)', 'przyp6', 'тꙑ; тебе; тебѣ; тѧ; тобоѭ; тебѣ', None),
    ('decl', 'Zaimki', 'мꙑ (my)', 'przyp6', 'мꙑ; насъ; намъ; ны; нами; насъ', None),
    ('decl', 'Zaimki', 'вꙑ (wy)', 'przyp6', 'вꙑ; васъ; вамъ; вꙑ; вами; васъ', None),
]
_o = []
for _p in PARADIGMS:
    if _p[1] not in _o:
        _o.append(_p[1])
PARADIGMS.sort(key=lambda p: _o.index(p[1]))
# === /PRONOUNS ===

# === SŁOWNICTWO (generowane z langs/vocab, nie edytuj ręcznie) ===
UNITS += [{'id': 'v01a', 'title': 'Ludzie 1', 'icon': 'L', 'track': 'jezyk', 'words': [('чедо', 'dziecko', None, 'rodzaj nijaki'), ('отрокъ', 'chłopiec', None, 'rodzaj męski'), ('дѣвица', 'dziewczynka', None, 'rodzaj żeński'), ('родъ', 'rodzina', None, 'rodzaj męski'), ('братръ', 'brat', None, 'rodzaj męski'), ('дѣдъ', 'dziadek', None, 'rodzaj męski'), ('вънѹкъ', 'wnuk', None, 'rodzaj męski'), ('оуи', 'wuj', None, 'rodzaj męski'), ('дроугъ', 'przyjaciel', None, 'rodzaj męski'), ('съсѣдъ', 'sąsiad', None, 'rodzaj męski'), ('гостъ', 'gość', None, 'rodzaj męski'), ('врагъ', 'wróg', None, 'rodzaj męski'), ('краль', 'król', None, 'rodzaj męski'), ('кънѧзь', 'książę', None, 'rodzaj męski'), ('воѥвода', 'wódz', None, 'rodzaj męski'), ('владꙑка', 'władca', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01b', 'title': 'Ludzie 2', 'icon': 'L', 'track': 'jezyk', 'words': [('жьрьць', 'kapłan', None, 'rodzaj męski'), ('еписколъ', 'biskup', None, 'rodzaj męski'), ('чьрноризьць', 'mnich', None, 'rodzaj męski'), ('оучитель', 'nauczyciel', None, 'rodzaj męski'), ('оученикъ', 'uczeń', None, 'rodzaj męski'), ('врачь', 'lekarz', None, 'rodzaj męski'), ('вои', 'żołnierz', None, 'rodzaj męski'), ('ратаи', 'rolnik', None, 'rodzaj męski'), ('купьць', 'kupiec', None, 'rodzaj męski'), ('дѣлатель', 'rzemieślnik', None, 'rodzaj męski'), ('пастоухъ', 'pasterz', None, 'rodzaj męski'), ('сѫдии', 'sędzia', None, 'rodzaj męski'), ('рабъ', 'niewolnik', None, 'rodzaj męski'), ('раба', 'niewolnica', None, 'rodzaj żeński'), ('старьць', 'starzec', None, 'rodzaj męski'), ('юноша', 'młodzieniec', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01c', 'title': 'Ludzie 3', 'icon': 'L', 'track': 'jezyk', 'words': [('вьдова', 'wdowa', None, 'rodzaj żeński'), ('сирота', 'sierota', None, 'rodzaj męski'), ('чоужинъ', 'cudzoziemiec', None, 'rodzaj męski'), ('тать', 'złodziej', None, 'rodzaj męski'), ('разбоиникъ', 'zbójca', None, 'rodzaj męski'), ('посълъ', 'posłaniec', None, 'rodzaj męski'), ('ангелъ', 'anioł', None, 'rodzaj męski'), ('пророкъ', 'prorok', None, 'rodzaj męski'), ('апостолъ', 'apostoł', None, 'rodzaj męski'), ('грѣшьникъ', 'grzesznik', None, 'rodzaj męski'), ('мѫдрьць', 'mędrzec', None, 'rodzaj męski'), ('пѣвьць', 'poeta', None, 'rodzaj męski'), ('кънижьникъ', 'pisarz', None, 'rodzaj męski'), ('стражь', 'strażnik', None, 'rodzaj męski'), ('плѣнникъ', 'jeniec', None, 'rodzaj męski'), ('жителъ', 'mieszkaniec', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01d', 'title': 'Ludzie 4', 'icon': 'L', 'track': 'jezyk', 'words': [('ѩꙁꙑкъ', 'naród', None, 'rodzaj męski'), ('народъ', 'tłum', None, 'rodzaj męski'), ('богатъ', 'bogacz', None, 'rodzaj męski'), ('ништь', 'biedak', None, 'rodzaj męski'), ('странъникъ', 'wędrowiec', None, 'rodzaj męski'), ('роди', 'rodzice', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v02a', 'title': 'Ciało 1', 'icon': 'C', 'track': 'jezyk', 'words': [('лице', 'twarz', None, 'rodzaj nijaki'), ('носъ', 'nos', None, 'rodzaj męski'), ('оуста', 'usta', None, 'rodzaj nijaki'), ('власꙑ', 'włosy', None, 'rodzaj męski'), ('вꙑꙗ', 'szyja', None, 'rodzaj żeński'), ('рамо', 'ramię', None, 'rodzaj nijaki'), ('пьрстъ', 'palec', None, 'rodzaj męski'), ('стопа', 'stopa', None, 'rodzaj żeński'), ('колѣно', 'kolano', None, 'rodzaj nijaki'), ('хрьбьтъ', 'plecy', None, 'rodzaj męski'), ('чрѣво', 'brzuch', None, 'rodzaj nijaki'), ('кръвь', 'krew', None, 'rodzaj żeński'), ('кость', 'kość', None, 'rodzaj żeński'), ('кожа', 'skóra', None, 'rodzaj żeński'), ('тѣло', 'ciało', None, 'rodzaj nijaki'), ('желѫдъкъ', 'żołądek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v02b', 'title': 'Ciało 2', 'icon': 'C', 'track': 'jezyk', 'words': [('брада', 'broda', None, 'rodzaj żeński'), ('ногъть', 'paznokieć', None, 'rodzaj męski'), ('пьрси', 'pierś', None, 'rodzaj żeński'), ('мозгъ', 'mózg', None, 'rodzaj męski'), ('лакъть', 'łokieć', None, 'rodzaj męski'), ('чело', 'czoło', None, 'rodzaj nijaki'), ('лаꙁꙋ', 'policzek', None, 'rodzaj żeński'), ('пѧта', 'pięta', None, 'rodzaj żeński'), ('пьчень', 'wątroba', None, 'rodzaj żeński'), ('потъ', 'pot', None, 'rodzaj męski'), ('слꙁа', 'łza', None, 'rodzaj żeński'), ('жила', 'żyła', None, 'rodzaj żeński'), ('тоукъ', 'tłuszcz', None, 'rodzaj męski'), ('крило', 'skrzydło', None, 'rodzaj nijaki'), ('рогъ', 'róg', None, 'rodzaj męski'), ('опашь', 'ogon', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v02c', 'title': 'Ciało 3', 'icon': 'C', 'track': 'jezyk', 'words': [('длань', 'dłoń', None, 'rodzaj żeński'), ('пѧсть', 'pięść', None, 'rodzaj żeński'), ('бокъ', 'bok', None, 'rodzaj męski'), ('бедро', 'udo', None, 'rodzaj nijaki'), ('лоно', 'brzuch (łono)', None, 'rodzaj nijaki'), ('оутроба', 'wnętrzności', None, 'rodzaj żeński'), ('гласъ', 'głos', None, 'rodzaj męski'), ('дꙑханиѥ', 'oddech', None, 'rodzaj nijaki'), ('съпъ', 'sen', None, 'rodzaj męski'), ('доухъ', 'duch', None, 'rodzaj męski'), ('дѹша', 'dusza', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v03a', 'title': 'Jedzenie 1', 'icon': 'J', 'track': 'jezyk', 'words': [('масло', 'masło', None, 'rodzaj nijaki'), ('съръ', 'ser', None, 'rodzaj męski'), ('млѣко', 'mleko', None, 'rodzaj nijaki'), ('ѩи', 'jajko', None, 'rodzaj nijaki'), ('мѧсо', 'mięso', None, 'rodzaj nijaki'), ('рꙑба', 'ryba', None, 'rodzaj żeński'), ('оуха', 'zupa', None, 'rodzaj żeński'), ('каша', 'kasza', None, 'rodzaj żeński'), ('мѣка', 'mąka', None, 'rodzaj żeński'), ('цѣпъ', 'cebula', None, 'rodzaj męski'), ('чеснъкъ', 'czosnek', None, 'rodzaj męski'), ('ѩблъко', 'jabłko', None, 'rodzaj nijaki'), ('гроуша', 'gruszka', None, 'rodzaj żeński'), ('гроздъ', 'winogrono', None, 'rodzaj męski'), ('смоква', 'figa', None, 'rodzaj żeński'), ('маслина', 'oliwka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v03b', 'title': 'Jedzenie 2', 'icon': 'J', 'track': 'jezyk', 'words': [('орѣхъ', 'orzech', None, 'rodzaj męski'), ('медъ', 'miód', None, 'rodzaj męski'), ('соль', 'sól', None, 'rodzaj żeński'), ('пьпьръ', 'pieprz', None, 'rodzaj męski'), ('вино', 'wino', None, 'rodzaj nijaki'), ('ѡцьтъ', 'ocet', None, 'rodzaj męski'), ('обѣдъ', 'śniadanie', None, 'rodzaj męski'), ('вечеря', 'wieczerza', None, 'rodzaj żeński'), ('пиръ', 'uczta', None, 'rodzaj męski'), ('гладъ', 'głód', None, 'rodzaj męski'), ('ѣдь', 'jedzenie', None, 'rodzaj żeński'), ('пища', 'pokarm', None, 'rodzaj żeński'), ('пиѥ', 'napój', None, 'rodzaj nijaki'), ('пиво', 'piwo', None, 'rodzaj nijaki'), ('гороху', 'groch', None, 'rodzaj męski'), ('капоуста', 'kapusta', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v03c', 'title': 'Jedzenie 3', 'icon': 'J', 'track': 'jezyk', 'words': [('оугоурьць', 'ogórek', None, 'rodzaj męski'), ('плодъ', 'owoc', None, 'rodzaj męski'), ('жито', 'zboże', None, 'rodzaj nijaki'), ('пьшеница', 'pszenica', None, 'rodzaj żeński'), ('ꙇечьмꙑ', 'jęczmień', None, 'rodzaj męski'), ('ръжь', 'żyto', None, 'rodzaj żeński'), ('пьсо', 'proso', None, 'rodzaj nijaki'), ('бобъ', 'bób', None, 'rodzaj męski'), ('зърно', 'ziarno', None, 'rodzaj nijaki'), ('пєчєнъ', 'mięso (pieczone)', None, 'rodzaj męski'), ('кълбаса', 'kiełbasa', None, 'rodzaj żeński'), ('сало', 'tłuszcz (smalec)', None, 'rodzaj nijaki'), ('сметана', 'śmietana', None, 'rodzaj żeński'), ('квасъ', 'kwas', None, 'rodzaj męski'), ('пєчи', 'piec chleb', None, None), ('рѣпа', 'rzepa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v03d', 'title': 'Jedzenie 4', 'icon': 'J', 'track': 'jezyk', 'words': [('рѣдькꙑ', 'rzodkiew', None, 'rodzaj żeński'), ('макъ', 'mak', None, 'rodzaj męski'), ('ꙗгода', 'jagoda', None, 'rodzaj żeński'), ('малина', 'malina', None, 'rodzaj żeński'), ('вишьнꙗ', 'wiśnia', None, 'rodzaj żeński'), ('слива', 'śliwka', None, 'rodzaj żeński'), ('лѣщина', 'orzech laskowy', None, 'rodzaj żeński'), ('гливъ', 'grzyb', None, 'rodzaj męski'), ('щавь', 'szczaw', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04a', 'title': 'Dom 1', 'icon': 'D', 'track': 'jezyk', 'words': [('хꙑжа', 'chata', None, 'rodzaj żeński'), ('кѫща', 'pokój', None, 'rodzaj żeński'), ('коуханꙗ', 'kuchnia', None, 'rodzaj żeński'), ('вьртъ', 'ogród', None, 'rodzaj męski'), ('двьри', 'drzwi', None, 'rodzaj żeński'), ('врата', 'brama', None, 'rodzaj nijaki'), ('окъно', 'okno', None, 'rodzaj nijaki'), ('стѣна', 'ściana', None, 'rodzaj żeński'), ('подъ', 'podłoga', None, 'rodzaj męski'), ('крꙑвъ', 'dach', None, 'rodzaj męski'), ('стъпѣни', 'schody', None, 'rodzaj żeński'), ('ключь', 'klucz', None, 'rodzaj męski'), ('запоръ', 'zamek', None, 'rodzaj męski'), ('столъ', 'stół', None, 'rodzaj męski'), ('лавица', 'ława', None, 'rodzaj żeński'), ('одръ', 'łóżko', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04b', 'title': 'Dom 2', 'icon': 'D', 'track': 'jezyk', 'words': [('скрынꙗ', 'szafa', None, 'rodzaj żeński'), ('свѣтилъникъ', 'lampa', None, 'rodzaj męski'), ('свѣща', 'świeca', None, 'rodzaj żeński'), ('огнище', 'ognisko', None, 'rodzaj nijaki'), ('кладѧѕь', 'studnia', None, 'rodzaj męski'), ('пєшть', 'piec', None, 'rodzaj żeński'), ('дворъ', 'dziedziniec', None, 'rodzaj męski'), ('хлѣвъ', 'stajnia', None, 'rodzaj męski'), ('оградъ', 'płot', None, 'rodzaj męski'), ('брѣвьно', 'belka', None, 'rodzaj nijaki'), ('цѣгла', 'cegła', None, 'rodzaj żeński'), ('камꙑ', 'kamień', None, 'rodzaj męski'), ('чаша', 'miska', None, 'rodzaj żeński'), ('крьчагъ', 'dzban', None, 'rodzaj męski'), ('гърньць', 'garnek', None, 'rodzaj męski'), ('коша', 'kosz', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v04c', 'title': 'Dom 3', 'icon': 'D', 'track': 'jezyk', 'words': [('ковьчегъ', 'skrzynia', None, 'rodzaj męski'), ('ведро', 'wiadro', None, 'rodzaj nijaki'), ('ножь', 'nóż', None, 'rodzaj męski'), ('лъжица', 'łyżka', None, 'rodzaj żeński'), ('блюдо', 'talerz', None, 'rodzaj nijaki'), ('съсѫдъ', 'naczynie', None, 'rodzaj męski'), ('вьсь', 'wieś', None, 'rodzaj żeński'), ('сѣдалище', 'siedziba', None, 'rodzaj nijaki'), ('оубѣжище', 'schronienie', None, 'rodzaj nijaki'), ('праґъ', 'próg', None, 'rodzaj męski'), ('стрѣха', 'dach (strzecha)', None, 'rodzaj żeński'), ('ложе', 'łoże', None, 'rodzaj nijaki'), ('възглавьница', 'poduszka', None, 'rodzaj żeński'), ('подъꙁемьница', 'piwnica', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v05a', 'title': 'Ubrania 1', 'icon': 'U', 'track': 'jezyk', 'words': [('ѡдежда', 'ubranie', None, 'rodzaj żeński'), ('срачица', 'koszula', None, 'rodzaj żeński'), ('плащь', 'płaszcz', None, 'rodzaj męski'), ('сапогъ', 'but', None, 'rodzaj męski'), ('сѫпогъ', 'sandał', None, 'rodzaj męski'), ('клобоукъ', 'kapelusz', None, 'rodzaj męski'), ('поꙗсъ', 'pas', None, 'rodzaj męski'), ('прьстень', 'pierścień', None, 'rodzaj męski'), ('ожерельє', 'naszyjnik', None, 'rodzaj nijaki'), ('платьно', 'tkanina', None, 'rodzaj nijaki'), ('вльна', 'wełna', None, 'rodzaj żeński'), ('лѣнъ', 'len', None, 'rodzaj męski'), ('ши̑лкъ', 'jedwab', None, 'rodzaj męski'), ('покровъ', 'welon', None, 'rodzaj męski'), ('вѣнѣць', 'wieniec', None, 'rodzaj męski'), ('вѣньць', 'korona', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v05b', 'title': 'Ubrania 2', 'icon': 'U', 'track': 'jezyk', 'words': [('багрьно', 'purpura', None, 'rodzaj nijaki'), ('одежда', 'szata', None, 'rodzaj żeński'), ('рукавъ', 'rękaw', None, 'rodzaj męski'), ('оукрашєниѥ', 'ozdoba', None, 'rodzaj nijaki'), ('нить', 'nić', None, 'rodzaj żeński'), ('иглꙋ', 'igła', None, 'rodzaj żeński'), ('стань', 'krosno', None, 'rodzaj męski'), ('вретено', 'wrzeciono', None, 'rodzaj nijaki'), ('тькати', 'tkać', None, None), ('шити', 'szyć', None, None), ('новъ ѡдежда', 'nowe ubranie', None, None), ('кожоухъ', 'futro', None, 'rodzaj męski'), ('рѫкавица', 'rękawica', None, 'rodzaj żeński'), ('шапка', 'czapka', None, 'rodzaj żeński'), ('лѣньна ризꙗ', 'lniana szata', None, None), ('ризꙗ', 'ryza', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v06a', 'title': 'Kolory i kształty 1', 'icon': 'K', 'track': 'jezyk', 'words': [('чрьвьнъ', 'czerwony', None, None), ('синь', 'niebieski', None, None), ('зелень', 'zielony', None, None), ('жьлтъ', 'żółty', None, None), ('чрьнъ', 'czarny', None, None), ('бѣлъ', 'biały', None, None), ('сѣръ', 'szary', None, None), ('бронъ', 'brązowy', None, None), ('рꙋменъ', 'różowy', None, None), ('златъ', 'złoty', None, None), ('сьребрьнъ', 'srebrny', None, None), ('свѣтьлъ', 'jasny', None, None), ('тьмьнъ', 'ciemny', None, None), ('цвѣтъ', 'kolor', None, 'rodzaj męski'), ('кроуглъ', 'okrągły', None, None), ('прѧмъ', 'prosty', None, None)], 'sentences': []}, {'id': 'v06b', 'title': 'Kolory i kształty 2', 'icon': 'K', 'track': 'jezyk', 'words': [('кривъ', 'krzywy', None, None), ('чрьта', 'linia', None, 'rodzaj żeński'), ('точька', 'punkt', None, 'rodzaj żeński'), ('коло', 'koło', None, 'rodzaj nijaki'), ('образъ', 'kształt', None, 'rodzaj męski'), ('оуглъ', 'kąt', None, 'rodzaj męski'), ('страна', 'bok', None, 'rodzaj żeński'), ('срѣдина', 'środek', None, 'rodzaj żeński'), ('высота', 'wysokość', None, 'rodzaj żeński'), ('длъгота', 'długość', None, 'rodzaj żeński'), ('широта', 'szerokość', None, 'rodzaj żeński'), ('глѫбина', 'głębokość', None, 'rodzaj żeński'), ('величьство', 'wielkość', None, 'rodzaj nijaki'), ('мѣра', 'miara', None, 'rodzaj żeński'), ('остръ', 'ostry', None, None), ('тѫпъ', 'tępy', None, None)], 'sentences': []}, {'id': 'v06c', 'title': 'Kolory i kształty 3', 'icon': 'K', 'track': 'jezyk', 'words': [('гладькъ', 'gładki', None, None), ('шьроховатъ', 'szorstki', None, None), ('чрьвь', 'czerwień', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v07a', 'title': 'Liczby i ilości 1', 'icon': 'L', 'track': 'jezyk', 'words': [('три', 'trzy', None, None), ('ѥдинъ на десѧте', 'jedenaście', None, None), ('дъва на десѧте', 'dwanaście', None, None), ('дъва десѧти', 'dwadzieścia', None, None), ('три десѧти', 'trzydzieści', None, None), ('четꙑре десѧти', 'czterdzieści', None, None), ('пѧть десѧтъ', 'pięćdziesiąt', None, None), ('шесть десѧтъ', 'sześćdziesiąt', None, None), ('седмь десѧтъ', 'siedemdziesiąt', None, None), ('осмь десѧтъ', 'osiemdziesiąt', None, None), ('девѧть десѧтъ', 'dziewięćdziesiąt', None, None), ('съто', 'sto', None, 'rodzaj nijaki'), ('дъвѣ сътѣ', 'dwieście', None, None), ('тꙑсѫщи', 'tysiąc', None, 'rodzaj żeński'), ('пьрвꙑи', 'pierwszy', None, None), ('въторꙑи', 'drugi', None, None)], 'sentences': []}, {'id': 'v07b', 'title': 'Liczby i ilości 2', 'icon': 'L', 'track': 'jezyk', 'words': [('третии', 'trzeci', None, None), ('четвьртꙑи', 'czwarty', None, None), ('пѧтꙑи', 'piąty', None, None), ('шестꙑи', 'szósty', None, None), ('седмꙑи', 'siódmy', None, None), ('осмꙑи', 'ósmy', None, None), ('девѧтꙑи', 'dziewiąty', None, None), ('десѧтꙑи', 'dziesiąty', None, None), ('полъ', 'połowa', None, 'rodzaj męski'), ('чета', 'para', None, 'rodzaj żeński'), ('нѣколико', 'kilka', None, None), ('мъного', 'wiele', None, None), ('мало', 'mało', None, None), ('вьси', 'wszyscy', None, None), ('вьсе', 'wszystko', None, None), ('ничьто', 'żaden', None, None)], 'sentences': []}, {'id': 'v07c', 'title': 'Liczby i ilości 3', 'icon': 'L', 'track': 'jezyk', 'words': [('дъважды', 'dwa razy', None, None), ('триждꙑ', 'trzy razy', None, None), ('ѥдинъ дьнь', 'raz', None, None), ('колико', 'ile', None, None), ('толико', 'tyle', None, None), ('вѧще', 'więcej', None, None), ('мьнѥ', 'mniej', None, None), ('доволь', 'dość', None, None), ('пьрѣ', 'zbyt', None, None), ('дъвоиныи', 'podwójny', None, None), ('чети', 'pary', None, None), ('сътьникъ', 'setka', None, 'rodzaj męski'), ('тꙑсѫщьнꙑи', 'tysiączny', None, None), ('дъвое', 'dwoje', None, None), ('трое', 'troje', None, None), ('четверо', 'czworo', None, None)], 'sentences': []}, {'id': 'v07d', 'title': 'Liczby i ilości 4', 'icon': 'L', 'track': 'jezyk', 'words': [('оба', 'oboje', None, None)], 'sentences': []}, {'id': 'v08a', 'title': 'Czas 1', 'icon': 'C', 'track': 'jezyk', 'words': [('часъ', 'godzina', None, 'rodzaj męski'), ('нощь', 'noc', None, 'rodzaj żeński'), ('нєдѣлѧ', 'tydzień', None, 'rodzaj żeński'), ('лѣто', 'rok', None, 'rodzaj nijaki'), ('веснꙗ', 'wiosna', None, 'rodzaj żeński'), ('есень', 'jesień', None, 'rodzaj żeński'), ('зима', 'zima', None, 'rodzaj żeński'), ('оутро', 'rano', None, 'rodzaj nijaki'), ('пол̑ꙋдьнє', 'południe', None, 'rodzaj nijaki'), ('вечеръ', 'wieczór', None, 'rodzaj męski'), ('вьсєгда', 'zawsze', None, None), ('николиже', 'nigdy', None, None), ('иногда', 'czasem', None, None), ('чѧсто', 'często', None, None), ('оуже', 'już', None, None), ('ѥще', 'jeszcze', None, None)], 'sentences': []}, {'id': 'v08b', 'title': 'Czas 2', 'icon': 'C', 'track': 'jezyk', 'words': [('скоро', 'wkrótce', None, None), ('по томь', 'później', None, None), ('рано', 'wcześnie', None, None), ('поздѣ', 'późno', None, None), ('когда', 'kiedy', None, None), ('бꙑвъшее', 'przeszłość', None, 'rodzaj nijaki'), ('бѫдѫщее', 'przyszłość', None, 'rodzaj nijaki'), ('нꙑнѣ', 'teraźniejszość', None, 'rodzaj nijaki'), ('праздьникъ', 'święto', None, 'rodzaj męski'), ('вьчера', 'wczoraj', None, None), ('тогда', 'wtedy', None, None), ('вѣкъ', 'wiek', None, 'rodzaj męski'), ('мигъ', 'chwila', None, 'rodzaj męski'), ('врѣмѧ', 'czas', None, 'rodzaj nijaki'), ('юность', 'młodość', None, 'rodzaj żeński'), ('старость', 'starość', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v08c', 'title': 'Czas 3', 'icon': 'C', 'track': 'jezyk', 'words': [('дѣтьство', 'dzieciństwo', None, 'rodzaj nijaki'), ('зара', 'świt', None, 'rodzaj żeński'), ('сѫмракъ', 'zmierzch', None, 'rodzaj męski'), ('полоночь', 'północ', None, 'rodzaj żeński'), ('отъселѣ', 'odtąd', None, None), ('давьно', 'dawno', None, None), ('нєдавьно', 'niedawno', None, None), ('абиѥ', 'natychmiast', None, None), ('междоу тѣмь', 'tymczasem', None, None), ('прѣжде', 'wcześniej', None, None), ('наконьць', 'wreszcie', None, None), ('пьрвѣѥ', 'najpierw', None, None), ('потомь', 'potem', None, None), ('нєдѣлꙗ', 'niedziela', None, 'rodzaj żeński'), ('пондѣльникъ', 'poniedziałek', None, 'rodzaj męski'), ('пѧтъкъ', 'piątek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v08d', 'title': 'Czas 4', 'icon': 'C', 'track': 'jezyk', 'words': [('сѫбота', 'sobota', None, 'rodzaj żeński'), ('пасха', 'wielkanoc', None, 'rodzaj żeński'), ('рождьство', 'boże narodzenie', None, 'rodzaj nijaki'), ('постъ', 'post', None, 'rodzaj męski'), ('вѣчьность', 'wieczność', None, 'rodzaj żeński'), ('столѣтиѥ', 'stulecie', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v09a', 'title': 'Przyroda i pogoda 1', 'icon': 'P', 'track': 'jezyk', 'words': [('звѣзда', 'gwiazda', None, 'rodzaj żeński'), ('облакъ', 'chmura', None, 'rodzaj męski'), ('дождь', 'deszcz', None, 'rodzaj męski'), ('снѣгъ', 'śnieg', None, 'rodzaj męski'), ('вѣтръ', 'wiatr', None, 'rodzaj męski'), ('бꙋрꙗ', 'burza', None, 'rodzaj żeński'), ('мьгла', 'mgła', None, 'rodzaj żeński'), ('ледъ', 'lód', None, 'rodzaj męski'), ('море', 'morze', None, 'rodzaj nijaki'), ('рѣка', 'rzeka', None, 'rodzaj żeński'), ('езеро', 'jezioro', None, 'rodzaj nijaki'), ('гора', 'góra', None, 'rodzaj żeński'), ('дрѣво', 'drzewo', None, 'rodzaj nijaki'), ('трава', 'trawa', None, 'rodzaj żeński'), ('листъ', 'liść', None, 'rodzaj męski'), ('поле', 'pole', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v09b', 'title': 'Przyroda i pogoda 2', 'icon': 'P', 'track': 'jezyk', 'words': [('лѫка', 'łąka', None, 'rodzaj żeński'), ('островъ', 'wyspa', None, 'rodzaj męski'), ('бьрегъ', 'brzeg', None, 'rodzaj męski'), ('поустꙑнꙗ', 'pustynia', None, 'rodzaj żeński'), ('скала', 'skała', None, 'rodzaj żeński'), ('жара', 'upał', None, 'rodzaj żeński'), ('студь', 'zimno', None, 'rodzaj żeński'), ('топло', 'ciepło', None, 'rodzaj nijaki'), ('мразъ', 'mróz', None, 'rodzaj męski'), ('громъ', 'grzmot', None, 'rodzaj męski'), ('мльнии', 'błyskawica', None, 'rodzaj żeński'), ('дꙋга', 'tęcza', None, 'rodzaj żeński'), ('блато', 'błoto', None, 'rodzaj nijaki'), ('пѣскъ', 'piasek', None, 'rodzaj męski'), ('доль', 'dolina', None, 'rodzaj żeński'), ('холмъ', 'wzgórze', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v09c', 'title': 'Przyroda i pogoda 3', 'icon': 'P', 'track': 'jezyk', 'words': [('пещера', 'jaskinia', None, 'rodzaj żeński'), ('источьникъ', 'źródło', None, 'rodzaj męski'), ('болото', 'bagno', None, 'rodzaj nijaki'), ('грьмъ', 'krzak', None, 'rodzaj męski'), ('корꙋнь', 'korzeń', None, 'rodzaj męski'), ('вѣтвь', 'gałąź', None, 'rodzaj żeński'), ('роса', 'rosa', None, 'rodzaj żeński'), ('потопъ', 'powódź', None, 'rodzaj męski'), ('трѫсъ', 'trzęsienie ziemi', None, 'rodzaj męski'), ('тьма', 'ciemność', None, 'rodzaj żeński'), ('сѣнь', 'cień', None, 'rodzaj żeński'), ('мирь', 'świat', None, 'rodzaj męski'), ('пьнь', 'pień', None, 'rodzaj męski'), ('кора', 'kora', None, 'rodzaj żeński'), ('стьꙁꙗ', 'ścieżka', None, 'rodzaj żeński'), ('вꙁдꙋхъ', 'powietrze', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v09d', 'title': 'Przyroda i pogoda 4', 'icon': 'P', 'track': 'jezyk', 'words': [('заꙗ', 'zorza', None, 'rodzaj żeński'), ('добро врѣмѧ', 'pogoda', None, None), ('вихръ', 'wichura', None, 'rodzaj męski'), ('капъля', 'kropla', None, 'rodzaj żeński'), ('дѫбрава', 'gaj', None, 'rodzaj żeński'), ('боръ', 'bór', None, 'rodzaj męski'), ('дѫбъ', 'dąb', None, 'rodzaj męski'), ('бреꙁа', 'brzoza', None, 'rodzaj żeński'), ('сосна', 'sosna', None, 'rodzaj żeński'), ('ела', 'jodła', None, 'rodzaj żeński'), ('вьрба', 'wierzba', None, 'rodzaj żeński'), ('липа', 'lipa', None, 'rodzaj żeński'), ('бꙋкъ', 'buk', None, 'rodzaj męski'), ('ꙗсень', 'jesion', None, 'rodzaj męski'), ('ꙗблонь', 'jabłoń', None, 'rodzaj żeński'), ('лоꙁа', 'winorośl', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v09e', 'title': 'Przyroda i pogoda 5', 'icon': 'P', 'track': 'jezyk', 'words': [('роꙁа', 'róża', None, 'rodzaj żeński'), ('крин', 'lilia', None, 'rodzaj męski'), ('мъхъ', 'mech', None, 'rodzaj męski'), ('зелиѥ', 'ziele', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v10a', 'title': 'Zwierzęta 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('пьсъ', 'pies', None, 'rodzaj męski'), ('кошька', 'kot', None, 'rodzaj żeński'), ('конь', 'koń', None, 'rodzaj męski'), ('кобꙑла', 'klacz', None, 'rodzaj żeński'), ('кроваꙗ', 'krowa', None, 'rodzaj żeński'), ('боулъ', 'byk', None, 'rodzaj męski'), ('волъ', 'wół', None, 'rodzaj męski'), ('свинꙗ', 'świnia', None, 'rodzaj żeński'), ('овьца', 'owca', None, 'rodzaj żeński'), ('овьнъ', 'baran', None, 'rodzaj męski'), ('коза', 'koza', None, 'rodzaj żeński'), ('кꙋрꙑ', 'kura', None, 'rodzaj żeński'), ('пѣтлъ', 'kogut', None, 'rodzaj męski'), ('оутъка', 'kaczka', None, 'rodzaj żeński'), ('пътица', 'ptak', None, 'rodzaj żeński'), ('мꙑшь', 'mysz', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v10b', 'title': 'Zwierzęta 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('ѕмии', 'wąż', None, 'rodzaj męski'), ('жаба', 'żaba', None, 'rodzaj żeński'), ('лѣвъ', 'lew', None, 'rodzaj męski'), ('мєдвѣдь', 'niedźwiedź', None, 'rodzaj męski'), ('влькъ', 'wilk', None, 'rodzaj męski'), ('лиса', 'lis', None, 'rodzaj żeński'), ('заꙗць', 'zając', None, 'rodzaj męski'), ('ѥленъ', 'jeleń', None, 'rodzaj męski'), ('ослъ', 'osioł', None, 'rodzaj męski'), ('вельбѫдъ', 'wielbłąd', None, 'rodzaj męski'), ('орьлъ', 'orzeł', None, 'rodzaj męski'), ('сова', 'sowa', None, 'rodzaj żeński'), ('голѫбь', 'gołąb', None, 'rodzaj męski'), ('врана', 'wrona', None, 'rodzaj żeński'), ('вранъ', 'kruk', None, 'rodzaj męski'), ('лєбєдь', 'łabędź', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10c', 'title': 'Zwierzęta 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('гѫсь', 'gęś', None, 'rodzaj żeński'), ('славии', 'słowik', None, 'rodzaj męski'), ('ластовица', 'jaskółka', None, 'rodzaj żeński'), ('соколъ', 'sokół', None, 'rodzaj męski'), ('вепрь', 'dzik', None, 'rodzaj męski'), ('желъва', 'żółw', None, 'rodzaj żeński'), ('слимакъ', 'ślimak', None, 'rodzaj męski'), ('мравии', 'mrówka', None, 'rodzaj męski'), ('комаръ', 'komar', None, 'rodzaj męski'), ('ѡса', 'osa', None, 'rodzaj żeński'), ('бъчела', 'pszczoła', None, 'rodzaj żeński'), ('мꙋха', 'mucha', None, 'rodzaj żeński'), ('паѫкъ', 'pająk', None, 'rodzaj męski'), ('ракъ', 'rak', None, 'rodzaj męski'), ('скорпии', 'skorpion', None, 'rodzaj męski'), ('стадо', 'stado', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v10d', 'title': 'Zwierzęta 4', 'icon': 'Z', 'track': 'jezyk', 'words': [('чрѣда', 'trzoda', None, 'rodzaj żeński'), ('агнѧ', 'jagnię', None, 'rodzaj nijaki'), ('тєлѧ', 'cielę', None, 'rodzaj nijaki'), ('гнѣздо', 'gniazdo', None, 'rodzaj nijaki'), ('копыто', 'kopyto', None, 'rodzaj nijaki'), ('клѣть', 'klatka', None, 'rodzaj żeński'), ('оулии', 'ul', None, 'rodzaj męski'), ('лапа', 'łapa', None, 'rodzaj żeński'), ('клꙑкъ', 'kieł', None, 'rodzaj męski'), ('кортъ', 'pazur', None, 'rodzaj męski'), ('дракон', 'smok', None, 'rodzaj męski'), ('звѣрь', 'zwierzę', None, 'rodzaj męski'), ('скотъ', 'bydło', None, 'rodzaj męski'), ('лосось', 'ryba (łosoś)', None, 'rodzaj męski'), ('оугорь', 'węgorz', None, 'rodzaj męski'), ('китъ', 'wieloryb', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10e', 'title': 'Zwierzęta 5', 'icon': 'Z', 'track': 'jezyk', 'words': [('ѥхидна', 'wąż (żmija)', None, 'rodzaj żeński'), ('гадъ', 'gad', None, 'rodzaj męski'), ('тоуръ', 'tur', None, 'rodzaj męski'), ('зоубръ', 'żubr', None, 'rodzaj męski'), ('бобръ', 'bóbr', None, 'rodzaj męski'), ('вѣверица', 'wiewiórka', None, 'rodzaj żeński'), ('коуна', 'kuna', None, 'rodzaj żeński'), ('ꙗстрѧбъ', 'sokół (jastrząb)', None, 'rodzaj męski'), ('жеравль', 'żuraw', None, 'rodzaj męski'), ('кокошь', 'kukułka', None, 'rodzaj żeński'), ('дѧтьлъ', 'dzięcioł', None, 'rodzaj męski'), ('врабии', 'wróbel', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11a', 'title': 'Miasto i budynki 1', 'icon': 'M', 'track': 'jezyk', 'words': [('село', 'wieś', None, 'rodzaj nijaki'), ('оулица', 'ulica', None, 'rodzaj żeński'), ('пѫть', 'droga', None, 'rodzaj męski'), ('трьгъ', 'plac', None, 'rodzaj męski'), ('мостъ', 'most', None, 'rodzaj męski'), ('торгъ', 'targ', None, 'rodzaj męski'), ('храмъ', 'świątynia', None, 'rodzaj męski'), ('цьрки', 'kościół', None, 'rodzaj żeński'), ('манастꙑрь', 'klasztor', None, 'rodzaj męski'), ('приставъ', 'port', None, 'rodzaj męski'), ('вежа', 'wieża', None, 'rodzaj żeński'), ('твьрдꙑнꙗ', 'twierdza', None, 'rodzaj żeński'), ('градьна врата', 'brama miejska', None, None), ('станъ', 'obóz', None, 'rodzaj męski'), ('тьмьница', 'więzienie', None, 'rodzaj żeński'), ('гробъ', 'grób', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11b', 'title': 'Miasto i budynki 2', 'icon': 'M', 'track': 'jezyk', 'words': [('школа', 'szkoła', None, 'rodzaj żeński'), ('млинъ', 'młyn', None, 'rodzaj męski'), ('палата', 'pałac', None, 'rodzaj żeński'), ('градище', 'grodzisko', None, 'rodzaj nijaki'), ('корьчьма', 'karczma', None, 'rodzaj żeński'), ('олътарь', 'ołtarz', None, 'rodzaj męski'), ('звонница', 'dzwonnica', None, 'rodzaj żeński'), ('крьстъ', 'krzyż', None, 'rodzaj męski'), ('икона', 'ikona', None, 'rodzaj żeński'), ('мощи', 'relikwie', None, 'rodzaj żeński'), ('жилище', 'mieszkanie', None, 'rodzaj nijaki'), ('пригородъ', 'przedmieście', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v12a', 'title': 'Podróż i transport 1', 'icon': 'P', 'track': 'jezyk', 'words': [('возъ', 'wóz', None, 'rodzaj męski'), ('колесница', 'rydwan', None, 'rodzaj żeński'), ('корабль', 'statek', None, 'rodzaj męski'), ('лодии', 'łódź', None, 'rodzaj żeński'), ('весло', 'wiosło', None, 'rodzaj nijaki'), ('ветрило', 'żagiel', None, 'rodzaj nijaki'), ('кръма', 'ster', None, 'rodzaj żeński'), ('ꙗкорь', 'kotwica', None, 'rodzaj męski'), ('пѫтьствиѥ', 'podróż', None, 'rodzaj nijaki'), ('походъ', 'wyprawa', None, 'rodzaj męski'), ('распѫтии', 'skrzyżowanie', None, 'rodzaj nijaki'), ('бродъ', 'brod', None, 'rodzaj męski'), ('перевозъ', 'przeprawa', None, 'rodzaj męski'), ('гранꙇь', 'granica', None, 'rodzaj żeński'), ('пѫтьникъ', 'podróżnik', None, 'rodzaj męski'), ('сѫша', 'ląd', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v12b', 'title': 'Podróż i transport 2', 'icon': 'P', 'track': 'jezyk', 'words': [('брѣгъ', 'wybrzeże', None, 'rodzaj męski'), ('колесо', 'koło', None, 'rodzaj nijaki'), ('сани', 'sanie', None, 'rodzaj żeński'), ('сѣдло', 'siodło', None, 'rodzaj nijaki'), ('оуꙁда', 'uzda', None, 'rodzaj żeński'), ('ѣꙁда', 'jazda', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13a', 'title': 'Praca i szkoła 1', 'icon': 'P', 'track': 'jezyk', 'words': [('дѣло', 'praca', None, 'rodzaj nijaki'), ('кꙋзнь', 'kowal', None, 'rodzaj żeński'), ('дрѣводѣль', 'stolarz', None, 'rodzaj męski'), ('рꙑбарь', 'rybak', None, 'rodzaj męski'), ('мьꙁда', 'pensja', None, 'rodzaj żeński'), ('оучєниє', 'lekcja', None, 'rodzaj nijaki'), ('искоушєниє', 'egzamin', None, 'rodzaj nijaki'), ('кънига', 'książka', None, 'rodzaj żeński'), ('свитъкъ', 'zwój', None, 'rodzaj męski'), ('пєро', 'pióro', None, 'rodzaj nijaki'), ('чрьнило', 'atrament', None, 'rodzaj nijaki'), ('пєргаминъ', 'pergamin', None, 'rodzaj męski'), ('въпросъ', 'pytanie', None, 'rodzaj męski'), ('отъвѣтъ', 'odpowiedź', None, 'rodzaj męski'), ('наука', 'nauka', None, 'rodzaj żeński'), ('вѣдѣниѥ', 'wiedza', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v13b', 'title': 'Praca i szkoła 2', 'icon': 'P', 'track': 'jezyk', 'words': [('мѫдрость', 'mądrość', None, 'rodzaj żeński'), ('съвѣтъ', 'rada', None, 'rodzaj męski'), ('запо', 'polecenie', None, 'rodzaj żeński'), ('повелѣниѥ', 'rozkaz', None, 'rodzaj nijaki'), ('законъ', 'ustawa', None, 'rodzaj męski'), ('казнь', 'kara', None, 'rodzaj żeński'), ('награда', 'nagrada', None, 'rodzaj żeński'), ('длъгъ', 'obowiązek', None, 'rodzaj męski'), ('орѫдиѥ', 'narzędzie', None, 'rodzaj nijaki'), ('мотъ', 'młot', None, 'rodzaj męski'), ('сѣкꙑра', 'siekiera', None, 'rodzaj żeński'), ('пила', 'piła', None, 'rodzaj żeński'), ('плугъ', 'pług', None, 'rodzaj męski'), ('сръпъ', 'sierp', None, 'rodzaj męski'), ('коса', 'kosa', None, 'rodzaj żeński'), ('вѫже', 'lina', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v13c', 'title': 'Praca i szkoła 3', 'icon': 'P', 'track': 'jezyk', 'words': [('цѣпь', 'łańcuch', None, 'rodzaj żeński'), ('гвоꙁдь', 'gwóźdź', None, 'rodzaj męski'), ('пьсаниѥ', 'pismo', None, 'rodzaj nijaki'), ('боукꙑ', 'litera', None, 'rodzaj żeński'), ('рѣчь', 'mowa', None, 'rodzaj żeński'), ('бесѣда', 'przemowa', None, 'rodzaj żeński'), ('молитва', 'modlitwa', None, 'rodzaj żeński'), ('пѣснь', 'pieśń', None, 'rodzaj żeński'), ('псалъмъ', 'psalm', None, 'rodzaj męski'), ('проповѣдь', 'kazanie', None, 'rodzaj żeński'), ('евангелиѥ', 'ewangelia', None, 'rodzaj nijaki'), ('притъча', 'przypowieść', None, 'rodzaj żeński'), ('повѣсть', 'historia', None, 'rodzaj żeński'), ('право', 'prawo', None, 'rodzaj nijaki'), ('сѫдъ', 'sąd', None, 'rodzaj męski'), ('приговоръ', 'wyrok', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13d', 'title': 'Praca i szkoła 4', 'icon': 'P', 'track': 'jezyk', 'words': [('съвѣдѣтель', 'świadek', None, 'rodzaj męski'), ('клѧтва', 'przysięga', None, 'rodzaj żeński'), ('завѣтъ', 'umowa (przymierze)', None, 'rodzaj męski'), ('дань', 'podatek', None, 'rodzaj żeński'), ('мꙑто', 'cło', None, 'rodzaj nijaki'), ('цѣна', 'cena', None, 'rodzaj żeński'), ('богатьство', 'bogactwo', None, 'rodzaj nijaki'), ('нищета', 'ubóstwo', None, 'rodzaj żeński'), ('даръ', 'dar', None, 'rodzaj męski'), ('добꙑчь', 'łup', None, 'rodzaj żeński'), ('бранъ', 'bitwa', None, 'rodzaj żeński'), ('побѣда', 'zwycięstwo', None, 'rodzaj żeński'), ('пълкъ', 'wojsko', None, 'rodzaj męski'), ('щитъ', 'tarcza', None, 'rodzaj męski'), ('копиѥ', 'włócznia', None, 'rodzaj nijaki'), ('мєчь', 'miecz', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13e', 'title': 'Praca i szkoła 5', 'icon': 'P', 'track': 'jezyk', 'words': [('лѫкъ', 'łuk', None, 'rodzaj męski'), ('стрѣла', 'strzała', None, 'rodzaj żeński'), ('шьломъ', 'hełm', None, 'rodzaj męski'), ('бронꙗ', 'pancerz', None, 'rodzaj żeński'), ('бѣгъ', 'ucieczka', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v14a', 'title': 'Zdrowie 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('здравиѥ', 'zdrowie', None, 'rodzaj nijaki'), ('болѣзнь', 'choroba', None, 'rodzaj żeński'), ('болѣсть', 'ból', None, 'rodzaj żeński'), ('кашель', 'kaszel', None, 'rodzaj męski'), ('врачеваниѥ', 'lekarstwo', None, 'rodzaj nijaki'), ('рана', 'rana', None, 'rodzaj żeński'), ('здравъ', 'zdrowy', None, None), ('болнъ', 'chory', None, None), ('оутомьнъ', 'zmęczony', None, None), ('крѣпъкъ', 'silny', None, None), ('слабъ', 'słaby', None, None), ('глоухъ', 'głuchy', None, None), ('слѣпъ', 'ślepy', None, None), ('хромъ', 'kulawy', None, None), ('нѣмъ', 'niemy', None, None), ('безоумьнъ', 'szalony', None, None)], 'sentences': []}, {'id': 'v14b', 'title': 'Zdrowie 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('ѩдъ', 'trucizna', None, 'rodzaj męski'), ('съмрьть', 'śmierć', None, 'rodzaj żeński'), ('трупъ', 'trup', None, 'rodzaj męski'), ('цѣлєниє', 'uzdrowienie', None, 'rodzaj nijaki'), ('помощь', 'pomoc', None, 'rodzaj żeński'), ('покои', 'odpoczynek', None, 'rodzaj męski'), ('масть', 'maść', None, 'rodzaj żeński'), ('врачєваниѥ', 'leczenie', None, 'rodzaj nijaki'), ('проказа', 'trąd', None, 'rodzaj żeński'), ('прокаженъ', 'trędowaty', None, None), ('слѣпота', 'ślepota', None, 'rodzaj żeński'), ('плачь', 'płacz', None, 'rodzaj męski'), ('вопль', 'krzyk', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v15a', 'title': 'Uczucia i charakter 1', 'icon': 'U', 'track': 'jezyk', 'words': [('радость', 'radość', None, 'rodzaj żeński'), ('печаль', 'smutek', None, 'rodzaj żeński'), ('страхъ', 'strach', None, 'rodzaj męski'), ('гнѣвъ', 'gniew', None, 'rodzaj męski'), ('любꙑ', 'miłość', None, 'rodzaj żeński'), ('дроужба', 'przyjaźń', None, 'rodzaj żeński'), ('ненавидь', 'nienawiść', None, 'rodzaj żeński'), ('надѣѭ', 'nadzieja', None, 'rodzaj żeński'), ('сънъ', 'marzenie', None, 'rodzaj męski'), ('счастиѥ', 'szczęście', None, 'rodzaj nijaki'), ('срамъ', 'wstyd', None, 'rodzaj męski'), ('чоудо', 'zdziwienie', None, 'rodzaj nijaki'), ('тьрпѣниѥ', 'cierpliwość', None, 'rodzaj nijaki'), ('искьрьнь', 'szczery', None, None), ('милъ', 'miły', None, None), ('глоупъ', 'głupi', None, None)], 'sentences': []}, {'id': 'v15b', 'title': 'Uczucia i charakter 2', 'icon': 'U', 'track': 'jezyk', 'words': [('мѫдръ', 'mądry', None, None), ('лѣнивъ', 'leniwy', None, None), ('веселъ', 'wesoły', None, None), ('печаленъ', 'smutny', None, None), ('гнѣвьливъ', 'zły', None, None), ('блаженъ', 'szczęśliwy', None, None), ('самъ', 'samotny', None, None), ('тихъ', 'spokojny', None, None), ('гръдъ', 'dumny', None, None), ('зависливъ', 'zazdrosny', None, None), ('благодарьнъ', 'wdzięczny', None, None), ('храбьръ', 'odważny', None, None), ('вѣрьнъ', 'wierny', None, None), ('невѣрьнъ', 'zdradziecki', None, None), ('скѫпъ', 'skąpy', None, None), ('щедръ', 'hojny', None, None)], 'sentences': []}, {'id': 'v15c', 'title': 'Uczucia i charakter 3', 'icon': 'U', 'track': 'jezyk', 'words': [('съмѣрьнъ', 'pokorny', None, None), ('милостивъ', 'litościwy', None, None), ('жестокъ', 'okrutny', None, None), ('праведьнъ', 'sprawiedliwy', None, None), ('неправьдьнъ', 'niesprawiedliwy', None, None), ('нєчьстивъ', 'nikczemny', None, None), ('благочьстивъ', 'pobożny', None, None), ('безбожьнъ', 'bezbożny', None, None), ('благородьнъ', 'szlachetny', None, None), ('милость', 'litość', None, 'rodzaj żeński'), ('жаль', 'żal', None, 'rodzaj żeński'), ('тѫга', 'tęsknota', None, 'rodzaj żeński'), ('зависть', 'zazdrość', None, 'rodzaj żeński'), ('мьсть', 'zemsta', None, 'rodzaj żeński'), ('сѫдьба', 'los', None, 'rodzaj żeński'), ('грѣхъ', 'grzech', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v15d', 'title': 'Uczucia i charakter 4', 'icon': 'U', 'track': 'jezyk', 'words': [('благодать', 'łaska', None, 'rodzaj żeński'), ('вѣра', 'wiara', None, 'rodzaj żeński'), ('съмѣрєниє', 'pokora', None, 'rodzaj nijaki'), ('добродѣтєль', 'cnota', None, 'rodzaj żeński'), ('поровъ', 'wada', None, 'rodzaj męski'), ('гръдость', 'pycha', None, 'rodzaj żeński'), ('сребролюбиѥ', 'chciwość', None, 'rodzaj nijaki'), ('правьда', 'prawda', None, 'rodzaj żeński'), ('лъжа', 'kłamstwo', None, 'rodzaj żeński'), ('свобода', 'wolność', None, 'rodzaj żeński'), ('работа', 'niewola', None, 'rodzaj żeński'), ('чьсть', 'honor', None, 'rodzaj żeński'), ('хвала', 'chwała', None, 'rodzaj żeński'), ('срамота', 'hańba', None, 'rodzaj żeński'), ('прѣмѫдрость', 'mądrość (Bożą)', None, 'rodzaj żeński'), ('воля', 'wola', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v15e', 'title': 'Uczucia i charakter 5', 'icon': 'U', 'track': 'jezyk', 'words': [('оумъ', 'rozum', None, 'rodzaj męski'), ('памѧть', 'pamięć', None, 'rodzaj żeński'), ('мꙑсль', 'myśl', None, 'rodzaj żeński'), ('съвѣсть', 'sumienie', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v16a', 'title': 'Przymiotniki 1', 'icon': 'P', 'track': 'jezyk', 'words': [('великъ', 'duży', None, None), ('малъ', 'mały', None, None), ('кратъкъ', 'krótki', None, None), ('высокъ', 'wysoki', None, None), ('нижьнь', 'niski', None, None), ('широкъ', 'szeroki', None, None), ('оуꙁъкъ', 'wąski', None, None), ('тлъстъ', 'gruby', None, None), ('тънъкъ', 'chudy', None, None), ('тѧжькъ', 'ciężki', None, None), ('лѣгъкъ', 'lekki', None, None), ('скоръ', 'szybki', None, None), ('мꙑдьльнъ', 'wolny', None, None), ('твръдъ', 'twardy', None, None), ('мѧхъкъ', 'miękki', None, None), ('мокръ', 'mokry', None, None)], 'sentences': []}, {'id': 'v16b', 'title': 'Przymiotniki 2', 'icon': 'P', 'track': 'jezyk', 'words': [('сꙋхъ', 'suchy', None, None), ('чистъ', 'czysty', None, None), ('нечистъ', 'brudny', None, None), ('плънъ', 'pełny', None, None), ('поустъ', 'pusty', None, None), ('гласьнъ', 'głośny', None, None), ('младъ', 'młody', None, None), ('старъ', 'stary', None, None), ('новъ', 'nowy', None, None), ('ѕълъ', 'zły (zły)', None, None), ('красьнъ', 'ładny', None, None), ('гꙑдъкъ', 'brzydki', None, None), ('трѫдьнъ', 'trudny', None, None), ('важьнъ', 'ważny', None, None), ('возможьнъ', 'możliwy', None, None), ('истиньнъ', 'prawdziwy', None, None)], 'sentences': []}, {'id': 'v16c', 'title': 'Przymiotniki 3', 'icon': 'P', 'track': 'jezyk', 'words': [('лъжьнъ', 'fałszywy', None, None), ('свои', 'własny', None, None), ('чоужь', 'obcy', None, None), ('могꙋщь', 'potężny', None, None), ('слависвъ', 'sławny', None, None), ('близъ', 'bliski', None, None), ('далекъ', 'daleki', None, None), ('готовъ', 'gotowy', None, None), ('подобьнъ', 'podobny', None, None), ('инъ', 'inny', None, None), ('къжьдо', 'każdy', None, None), ('глѫбокъ', 'głęboki', None, None), ('мѣлъкъ', 'płytki', None, None), ('сладъкъ', 'słodki', None, None), ('горькъ', 'gorzki', None, None), ('кисель', 'kwaśny', None, None)], 'sentences': []}, {'id': 'v16d', 'title': 'Przymiotniki 4', 'icon': 'P', 'track': 'jezyk', 'words': [('сланъ', 'słony', None, None), ('горѧчь', 'gorący', None, None), ('студенъ', 'zimny', None, None), ('теплъ', 'ciepły', None, None), ('рѣдъкъ', 'rzadki', None, None), ('обьштъ', 'wspólny', None, None), ('особьнъ', 'osobny', None, None), ('послѣдьнь', 'ostatni', None, None), ('слѣдоующь', 'następny', None, None), ('древьнь', 'dawny', None, None), ('вѣчьнъ', 'wieczny', None, None), ('съмрьтьнъ', 'śmiertelny', None, None), ('безсмрьтьнъ', 'nieśmiertelny', None, None), ('божьскъ', 'boski', None, None), ('чловѣчьскъ', 'ludzki', None, None), ('грьчьскъ', 'grecki', None, None)], 'sentences': []}, {'id': 'v16e', 'title': 'Przymiotniki 5', 'icon': 'P', 'track': 'jezyk', 'words': [('словѣньскъ', 'słowiański', None, None), ('землѣнъ', 'ziemski', None, None), ('небесьнъ', 'niebiański', None, None), ('доухоуьнъ', 'duchowy', None, None), ('плътьскъ', 'cielesny', None, None), ('ѥдиныи', 'jedyny', None, None), ('чьстьнъ', 'szanowny', None, None), ('любимъ', 'drogi (ukochany)', None, None), ('дорогъ', 'drogi (kosztowny)', None, None), ('ѕълѣ', 'źle', None, None)], 'sentences': []}, {'id': 'v17a', 'title': 'Czasowniki podstawowe 1', 'icon': 'C', 'track': 'jezyk', 'words': [('бꙑти', 'być', None, None), ('имѣти', 'mieć', None, None), ('дѣлати', 'robić', None, None), ('ити', 'iść', None, None), ('ѣхати', 'jechać', None, None), ('приити', 'przyjść', None, None), ('изити', 'wyjść', None, None), ('вьнити', 'wejść', None, None), ('възвратити сѧ', 'wrócić', None, None), ('бѣжати', 'biec', None, None), ('стоꙗти', 'stać', None, None), ('сѣдѣти', 'siedzieć', None, None), ('лежати', 'leżeć', None, None), ('спати', 'spać', None, None), ('въстати', 'wstać', None, None), ('ѩсти', 'jeść', None, None)], 'sentences': []}, {'id': 'v17b', 'title': 'Czasowniki podstawowe 2', 'icon': 'C', 'track': 'jezyk', 'words': [('пити', 'pić', None, None), ('варити', 'gotować', None, None), ('мꙑти', 'myć', None, None), ('wѣлѣцѣти', 'ubierać się', None, None), ('глаголати', 'mówić', None, None), ('рєшти', 'powiedzieć', None, None), ('въпрашати', 'pytać', None, None), ('отъвѣштати', 'odpowiadać', None, None), ('слꙑшати', 'słyszeć', None, None), ('видѣти', 'widzieć', None, None), ('гледати', 'patrzeć', None, None), ('чисти', 'czytać', None, None), ('писати', 'pisać', None, None), ('оучити сѧ', 'uczyć się', None, None), ('оучити', 'uczyć', None, None), ('разоумѣти', 'rozumieć', None, None)], 'sentences': []}, {'id': 'v17c', 'title': 'Czasowniki podstawowe 3', 'icon': 'C', 'track': 'jezyk', 'words': [('вѣдѣти', 'wiedzieć', None, None), ('знати', 'znać', None, None), ('мꙑслити', 'myśleć', None, None), ('помьнѣти', 'pamiętać', None, None), ('забꙑвати', 'zapominać', None, None), ('хотѣти', 'chcieć', None, None), ('любити', 'lubić', None, None), ('трѣбовати', 'potrzebować', None, None), ('могти', 'móc', None, None), ('мѫсити', 'musieć', None, None), ('дати', 'dawać', None, None), ('приѩти', 'brać', None, None), ('купити', 'kupować', None, None), ('продати', 'sprzedawać', None, None), ('платити', 'płacić', None, None), ('отъвьрсти', 'otwierać', None, None)], 'sentences': []}, {'id': 'v17d', 'title': 'Czasowniki podstawowe 4', 'icon': 'C', 'track': 'jezyk', 'words': [('затворити', 'zamykać', None, None), ('начинати', 'zaczynać', None, None), ('къчати', 'kończyć', None, None), ('играти', 'grać', None, None), ('пѣти', 'śpiewać', None, None), ('плѧсати', 'tańczyć', None, None), ('плꙑти', 'pływać', None, None), ('летѣти', 'latać', None, None), ('положити', 'kłaść', None, None), ('искати', 'szukać', None, None), ('нати', 'znajdować', None, None), ('чьдати', 'czekać', None, None), ('помагати', 'pomagać', None, None), ('просити', 'prosić', None, None), ('прощати', 'przepraszać', None, None), ('позволити', 'pozwalać', None, None)], 'sentences': []}, {'id': 'v17e', 'title': 'Czasowniki podstawowe 5', 'icon': 'C', 'track': 'jezyk', 'words': [('искоушати', 'próbować', None, None), ('мѣнити', 'zmieniać', None, None), ('носити', 'nosić', None, None), ('дьржати', 'trzymać', None, None), ('метати', 'rzucać', None, None), ('ловити', 'łapać', None, None), ('бити', 'bić', None, None), ('оубити', 'zabijać', None, None), ('оумирати', 'umierać', None, None), ('жити', 'żyć', None, None), ('срѣсти', 'spotykać', None, None), ('посълати', 'wysyłać', None, None), ('получити', 'dostawać', None, None), ('показати', 'pokazywać', None, None), ('приꙁвати', 'zapraszać', None, None), ('посѣтити', 'odwiedzać', None, None)], 'sentences': []}, {'id': 'v17f', 'title': 'Czasowniki podstawowe 6', 'icon': 'C', 'track': 'jezyk', 'words': [('плакати', 'płakać', None, None), ('съмѣꙗти сѧ', 'śmiać się', None, None), ('боꙗти сѧ', 'bać się', None, None), ('радовати сѧ', 'cieszyć się', None, None), ('вѣровати', 'wierzyć', None, None), ('съгласити сѧ', 'zgadzać się', None, None), ('избирати', 'wybierać', None, None), ('ръшити', 'decydować', None, None), ('числити', 'liczyć', None, None), ('владѣти', 'rządzić', None, None), ('водити', 'prowadzić', None, None), ('покорити сѧ', 'poddać się', None, None), ('побѣдити', 'zwyciężać', None, None), ('бороти сѧ', 'walczyć', None, None), ('брънити', 'bronić', None, None), ('напасти', 'atakować', None, None)], 'sentences': []}, {'id': 'v17g', 'title': 'Czasowniki podstawowe 7', 'icon': 'C', 'track': 'jezyk', 'words': [('погꙋбити', 'niszczyć', None, None), ('съзьдати', 'budować', None, None), ('разроушити', 'burzyć', None, None), ('жєшти', 'palić', None, None), ('гасити', 'gasić', None, None), ('жѧдати', 'pragnąć', None, None), ('срамити сѧ', 'wstydzić się', None, None), ('жалѣти', 'żałować', None, None), ('съпасти', 'ratować', None, None), ('свободити', 'wyzwalać', None, None), ('чьстити', 'czcić', None, None), ('молити сѧ', 'modlić się', None, None), ('жьрти', 'składać ofiarę', None, None), ('клѧти сѧ', 'przysięgać', None, None), ('обѣштати', 'obiecywać', None, None), ('лъгати', 'kłamać', None, None)], 'sentences': []}, {'id': 'v17h', 'title': 'Czasowniki podstawowe 8', 'icon': 'C', 'track': 'jezyk', 'words': [('ѡклеветати', 'oskarżać', None, None), ('сѫдити', 'sądzić', None, None), ('казнити', 'karać', None, None), ('благодарити', 'dziękować', None, None), ('цѣловати', 'pozdrawiać', None, None), ('благословити', 'błogosławić', None, None), ('крьстити', 'chrzcić', None, None), ('проповѣдати', 'głosić', None, None), ('исповѣдати', 'wyznawać', None, None), ('грѣшити', 'grzeszyć', None, None), ('отъпоуштати', 'odpuszczać', None, None), ('съпасати', 'zbawiać', None, None), ('сътворити', 'stworzyć', None, None), ('родити сѧ', 'narodzić się', None, None), ('въскрьсити', 'wskrzesić', None, None), ('възрѣти', 'widzieć (spojrzeć)', None, None)], 'sentences': []}, {'id': 'v17i', 'title': 'Czasowniki podstawowe 9', 'icon': 'C', 'track': 'jezyk', 'words': [('поклонити сѧ', 'oddawać cześć', None, None), ('молити', 'błagać', None, None), ('чоудити сѧ', 'dziwić się', None, None), ('оудивити', 'zdumiewać', None, None)], 'sentences': []}, {'id': 'v18a', 'title': 'Czasowniki dnia codziennego 1', 'icon': 'C', 'track': 'jezyk', 'words': [('ходити', 'chodzić', None, None), ('ѣздити', 'jeździć', None, None), ('въсѣсти', 'wsiadać', None, None), ('сѣсти', 'wysiadać', None, None), ('отвратити', 'skręcać', None, None), ('стати', 'zatrzymywać się', None, None), ('тѣшити сѧ', 'spieszyć się', None, None), ('почивати', 'odpoczywać', None, None), ('поправити', 'naprawiać', None, None), ('сѣшти', 'ciąć', None, None), ('жарити', 'smażyć', None, None), ('пєшти', 'piec', None, None), ('мѣсити', 'mieszać', None, None), ('наливати', 'nalewać', None, None), ('чистити', 'sprzątać', None, None), ('прати', 'prać', None, None)], 'sentences': []}, {'id': 'v18b', 'title': 'Czasowniki dnia codziennego 2', 'icon': 'C', 'track': 'jezyk', 'words': [('брити сѧ', 'golić się', None, None), ('чесати', 'czesać', None, None), ('купати сѧ', 'kąpać się', None, None), ('бꙋдити сѧ', 'budzić się', None, None), ('оусъпати', 'zasypiać', None, None), ('сънити сѧ', 'śnić', None, None), ('оупражнѧти', 'ćwiczyć', None, None), ('двигати', 'ruszać', None, None), ('тѧгнѫти', 'ciągnąć', None, None), ('тъкати', 'pchać', None, None), ('въздвигнѫти', 'podnosić', None, None), ('падати', 'spadać', None, None), ('скакати', 'skakać', None, None), ('лѣзти', 'wspinać się', None, None), ('скрꙑти', 'ukrywać', None, None), ('красти', 'kraść', None, None)], 'sentences': []}, {'id': 'v18c', 'title': 'Czasowniki dnia codziennego 3', 'icon': 'C', 'track': 'jezyk', 'words': [('отдати', 'oddawać', None, None), ('заꙗти', 'pożyczać', None, None), ('издати', 'wydawać', None, None), ('щадити', 'oszczędzać', None, None), ('орати', 'orać', None, None), ('сѣѩти', 'siać', None, None), ('жєти', 'żąć', None, None), ('събирати', 'zbierać', None, None), ('садити', 'sadzić', None, None), ('поливати', 'podlewać', None, None), ('пасти', 'paść', None, None), ('доити', 'doić', None, None), ('стрищи', 'strzyc', None, None), ('прѧсти', 'prząść', None, None), ('мълти', 'mleć', None, None), ('рѣзати', 'rzeźbić', None, None)], 'sentences': []}, {'id': 'v18d', 'title': 'Czasowniki dnia codziennego 4', 'icon': 'C', 'track': 'jezyk', 'words': [('коути', 'kuć', None, None), ('топити', 'topić', None, None), ('копати', 'kopać', None, None), ('вѧзати', 'wiązać', None, None), ('развѧзати', 'rozwiązywać', None, None), ('отъкрꙑти', 'odmykać', None, None), ('сѣдати', 'siadać', None, None), ('бесѣдовати', 'rozmawiać', None, None), ('кричати', 'krzyczeć', None, None), ('млъчати', 'milczeć', None, None), ('шьпътати', 'szeptać', None, None), ('въꙁꙑвати', 'wołać', None, None), ('проводити', 'żegnać', None, None), ('приветъствовати', 'witać', None, None), ('нарицати', 'nazywać', None, None), ('повѣдати', 'opowiadać', None, None)], 'sentences': []}, {'id': 'v18e', 'title': 'Czasowniki dnia codziennego 5', 'icon': 'C', 'track': 'jezyk', 'words': [('описати', 'opisywać', None, None), ('тлъковати', 'tłumaczyć', None, None), ('хвалити', 'chwalić', None, None), ('хоулити', 'ganić', None, None), ('проштати', 'wybaczać', None, None), ('повелѣвати', 'rozkazywać', None, None), ('запрештати', 'zabraniać', None, None), ('воєводьствовати', 'dowodzić', None, None), ('грести', 'wiosłować', None, None), ('причѧстити сѧ', 'brać udział', None, None), ('приходити', 'przybywać', None, None), ('отходити', 'odchodzić', None, None), ('възвращати сѧ', 'wracać', None, None), ('ꙗвити сѧ', 'ukazywać się', None, None), ('бꙑвати', 'stawać się', None, None), ('сътворити сѧ', 'wydarzać się', None, None)], 'sentences': []}, {'id': 'v18f', 'title': 'Czasowniki dnia codziennego 6', 'icon': 'C', 'track': 'jezyk', 'words': [('видѣти сѧ', 'wydawać się', None, None), ('ѡстати', 'pozostawać', None, None), ('отъставити', 'porzucać', None, None), ('слоушати', 'słuchać', None, None), ('касати сѧ', 'dotykać', None, None), ('чоути', 'czuć', None, None), ('нюхати', 'wąchać', None, None), ('вкоусити', 'smakować', None, None), ('трѫдити сѧ', 'ciężko pracować', None, None), ('мѫчити сѧ', 'męczyć się', None, None), ('тьрпѣти', 'cierpieć', None, None), ('растѫ', 'wzrastać', None, None), ('родити', 'rodzić', None, None), ('кърмити', 'karmić', None, None), ('въспитати', 'wychowywać', None, None)], 'sentences': []}, {'id': 'v19a', 'title': 'Słowa funkcyjne 1', 'icon': 'S', 'track': 'jezyk', 'words': [('тъ', 'ten', None, None), ('сѣмо', 'tutaj', None, None), ('тамо', 'tam', None, None), ('отьсѫдꙋ', 'stąd', None, None), ('къдє', 'gdzie', None, None), ('како', 'jak', None, None), ('почьто', 'dlaczego', None, None), ('ѥже', 'który', None, None), ('каковъ', 'jaki', None, None), ('нѫ', 'ale', None, None), ('или', 'lub', None, None), ('бо', 'bo', None, None), ('яко', 'ponieważ', None, None), ('аште', 'jeśli', None, None), ('оубо', 'więc', None, None), ('же', 'też', None, None)], 'sentences': []}, {'id': 'v19b', 'title': 'Słowa funkcyjne 2', 'icon': 'S', 'track': 'jezyk', 'words': [('токьмо', 'tylko', None, None), ('нѣчьто', 'trochę', None, None), ('нѣкъто', 'ktoś', None, None), ('никътоже', 'nikt', None, None), ('можєтъ', 'może', None, None), ('истиною', 'na pewno', None, None), ('вмѣстѣ', 'razem', None, None), ('бєꙁ', 'bez', None, None), ('съ', 'z', None, None), ('къ', 'do', None, None), ('ради', 'dla', None, None), ('чрѣзъ', 'przez', None, None), ('по', 'po', None, None), ('прѣдъ', 'przed', None, None), ('за', 'za', None, None), ('надъ', 'nad', None, None)], 'sentences': []}, {'id': 'v19c', 'title': 'Słowa funkcyjne 3', 'icon': 'S', 'track': 'jezyk', 'words': [('междю', 'między', None, None), ('противъ', 'przeciw', None, None), ('о', 'o', None, None), ('окрѫгъ', 'około', None, None), ('почти', 'prawie', None, None), ('нѣгдє', 'gdzieś', None, None), ('нигдѣже', 'nigdzie', None, None), ('вьсюдꙋ', 'wszędzie', None, None), ('вельми', 'bardzo', None, None), ('тако', 'tak', None, None), ('нє', 'nie', None, None), ('ли', 'czy', None, None), ('обаче', 'jednak', None, None), ('аште и', 'chociaż', None, None), ('егда', 'gdy', None, None), ('доидєже', 'dopóki', None, None)], 'sentences': []}, {'id': 'v19d', 'title': 'Słowa funkcyjne 4', 'icon': 'S', 'track': 'jezyk', 'words': [('прѣжде даже', 'zanim', None, None), ('нито', 'ani', None, None), ('вѣдь', 'przecież', None, None), ('истинѣ', 'naprawdę', None, None), ('ꙗвѣ', 'oczywiście', None, None), ('ѥстъ', 'mianowicie', None, None), ('сегоради', 'dlatego', None, None), ('а', 'natomiast', None, None), ('откꙋдꙋ', 'skąd', None, None), ('камо', 'dokąd', None, None), ('дроугъ дроуга', 'wzajemnie', None, None), ('мѧ', 'mnie', None, None), ('тѧ', 'ciebie', None, None), ('ѥго', 'jego', None, None), ('васъ', 'was', None, None), ('ихъ', 'ich', None, None)], 'sentences': []}, {'id': 'v19e', 'title': 'Słowa funkcyjne 5', 'icon': 'S', 'track': 'jezyk', 'words': [('она', 'ona', None, None), ('оно', 'ono', None, None), ('вꙑ', 'wy', None, None), ('они', 'oni', None, None), ('да бꙋдєтъ', 'niechaj', None, None)], 'sentences': []}, {'id': 'v20a', 'title': 'Wiara i świat 1', 'icon': 'W', 'track': 'jezyk', 'words': [('Богъ', 'Bóg', None, 'rodzaj męski'), ('Христосъ', 'Chrystus', None, 'rodzaj męski'), ('Исоусъ', 'Jezus', None, 'rodzaj męski'), ('Свѧтꙑи Доухъ', 'Duch Święty', None, 'rodzaj męski'), ('Троица', 'Trójca', None, 'rodzaj żeński'), ('Мариꙗ', 'Maryja', None, 'rodzaj żeński'), ('Богородица', 'Matka Boża', None, 'rodzaj żeński'), ('свѧта', 'święta', None, 'rodzaj żeński'), ('нєбєса', 'niebo', None, 'rodzaj żeński'), ('адъ', 'piekło', None, 'rodzaj męski'), ('раи', 'raj', None, 'rodzaj męski'), ('сатана', 'szatan', None, 'rodzaj męski'), ('дьꙗволъ', 'diabeł', None, 'rodzaj męski'), ('бѣсъ', 'demon', None, 'rodzaj męski'), ('искоупленіе', 'odkupienie', None, 'rodzaj nijaki'), ('спасениѥ', 'zbawienie', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v20b', 'title': 'Wiara i świat 2', 'icon': 'W', 'track': 'jezyk', 'words': [('въскрьсениѥ', 'zmartwychwstanie', None, 'rodzaj nijaki'), ('жрьтва', 'ofiara', None, 'rodzaj żeński'), ('поста', 'post', None, 'rodzaj męski'), ('литургиꙗ', 'msza', None, 'rodzaj żeński'), ('крьщєниє', 'chrzest', None, 'rodzaj nijaki'), ('причєщєниє', 'komunia', None, 'rodzaj nijaki'), ('исповѣдь', 'spowiedź', None, 'rodzaj żeński'), ('свѧштєникъ', 'kapłan', None, 'rodzaj męski'), ('диꙗконъ', 'diakon', None, 'rodzaj męski'), ('патриархъ', 'patriarcha', None, 'rodzaj męski'), ('пєтьдєсєтница', 'Pięćdziesiątnica', None, 'rodzaj żeński'), ('пророчьство', 'proroctwo', None, 'rodzaj nijaki'), ('ꙗвлєниѥ', 'objawienie', None, 'rodzaj nijaki'), ('животъ', 'życie', None, 'rodzaj męski'), ('страшьныи сѫдъ', 'sąd ostateczny', None, 'rodzaj męski'), ('милосрьдиѥ', 'miłosierdzie', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v20c', 'title': 'Wiara i świat 3', 'icon': 'W', 'track': 'jezyk', 'words': [('благословєниє', 'błogosławieństwo', None, 'rodzaj nijaki'), ('проклѧтиѥ', 'przekleństwo', None, 'rodzaj nijaki'), ('Кириллъ', 'Cyryl', None, 'rodzaj męski'), ('Мєфодии', 'Metody', None, 'rodzaj męski'), ('Моравꙗ', 'Morawy', None, 'rodzaj żeński'), ('Цариградъ', 'Konstantynopol', None, 'rodzaj męski'), ('Охридъ', 'Ochryda', None, 'rodzaj męski'), ('Блъгарьскъ', 'Bułgaria', None, 'rodzaj żeński'), ('Плиска', 'Pliska', None, 'rodzaj żeński'), ('Прєславъ', 'Preslaw', None, 'rodzaj męski'), ('цѣсарь', 'car', None, 'rodzaj męski'), ('Симєонъ', 'Symeon', None, 'rodzaj męski'), ('Борисъ', 'Borys', None, 'rodzaj męski')], 'sentences': []}]
# === /SŁOWNICTWO ===

"""[en — wygenerowane przez tools/i18n.py, nie edytuj] Treść kursu: język kaszubski dla Polaków.

Słowo:     (forma, znaczenie po polsku, polski odpowiednik lub None, skojarzenie lub None)
Litera:    (litera lub dwuznak, jak czytać, przykład)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie, dział)

Wymowa (pole „tr”) powstaje automatycznie w engine.py, zapisana polskimi literami:
òwca → łewca, zëma → zyma.

Źródła: alfabet i wymowa wg Wikipedii (Kashubian alphabet); zaimki, odmiana bëc i robic,
liczebniki, rzeczowniki i przymiotniki wg Wikipedii (Kashubian grammar); słownictwo z podręcznika
języka kaszubskiego na zpe.gov.pl; zwroty wg omniglot.com; art. 1 Powszechnej Deklaracji Praw
Człowieka wg Wikipedii (Kashubian language); początek „Òjcze nasz” wg Wikipedii (Lechitic languages)
i kaszuby.info.pl.
"""

UNITS = [
    # ------------------------------------------------------------------ pismo
    {
        "id": "pismo1", "title": 'Letters I', "icon": "Ò", "track": "pismo",
        "letters": [
            ("ò", '[wɛ]: òwca reads “wetsa”, mòrze “mwezhe”', "òwca"),
            ("ù", '[wʉ]: kùńszt (art) reads “kwunsht”', "kùńszt"),
            ("ë", '[ə] (schwa), like the a in “about”', "zëma"),
            ("ã", '[ã], nasal a', "jãzëk"),
        ],
    },
    {
        "id": "pismo2", "title": 'Letters II', "icon": "Ô", "track": "pismo",
        "letters": [
            ("ô", '[ɞ] (in dialects [o], [u] or [ɛ])', "czwiôrtk"),
            ("é", '[e], at the end of a word [ɨ]', "rzéka"),
            ("ó", '[o] (in southern Kashubia [u])', "zdrzódło"),
            ("ą", '[õ] (in the south [ũ])', "są"),
            ("cz", '[tʃ], as in “church”', "czedë"),
        ],
    },
    # ------------------------------------------------------------------ język
    {
        "id": "slowa", "title": 'First words', "icon": "A", "track": "jezyk", "requires": "pismo1",
        "words": [
            ("Witôj", 'hello; welcome', None, 'Polish has witaj; Kashubian turns a into ô.'),
            ("jo", 'yes', None, 'Careful: jo means “yes”, but jô means “I”!'),
            ("nié", 'no (answer)', 'no', 'nié is the answer “no”. Before a verb you say nie.'),
            ("jô", 'I', None, 'Not to be confused with jo (yes).'),
            ("të", 'you (one person)', None, 'ë is a short schwa: “tuh”.'),
            ("òn", 'he', None, 'ò reads “we”: “wen”.'),
            ("òna", 'she', None, None),
            ("jem", 'I am', 'am', None),
            ("jes", 'you are', None, None),
            ("je", 'is', 'is', None),
            ("z", 'from; with', None, None),
            ("Kaszëb", 'Kashubia (from Kashubia)', None, 'Kaszëbë is Kashubia; z Kaszëb = from Kashubia.'),
            ("Proszã", 'please', None, 'ã is a nasal a.'),
            ("Dzãkùjã", 'thank you', None, 'ù reads “wu”.'),
        ],
        "sentences": [
            (["jô", "jem", "z", "Kaszëb"], 'I am from Kashubia.',
             {"jo": 'jo means “yes”. I: jô.', "je": 'je means “is”. About yourself: jem.'}),
            (["të", "jes", "z", "Kaszëb"], 'You are from Kashubia.', {"jem": 'jem means “I am”. To “you”: jes.'}),
            (["òna", "je", "z", "Kaszëb"], 'She is from Kashubia.', {"jes": 'jes means “you are”. About her: je.'}),
            (["jo", ",", "jô", "jem", "z", "Kaszëb"], 'Yes, I am from Kashubia.',
             {"nié": 'nié means “no”. Here: jo (yes).'}),
            (["Dzãkùjã", "!"], 'Thank you!', {}),
        ],
    },
    {
        "id": "kaszubienie", "title": 'Sound rules', "icon": "B", "track": "jezyk",
        "words": [
            ("cëchò", 'quiet; quietly', None, 'Kashubian keeps c where Polish softened it to ci.'),
            ("swiat", 'world', None, 'Polish świat, Kashubian swiat: s stays hard.'),
            ("zëma", 'winter', None, None),
            ("lëpa", 'linden tree', None, None),
            ("bëc", 'to be', 'be', 'Same root as English “be”.'),
            ("chòdzëc", 'to walk; to go', None, None),
            ("òwca", 'sheep', 'ewe', 'At the start of a word o becomes ò (“we”). Related to English ewe.'),
            ("mòrze", 'sea', 'marine', None),
            ("kôłbasa", 'sausage', 'kielbasa', None),
            ("chto", 'who', None, None),
            ("czedë", 'when', None, 'k before e turns into cz (“ch”).'),
            ("nodżi", 'legs', None, 'g before i turns into dż (“j”).'),
            ("baro", 'very', None, None),
            ("pierszi", 'first', None, None),
        ],
        "sentences": [
            (["je", "cëchò"], 'It is quiet.', {}),
            (["czedë", "je", "zëma", "?"], 'When is winter?', {"chto": 'chto means “who”. When: czedë.'}),
            (["chto", "je", "z", "Kaszëb", "?"], 'Who is from Kashubia?', {"czedë": 'czedë means “when”. Who: chto.'}),
            (["je", "baro", "cëchò"], 'It is very quiet.', {}),
        ],
    },
    {
        "id": "rodzina", "title": 'Family', "icon": "C", "track": "jezyk",
        "words": [
            ("mëma", 'mum', 'mama', None),
            ("tatk", 'dad', None, None),
            ("sostra", 'sister', 'sister', None),
            ("bratk", 'brother', 'brother', None),
            ("starka", 'grandma', None, 'Starka literally means “the old one”.'),
            ("dzecko", 'child', None, None),
            ("knôp", 'boy', None, 'From Low German, like German Knabe and English knave.'),
            ("dzéwczã", 'girl', None, None),
            ("mòja", 'my (feminine)', None, None),
            ("mój", 'my (masculine)', None, None),
            ("to", 'this; it', None, None),
            ("chëcz", 'house; home', None, 'An old Slavic word for a hut.'),
            ("dobri", 'good (masculine)', None, 'Masculine adjectives end in -i.'),
            ("dobrô", 'good (feminine)', None, 'Feminine adjectives end in -ô.'),
            ("stôri", 'old', None, None),
            ("młodi", 'young (masculine)', None, None),
            ("młodô", 'young (feminine)', None, None),
        ],
        "sentences": [
            (["to", "je", "mòja", "mëma"], 'This is my mum.', {"mój": 'mëma is feminine: mòja.'}),
            (["mój", "tatk", "je", "dobri"], 'My dad is good.', {"dobrô": 'tatk is masculine: dobri.'}),
            (["mòja", "sostra", "je", "młodô"], 'My sister is young.',
             {"młodi": 'sostra is feminine: młodô.'}),
            (["starka", "je", "dobrô"], 'Grandma is good.', {"dobri": 'starka is feminine: dobrô.'}),
            (["to", "je", "mòja", "chëcz"], 'This is my house.', {"mój": 'chëcz is feminine: mòja chëcz.'}),
        ],
    },
    {
        "id": "liczby", "title": 'Numbers', "icon": "D", "track": "jezyk",
        "words": [
            ("jeden", 'one', None, None),
            ("dwa", 'two', 'two', None),
            ("trzë", 'three', 'three', None),
            ("sztërë", 'four', None, None),
            ("piãc", 'five', None, 'ã is a nasal a; c sounds “ts”.'),
            ("szesc", 'six', 'six', None),
            ("sétmë", 'seven', 'seven', None),
            ("òsmë", 'eight', None, None),
            ("dzewiãc", 'nine', None, None),
            ("dzesãc", 'ten', None, None),
            ("ë", 'and', None, 'The word “and” in Kashubian is just ë.'),
            ("są", '(they) are', None, None),
        ],
        "sentences": [
            (["jeden", "ë", "jeden", "to", "dwa"], 'One and one is two.', {}),
            (["trzë", "ë", "sztërë", "to", "sétmë"], 'Three and four is seven.', {"sztërë": 'sztërë means 4.'}),
            (["piãc", "ë", "piãc", "to", "dzesãc"], 'Five and five is ten.', {}),
        ],
    },
    {
        "id": "swiat2", "title": 'Nature', "icon": "E", "track": "jezyk",
        "words": [
            ("wòda", 'water', 'water', None),
            ("zemia", 'earth; land', None, None),
            ("słuńce", 'sun', 'sun', None),
            ("rzéka", 'river', None, None),
            ("jezoro", 'lake', None, None),
            ("deszcz", 'rain', None, None),
            ("wiater", 'wind', 'wind', None),
            ("lato", 'summer', None, None),
            ("dzéń", 'day', None, None),
            ("dzys", 'today', None, None),
            ("snôżi", 'beautiful', None, 'A typically Kashubian word for “beautiful”.'),
            ("wiôldżi", 'big (masculine)', None, None),
            ("wiôlgô", 'big (feminine)', None, 'In the feminine the g comes back: wiôlgô, as in the village name Wiôlgô Wies.'),
            ("môłi", 'small', None, None),
        ],
        "sentences": [
            (["dzys", "je", "snôżi", "dzéń"], 'Today is a beautiful day.', {}),
            (["mòrze", "je", "wiôldżi"], 'The sea is big.', {}),
            (["rzéka", "je", "wiôlgô"], 'The river is big.', {"wiôldżi": 'rzéka is feminine: wiôlgô.'}),
            (["jezoro", "je", "môłi"], 'The lake is small.', {}),
            (["dzys", "je", "lato"], 'Today it is summer.', {}),
        ],
    },
    {
        "id": "zwierze", "title": 'Animals', "icon": "F", "track": "jezyk",
        "words": [
            ("pies", 'dog', None, None),
            ("kòt", 'cat', 'cat', 'ò reads “we”: “kwet”.'),
            ("rëba", 'fish', None, None),
            ("lës", 'fox', None, None),
            ("ptôch", 'bird', None, 'ô and ch: “ptokh”.'),
            ("wilk", 'wolf', 'wolf', None),
            ("krowa", 'cow', None, None),
            ("kaczka", 'duck', None, None),
            ("kòń", 'horse', None, None),
        ],
        "sentences": [
            (["kòt", "je", "môłi"], 'The cat is small.', {}),
            (["kòń", "je", "wiôldżi"], 'The horse is big.', {"wiôlgô": 'kòń is masculine: wiôldżi.'}),
            (["to", "je", "mój", "pies"], 'This is my dog.', {"mòja": 'pies is masculine: mój.'}),
            (["chto", "to", "je", "?"], 'Who is it?', {}),
        ],
    },
    {
        "id": "czasowniki", "title": 'Verbs', "icon": "G", "track": "jezyk",
        "words": [
            ("czëtóm", 'I read', None, '-óm means “I”.'),
            ("czëtôsz", 'you read', None, '-ôsz means “you”.'),
            ("czëtô", '(he/she) reads', None, None),
            ("gôdóm", 'I speak', None, 'gôdac means “to speak”; compare English “gab”.'),
            ("gôdôsz", 'you speak', None, None),
            ("robiã", 'I do; I work', None, None),
            ("robisz", 'you do', None, None),
            ("robi", '(he/she) does', None, None),
            ("co", 'what', None, None),
            ("nie", 'not (before a verb)', 'no', 'Before a verb: nie. The answer “no” on its own: nié.'),
            ("pò", 'in (a language)', None, None),
            ("kaszëbskù", 'Kashubian (pò kaszëbskù = in Kashubian)', None, 'pò kaszëbskù, as in the slogan “gôdómë pò kaszëbskù”.'),
            ("kąsk", 'a little', None, 'Kąsk literally means “a morsel”.'),
        ],
        "sentences": [
            (["co", "robisz", "?"], 'What are you doing?', {"robiã": "You're asking someone: robisz."}),
            (["jô", "czëtóm"], "I'm reading.", {"czëtô": 'czëtô means “reads”. I: czëtóm.'}),
            (["gôdôsz", "pò", "kaszëbskù", "?"], 'Do you speak Kashubian?',
             {"gôdóm": 'gôdóm means “I speak”. To “you”: gôdôsz.'}),
            (["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"], 'Yes, I speak a little Kashubian.',
             {"jô": 'jô means “I”. Yes: jo.'}),
            (["mëma", "czëtô"], 'Mum is reading.', {"czëtóm": 'About mum: czëtô (-ô for he/she).'}),
            (["jô", "nie", "gôdóm", "pò", "kaszëbskù"], "I don't speak Kashubian.",
             {"nié": 'Before a verb: nie. nié is the answer “no” on its own.'}),
        ],
    },
    {
        "id": "be", "title": 'We, you, Wë', "icon": "H", "track": "jezyk",
        "words": [
            ("më", 'we', None, 'ë is a short schwa.'),
            ("wa", 'you (plural)', None, 'Wa was once the dual, “you two”. Today it is the ordinary plural “you”.'),
            ("Wë", 'you (polite: Sir; Madam)', None, 'Kashubians address people politely with Wë, like old-fashioned “ye”.'),
            ("òni", 'they', None, None),
            ("jesmë", 'we are', None, None),
            ("jesta", 'you (all) are', None, None),
            ("jesce", 'you are (polite)', None, 'With Wë: jesce.'),
            ("robimë", 'we do; we work', None, '-më means “we”.'),
            ("gôdómë", 'we speak', None, "“Gôdómë pò kaszëbskù” (Let's speak Kashubian) is the slogan of a campaign promoting the language."),
            ("skądka", 'where from', None, None),
        ],
        "sentences": [
            (["më", "jesmë", "z", "Kaszëb"], 'We are from Kashubia.', {"jesta": 'jesta means “you (all) are”. We: jesmë.'}),
            (["wa", "jesta", "z", "Kaszëb"], 'You (all) are from Kashubia.', {"jesce": 'jesce is the polite “you are”.'}),
            (["skądka", "Wë", "jesce", "?"], 'Where are you from? (polite)', {"jes": 'Politely: Wë jesce, not të jes.'}),
            (["òni", "są", "z", "Kaszëb"], 'They are from Kashubia.', {}),
            (["gôdómë", "pò", "kaszëbskù"], 'We speak Kashubian.', {"gôdóm": 'We: gôdómë (-më).'}),
            (["më", "robimë"], 'We are working.', {"robiã": 'We: robimë.'}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "prawa", "title": 'Human rights', "icon": "I", "track": "teksty", "requires": "be",
        "words": [
            ("wszëtczi", 'all (people)', None, None),
            ("lëdze", 'people', None, None),
            ("rodzą", '(they) are born', None, None),
            ("sã", '(themselves)', None, 'rodzą sã = are born, literally “give birth to themselves”.'),
            ("wòlny", 'free', None, None),
            ("równy", 'equal', None, None),
        ],
        "sentences": [
            (["wszëtczi", "lëdze", "rodzą", "sã", "wòlny", "ë", "równy"],
             'All human beings are born free and equal.', {}),
            (["lëdze", "są", "wòlny"], 'People are free.', {}),
        ],
    },
    {
        "id": "ojcze", "title": 'Òjcze nasz', "icon": "J", "track": "teksty",
        "words": [
            ("Òjcze", 'Father (calling)', 'father', 'The vocative, used when calling someone. Ò at the start: “Wejche”.'),
            ("nasz", 'our', None, None),
            ("jaczi", 'who (literally “what kind”)', None, 'Kashubian says “jaczi jes”: what kind you are.'),
            ("w", 'in', None, None),
            ("niebie", 'heaven (in heaven)', None, None),
        ],
        "sentences": [
            (["Òjcze", "nasz", ",", "jaczi", "jes", "w", "niebie"], 'Our Father, who art in heaven.', {}),
        ],
    },
]

TRACKS = {
    "pismo": 'WRITING',
    "jezyk": 'JÃZËK · LANGUAGE',
    "teksty": 'TEKSTË · TEXTS',
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "pismo1": [
        {"title": 'The marks tell you how to read',
         "text": 'Kashubian is written with the Latin alphabet plus a few letters of its own. The most important: ò reads “we”, so kòt (cat) sounds like “kwet”. And ë is a schwa: a short, dull vowel like the a in “about”.',
         "chain": []},
    ],
    "slowa": [
        {"title": 'Kashubian is a cousin of Polish',
         "text": 'Kashubian is a West Slavic language spoken on the Baltic coast of Poland, the closest relative of Polish. Many words are short and regular: jô (I), të (you), jem (I am). Just watch out for jo: it means “yes”.',
         "chain": [
             ('I am from Kashubia.', ["jô", "jem", "z", "Kaszëb"], 'jô (I) + jem (am).'),
             ('You are from Kashubia.', ["të", "jes", "z", "Kaszëb"], 'Change the person: të, jes.'),
         ]},
    ],
    "kaszubienie": [
        {"title": 'Hard c and soft cz',
         "text": 'Kashubian keeps old hard consonants where Polish softened them: cëchò (quiet), swiat (world), zëma (winter). And k, g before e and i turn into cz, dż: czedë (when), nodżi (legs). Learn these rules and you can recognise hundreds of words.',
         "chain": [
             ('When is winter?', ["czedë", "je", "zëma", "?"], 'czedë (when) + je (is) + zëma (winter).'),
         ]},
    ],
    "rodzina": [
        {"title": 'Adjectives agree, like in Latin or French',
         "text": 'Adjectives change with gender: dobri (good, masculine), dobrô (good, feminine). The same goes for “my”: mój tatk, mòja mëma. Feminine adjectives end in -ô.',
         "chain": [
             ('This is my mum.', ["to", "je", "mòja", "mëma"], 'to je + mòja (feminine) + mëma.'),
             ('Grandma is good.', ["starka", "je", "dobrô"], 'starka is feminine: dobrô.'),
         ]},
    ],
    "liczby": [
        {"title": 'Numbers you half know',
         "text": 'Two is dwa, three is trzë, six is szesc, seven is sétmë: you can hear English two, three, six, seven. And the word “and” is just ë.',
         "chain": [('One and one is two.', ["jeden", "ë", "jeden", "to", "dwa"], '“and” is ë.')]},
    ],
    "swiat2": [
        {"title": 'Big: wiôldżi, wiôlgô',
         "text": 'Before i the g softens into dż (wiôldżi), before ô it stays g (wiôlgô). It is the same rule as noga → nodżi (leg → legs).',
         "chain": [
             ('Today is a beautiful day.', ["dzys", "je", "snôżi", "dzéń"], 'dzys (today), snôżi dzéń (beautiful day).'),
             ('The river is big.', ["rzéka", "je", "wiôlgô"], 'Feminine: wiôlgô.'),
         ]},
    ],
    "zwierze": [
        {"title": 'ò after lip sounds',
         "text": 'Old o after p, b, m, w, k, g, ch and at the start of a word usually gets a mark: kòt (cat), kòń (horse), mòrze (sea). Read it “we”: kwet, kweny, mwezhe.',
         "chain": [('The cat is small.', ["kòt", "je", "môłi"], 'kòt (cat) + je (is) + môłi (small).')]},
    ],
    "czasowniki": [
        {"title": 'Endings tell you who',
         "text": 'Like in Spanish or Latin, the verb ending shows the person, so you can drop the pronoun: czëtóm (I read), czëtôsz (you read), czëtô (he/she reads). Speaking is gôdac.',
         "chain": [
             ("I'm reading.", ["jô", "czëtóm"], '-óm means “I”.'),
             ('Yes, I speak a little Kashubian.', ["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"],
              'jo (yes), gôdóm (I speak), kąsk (a little).'),
         ]},
    ],
    "be": [
        {"title": 'Politely: Wë',
         "text": "Kashubians don't use “Sir” or “Madam”. To older people and strangers they say Wë, and the verb ends in -ce: Wë jesce = you are (polite). To several people: wa jesta (you all are).",
         "chain": [
             ('Where are you from? (polite)', ["skądka", "Wë", "jesce", "?"], 'skądka + Wë + jesce.'),
             ('We are from Kashubia.', ["më", "jesmë", "z", "Kaszëb"], 'më, jesmë (-më means “we”).'),
         ]},
    ],
    "prawa": [
        {"title": 'Article one',
         "text": 'This is how the Universal Declaration of Human Rights begins in Kashubian. wszëtczi = all, lëdze = people, rodzą sã = are born.',
         "chain": [('People are free.', ["lëdze", "są", "wòlny"], 'lëdze + są + wòlny.')]},
    ],
    "ojcze": [
        {"title": 'A prayer in Kashubian',
         "text": 'The Kashubian “Our Father” is very close to Polish. Instead of “who art” it says “jaczi jes”, literally “what kind you are”.',
         "chain": [('Our Father, who art in heaven.', ["Òjcze", "nasz", ",", "jaczi", "jes", "w", "niebie"],
                    'Òjcze nasz + jaczi jes + w niebie.')]},
    ],
}

ENDINGS_INSIGHT = {
    "title": 'Endings at a glance',
    "text": 'Kashubian endings follow a few patterns: -ã for “I” (robiã), -óm also for “I” (czëtóm), -ô for feminine adjectives (dobrô), -më for “we” (robimë). When in doubt, ask: who is doing it?',
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("mòja mëma je ", "dobr", "ô", "", ["i", "ô", "é", "a"], 'my mum is good', 'Feminine: -ô.', "rodzina"),
    ("mój tatk je ", "dobr", "i", "", ["i", "ô", "é", "y"], 'my dad is good', 'Masculine: -i.', "rodzina"),
    ("", "m", "òja", " sostra", ["ój", "òja", "òje", "oja"], 'my sister', 'Feminine: mòja.', "rodzina"),
    ("dzys je ", "snôż", "i", " dzéń", ["i", "ô", "é", "y"], 'today is a beautiful day', 'dzéń is masculine: snôżi.', "swiat2"),
    ("rzéka je ", "wiôl", "gô", "", ["dżi", "gô", "dżé", "ga"], 'the river is big', 'Feminine: wiôlgô.', "swiat2"),
    ("jô ", "czët", "óm", "", ["óm", "ôsz", "ô", "ómë"], 'I read', 'I: -óm.', "czasowniki"),
    ("të ", "czët", "ôsz", "", ["óm", "ôsz", "ô", "ómë"], 'you read', 'You: -ôsz.', "czasowniki"),
    ("mëma ", "czët", "ô", "", ["óm", "ôsz", "ô", "ómë"], 'mum reads', 'She: -ô.', "czasowniki"),
    ("jô ", "rob", "iã", "", ["iã", "isz", "i", "imë"], 'I do', 'I: -ã.', "czasowniki"),
    ("më ", "rob", "imë", "", ["iã", "isz", "i", "imë"], 'we do', 'We: -më.', "be"),
    ("Wë ", "jes", "ce", " z Kaszëb?", ["m", "s", "ce", "ta"], 'Are you from Kashubia? (polite)', 'Politely: Wë jesce.', "be"),
    ("wa ", "jes", "ta", " z Kaszëb", ["m", "s", "ce", "ta"], 'you (all) are from Kashubia', 'You all: wa jesta.', "be"),
    ("më ", "jes", "më", " z Kaszëb", ["m", "më", "ce", "ta"], 'we are from Kashubia', 'We: jesmë.', "be"),
]

# Kolorem wyróżniamy litery, których nie ma w polskim alfabecie.
LONG_VOWELS = "ãëéòôùÃËÉÒÔÙ"

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "witaj", "title": 'Saying hello', "partner": "Kasia", "avatar": "K", "requires": "slowa",
        "turns": [
            {"bot": ["Witôj", "!"], "en": 'Hello!',
             "options": [(["Witôj", "!"], True, None),
                         (["Dzãkùjã", "!"], False, 'Dzãkùjã means “thank you”. Say hello first!')]},
            {"bot": ["të", "jes", "z", "Kaszëb", "?"], "en": 'Are you from Kashubia?',
             "options": [(["jo", ",", "jô", "jem", "z", "Kaszëb"], True, None),
                         (["jô", ",", "jô", "jem", "z", "Kaszëb"], False, 'jô means “I”. Yes: jo.'),
                         (["jo", ",", "jô", "je", "z", "Kaszëb"], False, 'je means “is”. About yourself: jem.')]},
            {"bot": ["Do", "ùzdrzeniô", "!"], "en": 'Goodbye!', "build": (["Dzãkùjã", "!"], 'Thank you!')},
        ],
    },
    {
        "id": "dom", "title": 'At home', "partner": "Starka", "avatar": "S", "requires": "rodzina",
        "turns": [
            {"bot": ["chto", "to", "je", "?"], "en": 'Who is it?',
             "options": [(["to", "je", "mòja", "sostra"], True, None),
                         (["to", "je", "mój", "sostra"], False, 'sostra is feminine: mòja.'),
                         (["chto", "je", "mòja", "sostra"], False, 'chto means “who”. You answer: to je…')]},
            {"bot": ["a", "tatk", "?"], "en": 'And dad?',
             "build": (["mój", "tatk", "je", "dobri"], 'My dad is good.')},
        ],
    },
    {
        "id": "morze", "title": 'By the sea', "partner": "Józef", "avatar": "J", "requires": "czasowniki",
        "turns": [
            {"bot": ["dzys", "je", "snôżi", "dzéń", "!"], "en": 'Today is a beautiful day!',
             "options": [(["jo", ",", "mòrze", "je", "baro", "snôżi"], True, None),
                         (["nié", ",", "mòrze", "je", "baro", "snôżi"], False, 'nié means “no”. You agree: jo.')],
             "note": 'baro means “very”.'},
            {"bot": ["gôdôsz", "pò", "kaszëbskù", "?"], "en": 'Do you speak Kashubian?',
             "options": [(["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"], True, None),
                         (["jo", ",", "gôdôsz", "kąsk", "pò", "kaszëbskù"], False,
                          'gôdôsz means “you speak”. About yourself: gôdóm.')]},
            {"bot": ["co", "robisz", "?"], "en": 'What are you doing?', "build": (["jô", "czëtóm"], "I'm reading.")},
        ],
    },
    {
        "id": "sasiedzi", "title": "At the neighbours'", "partner": "Pani Ana", "avatar": "A", "requires": "be",
        "turns": [
            {"bot": ["skądka", "Wë", "jesce", "?"], "en": 'Where are you from? (polite)',
             "options": [(["jô", "jem", "z", "Kaszëb"], True, None),
                         (["jô", "jesce", "z", "Kaszëb"], False, 'jesce is the form for Wë. About yourself: jem.')]},
            {"bot": ["a", "wa", "?"], "en": 'And you all?', "note": 'She is asking about the whole family.',
             "build": (["më", "jesmë", "z", "Kaszëb"], 'We are from Kashubia.')},
            {"bot": ["Do", "ùzdrzeniô", "!"], "en": 'Goodbye!',
             "options": [(["Do", "ùzdrzeniô", "!"], True, None),
                         (["Witôj", "!"], False, 'Witôj is a greeting. Now you are saying goodbye.')]},
        ],
    },
]

CHAT_EXTRA = {"Do": 'good-', "ùzdrzeniô": '-bye (lit. seeing)', "a": 'and'}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['jô', 'të', 'òn/òna', 'më', 'wa', 'òni/òne'],
    'dzies': ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
    'przyp6': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'narzędnik', 'miejscownik'],
    't_kasz': ['siano', 'zima', 'cicho', 'dzień', 'siedem', 'ciepło'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'robic (robić)', 'os', 'robiã; robisz; robi; robimë; robita; robią', '1. osoba lp. na -ã, 1. lm. na -më, 2. lm. na -ta.'),
    ('conj', 'Wzory koniugacji', 'gadac (mówić)', 'os', 'gôdóm; gôdôsz; gôdô; gôdómë; gôdôta; gôdają', 'Koniugacja na -óm, -ôsz.'),
    ('conj', 'Czasowniki nieregularne', 'bëc (być)', 'os', 'jem; jes; je; jesmë; jesta; są', None),
    ('conj', 'Czasowniki nieregularne', 'miec (mieć)', 'os', 'móm; môsz; mô; mómë; môta; mają', None),
    ('conj', 'Czasowniki nieregularne', 'jic (iść)', 'os', 'jidã; jidzesz; jidze; jidzemë; jidzeta; jidą', None),
    ('conj', 'Czasowniki nieregularne', 'chcec (chcieć)', 'os', 'chcã; chcesz; chce; chcemë; chceta; chcą', None),
    ('form', 'Liczebniki', 'Liczenie do dziesięciu', 'dzies', 'jeden; dwa; trzë; sztërë; piãc; szesc; sétmë; òsmë; dzewiãc; dzesãc', None),
    ('decl', 'Liczebniki', 'jeden (jeden)', 'przyp6', 'jeden; jednégò; jednémù; jeden; jednym; jednym', None),
    ('decl', 'Liczebniki', 'dwa (dwa)', 'przyp6', 'dwa; dwùch; dwóm; dwa; dwùma; dwùch', None),
    ('form', 'Typowe trudności', 'Kaszubienie: jak to brzmi po kaszubsku?', 't_kasz', 'sano; zëma; cëchò; dzéń; sétmë; cepło', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['òkno', 'òjc', 'ùcho', 'ùczëc', 'kòt', 'pòle', 'ptôch', 'trôwa'],
    't_m1': ['robic', 'bëc', 'miec', 'jic', 'chcec', 'gadac'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'ò, ù, ô: polski odpowiednik', 't_m0', 'okno; ojciec; ucho; uczyć; kot; pole; ptak; trawa', 'ò i ù czyta się z ł na początku; ô odpowiada polskiemu a.'),
    ('form', 'Typowe trudności', 'Liczba mnoga na -ta', 't_m1', 'wa robita; wa jesta; wa môta; wa jidzeta; wa chceta; wa gôdôta', 'W 2. osobie lm. jest -ta zamiast polskiego -cie.'),
]

"""Treść kursu: język kaszubski dla Polaków.

Słowo:     (forma, znaczenie po polsku, polski odpowiednik lub None, skojarzenie lub None)
Litera:    (litera lub dwuznak, jak czytać, przykład)
Zdanie:    (lista słów, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź po polsku, wyjaśnienie, dział)

Wymowa (pole „tr”) powstaje automatycznie w engine.py, zapisana polskimi literami:
òwca → łewca, zëma → zyma.

Źródła: alfabet i wymowa wg Wikipedii (Kashubian alphabet); zaimki, odmiana bëc i robic,
liczebniki, rzeczowniki i przymiotniki wg Wikipedii (Kashubian grammar); słownictwo z podręcznika
języka kaszubskiego na zpe.gov.pl; zwroty wg omniglot.com; art. 1 Powszechnej Deklaracji Praw
Człowieka wg Wikipedii (Kashubian language); początek „Òjcze nasz” wg Wikipedii (Lechitic languages)
i kaszuby.info.pl.
"""

UNITS = [
    # ------------------------------------------------------------------ pismo
    {
        "id": "pismo1", "title": "Litery I", "icon": "Ò", "track": "pismo",
        "letters": [
            ("ò", "[wɛ]: òwca czytaj „łewca”, mòrze „młeże”", "òwca"),
            ("ù", "[wʉ]: kùńszt (sztuka) czytaj „kłuńszt”", "kùńszt"),
            ("ë", "[ə] (szwa); tam, gdzie polski ma i, y, u", "zëma"),
            ("ã", "[ã]; tam, gdzie polski ma ę", "jãzëk"),
        ],
    },
    {
        "id": "pismo2", "title": "Litery II", "icon": "Ô", "track": "pismo",
        "letters": [
            ("ô", "[ɞ] (w gwarach [o], [u] lub [ɛ]); tam, gdzie polskie a", "czwiôrtk"),
            ("é", "[e], na końcu słowa [ɨ]; tam, gdzie polskie e", "rzéka"),
            ("ó", "[o] (na południu Kaszub [u])", "zdrzódło"),
            ("ą", "[õ] (na południu [ũ])", "są"),
            ("cz", "[tʃ], miększe niż polskie cz", "czedë"),
        ],
    },
    # ------------------------------------------------------------------ język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "A", "track": "jezyk", "requires": "pismo1",
        "words": [
            ("Witôj", "witaj", "witaj", "ô w miejscu polskiego a: witaj → Witôj."),
            ("jo", "tak", None, "Uwaga: jo to „tak”, a jô to „ja”!"),
            ("nié", "nie (odpowiedź)", "nie", "nié to odpowiedź „nie”. Przed czasownikiem mówi się nie."),
            ("jô", "ja", "ja", "ô zamiast a: ja → jô."),
            ("të", "ty", "ty", "ë zamiast y: ty → të."),
            ("òn", "on", "on", "ò czytaj łe: „łen”."),
            ("òna", "ona", "ona", None),
            ("jem", "jestem", "jestem", None),
            ("jes", "jesteś", "jesteś", None),
            ("je", "jest", "jest", None),
            ("z", "z", "z", None),
            ("Kaszëb", "Kaszub (z Kaszub)", "Kaszuby", "Kaszëbë to Kaszuby; z Kaszëb = z Kaszub."),
            ("Proszã", "proszę", "proszę", "ã w miejscu polskiego ę."),
            ("Dzãkùjã", "dziękuję", "dziękuję", "ã za ę, ù to „łu”, a dz zamiast dzi."),
        ],
        "sentences": [
            (["jô", "jem", "z", "Kaszëb"], "Jestem z Kaszub.",
             {"jo": "jo to „tak”. Ja: jô.", "je": "je to „jest”. O sobie: jem."}),
            (["të", "jes", "z", "Kaszëb"], "Jesteś z Kaszub.", {"jem": "jem to „jestem”. Do „ty”: jes."}),
            (["òna", "je", "z", "Kaszëb"], "Ona jest z Kaszub.", {"jes": "jes to „jesteś”. O niej: je."}),
            (["jo", ",", "jô", "jem", "z", "Kaszëb"], "Tak, jestem z Kaszub.",
             {"nié": "nié to „nie”. Tutaj: jo (tak)."}),
            (["Dzãkùjã", "!"], "Dziękuję!", {}),
        ],
    },
    {
        "id": "kaszubienie", "title": "Kaszubienie", "icon": "B", "track": "jezyk",
        "words": [
            ("cëchò", "cicho", "cicho", "Polskie ci → c, a i → ë. Na końcu o → ò."),
            ("swiat", "świat", "świat", "Polskie ś → s."),
            ("zëma", "zima", "zima", "Polskie zi → zë."),
            ("lëpa", "lipa", "lipa", None),
            ("bëc", "być", "być", "Polskie -yć → -ëc."),
            ("chòdzëc", "chodzić", "chodzić", "dzi → dzë, a -ić → -ëc."),
            ("òwca", "owca", "owca", "Na początku słowa o → ò (łe)."),
            ("mòrze", "morze", "morze", None),
            ("kôłbasa", "kiełbasa", "kiełbasa", None),
            ("chto", "kto", "kto", None),
            ("czedë", "kiedy", "kiedy", "Polskie kie → cze."),
            ("nodżi", "nogi", "nogi", "Polskie gi → dżi."),
            ("baro", "bardzo", "bardzo", None),
            ("pierszi", "pierwszy", "pierwszy", None),
        ],
        "sentences": [
            (["je", "cëchò"], "Jest cicho.", {}),
            (["czedë", "je", "zëma", "?"], "Kiedy jest zima?", {"chto": "chto to „kto”. Kiedy: czedë."}),
            (["chto", "je", "z", "Kaszëb", "?"], "Kto jest z Kaszub?", {"czedë": "czedë to „kiedy”. Kto: chto."}),
            (["je", "baro", "cëchò"], "Jest bardzo cicho.", {}),
        ],
    },
    {
        "id": "rodzina", "title": "Rodzina", "icon": "C", "track": "jezyk",
        "words": [
            ("mëma", "mama", "mama", "ë w miejscu a: mama → mëma."),
            ("tatk", "tata", "tatko", None),
            ("sostra", "siostra", "siostra", None),
            ("bratk", "brat", "bratek", None),
            ("starka", "babcia", "starka", "Starka, czyli „stara”: babcia."),
            ("dzecko", "dziecko", "dziecko", "dzie → dze."),
            ("knôp", "chłopiec", None, "Z dolnoniemieckiego, jak niemieckie Knabe."),
            ("dzéwczã", "dziewczyna", "dziewczę", None),
            ("mòja", "moja", "moja", None),
            ("mój", "mój", "mój", None),
            ("to", "to", "to", None),
            ("chëcz", "dom", "chyża", "Dawne polskie „chyża” to chata."),
            ("dobri", "dobry", "dobry", "Polskie -y → -i."),
            ("dobrô", "dobra", "dobra", "Polskie -a w przymiotniku → -ô."),
            ("stôri", "stary", "stary", None),
            ("młodi", "młody", "młody", None),
            ("młodô", "młoda", "młoda", None),
        ],
        "sentences": [
            (["to", "je", "mòja", "mëma"], "To jest moja mama.", {"mój": "mëma jest żeńska: mòja."}),
            (["mój", "tatk", "je", "dobri"], "Mój tata jest dobry.", {"dobrô": "tatk jest męski: dobri."}),
            (["mòja", "sostra", "je", "młodô"], "Moja siostra jest młoda.",
             {"młodi": "sostra jest żeńska: młodô."}),
            (["starka", "je", "dobrô"], "Babcia jest dobra.", {"dobri": "starka jest żeńska: dobrô."}),
            (["to", "je", "mòja", "chëcz"], "To jest mój dom.", {"mój": "chëcz jest żeńska: mòja chëcz."}),
        ],
    },
    {
        "id": "liczby", "title": "Liczby", "icon": "D", "track": "jezyk",
        "words": [
            ("jeden", "jeden", "jeden", None),
            ("dwa", "dwa", "dwa", None),
            ("trzë", "trzy", "trzy", None),
            ("sztërë", "cztery", "cztery", None),
            ("piãc", "pięć", "pięć", "ã za ę, c za ć."),
            ("szesc", "sześć", "sześć", None),
            ("sétmë", "siedem", "siódmy", None),
            ("òsmë", "osiem", "ósmy", None),
            ("dzewiãc", "dziewięć", "dziewięć", None),
            ("dzesãc", "dziesięć", "dziesięć", None),
            ("ë", "i", "i", "Spójnik „i” to po kaszubsku ë."),
            ("są", "są", "są", None),
        ],
        "sentences": [
            (["jeden", "ë", "jeden", "to", "dwa"], "Jeden i jeden to dwa.", {}),
            (["trzë", "ë", "sztërë", "to", "sétmë"], "Trzy i cztery to siedem.", {"sztërë": "sztërë to 4."}),
            (["piãc", "ë", "piãc", "to", "dzesãc"], "Pięć i pięć to dziesięć.", {}),
        ],
    },
    {
        "id": "swiat2", "title": "Przyroda", "icon": "E", "track": "jezyk",
        "words": [
            ("wòda", "woda", "woda", None),
            ("zemia", "ziemia", "ziemia", "zie → ze."),
            ("słuńce", "słońce", "słońce", None),
            ("rzéka", "rzeka", "rzeka", None),
            ("jezoro", "jezioro", "jezioro", None),
            ("deszcz", "deszcz", "deszcz", None),
            ("wiater", "wiatr", "wiatr", None),
            ("lato", "lato", "lato", None),
            ("dzéń", "dzień", "dzień", None),
            ("dzys", "dziś", "dziś", None),
            ("snôżi", "piękny", None, "Kaszubskie słowo na „piękny”."),
            ("wiôldżi", "wielki; duży", "wielki", None),
            ("wiôlgô", "wielka; duża", "wielka", "W rodzaju żeńskim wraca g: wiôlgô. Jak Wiôlgô Wies."),
            ("môłi", "mały", "mały", None),
        ],
        "sentences": [
            (["dzys", "je", "snôżi", "dzéń"], "Dziś jest piękny dzień.", {}),
            (["mòrze", "je", "wiôldżi"], "Morze jest wielkie.", {}),
            (["rzéka", "je", "wiôlgô"], "Rzeka jest wielka.", {"wiôldżi": "rzéka jest żeńska: wiôlgô."}),
            (["jezoro", "je", "môłi"], "Jezioro jest małe.", {}),
            (["dzys", "je", "lato"], "Dziś jest lato.", {}),
        ],
    },
    {
        "id": "zwierze", "title": "Zwierzęta", "icon": "F", "track": "jezyk",
        "words": [
            ("pies", "pies", "pies", None),
            ("kòt", "kot", "kot", "ò czytaj łe: „kłet”."),
            ("rëba", "ryba", "ryba", None),
            ("lës", "lis", "lis", None),
            ("ptôch", "ptak", "ptak", "ô za a, ch za k."),
            ("wilk", "wilk", "wilk", None),
            ("krowa", "krowa", "krowa", None),
            ("kaczka", "kaczka", "kaczka", None),
            ("kòń", "koń", "koń", None),
        ],
        "sentences": [
            (["kòt", "je", "môłi"], "Kot jest mały.", {}),
            (["kòń", "je", "wiôldżi"], "Koń jest duży.", {"wiôlgô": "kòń jest męski: wiôldżi."}),
            (["to", "je", "mój", "pies"], "To jest mój pies.", {"mòja": "pies jest męski: mój."}),
            (["chto", "to", "je", "?"], "Kto to jest?", {}),
        ],
    },
    {
        "id": "czasowniki", "title": "Czasowniki", "icon": "G", "track": "jezyk",
        "words": [
            ("czëtóm", "czytam", "czytam", "-óm jak polskie -am."),
            ("czëtôsz", "czytasz", "czytasz", "-ôsz jak polskie -asz."),
            ("czëtô", "czyta", "czyta", None),
            ("gôdóm", "mówię", "gadam", "gôdac znaczy „mówić”, jak polskie gadać."),
            ("gôdôsz", "mówisz", "gadasz", None),
            ("robiã", "robię; pracuję", "robię", None),
            ("robisz", "robisz", "robisz", None),
            ("robi", "robi", "robi", None),
            ("co", "co", "co", None),
            ("nie", "nie (przed czasownikiem)", "nie", "Przed czasownikiem: nie. Samo „nie” jako odpowiedź: nié."),
            ("pò", "po", "po", None),
            ("kaszëbskù", "kaszubsku (po kaszubsku)", "kaszubsku", "pò kaszëbskù, jak „gôdómë pò kaszëbskù”."),
            ("kąsk", "trochę", "kąsek", "Kąsk to „kąsek”, czyli trochę."),
        ],
        "sentences": [
            (["co", "robisz", "?"], "Co robisz?", {"robiã": "Pytasz kogoś: robisz."}),
            (["jô", "czëtóm"], "Czytam.", {"czëtô": "czëtô to „czyta”. Ja: czëtóm."}),
            (["gôdôsz", "pò", "kaszëbskù", "?"], "Mówisz po kaszubsku?",
             {"gôdóm": "gôdóm to „mówię”. Do „ty”: gôdôsz."}),
            (["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"], "Tak, mówię trochę po kaszubsku.",
             {"jô": "jô to „ja”. Tak: jo."}),
            (["mëma", "czëtô"], "Mama czyta.", {"czëtóm": "O mamie: czëtô (-ô jak polskie -a)."}),
            (["jô", "nie", "gôdóm", "pò", "kaszëbskù"], "Nie mówię po kaszubsku.",
             {"nié": "Przed czasownikiem: nie. nié to samo „nie” w odpowiedzi."}),
        ],
    },
    {
        "id": "be", "title": "My, wy, Wë", "icon": "H", "track": "jezyk",
        "words": [
            ("më", "my", "my", "ë zamiast y."),
            ("wa", "wy", "wy", "Wa to dawna liczba podwójna: „wy dwaj”. Dziś zwykłe „wy”."),
            ("Wë", "Pan; Pani (grzecznie)", "Wy", "Kaszubi zwracają się grzecznie przez Wë, jak dawniej „Wy”."),
            ("òni", "oni", "oni", None),
            ("jesmë", "jesteśmy", "jesteśmy", None),
            ("jesta", "jesteście", "jesteście", None),
            ("jesce", "jest Pan; jest Pani", None, "Do Wë: jesce."),
            ("robimë", "robimy", "robimy", "-më jak polskie -my."),
            ("gôdómë", "mówimy", "gadamy", "„Gôdómë pò kaszëbskù” to hasło akcji promującej kaszubski."),
            ("skądka", "skąd", "skąd", None),
        ],
        "sentences": [
            (["më", "jesmë", "z", "Kaszëb"], "Jesteśmy z Kaszub.", {"jesta": "jesta to „jesteście”. My: jesmë."}),
            (["wa", "jesta", "z", "Kaszëb"], "Jesteście z Kaszub.", {"jesce": "jesce to grzeczne „Pan jest”."}),
            (["skądka", "Wë", "jesce", "?"], "Skąd Pan jest?", {"jes": "Grzecznie: Wë jesce, nie të jes."}),
            (["òni", "są", "z", "Kaszëb"], "Oni są z Kaszub.", {}),
            (["gôdómë", "pò", "kaszëbskù"], "Mówimy po kaszubsku.", {"gôdóm": "My: gôdómë (-më)."}),
            (["më", "robimë"], "Pracujemy.", {"robiã": "My: robimë."}),
        ],
    },
    # ----------------------------------------------------------------- teksty
    {
        "id": "prawa", "title": "Prawa człowieka", "icon": "I", "track": "teksty", "requires": "be",
        "words": [
            ("wszëtczi", "wszyscy", "wszyscy", "szy → szë, scy → czi."),
            ("lëdze", "ludzie", "ludzie", None),
            ("rodzą", "rodzą", "rodzą", None),
            ("sã", "się", "się", "ã za ę: się → sã."),
            ("wòlny", "wolni", "wolny", None),
            ("równy", "równi", "równy", None),
        ],
        "sentences": [
            (["wszëtczi", "lëdze", "rodzą", "sã", "wòlny", "ë", "równy"],
             "Wszyscy ludzie rodzą się wolni i równi.", {}),
            (["lëdze", "są", "wòlny"], "Ludzie są wolni.", {}),
        ],
    },
    {
        "id": "ojcze", "title": "Òjcze nasz", "icon": "J", "track": "teksty",
        "words": [
            ("Òjcze", "Ojcze", "ojcze", "Wołacz, jak po polsku. Ò na początku: „Łejcze”."),
            ("nasz", "nasz", "nasz", None),
            ("jaczi", "który (dosł. jaki)", "jaki", "Kaszubski mówi „jaczi jes”: jaki jesteś."),
            ("w", "w", "w", None),
            ("niebie", "niebie", "niebie", None),
        ],
        "sentences": [
            (["Òjcze", "nasz", ",", "jaczi", "jes", "w", "niebie"], "Ojcze nasz, któryś jest w niebie.", {}),
        ],
    },
]

TRACKS = {
    "pismo": "PISMO",
    "jezyk": "JÃZËK · JĘZYK",
    "teksty": "TEKSTË · TEKSTY",
}

# ---------------------------------------------------------------------------
# Wglądy (Language Transfer): dlaczego, w oparciu o polski, potem kroki.
# ---------------------------------------------------------------------------
INSIGHTS = {
    "pismo1": [
        {"title": "Kreski mówią, jak czytać",
         "text": "Kaszubski pisze się prawie jak polski, ale ma swoje litery. Najważniejsza: ò czyta się "
                 "„łe”. Polskie „kot” po kaszubsku to kòt, czyli „kłet”. A ë to szwa: krótki, "
                 "przytłumiony dźwięk tam, gdzie polski ma i, y albo u.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Znasz już kaszubski",
         "text": "Kaszubski to język zachodniosłowiański, najbliższy krewny polskiego. Wiele słów różni "
                 "się jedną literą: ja → jô, ty → të, jestem → jem. Uważaj tylko na jo: to „tak”.",
         "chain": [
             ("Jestem z Kaszub.", ["jô", "jem", "z", "Kaszëb"], "jô (ja) + jem (jestem)."),
             ("Jesteś z Kaszub.", ["të", "jes", "z", "Kaszëb"], "Zmień osobę: të, jes."),
         ]},
    ],
    "kaszubienie": [
        {"title": "Kaszubienie: ci → c",
         "text": "Gdzie polski ma miękkie ci, si, zi, dzi, kaszubski ma twarde c, s, z, dz: cicho → cëchò, "
                 "świat → swiat, zima → zëma. A k, g przed e, i zmiękczają się w cz, dż: kiedy → czedë, "
                 "nogi → nodżi. Znając tę regułę, odgadniesz setki słów.",
         "chain": [
             ("Kiedy jest zima?", ["czedë", "je", "zëma", "?"], "kiedy → czedë, zima → zëma."),
         ]},
    ],
    "rodzina": [
        {"title": "-a w przymiotniku to -ô",
         "text": "Rodzaj działa jak po polsku, zmieniają się tylko samogłoski: dobry → dobri, "
                 "dobra → dobrô, moja → mòja. Polskie -a w przymiotniku to po kaszubsku -ô.",
         "chain": [
             ("To jest moja mama.", ["to", "je", "mòja", "mëma"], "to je + mòja (żeńska) + mëma."),
             ("Babcia jest dobra.", ["starka", "je", "dobrô"], "starka jest żeńska: dobrô."),
         ]},
    ],
    "liczby": [
        {"title": "Liczby prawie po polsku",
         "text": "Jeden, dwa: bez zmian. Dalej działają te same reguły: y → ë (trzë), ę → ã (piãc, "
                 "dzewiãc), ś → s (szesc). A spójnik „i” to ë.",
         "chain": [("Jeden i jeden to dwa.", ["jeden", "ë", "jeden", "to", "dwa"], "„i” to ë.")]},
    ],
    "swiat2": [
        {"title": "Wielki, wielka: wiôldżi, wiôlgô",
         "text": "Polskie „wielki” i „wielka” mają różne spółgłoski tylko w pisowni kaszubskiej: przed i "
                 "g zmiękcza się w dż (wiôldżi), a przed ô zostaje g (wiôlgô). To ta sama reguła co "
                 "nogi → nodżi.",
         "chain": [
             ("Dziś jest piękny dzień.", ["dzys", "je", "snôżi", "dzéń"], "dziś → dzys, dzień → dzéń."),
             ("Rzeka jest wielka.", ["rzéka", "je", "wiôlgô"], "Żeńska: wiôlgô."),
         ]},
    ],
    "zwierze": [
        {"title": "ò wszędzie po wargowych",
         "text": "Polskie o po p, b, m, w, k, g, ch i na początku słowa po kaszubsku zwykle ma kreskę: "
                 "kot → kòt, koń → kòń, morze → mòrze. Czytasz „łe”: kłet, kłeń, młeże.",
         "chain": [("Kot jest mały.", ["kòt", "je", "môłi"], "kot → kòt, mały → môłi.")]},
    ],
    "czasowniki": [
        {"title": "-am to -óm, -asz to -ôsz",
         "text": "Końcówki czasowników pasują do polskich: czytam → czëtóm, czytasz → czëtôsz, czyta → "
                 "czëtô. A robię → robiã, bo polskie ę to kaszubskie ã. Mówić to gôdac, jak polskie gadać.",
         "chain": [
             ("Czytam.", ["jô", "czëtóm"], "-am → -óm."),
             ("Tak, mówię trochę po kaszubsku.", ["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"],
              "jo (tak), gôdóm (gadam), kąsk (kąsek)."),
         ]},
    ],
    "be": [
        {"title": "Grzecznie: Wë",
         "text": "Kaszubi nie mówią „Pan, Pani”. Do starszych i obcych mówi się Wë, a czasownik ma "
                 "końcówkę -ce: Wë jesce = Pan jest / Pani jest. Do kilku osób: wa jesta (jesteście).",
         "chain": [
             ("Skąd Pan jest?", ["skądka", "Wë", "jesce", "?"], "skądka + Wë + jesce."),
             ("Jesteśmy z Kaszub.", ["më", "jesmë", "z", "Kaszëb"], "më, jesmë (-më jak -my)."),
         ]},
    ],
    "prawa": [
        {"title": "Pierwszy artykuł",
         "text": "Tak zaczyna się Powszechna Deklaracja Praw Człowieka po kaszubsku. Każde słowo "
                 "odgadniesz z polskiego: wszyscy → wszëtczi, ludzie → lëdze, się → sã.",
         "chain": [("Ludzie są wolni.", ["lëdze", "są", "wòlny"], "lëdze + są + wòlny.")]},
    ],
    "ojcze": [
        {"title": "Modlitwę już znasz",
         "text": "Kaszubskie „Òjcze nasz” brzmi bardzo podobnie do polskiego. Zamiast „któryś jest” "
                 "jest „jaczi jes”, czyli „jaki jesteś”.",
         "chain": [("Ojcze nasz, któryś jest w niebie.", ["Òjcze", "nasz", ",", "jaczi", "jes", "w", "niebie"],
                    "Òjcze nasz + jaczi jes + w niebie.")]},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Końcówki jak po polsku",
    "text": "Kaszubskie końcówki to polskie końcówki z innymi samogłoskami: -ę → -ã, -a → -ô, "
            "-am → -óm, -my → -më. Gdy się wahasz, powiedz to po polsku i zamień samogłoskę.",
}

# (przed, temat, końcówka, po, opcje, podpowiedź, wyjaśnienie, dział)
ENDINGS = [
    ("mòja mëma je ", "dobr", "ô", "", ["i", "ô", "é", "a"], "moja mama jest dobra", "Żeńska: -ô, jak polskie -a.", "rodzina"),
    ("mój tatk je ", "dobr", "i", "", ["i", "ô", "é", "y"], "mój tata jest dobry", "Męska: -i, jak polskie -y.", "rodzina"),
    ("", "m", "òja", " sostra", ["ój", "òja", "òje", "oja"], "moja siostra", "Żeńska: mòja.", "rodzina"),
    ("dzys je ", "snôż", "i", " dzéń", ["i", "ô", "é", "y"], "dziś jest piękny dzień", "dzéń jest męski: snôżi.", "swiat2"),
    ("rzéka je ", "wiôl", "gô", "", ["dżi", "gô", "dżé", "ga"], "rzeka jest wielka", "Żeńska: wiôlgô.", "swiat2"),
    ("jô ", "czët", "óm", "", ["óm", "ôsz", "ô", "ómë"], "ja czytam", "Ja: -óm, jak polskie -am.", "czasowniki"),
    ("të ", "czët", "ôsz", "", ["óm", "ôsz", "ô", "ómë"], "ty czytasz", "Ty: -ôsz, jak -asz.", "czasowniki"),
    ("mëma ", "czët", "ô", "", ["óm", "ôsz", "ô", "ómë"], "mama czyta", "Ona: -ô, jak -a.", "czasowniki"),
    ("jô ", "rob", "iã", "", ["iã", "isz", "i", "imë"], "ja robię", "Ja: -ã, jak polskie -ę.", "czasowniki"),
    ("më ", "rob", "imë", "", ["iã", "isz", "i", "imë"], "my robimy", "My: -më, jak polskie -my.", "be"),
    ("Wë ", "jes", "ce", " z Kaszëb?", ["m", "s", "ce", "ta"], "Pan jest z Kaszub?", "Grzecznie: Wë jesce.", "be"),
    ("wa ", "jes", "ta", " z Kaszëb", ["m", "s", "ce", "ta"], "wy jesteście z Kaszub", "Wy: wa jesta.", "be"),
    ("më ", "jes", "më", " z Kaszëb", ["m", "më", "ce", "ta"], "my jesteśmy z Kaszub", "My: jesmë.", "be"),
]

# Kolorem wyróżniamy litery, których nie ma w polskim alfabecie.
LONG_VOWELS = "ãëéòôùÃËÉÒÔÙ"

# ---------------------------------------------------------------------------
# Rozmowy
# ---------------------------------------------------------------------------
CHATS = [
    {
        "id": "witaj", "title": "Na powitanie", "partner": "Kasia", "avatar": "K", "requires": "slowa",
        "turns": [
            {"bot": ["Witôj", "!"], "en": "Witaj!",
             "options": [(["Witôj", "!"], True, None),
                         (["Dzãkùjã", "!"], False, "Dzãkùjã to „dziękuję”. Najpierw się przywitaj!")]},
            {"bot": ["të", "jes", "z", "Kaszëb", "?"], "en": "Jesteś z Kaszub?",
             "options": [(["jo", ",", "jô", "jem", "z", "Kaszëb"], True, None),
                         (["jô", ",", "jô", "jem", "z", "Kaszëb"], False, "jô to „ja”. Tak: jo."),
                         (["jo", ",", "jô", "je", "z", "Kaszëb"], False, "je to „jest”. O sobie: jem.")]},
            {"bot": ["Do", "ùzdrzeniô", "!"], "en": "Do widzenia!", "build": (["Dzãkùjã", "!"], "Dziękuję!")},
        ],
    },
    {
        "id": "dom", "title": "W domu", "partner": "Starka", "avatar": "S", "requires": "rodzina",
        "turns": [
            {"bot": ["chto", "to", "je", "?"], "en": "Kto to jest?",
             "options": [(["to", "je", "mòja", "sostra"], True, None),
                         (["to", "je", "mój", "sostra"], False, "sostra jest żeńska: mòja."),
                         (["chto", "je", "mòja", "sostra"], False, "chto to „kto”. Odpowiadasz: to je…")]},
            {"bot": ["a", "tatk", "?"], "en": "A tata?",
             "build": (["mój", "tatk", "je", "dobri"], "Mój tata jest dobry.")},
        ],
    },
    {
        "id": "morze", "title": "Nad morzem", "partner": "Józef", "avatar": "J", "requires": "czasowniki",
        "turns": [
            {"bot": ["dzys", "je", "snôżi", "dzéń", "!"], "en": "Dziś jest piękny dzień!",
             "options": [(["jo", ",", "mòrze", "je", "baro", "snôżi"], True, None),
                         (["nié", ",", "mòrze", "je", "baro", "snôżi"], False, "nié to „nie”. Zgadzasz się: jo.")],
             "note": "baro to „bardzo”."},
            {"bot": ["gôdôsz", "pò", "kaszëbskù", "?"], "en": "Mówisz po kaszubsku?",
             "options": [(["jo", ",", "gôdóm", "kąsk", "pò", "kaszëbskù"], True, None),
                         (["jo", ",", "gôdôsz", "kąsk", "pò", "kaszëbskù"], False,
                          "gôdôsz to „mówisz”. O sobie: gôdóm.")]},
            {"bot": ["co", "robisz", "?"], "en": "Co robisz?", "build": (["jô", "czëtóm"], "Czytam.")},
        ],
    },
    {
        "id": "sasiedzi", "title": "U sąsiadów", "partner": "Pani Ana", "avatar": "A", "requires": "be",
        "turns": [
            {"bot": ["skądka", "Wë", "jesce", "?"], "en": "Skąd Pan jest?",
             "options": [(["jô", "jem", "z", "Kaszëb"], True, None),
                         (["jô", "jesce", "z", "Kaszëb"], False, "jesce to forma do Wë. O sobie: jem.")]},
            {"bot": ["a", "wa", "?"], "en": "A wy?", "note": "Pani pyta o całą rodzinę.",
             "build": (["më", "jesmë", "z", "Kaszëb"], "Jesteśmy z Kaszub.")},
            {"bot": ["Do", "ùzdrzeniô", "!"], "en": "Do widzenia!",
             "options": [(["Do", "ùzdrzeniô", "!"], True, None),
                         (["Witôj", "!"], False, "Witôj to powitanie. Teraz się żegnasz.")]},
        ],
    },
]

CHAT_EXTRA = {"Do": "do", "ùzdrzeniô": "widzenia", "a": "a"}
PUNCT = set(",.!?:;")


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
    'os': ['jô', 'të', 'òn/òna', 'më', 'wa', 'òni/òne'],
    'dzies': ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
    'przyp6': ['mianownik', 'dopełniacz', 'celownik', 'biernik', 'narzędnik', 'miejscownik'],
    't_kasz': ['siano', 'zima', 'cicho', 'dzień', 'siedem', 'ciepło'],
}

PARADIGMS = [
    ('conj', 'Wzory koniugacji', 'robic (robić)', 'os', 'robiã; robisz; robi; robimë; robita; robią', '1. osoba lp. na -ã, 1. lm. na -më, 2. lm. na -ta.'),
    ('conj', 'Wzory koniugacji', 'gadac (mówić)', 'os', 'gôdóm; gôdôsz; gôdô; gôdómë; gôdôta; gôdają', 'Koniugacja na -óm, -ôsz.'),
    ('conj', 'Czasowniki nieregularne', 'bëc (być)', 'os', 'jem; jes; je; jesmë; jesta; są', None),
    ('conj', 'Czasowniki nieregularne', 'miec (mieć)', 'os', 'móm; môsz; mô; mómë; môta; mają', None),
    ('conj', 'Czasowniki nieregularne', 'jic (iść)', 'os', 'jidã; jidzesz; jidze; jidzemë; jidzeta; jidą', None),
    ('conj', 'Czasowniki nieregularne', 'chcec (chcieć)', 'os', 'chcã; chcesz; chce; chcemë; chceta; chcą', None),
    ('form', 'Liczebniki', 'Liczenie do dziesięciu', 'dzies', 'jeden; dwa; trzë; sztërë; piãc; szesc; sétmë; òsmë; dzewiãc; dzesãc', None),
    ('decl', 'Liczebniki', 'jeden (jeden)', 'przyp6', 'jeden; jednégò; jednémù; jeden; jednym; jednym', None),
    ('decl', 'Liczebniki', 'dwa (dwa)', 'przyp6', 'dwa; dwùch; dwóm; dwa; dwùma; dwùch', None),
    ('form', 'Typowe trudności', 'Kaszubienie: jak to brzmi po kaszubsku?', 't_kasz', 'sano; zëma; cëchò; dzéń; sétmë; cepło', None),
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['òkno', 'òjc', 'ùcho', 'ùczëc', 'kòt', 'pòle', 'ptôch', 'trôwa'],
    't_m1': ['robic', 'bëc', 'miec', 'jic', 'chcec', 'gadac'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'ò, ù, ô: polski odpowiednik', 't_m0', 'okno; ojciec; ucho; uczyć; kot; pole; ptak; trawa', 'ò i ù czyta się z ł na początku; ô odpowiada polskiemu a.'),
    ('form', 'Typowe trudności', 'Liczba mnoga na -ta', 't_m1', 'wa robita; wa jesta; wa môta; wa jidzeta; wa chceta; wa gôdôta', 'W 2. osobie lm. jest -ta zamiast polskiego -cie.'),
]

# === SŁOWNICTWO (generowane z langs/vocab, nie edytuj ręcznie) ===
UNITS += [{'id': 'v01a', 'title': 'Ludzie 1', 'icon': 'L', 'track': 'jezyk', 'words': [('chłop', 'mężczyzna', None, 'rodzaj męski'), ('białka', 'kobieta', None, 'rodzaj żeński'), ('człowiek', 'człowiek', None, 'rodzaj męski'), ('rodzëna', 'rodzina', None, 'rodzaj żeński'), ('tata', 'ojciec', None, 'rodzaj męski'), ('sën', 'syn', None, 'rodzaj męski'), ('cora', 'córka', None, 'rodzaj żeński'), ('brat', 'brat', None, 'rodzaj męski'), ('dzadk', 'dziadek', None, 'rodzaj męski'), ('bòbka', 'babcia', None, 'rodzaj żeński'), ('wnuk', 'wnuk', None, 'rodzaj męski'), ('wùjk', 'wuj', None, 'rodzaj męski'), ('cëca', 'ciotka', None, 'rodzaj żeński'), ('drëch', 'przyjaciel', None, 'rodzaj męski'), ('sąsôd', 'sąsiad', None, 'rodzaj męski'), ('gòsc', 'gość', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01b', 'title': 'Ludzie 2', 'icon': 'L', 'track': 'jezyk', 'words': [('wróg', 'wróg', None, 'rodzaj męski'), ('król', 'król', None, 'rodzaj męski'), ('królewô', 'królowa', None, 'rodzaj żeński'), ('wòdz', 'wódz', None, 'rodzaj męski'), ('ksądz', 'ksiądz', None, 'rodzaj męski'), ('ùczëc', 'nauczyciel', None, 'rodzaj męski'), ('ùczen', 'uczeń', None, 'rodzaj męski'), ('dochtór', 'lekarz', None, 'rodzaj męski'), ('żôłnérz', 'żołnierz', None, 'rodzaj męski'), ('rôlnik', 'rolnik', None, 'rodzaj męski'), ('kùpiec', 'kupiec', None, 'rodzaj męski'), ('rëbôk', 'rybak', None, 'rodzaj męski'), ('kòwôl', 'kowal', None, 'rodzaj męski'), ('stolôrz', 'stolarz', None, 'rodzaj męski'), ('krôwc', 'krawiec', None, 'rodzaj męski'), ('szewc', 'szewc', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01c', 'title': 'Ludzie 3', 'icon': 'L', 'track': 'jezyk', 'words': [('piekôrz', 'piekarz', None, 'rodzaj męski'), ('rzeznik', 'rzeźnik', None, 'rodzaj męski'), ('sąd', 'sędzia', None, 'rodzaj męski'), ('służący', 'sługa', None, 'rodzaj męski'), ('starzëk', 'starzec', None, 'rodzaj męski'), ('młodzeniec', 'młodzieniec', None, 'rodzaj męski'), ('wdowa', 'wdowa', None, 'rodzaj żeński'), ('wdowc', 'wdowiec', None, 'rodzaj męski'), ('sziroka', 'sierota', None, 'rodzaj żeński'), ('òbcy', 'obcy', None, 'rodzaj męski'), ('złodzeja', 'złodziej', None, 'rodzaj męski'), ('pòsłaniec', 'posłaniec', None, 'rodzaj męski'), ('anioł', 'anioł', None, 'rodzaj męski'), ('swiãti', 'święty', None, 'rodzaj męski'), ('grzesznik', 'grzesznik', None, 'rodzaj męski'), ('mądrzél', 'mądrala', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v01d', 'title': 'Ludzie 4', 'icon': 'L', 'track': 'jezyk', 'words': [('poeta', 'poeta', None, 'rodzaj męski'), ('pisarz', 'pisarz', None, 'rodzaj męski'), ('stróż', 'strażnik', None, 'rodzaj męski'), ('wiãzniec', 'więzień', None, 'rodzaj męski'), ('mieszkańc', 'mieszkaniec', None, 'rodzaj męski'), ('lud', 'lud', None, 'rodzaj męski'), ('naród', 'naród', None, 'rodzaj męski'), ('tłum', 'tłum', None, 'rodzaj męski'), ('bògacz', 'bogacz', None, 'rodzaj męski'), ('biédak', 'biedak', None, 'rodzaj męski'), ('wãdrowiec', 'wędrowiec', None, 'rodzaj męski'), ('rodzëce', 'rodzice', None, 'rodzaj męski'), ('pón', 'pan', None, 'rodzaj męski'), ('pani', 'pani', None, 'rodzaj żeński'), ('państwò', 'państwo', None, 'rodzaj nijaki'), ('drëchna', 'przyjaciółka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v01e', 'title': 'Ludzie 5', 'icon': 'L', 'track': 'jezyk', 'words': [('kòleżanka', 'koleżanka', None, 'rodzaj żeński'), ('kòlega', 'kolega', None, 'rodzaj męski'), ('małżónk', 'małżonek', None, 'rodzaj męski'), ('teść', 'teść', None, 'rodzaj męski'), ('teściowô', 'teściowa', None, 'rodzaj żeński'), ('zeńc', 'zięć', None, 'rodzaj męski'), ('synowô', 'synowa', None, 'rodzaj żeński'), ('szwagier', 'szwagier', None, 'rodzaj męski'), ('bratanek', 'bratanek', None, 'rodzaj męski'), ('sostrzeniec', 'siostrzeniec', None, 'rodzaj męski'), ('chrzesnik', 'chrześniak', None, 'rodzaj męski'), ('kùm', 'kum', None, 'rodzaj męski'), ('kùmòter', 'kumoter', None, 'rodzaj męski'), ('sąsôdka', 'sąsiadka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v02a', 'title': 'Ciało 1', 'icon': 'C', 'track': 'jezyk', 'words': [('głowa', 'głowa', None, 'rodzaj żeński'), ('twôrz', 'twarz', None, 'rodzaj żeński'), ('òkò', 'oko', None, 'rodzaj nijaki'), ('ùcho', 'ucho', None, 'rodzaj nijaki'), ('nos', 'nos', None, 'rodzaj męski'), ('ùsta', 'usta', None, 'rodzaj nijaki'), ('zãb', 'ząb', None, 'rodzaj męski'), ('jãzëk', 'język (narząd)', None, 'rodzaj męski'), ('włosë', 'włosy', None, 'rodzaj męski'), ('szëja', 'szyja', None, 'rodzaj żeński'), ('ramiã', 'ramię', None, 'rodzaj nijaki'), ('rãka', 'ręka', None, 'rodzaj żeński'), ('palc', 'palec', None, 'rodzaj męski'), ('noga', 'noga', None, 'rodzaj żeński'), ('stopa', 'stopa', None, 'rodzaj żeński'), ('kòlano', 'kolano', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v02b', 'title': 'Ciało 2', 'icon': 'C', 'track': 'jezyk', 'words': [('pleca', 'plecy', None, 'rodzaj nijaki'), ('brzëch', 'brzuch', None, 'rodzaj męski'), ('serce', 'serce', None, 'rodzaj nijaki'), ('krew', 'krew', None, 'rodzaj żeński'), ('kòsc', 'kość', None, 'rodzaj żeński'), ('skóra', 'skóra', None, 'rodzaj żeński'), ('cało', 'ciało', None, 'rodzaj nijaki'), ('żôłądk', 'żołądek', None, 'rodzaj męski'), ('broda', 'broda', None, 'rodzaj żeński'), ('wërga', 'warga', None, 'rodzaj żeński'), ('pazur', 'paznokieć', None, 'rodzaj męski'), ('pierś', 'pierś', None, 'rodzaj żeński'), ('mózg', 'mózg', None, 'rodzaj męski'), ('łokcie', 'łokieć', None, 'rodzaj męski'), ('czoło', 'czoło', None, 'rodzaj nijaki'), ('pòliczk', 'policzek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v02c', 'title': 'Ciało 3', 'icon': 'C', 'track': 'jezyk', 'words': [('piãta', 'pięta', None, 'rodzaj żeński'), ('wątroba', 'wątroba', None, 'rodzaj żeński'), ('pòt', 'pot', None, 'rodzaj męski'), ('łza', 'łza', None, 'rodzaj żeński'), ('żëła', 'żyła', None, 'rodzaj żeński'), ('tłuszcz', 'tłuszcz', None, 'rodzaj męski'), ('skrzidło', 'skrzydło', None, 'rodzaj nijaki'), ('róg', 'róg', None, 'rodzaj męski'), ('ògón', 'ogon', None, 'rodzaj męski'), ('dłón', 'dłoń', None, 'rodzaj żeński'), ('piãsc', 'pięść', None, 'rodzaj żeński'), ('bok', 'bok', None, 'rodzaj męski'), ('ùdo', 'udo', None, 'rodzaj nijaki'), ('głos', 'głos', None, 'rodzaj męski'), ('òddech', 'oddech', None, 'rodzaj męski'), ('duch', 'duch', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v02d', 'title': 'Ciało 4', 'icon': 'C', 'track': 'jezyk', 'words': [('dëszô', 'dusza', None, 'rodzaj żeński'), ('brew', 'brew', None, 'rodzaj żeński'), ('rzãsa', 'rzęsa', None, 'rodzaj żeński'), ('kark', 'kark', None, 'rodzaj męski'), ('ramiona', 'ramiona', None, 'rodzaj nijaki'), ('żebro', 'żebro', None, 'rodzaj nijaki'), ('płëca', 'płuco', None, 'rodzaj nijaki'), ('nerka', 'nerka', None, 'rodzaj żeński'), ('kręgòsłup', 'kręgosłup', None, 'rodzaj męski'), ('gardło', 'gardło', None, 'rodzaj nijaki'), ('pòdbrodk', 'podbródek', None, 'rodzaj męski'), ('skrón', 'skroń', None, 'rodzaj żeński'), ('łëdka', 'łydka', None, 'rodzaj żeński'), ('kòstka', 'kostka', None, 'rodzaj żeński'), ('nadgarstk', 'nadgarstek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03a', 'title': 'Jedzenie 1', 'icon': 'J', 'track': 'jezyk', 'words': [('chléb', 'chleb', None, 'rodzaj męski'), ('masło', 'masło', None, 'rodzaj nijaki'), ('ser', 'ser', None, 'rodzaj męski'), ('mléko', 'mleko', None, 'rodzaj nijaki'), ('jaje', 'jajko', None, 'rodzaj nijaki'), ('mięsò', 'mięso', None, 'rodzaj nijaki'), ('zupa', 'zupa', None, 'rodzaj żeński'), ('kasza', 'kasza', None, 'rodzaj żeński'), ('mąka', 'mąka', None, 'rodzaj żeński'), ('cebùla', 'cebula', None, 'rodzaj żeński'), ('czosnk', 'czosnek', None, 'rodzaj męski'), ('jabkò', 'jabłko', None, 'rodzaj nijaki'), ('grëszka', 'gruszka', None, 'rodzaj żeński'), ('winogrono', 'winogrono', None, 'rodzaj nijaki'), ('śliwka', 'śliwka', None, 'rodzaj żeński'), ('òrzech', 'orzech', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03b', 'title': 'Jedzenie 2', 'icon': 'J', 'track': 'jezyk', 'words': [('miód', 'miód', None, 'rodzaj męski'), ('sól', 'sól', None, 'rodzaj żeński'), ('piéprz', 'pieprz', None, 'rodzaj męski'), ('wino', 'wino', None, 'rodzaj nijaki'), ('òcet', 'ocet', None, 'rodzaj męski'), ('sniôdanié', 'śniadanie', None, 'rodzaj nijaki'), ('òbiad', 'obiad', None, 'rodzaj męski'), ('kòlacëjô', 'kolacja', None, 'rodzaj żeński'), ('ùcta', 'uczta', None, 'rodzaj żeński'), ('głód', 'głód', None, 'rodzaj męski'), ('jedzenié', 'jedzenie', None, 'rodzaj nijaki'), ('pòkarm', 'pokarm', None, 'rodzaj męski'), ('nôpój', 'napój', None, 'rodzaj męski'), ('piwò', 'piwo', None, 'rodzaj nijaki'), ('kapùsta', 'kapusta', None, 'rodzaj żeński'), ('ògórk', 'ogórek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03c', 'title': 'Jedzenie 3', 'icon': 'J', 'track': 'jezyk', 'words': [('kartofel', 'ziemniak', None, 'rodzaj męski'), ('burk', 'burak', None, 'rodzaj męski'), ('mòrchew', 'marchew', None, 'rodzaj żeński'), ('grôch', 'groch', None, 'rodzaj męski'), ('fasolô', 'fasola', None, 'rodzaj żeński'), ('pòmidór', 'pomidor', None, 'rodzaj męski'), ('òwòc', 'owoc', None, 'rodzaj męski'), ('zbòżé', 'zboże', None, 'rodzaj nijaki'), ('pszenica', 'pszenica', None, 'rodzaj żeński'), ('jãczmiéń', 'jęczmień', None, 'rodzaj męski'), ('żëto', 'żyto', None, 'rodzaj nijaki'), ('òwies', 'owies', None, 'rodzaj męski'), ('grzib', 'grzyb', None, 'rodzaj męski'), ('jagòda', 'jagoda', None, 'rodzaj żeński'), ('malëna', 'malina', None, 'rodzaj żeński'), ('trëskawka', 'truskawka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v03d', 'title': 'Jedzenie 4', 'icon': 'J', 'track': 'jezyk', 'words': [('wiszniô', 'wiśnia', None, 'rodzaj żeński'), ('kiełbasa', 'kiełbasa', None, 'rodzaj żeński'), ('bòczk', 'boczek', None, 'rodzaj męski'), ('szinka', 'szynka', None, 'rodzaj żeński'), ('smiétana', 'śmietana', None, 'rodzaj żeński'), ('twarôg', 'twaróg', None, 'rodzaj męski'), ('kwas', 'kwas', None, 'rodzaj męski'), ('ciastò', 'ciasto', None, 'rodzaj nijaki'), ('plack', 'placek', None, 'rodzaj męski'), ('pierogi', 'pierogi', None, 'rodzaj męski'), ('kluszczi', 'kluski', None, 'rodzaj męski'), ('naleśniczi', 'naleśniki', None, 'rodzaj męski'), ('kartacze', 'kartacze', None, 'rodzaj męski'), ('słonina', 'słonina', None, 'rodzaj żeński'), ('smalc', 'smalec', None, 'rodzaj męski'), ('sos', 'sos', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v03e', 'title': 'Jedzenie 5', 'icon': 'J', 'track': 'jezyk', 'words': [('cukier', 'cukier', None, 'rodzaj męski'), ('herbata', 'herbata', None, 'rodzaj żeński'), ('kawa', 'kawa', None, 'rodzaj żeński'), ('wòdka', 'wódka', None, 'rodzaj żeński'), ('sok', 'sok', None, 'rodzaj męski'), ('cukierk', 'cukierek', None, 'rodzaj męski'), ('miska zupë', 'miska (zupy)', None, 'rodzaj żeński'), ('piekarnia', 'pieczywo', None, 'rodzaj żeński'), ('bùłka', 'bułka', None, 'rodzaj żeński'), ('kminek', 'kmin', None, 'rodzaj męski'), ('zele', 'ziele', None, 'rodzaj nijaki'), ('kòperk', 'koperek', None, 'rodzaj męski'), ('pietrëszka', 'pietruszka', None, 'rodzaj żeński'), ('szczipiòrk', 'szczypiorek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04a', 'title': 'Dom 1', 'icon': 'D', 'track': 'jezyk', 'words': [('dóm', 'dom', None, 'rodzaj męski'), ('chata', 'chata', None, 'rodzaj żeński'), ('pòkòj', 'pokój', None, 'rodzaj męski'), ('kùchniô', 'kuchnia', None, 'rodzaj żeński'), ('łazenka', 'łazienka', None, 'rodzaj żeński'), ('sypialnia', 'sypialnia', None, 'rodzaj żeński'), ('ògród', 'ogród', None, 'rodzaj męski'), ('dwiérze', 'drzwi', None, 'rodzaj żeński'), ('brama', 'brama', None, 'rodzaj żeński'), ('òknò', 'okno', None, 'rodzaj nijaki'), ('scana', 'ściana', None, 'rodzaj żeński'), ('pòdłoga', 'podłoga', None, 'rodzaj żeński'), ('dach', 'dach', None, 'rodzaj męski'), ('schòdë', 'schody', None, 'rodzaj męski'), ('klucz', 'klucz', None, 'rodzaj męski'), ('zamk', 'zamek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v04b', 'title': 'Dom 2', 'icon': 'D', 'track': 'jezyk', 'words': [('stół', 'stół', None, 'rodzaj męski'), ('krzesło', 'krzesło', None, 'rodzaj nijaki'), ('łóżkò', 'łóżko', None, 'rodzaj nijaki'), ('szafa', 'szafa', None, 'rodzaj żeński'), ('lampa', 'lampa', None, 'rodzaj żeński'), ('dëwón', 'dywan', None, 'rodzaj męski'), ('lëstro', 'lustro', None, 'rodzaj nijaki'), ('pòduszka', 'poduszka', None, 'rodzaj żeński'), ('kòc', 'koc', None, 'rodzaj męski'), ('òdżen', 'ogień', None, 'rodzaj męski'), ('piec', 'piec', None, 'rodzaj męski'), ('stùdniô', 'studnia', None, 'rodzaj żeński'), ('dwór', 'dziedziniec', None, 'rodzaj męski'), ('stajnia', 'stajnia', None, 'rodzaj żeński'), ('òbòra', 'obora', None, 'rodzaj żeński'), ('stodòła', 'stodoła', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v04c', 'title': 'Dom 3', 'icon': 'D', 'track': 'jezyk', 'words': [('płot', 'płot', None, 'rodzaj męski'), ('bielka', 'belka', None, 'rodzaj żeński'), ('cegła', 'cegła', None, 'rodzaj żeński'), ('kamiń', 'kamień', None, 'rodzaj męski'), ('miska', 'miska', None, 'rodzaj żeński'), ('dzbón', 'dzban', None, 'rodzaj męski'), ('gôrnk', 'garnek', None, 'rodzaj męski'), ('kòsz', 'kosz', None, 'rodzaj męski'), ('skrzinia', 'skrzynia', None, 'rodzaj żeński'), ('wiaderkò', 'wiadro', None, 'rodzaj nijaki'), ('nóż', 'nóż', None, 'rodzaj męski'), ('łëżka', 'łyżka', None, 'rodzaj żeński'), ('widelc', 'widelec', None, 'rodzaj męski'), ('talérz', 'talerz', None, 'rodzaj męski'), ('kùbk', 'kubek', None, 'rodzaj męski'), ('szklónka', 'szklanka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v04d', 'title': 'Dom 4', 'icon': 'D', 'track': 'jezyk', 'words': [('naczeniô', 'naczynie', None, 'rodzaj nijaki'), ('mebel', 'mebel', None, 'rodzaj męski'), ('strëch', 'strych', None, 'rodzaj męski'), ('piwnica', 'piwnica', None, 'rodzaj żeński'), ('kòmin', 'komin', None, 'rodzaj męski'), ('prog', 'próg', None, 'rodzaj męski'), ('słomiany dach', 'dach (słomiany)', None, 'rodzaj męski'), ('miotła', 'miotła', None, 'rodzaj żeński'), ('szczotka', 'szczotka', None, 'rodzaj żeński'), ('wanna', 'wanna', None, 'rodzaj żeński'), ('mëdło', 'mydło', None, 'rodzaj nijaki'), ('rãcznik', 'ręcznik', None, 'rodzaj męski'), ('grzebiéń', 'grzebień', None, 'rodzaj męski'), ('zegôr', 'zegar', None, 'rodzaj męski'), ('telewizor', 'telewizor', None, 'rodzaj męski'), ('radiò', 'radio', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v04e', 'title': 'Dom 5', 'icon': 'D', 'track': 'jezyk', 'words': [('telefón', 'telefon', None, 'rodzaj męski'), ('kòmpùter', 'komputer', None, 'rodzaj męski'), ('sofa', 'sofa', None, 'rodzaj żeński'), ('fòtel', 'fotel', None, 'rodzaj męski'), ('półka', 'półka', None, 'rodzaj żeński'), ('szuflada', 'szuflada', None, 'rodzaj żeński'), ('wieszôk', 'wieszak', None, 'rodzaj męski'), ('parapét', 'parapet', None, 'rodzaj męski'), ('zasłona', 'zasłona', None, 'rodzaj żeński'), ('gónk', 'ganek', None, 'rodzaj męski'), ('garaż', 'garaż', None, 'rodzaj męski'), ('kòmórka', 'komórka', None, 'rodzaj żeński'), ('winda', 'winda', None, 'rodzaj żeński'), ('swieca', 'świeca', None, 'rodzaj żeński'), ('latarniô', 'latarnia', None, 'rodzaj żeński'), ('drabina', 'drabina', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v04f', 'title': 'Dom 6', 'icon': 'D', 'track': 'jezyk', 'words': [('kòsa', 'kosa', None, 'rodzaj żeński'), ('grôbie', 'grabie', None, 'rodzaj żeński'), ('sekiera', 'siekiera', None, 'rodzaj żeński'), ('młotk', 'młotek', None, 'rodzaj męski'), ('piła', 'piła', None, 'rodzaj żeński'), ('gwózdz', 'gwóźdź', None, 'rodzaj męski'), ('sruba', 'śruba', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v05a', 'title': 'Ubrania 1', 'icon': 'U', 'track': 'jezyk', 'words': [('òbleczenié', 'ubranie', None, 'rodzaj nijaki'), ('kòszula', 'koszula', None, 'rodzaj żeński'), ('spòdnie', 'spodnie', None, 'rodzaj żeński'), ('sukienka', 'sukienka', None, 'rodzaj żeński'), ('spódnica', 'spódnica', None, 'rodzaj żeński'), ('płaszcz', 'płaszcz', None, 'rodzaj męski'), ('kùrtka', 'kurtka', None, 'rodzaj żeński'), ('swetr', 'sweter', None, 'rodzaj męski'), ('bót', 'but', None, 'rodzaj męski'), ('sandôł', 'sandał', None, 'rodzaj męski'), ('kapelusz', 'kapelusz', None, 'rodzaj męski'), ('czôpka', 'czapka', None, 'rodzaj żeński'), ('szalik', 'szalik', None, 'rodzaj męski'), ('rãkawiczka', 'rękawiczka', None, 'rodzaj żeński'), ('skarpetka', 'skarpetka', None, 'rodzaj żeński'), ('pas', 'pas', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v05b', 'title': 'Ubrania 2', 'icon': 'U', 'track': 'jezyk', 'words': [('pierscyń', 'pierścień', None, 'rodzaj męski'), ('naszëjnik', 'naszyjnik', None, 'rodzaj męski'), ('tkanina', 'tkanina', None, 'rodzaj żeński'), ('wełna', 'wełna', None, 'rodzaj żeński'), ('len', 'len', None, 'rodzaj męski'), ('jedwab', 'jedwab', None, 'rodzaj męski'), ('chùsta', 'chusta', None, 'rodzaj żeński'), ('wieńc', 'wieniec', None, 'rodzaj męski'), ('kòrona', 'korona', None, 'rodzaj żeński'), ('szata', 'szata', None, 'rodzaj żeński'), ('rãkôw', 'rękaw', None, 'rodzaj męski'), ('kieszéń', 'kieszeń', None, 'rodzaj żeński'), ('gùzik', 'guzik', None, 'rodzaj męski'), ('nic', 'nić', None, 'rodzaj żeński'), ('igła', 'igła', None, 'rodzaj żeński'), ('bielëzna', 'bielizna', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v05c', 'title': 'Ubrania 3', 'icon': 'U', 'track': 'jezyk', 'words': [('fartuch', 'fartuch', None, 'rodzaj męski'), ('krawat', 'krawat', None, 'rodzaj męski'), ('garnitur', 'garnitur', None, 'rodzaj męski'), ('òkùlarë', 'okulary', None, 'rodzaj męski'), ('torba', 'torba', None, 'rodzaj żeński'), ('plecôk', 'plecak', None, 'rodzaj męski'), ('zegarek', 'zegarek', None, 'rodzaj męski'), ('parasól', 'parasol', None, 'rodzaj męski'), ('chùsteczka', 'chusteczka', None, 'rodzaj żeński'), ('kòżuch', 'kożuch', None, 'rodzaj męski'), ('trzewik', 'trzewik', None, 'rodzaj męski'), ('kamasz', 'kamasz', None, 'rodzaj męski'), ('drzewiôk', 'drewniak', None, 'rodzaj męski'), ('szlafrok', 'szlafrok', None, 'rodzaj męski'), ('piżama', 'piżama', None, 'rodzaj żeński'), ('szelczi', 'szelki', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v05d', 'title': 'Ubrania 4', 'icon': 'U', 'track': 'jezyk', 'words': [('òzdoba', 'ozdoba', None, 'rodzaj żeński'), ('kòlczik', 'kolczyk', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v06a', 'title': 'Kolory i kształty 1', 'icon': 'K', 'track': 'jezyk', 'words': [('czerwòny', 'czerwony', None, None), ('niebieski', 'niebieski', None, None), ('zelony', 'zielony', None, None), ('żôłti', 'żółty', None, None), ('czôrny', 'czarny', None, None), ('biôłi', 'biały', None, None), ('szôri', 'szary', None, None), ('brunatny', 'brązowy', None, None), ('różowi', 'różowy', None, None), ('fiòlétowi', 'fioletowy', None, None), ('złoti', 'złoty', None, None), ('srebrny', 'srebrny', None, None), ('jasny', 'jasny', None, None), ('ciemny', 'ciemny', None, None), ('kòlór', 'kolor', None, 'rodzaj męski'), ('òkrąglëi', 'okrągły', None, None)], 'sentences': []}, {'id': 'v06b', 'title': 'Kolory i kształty 2', 'icon': 'K', 'track': 'jezyk', 'words': [('kwadratowi', 'kwadratowy', None, None), ('prosti', 'prosty', None, None), ('krzëwi', 'krzywy', None, None), ('linia', 'linia', None, 'rodzaj żeński'), ('pùnkt', 'punkt', None, 'rodzaj męski'), ('kòło', 'koło', None, 'rodzaj nijaki'), ('trójkąt', 'trójkąt', None, 'rodzaj męski'), ('kształt', 'kształt', None, 'rodzaj męski'), ('kùla', 'kula', None, 'rodzaj żeński'), ('kąt', 'kąt', None, 'rodzaj męski'), ('bòk', 'bok (figury)', None, 'rodzaj męski'), ('sriodk', 'środek', None, 'rodzaj męski'), ('wësokòsc', 'wysokość', None, 'rodzaj żeński'), ('dłëgòsc', 'długość', None, 'rodzaj żeński'), ('szérokòsc', 'szerokość', None, 'rodzaj żeński'), ('głãbòkòsc', 'głębokość', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v06c', 'title': 'Kolory i kształty 3', 'icon': 'K', 'track': 'jezyk', 'words': [('wiôlgòsc', 'wielkość', None, 'rodzaj żeński'), ('miara', 'miara', None, 'rodzaj żeński'), ('òstri', 'ostry', None, None), ('tãpi', 'tępy', None, None), ('gładczi', 'gładki', None, None), ('szorstczi', 'szorstki', None, None), ('paskòwati', 'pasiasty', None, None), ('w kratkã', 'w kratkę', None, None), ('kropczasti', 'kropkowany', None, None), ('błëszczący', 'błyszczący', None, None), ('matowi', 'matowy', None, None)], 'sentences': []}, {'id': 'v07a', 'title': 'Liczby i ilości 1', 'icon': 'L', 'track': 'jezyk', 'words': [('jedenôsce', 'jedenaście', None, None), ('dwanôsce', 'dwanaście', None, None), ('trzënôsce', 'trzynaście', None, None), ('czternôsce', 'czternaście', None, None), ('piãtnôsce', 'piętnaście', None, None), ('szesnôsce', 'szesnaście', None, None), ('sétnôsce', 'siedemnaście', None, None), ('òsemnôsce', 'osiemnaście', None, None), ('dzewiãtnôsce', 'dziewiętnaście', None, None), ('dwadzesca', 'dwadzieścia', None, None), ('trzëdzescë', 'trzydzieści', None, None), ('sztërdzescë', 'czterdzieści', None, None), ('piãcdzesąt', 'pięćdziesiąt', None, None), ('szescdzesąt', 'sześćdziesiąt', None, None), ('sédemdzesąt', 'siedemdziesiąt', None, None), ('òsemdzesąt', 'osiemdziesiąt', None, None)], 'sentences': []}, {'id': 'v07b', 'title': 'Liczby i ilości 2', 'icon': 'L', 'track': 'jezyk', 'words': [('dzewiãcdzesąt', 'dziewięćdziesiąt', None, None), ('sto', 'sto', None, None), ('dwiesce', 'dwieście', None, None), ('trzësta', 'trzysta', None, None), ('tësąc', 'tysiąc', None, None), ('milión', 'milion', None, None), ('pierwszi', 'pierwszy', None, None), ('drëdżi', 'drugi', None, None), ('trzecy', 'trzeci', None, None), ('czwôrti', 'czwarty', None, None), ('piąti', 'piąty', None, None), ('szósti', 'szósty', None, None), ('sódmi', 'siódmy', None, None), ('òsmi', 'ósmy', None, None), ('dzewiąti', 'dziewiąty', None, None), ('dzesąti', 'dziesiąty', None, None)], 'sentences': []}, {'id': 'v07c', 'title': 'Liczby i ilości 3', 'icon': 'L', 'track': 'jezyk', 'words': [('pòłowa', 'połowa', None, 'rodzaj żeński'), ('para', 'para', None, 'rodzaj żeński'), ('kilka', 'kilka', None, None), ('wiele', 'wiele', None, None), ('mało', 'mało', None, None), ('cały', 'cały', None, None), ('wszëscë', 'wszyscy', None, None), ('wszëtkò', 'wszystko', None, None), ('żôdny', 'żaden', None, None), ('dwa razë', 'dwa razy', None, None), ('trzë razë', 'trzy razy', None, None), ('rôz', 'raz', None, None), ('ile', 'ile', None, None), ('tëlé', 'tyle', None, None), ('wicy', 'więcej', None, None), ('mni', 'mniej', None, None)], 'sentences': []}, {'id': 'v07d', 'title': 'Liczby i ilości 4', 'icon': 'L', 'track': 'jezyk', 'words': [('dosc', 'dość', None, None), ('zbëtno', 'zbyt', None, None), ('dwójny', 'podwójny', None, None), ('setka', 'setka', None, 'rodzaj żeński'), ('dzesątka', 'dziesiątka', None, 'rodzaj żeński'), ('ćwiérc', 'ćwierć', None, 'rodzaj żeński'), ('trzecô czãsc', 'trzecia część', None, 'rodzaj żeński'), ('dwòje', 'dwoje', None, None), ('trzòje', 'troje', None, None), ('òbòje', 'oboje', None, None), ('zero', 'zero', None, None), ('plus', 'plus', None, None), ('minus', 'minus', None, None), ('razem', 'razem', None, None)], 'sentences': []}, {'id': 'v08a', 'title': 'Czas 1', 'icon': 'C', 'track': 'jezyk', 'words': [('sekùnda', 'sekunda', None, 'rodzaj żeński'), ('minuta', 'minuta', None, 'rodzaj żeński'), ('gòdzëna', 'godzina', None, 'rodzaj żeński'), ('nôc', 'noc', None, 'rodzaj żeński'), ('tidzéń', 'tydzień', None, 'rodzaj męski'), ('miesąc', 'miesiąc', None, 'rodzaj męski'), ('rok', 'rok', None, 'rodzaj męski'), ('wiesna', 'wiosna', None, 'rodzaj żeński'), ('jeséń', 'jesień', None, 'rodzaj żeński'), ('rano', 'rano', None, None), ('pòłudnié', 'południe', None, 'rodzaj nijaki'), ('wieczór', 'wieczór', None, 'rodzaj męski'), ('wiedno', 'zawsze', None, None), ('nigdë', 'nigdy', None, None), ('czasã', 'czasem', None, None), ('czãsto', 'często', None, None)], 'sentences': []}, {'id': 'v08b', 'title': 'Czas 2', 'icon': 'C', 'track': 'jezyk', 'words': [('ju', 'już', None, None), ('jesz', 'jeszcze', None, None), ('wnet', 'wkrótce', None, None), ('pòzni', 'później', None, None), ('wczasno', 'wcześnie', None, None), ('pòzno', 'późno', None, None), ('przeszłòsc', 'przeszłość', None, 'rodzaj żeński'), ('przińszłòsc', 'przyszłość', None, 'rodzaj żeński'), ('terôzniészòsc', 'teraźniejszość', None, 'rodzaj żeński'), ('swiãto', 'święto', None, 'rodzaj nijaki'), ('dzysô', 'dziś', None, None), ('jutro', 'jutro', None, None), ('wczorôj', 'wczoraj', None, None), ('terô', 'teraz', None, None), ('tedë', 'wtedy', None, None), ('wiek', 'wiek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v08c', 'title': 'Czas 3', 'icon': 'C', 'track': 'jezyk', 'words': [('chwila', 'chwila', None, 'rodzaj żeński'), ('czas', 'czas', None, 'rodzaj męski'), ('młodòsc', 'młodość', None, 'rodzaj żeński'), ('starzëzna', 'starość', None, 'rodzaj żeński'), ('dzecënstwò', 'dzieciństwo', None, 'rodzaj nijaki'), ('switanié', 'świt', None, 'rodzaj nijaki'), ('zmierzch', 'zmierzch', None, 'rodzaj męski'), ('pòłnoc', 'północ', None, 'rodzaj żeński'), ('dôwno', 'dawno', None, None), ('nie dôwno', 'niedawno', None, None), ('zarô', 'natychmiast', None, None), ('tim czasã', 'tymczasem', None, None), ('wczasni', 'wcześniej', None, None), ('wrescze', 'wreszcie', None, None), ('nômpierwi', 'najpierw', None, None), ('pòtemù', 'potem', None, None)], 'sentences': []}, {'id': 'v08d', 'title': 'Czas 4', 'icon': 'C', 'track': 'jezyk', 'words': [('niedzela', 'niedziela', None, 'rodzaj żeński'), ('pòniedzôłk', 'poniedziałek', None, 'rodzaj męski'), ('wtórk', 'wtorek', None, 'rodzaj męski'), ('sroda', 'środa', None, 'rodzaj żeński'), ('czwartk', 'czwartek', None, 'rodzaj męski'), ('piątk', 'piątek', None, 'rodzaj męski'), ('sobòta', 'sobota', None, 'rodzaj żeński'), ('stëcznik', 'styczeń', None, 'rodzaj męski'), ('gromicznik', 'luty', None, 'rodzaj męski'), ('strëmiannik', 'marzec', None, 'rodzaj męski'), ('łżëkwiat', 'kwiecień', None, 'rodzaj męski'), ('môj', 'maj', None, 'rodzaj męski'), ('czerwińc', 'czerwiec', None, 'rodzaj męski'), ('lëpińc', 'lipiec', None, 'rodzaj męski'), ('zélnik', 'sierpień', None, 'rodzaj męski'), ('séwnik', 'wrzesień', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v08e', 'title': 'Czas 5', 'icon': 'C', 'track': 'jezyk', 'words': [('rujan', 'październik', None, 'rodzaj męski'), ('lëstopadnik', 'listopad', None, 'rodzaj męski'), ('gòdnik', 'grudzień', None, 'rodzaj męski'), ('Wiôlgô Nocë', 'Wielkanoc', None, 'rodzaj żeński'), ('Gòdë', 'Boże Narodzenie', None, 'rodzaj męski'), ('pòst', 'post', None, 'rodzaj męski'), ('wiecznòsc', 'wieczność', None, 'rodzaj żeński'), ('stolatié', 'stulecie', None, 'rodzaj nijaki'), ('pora', 'pora', None, 'rodzaj żeński'), ('wczasny', 'wczesny', None, None), ('kòżdégò dnia', 'codziennie', None, None), ('kòżdi tidzéń', 'co tydzień', None, None), ('òstatno', 'ostatnio', None, None), ('nagle', 'nagle', None, None), ('pòwòlë', 'powoli', None, None)], 'sentences': []}, {'id': 'v09a', 'title': 'Przyroda i pogoda 1', 'icon': 'P', 'track': 'jezyk', 'words': [('miesądz', 'księżyc', None, 'rodzaj męski'), ('gwiôzda', 'gwiazda', None, 'rodzaj żeński'), ('niebò', 'niebo', None, 'rodzaj nijaki'), ('chmùra', 'chmura', None, 'rodzaj żeński'), ('dëszcz', 'deszcz', None, 'rodzaj męski'), ('sniég', 'śnieg', None, 'rodzaj męski'), ('wiatr', 'wiatr', None, 'rodzaj męski'), ('burza', 'burza', None, 'rodzaj żeński'), ('mgła', 'mgła', None, 'rodzaj żeński'), ('lód', 'lód', None, 'rodzaj męski'), ('góra', 'góra', None, 'rodzaj żeński'), ('las', 'las', None, 'rodzaj męski'), ('drzewò', 'drzewo', None, 'rodzaj nijaki'), ('kwiat', 'kwiat', None, 'rodzaj męski'), ('trôwa', 'trawa', None, 'rodzaj żeński'), ('lëst', 'liść', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v09b', 'title': 'Przyroda i pogoda 2', 'icon': 'P', 'track': 'jezyk', 'words': [('pòle', 'pole', None, 'rodzaj nijaki'), ('łąka', 'łąka', None, 'rodzaj żeński'), ('wëspa', 'wyspa', None, 'rodzaj żeński'), ('brzég', 'brzeg', None, 'rodzaj męski'), ('plaża', 'plaża', None, 'rodzaj żeński'), ('skała', 'skała', None, 'rodzaj żeński'), ('ùpôł', 'upał', None, 'rodzaj męski'), ('zëmno', 'zimno', None, 'rodzaj nijaki'), ('cepło', 'ciepło', None, 'rodzaj nijaki'), ('mróz', 'mróz', None, 'rodzaj męski'), ('grad', 'grad', None, 'rodzaj męski'), ('grzmòt', 'grzmot', None, 'rodzaj męski'), ('błëskawica', 'błyskawica', None, 'rodzaj żeński'), ('tãcza', 'tęcza', None, 'rodzaj żeński'), ('błoto', 'błoto', None, 'rodzaj nijaki'), ('piôsk', 'piasek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v09c', 'title': 'Przyroda i pogoda 3', 'icon': 'P', 'track': 'jezyk', 'words': [('dolëna', 'dolina', None, 'rodzaj żeński'), ('wzgórze', 'wzgórze', None, 'rodzaj nijaki'), ('jaskinia', 'jaskinia', None, 'rodzaj żeński'), ('zdrój', 'źródło', None, 'rodzaj męski'), ('bagno', 'bagno', None, 'rodzaj nijaki'), ('krzôk', 'krzak', None, 'rodzaj męski'), ('kòrzéń', 'korzeń', None, 'rodzaj męski'), ('gałąż', 'gałąź', None, 'rodzaj żeński'), ('falô', 'fala', None, 'rodzaj żeński'), ('rosa', 'rosa', None, 'rodzaj żeński'), ('pòwódz', 'powódź', None, 'rodzaj żeński'), ('ciemnòta', 'ciemność', None, 'rodzaj żeński'), ('swiatło', 'światło', None, 'rodzaj nijaki'), ('céń', 'cień', None, 'rodzaj męski'), ('pniak', 'pień', None, 'rodzaj męski'), ('kòra', 'kora', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v09d', 'title': 'Przyroda i pogoda 4', 'icon': 'P', 'track': 'jezyk', 'words': [('sceżka', 'ścieżka', None, 'rodzaj żeński'), ('pòwietrze', 'powietrze', None, 'rodzaj nijaki'), ('pògòda', 'pogoda', None, 'rodzaj żeński'), ('wichùra', 'wichura', None, 'rodzaj żeński'), ('kròpla', 'kropla', None, 'rodzaj żeński'), ('bòr', 'bór', None, 'rodzaj męski'), ('dąb', 'dąb', None, 'rodzaj męski'), ('brzoza', 'brzoza', None, 'rodzaj żeński'), ('sosna', 'sosna', None, 'rodzaj żeński'), ('jedla', 'jodła', None, 'rodzaj żeński'), ('wierzba', 'wierzba', None, 'rodzaj żeński'), ('bùk', 'buk', None, 'rodzaj męski'), ('òlcha', 'olcha', None, 'rodzaj żeński'), ('jabłón', 'jabłoń', None, 'rodzaj żeński'), ('różô', 'róża', None, 'rodzaj żeński'), ('lilia', 'lilia', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v09e', 'title': 'Przyroda i pogoda 5', 'icon': 'P', 'track': 'jezyk', 'words': [('mech', 'mech', None, 'rodzaj męski'), ('jałowc', 'jałowiec', None, 'rodzaj męski'), ('wrzos', 'wrzos', None, 'rodzaj męski'), ('bùrsztin', 'bursztyn', None, 'rodzaj męski'), ('wëdma', 'wydma', None, 'rodzaj żeński'), ('Bôłtik', 'morze (bałtyckie)', None, 'rodzaj męski'), ('zôtoka', 'zatoka', None, 'rodzaj żeński'), ('pòłwëspa', 'półwysep', None, 'rodzaj żeński'), ('klif', 'klif', None, 'rodzaj męski'), ('ùjscé', 'ujście', None, 'rodzaj nijaki'), ('pòłnocny wiatr', 'północny wiatr', None, 'rodzaj męski'), ('òdpłiw', 'odpływ', None, 'rodzaj męski'), ('przëpłiw', 'przypływ', None, 'rodzaj męski'), ('mòrskô falô', 'fala (morska)', None, 'rodzaj żeński'), ('mewa', 'mewa', None, 'rodzaj żeński'), ('mòrskô latarniô', 'latarnia morska', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v10a', 'title': 'Zwierzęta 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('kóń', 'koń', None, 'rodzaj męski'), ('klacz', 'klacz', None, 'rodzaj żeński'), ('bik', 'byk', None, 'rodzaj męski'), ('wół', 'wół', None, 'rodzaj męski'), ('swinia', 'świnia', None, 'rodzaj żeński'), ('barón', 'baran', None, 'rodzaj męski'), ('koza', 'koza', None, 'rodzaj żeński'), ('kùra', 'kura', None, 'rodzaj żeński'), ('kògùt', 'kogut', None, 'rodzaj męski'), ('ptôk', 'ptak', None, 'rodzaj męski'), ('mësz', 'mysz', None, 'rodzaj żeński'), ('wąż', 'wąż', None, 'rodzaj męski'), ('żaba', 'żaba', None, 'rodzaj żeński'), ('lew', 'lew', None, 'rodzaj męski'), ('niedzwiédz', 'niedźwiedź', None, 'rodzaj męski'), ('zajc', 'zając', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10b', 'title': 'Zwierzęta 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('jeleń', 'jeleń', None, 'rodzaj męski'), ('òsół', 'osioł', None, 'rodzaj męski'), ('wielbłąd', 'wielbłąd', None, 'rodzaj męski'), ('òrzeł', 'orzeł', None, 'rodzaj męski'), ('sowa', 'sowa', None, 'rodzaj żeński'), ('gołąb', 'gołąb', None, 'rodzaj męski'), ('wrona', 'wrona', None, 'rodzaj żeński'), ('kruk', 'kruk', None, 'rodzaj męski'), ('łabądz', 'łabędź', None, 'rodzaj męski'), ('gãs', 'gęś', None, 'rodzaj żeński'), ('słowik', 'słowik', None, 'rodzaj męski'), ('jaskółka', 'jaskółka', None, 'rodzaj żeński'), ('sokół', 'sokół', None, 'rodzaj męski'), ('dzik', 'dzik', None, 'rodzaj męski'), ('żółw', 'żółw', None, 'rodzaj męski'), ('ślimôk', 'ślimak', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10c', 'title': 'Zwierzęta 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('robôk', 'robak', None, 'rodzaj męski'), ('mrówka', 'mrówka', None, 'rodzaj żeński'), ('kòmar', 'komar', None, 'rodzaj męski'), ('òsa', 'osa', None, 'rodzaj żeński'), ('pszczoła', 'pszczoła', None, 'rodzaj żeński'), ('mùcha', 'mucha', None, 'rodzaj żeński'), ('pająk', 'pająk', None, 'rodzaj męski'), ('rak', 'rak', None, 'rodzaj męski'), ('stado', 'stado', None, 'rodzaj nijaki'), ('jagnã', 'jagnię', None, 'rodzaj nijaki'), ('cele', 'cielę', None, 'rodzaj nijaki'), ('gniôzdo', 'gniazdo', None, 'rodzaj nijaki'), ('kòpito', 'kopyto', None, 'rodzaj nijaki'), ('fùtro', 'futro', None, 'rodzaj nijaki'), ('klatka', 'klatka', None, 'rodzaj żeński'), ('ùl', 'ul', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10d', 'title': 'Zwierzęta 4', 'icon': 'Z', 'track': 'jezyk', 'words': [('łapa', 'łapa', None, 'rodzaj żeński'), ('kieł', 'kieł', None, 'rodzaj męski'), ('smòk', 'smok', None, 'rodzaj męski'), ('zwierzã', 'zwierzę', None, 'rodzaj nijaki'), ('bidło', 'bydło', None, 'rodzaj nijaki'), ('òwad', 'owad', None, 'rodzaj męski'), ('łosos', 'łosoś', None, 'rodzaj męski'), ('wãgórz', 'węgorz', None, 'rodzaj męski'), ('szczëpôk', 'szczupak', None, 'rodzaj męski'), ('wielorib', 'wieloryb', None, 'rodzaj męski'), ('fòka', 'foka', None, 'rodzaj żeński'), ('delfin', 'delfin', None, 'rodzaj męski'), ('tur', 'tur', None, 'rodzaj męski'), ('żóbr', 'żubr', None, 'rodzaj męski'), ('bóbr', 'bóbr', None, 'rodzaj męski'), ('wiewiórka', 'wiewiórka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v10e', 'title': 'Zwierzęta 5', 'icon': 'Z', 'track': 'jezyk', 'words': [('kùna', 'kuna', None, 'rodzaj żeński'), ('jastrzãb', 'jastrząb', None, 'rodzaj męski'), ('bòcón', 'bocian', None, 'rodzaj męski'), ('żuraw', 'żuraw', None, 'rodzaj męski'), ('kùkùłka', 'kukułka', None, 'rodzaj żeński'), ('dzãcioł', 'dzięcioł', None, 'rodzaj męski'), ('wróbel', 'wróbel', None, 'rodzaj męski'), ('szpak', 'szpak', None, 'rodzaj męski'), ('sledz', 'śledź', None, 'rodzaj męski'), ('dorsz', 'dorsz', None, 'rodzaj męski'), ('flądra', 'flądra', None, 'rodzaj żeński'), ('krewetka', 'krewetka', None, 'rodzaj żeński'), ('krab', 'krab', None, 'rodzaj męski'), ('medùza', 'meduza', None, 'rodzaj żeński'), ('kùropatwa', 'kuropatwa', None, 'rodzaj żeński'), ('bażant', 'bażant', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v10f', 'title': 'Zwierzęta 6', 'icon': 'Z', 'track': 'jezyk', 'words': [('indik', 'indyk', None, 'rodzaj męski'), ('ropucha', 'ropucha', None, 'rodzaj żeński'), ('jaszczurka', 'jaszczurka', None, 'rodzaj żeński'), ('nietoperz', 'nietoperz', None, 'rodzaj męski'), ('jeż', 'jeż', None, 'rodzaj męski'), ('kret', 'kret', None, 'rodzaj męski'), ('borsuk', 'borsuk', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11a', 'title': 'Miasto i budynki 1', 'icon': 'M', 'track': 'jezyk', 'words': [('miasto', 'miasto', None, 'rodzaj nijaki'), ('wies', 'wieś', None, 'rodzaj żeński'), ('ùlica', 'ulica', None, 'rodzaj żeński'), ('drogô', 'droga', None, 'rodzaj żeński'), ('plac', 'plac', None, 'rodzaj męski'), ('rinek', 'rynek', None, 'rodzaj męski'), ('mòst', 'most', None, 'rodzaj męski'), ('sklep', 'sklep', None, 'rodzaj męski'), ('targ', 'targ', None, 'rodzaj męski'), ('bank', 'bank', None, 'rodzaj męski'), ('pòcztã', 'poczta', None, 'rodzaj żeński'), ('szpitôl', 'szpital', None, 'rodzaj męski'), ('ùniwersytet', 'uniwersytet', None, 'rodzaj męski'), ('biblioteka', 'biblioteka', None, 'rodzaj żeński'), ('mùzeum', 'muzeum', None, 'rodzaj nijaki'), ('kòscół', 'kościół', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11b', 'title': 'Miasto i budynki 2', 'icon': 'M', 'track': 'jezyk', 'words': [('klasztór', 'klasztor', None, 'rodzaj męski'), ('restauracëjô', 'restauracja', None, 'rodzaj żeński'), ('karczma', 'karczma', None, 'rodzaj żeński'), ('pòrt', 'port', None, 'rodzaj męski'), ('dwòrzec', 'dworzec', None, 'rodzaj męski'), ('wieża', 'wieża', None, 'rodzaj żeński'), ('mur', 'mur', None, 'rodzaj męski'), ('òbòz', 'obóz', None, 'rodzaj męski'), ('więzeniô', 'więzienie', None, 'rodzaj nijaki'), ('grób', 'grób', None, 'rodzaj męski'), ('smãtôrz', 'cmentarz', None, 'rodzaj męski'), ('pòmnik', 'pomnik', None, 'rodzaj męski'), ('szkòła', 'szkoła', None, 'rodzaj żeński'), ('młin', 'młyn', None, 'rodzaj męski'), ('ùrząd', 'urząd', None, 'rodzaj męski'), ('ratusz', 'ratusz', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v11c', 'title': 'Miasto i budynki 3', 'icon': 'M', 'track': 'jezyk', 'words': [('òsada', 'osada', None, 'rodzaj żeński'), ('òłtôrz', 'ołtarz', None, 'rodzaj męski'), ('dzwònnica', 'dzwonnica', None, 'rodzaj żeński'), ('krzëż', 'krzyż', None, 'rodzaj męski'), ('kaplica', 'kaplica', None, 'rodzaj żeński'), ('dzelnica', 'dzielnica', None, 'rodzaj żeński'), ('przedmiescé', 'przedmieście', None, 'rodzaj nijaki'), ('fabrika', 'fabryka', None, 'rodzaj żeński'), ('stocznia', 'stocznia', None, 'rodzaj żeński'), ('stadiòn', 'stadion', None, 'rodzaj męski'), ('kinò', 'kino', None, 'rodzaj nijaki'), ('teatr', 'teatr', None, 'rodzaj męski'), ('apteka', 'apteka', None, 'rodzaj żeński'), ('hòtel', 'hotel', None, 'rodzaj męski'), ('pensjonat', 'pensjonat', None, 'rodzaj męski'), ('rëbackô wies', 'wieś rybacka', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v11d', 'title': 'Miasto i budynki 4', 'icon': 'M', 'track': 'jezyk', 'words': [('przistań', 'przystań', None, 'rodzaj żeński'), ('mòlo', 'molo', None, 'rodzaj nijaki'), ('szkółka', 'szkółka', None, 'rodzaj żeński'), ('dóm kùlturë', 'dom kultury', None, 'rodzaj męski'), ('stacëjô', 'stacja', None, 'rodzaj żeński'), ('lotnisko', 'lotnisko', None, 'rodzaj nijaki'), ('parking', 'parking', None, 'rodzaj męski'), ('skrzëżowanié', 'skrzyżowanie', None, 'rodzaj nijaki'), ('rondo', 'rondo', None, 'rodzaj nijaki'), ('chòdnik', 'chodnik', None, 'rodzaj męski'), ('ulëcznô latarniô', 'latarnia uliczna', None, 'rodzaj żeński'), ('adres', 'adres', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v12a', 'title': 'Podróż i transport 1', 'icon': 'P', 'track': 'jezyk', 'words': [('wóz', 'wóz', None, 'rodzaj męski'), ('aùtò', 'samochód', None, 'rodzaj nijaki'), ('autobùs', 'autobus', None, 'rodzaj męski'), ('pòciąg', 'pociąg', None, 'rodzaj męski'), ('tramwaj', 'tramwaj', None, 'rodzaj męski'), ('rower', 'rower', None, 'rodzaj męski'), ('mòtocykl', 'motocykl', None, 'rodzaj męski'), ('samolot', 'samolot', None, 'rodzaj męski'), ('stôtk', 'statek', None, 'rodzaj męski'), ('łódka', 'łódź', None, 'rodzaj żeński'), ('wiosło', 'wiosło', None, 'rodzaj nijaki'), ('żôgel', 'żagiel', None, 'rodzaj męski'), ('masta', 'maszt', None, 'rodzaj żeński'), ('ster', 'ster', None, 'rodzaj męski'), ('kòtwica', 'kotwica', None, 'rodzaj żeński'), ('pòdróż', 'podróż', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v12b', 'title': 'Podróż i transport 2', 'icon': 'P', 'track': 'jezyk', 'words': [('wëprawa', 'wyprawa', None, 'rodzaj żeński'), ('bród', 'brod', None, 'rodzaj męski'), ('granica', 'granica', None, 'rodzaj żeński'), ('kierowca', 'kierowca', None, 'rodzaj męski'), ('pasażer', 'pasażer', None, 'rodzaj męski'), ('bilet', 'bilet', None, 'rodzaj męski'), ('paszpòrt', 'paszport', None, 'rodzaj męski'), ('bagaż', 'bagaż', None, 'rodzaj męski'), ('walizka', 'walizka', None, 'rodzaj żeński'), ('mapa', 'mapa', None, 'rodzaj żeński'), ('lãd', 'ląd', None, 'rodzaj męski'), ('wëbrzeże', 'wybrzeże', None, 'rodzaj nijaki'), ('sztorm', 'sztorm', None, 'rodzaj męski'), ('flòta', 'flota', None, 'rodzaj żeński'), ('kapitón', 'kapitan', None, 'rodzaj męski'), ('marinôrz', 'marynarz', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v12c', 'title': 'Podróż i transport 3', 'icon': 'P', 'track': 'jezyk', 'words': [('sanie', 'sanie', None, 'rodzaj żeński'), ('sedło', 'siodło', None, 'rodzaj nijaki'), ('ùzda', 'uzda', None, 'rodzaj żeński'), ('jazda', 'jazda', None, 'rodzaj żeński'), ('przejazd', 'przejazd', None, 'rodzaj męski'), ('objazd', 'objazd', None, 'rodzaj męski'), ('benzina', 'benzyna', None, 'rodzaj żeński'), ('hamùlec', 'hamulec', None, 'rodzaj męski'), ('silnik', 'silnik', None, 'rodzaj męski'), ('kierownica', 'kierownica', None, 'rodzaj żeński'), ('prawò jazdë', 'prawo jazdy', None, 'rodzaj nijaki'), ('mandat', 'mandat', None, 'rodzaj męski'), ('wëpadk', 'wypadek', None, 'rodzaj męski'), ('kòrk', 'korek', None, 'rodzaj męski'), ('trasa', 'trasa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13a', 'title': 'Praca i szkoła 1', 'icon': 'P', 'track': 'jezyk', 'words': [('robòta', 'praca', None, 'rodzaj żeński'), ('zawód', 'zawód', None, 'rodzaj męski'), ('pieniądze', 'pieniądze', None, 'rodzaj męski'), ('pensjô', 'pensja', None, 'rodzaj żeński'), ('ùmòwa', 'umowa', None, 'rodzaj żeński'), ('lekcëjô', 'lekcja', None, 'rodzaj żeński'), ('egzamin', 'egzamin', None, 'rodzaj męski'), ('knąga', 'książka', None, 'rodzaj żeński'), ('zeszit', 'zeszyt', None, 'rodzaj męski'), ('piórkò', 'pióro', None, 'rodzaj nijaki'), ('òłówk', 'ołówek', None, 'rodzaj męski'), ('atrament', 'atrament', None, 'rodzaj męski'), ('papiér', 'papier', None, 'rodzaj męski'), ('słowôrz', 'słownik', None, 'rodzaj męski'), ('pëtanié', 'pytanie', None, 'rodzaj nijaki'), ('òdpòwiesc', 'odpowiedź', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13b', 'title': 'Praca i szkoła 2', 'icon': 'P', 'track': 'jezyk', 'words': [('zadanié', 'zadanie', None, 'rodzaj nijaki'), ('naùka', 'nauka', None, 'rodzaj żeński'), ('wiédza', 'wiedza', None, 'rodzaj żeński'), ('mądrosc', 'mądrość', None, 'rodzaj żeński'), ('rada', 'rada', None, 'rodzaj żeński'), ('pòlecenié', 'polecenie', None, 'rodzaj nijaki'), ('rozkôz', 'rozkaz', None, 'rodzaj męski'), ('ùstawa', 'ustawa', None, 'rodzaj żeński'), ('kara', 'kara', None, 'rodzaj żeński'), ('nagroda', 'nagroda', None, 'rodzaj żeński'), ('òbòwiązk', 'obowiązek', None, 'rodzaj męski'), ('nôrzãdzé', 'narzędzie', None, 'rodzaj nijaki'), ('młot', 'młot', None, 'rodzaj męski'), ('kòwadło', 'kowadło', None, 'rodzaj nijaki'), ('pług', 'pług', None, 'rodzaj męski'), ('sierp', 'sierp', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13c', 'title': 'Praca i szkoła 3', 'icon': 'P', 'track': 'jezyk', 'words': [('łopata', 'łopata', None, 'rodzaj żeński'), ('lëna', 'lina', None, 'rodzaj żeński'), ('łańcuch', 'łańcuch', None, 'rodzaj męski'), ('pismò', 'pismo', None, 'rodzaj nijaki'), ('lëtera', 'litera', None, 'rodzaj żeński'), ('słowò', 'słowo', None, 'rodzaj nijaki'), ('zdanié', 'zdanie', None, 'rodzaj nijaki'), ('gramatika', 'gramatyka', None, 'rodzaj żeński'), ('mòwa', 'mowa', None, 'rodzaj żeński'), ('mòdlëtwa', 'modlitwa', None, 'rodzaj żeński'), ('pòwiesc', 'pieśń', None, 'rodzaj żeński'), ('bôjka', 'bajka', None, 'rodzaj żeński'), ('historiô', 'historia', None, 'rodzaj żeński'), ('swiadk', 'świadek', None, 'rodzaj męski'), ('przësãga', 'przysięga', None, 'rodzaj żeński'), ('pòdatk', 'podatek', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13d', 'title': 'Praca i szkoła 4', 'icon': 'P', 'track': 'jezyk', 'words': [('cło', 'cło', None, 'rodzaj nijaki'), ('handel', 'handel', None, 'rodzaj męski'), ('dłëg', 'dług', None, 'rodzaj męski'), ('cena', 'cena', None, 'rodzaj żeński'), ('zësk', 'zysk', None, 'rodzaj męski'), ('strata', 'strata', None, 'rodzaj żeński'), ('bògactwò', 'bogactwo', None, 'rodzaj nijaki'), ('biéda', 'ubóstwo', None, 'rodzaj żeński'), ('darënk', 'dar', None, 'rodzaj męski'), ('wòjna', 'wojna', None, 'rodzaj żeński'), ('bitwa', 'bitwa', None, 'rodzaj żeński'), ('zwëcãstwò', 'zwycięstwo', None, 'rodzaj nijaki'), ('wòjsko', 'wojsko', None, 'rodzaj nijaki'), ('tarcza', 'tarcza', None, 'rodzaj żeński'), ('włóczniô', 'włócznia', None, 'rodzaj żeński'), ('miecz', 'miecz', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v13e', 'title': 'Praca i szkoła 5', 'icon': 'P', 'track': 'jezyk', 'words': [('łuk', 'łuk', None, 'rodzaj męski'), ('strzała', 'strzała', None, 'rodzaj żeński'), ('hełm', 'hełm', None, 'rodzaj męski'), ('fòrma', 'firma', None, 'rodzaj żeński'), ('szef', 'szef', None, 'rodzaj męski'), ('robòtnik', 'pracownik', None, 'rodzaj męski'), ('biùro', 'biuro', None, 'rodzaj nijaki'), ('zebranié', 'zebranie', None, 'rodzaj nijaki'), ('karierô', 'kariera', None, 'rodzaj żeński'), ('bezrobòcé', 'bezrobocie', None, 'rodzaj nijaki'), ('zasiłk', 'zasiłek', None, 'rodzaj męski'), ('emerëtura', 'emerytura', None, 'rodzaj żeński'), ('wënagrodzenié', 'wynagrodzenie', None, 'rodzaj nijaki'), ('ùrlop', 'urlop', None, 'rodzaj męski'), ('wakacje', 'wakacje', None, 'rodzaj żeński'), ('klasa', 'klasa', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v13f', 'title': 'Praca i szkoła 6', 'icon': 'P', 'track': 'jezyk', 'words': [('tablica', 'tablica', None, 'rodzaj żeński'), ('kreda', 'kreda', None, 'rodzaj żeński'), ('szkòlny plecôk', 'plecak szkolny', None, 'rodzaj męski'), ('ocena', 'ocena', None, 'rodzaj żeński'), ('swiadectwò', 'świadectwo', None, 'rodzaj nijaki'), ('stùdent', 'student', None, 'rodzaj męski'), ('profesór', 'profesor', None, 'rodzaj męski'), ('dërektór', 'dyrektor', None, 'rodzaj męski'), ('wëkład', 'wykład', None, 'rodzaj męski'), ('matura', 'matura', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v14a', 'title': 'Zdrowie 1', 'icon': 'Z', 'track': 'jezyk', 'words': [('zdrowié', 'zdrowie', None, 'rodzaj nijaki'), ('chòrota', 'choroba', None, 'rodzaj żeński'), ('ból', 'ból', None, 'rodzaj męski'), ('gòrączka', 'gorączka', None, 'rodzaj żeński'), ('kaszel', 'kaszel', None, 'rodzaj męski'), ('katar', 'katar', None, 'rodzaj męski'), ('lekarstwò', 'lekarstwo', None, 'rodzaj nijaki'), ('rana', 'rana', None, 'rodzaj żeński'), ('zdrowi', 'zdrowy', None, None), ('chòri', 'chory', None, None), ('zmãczony', 'zmęczony', None, None), ('spiący', 'śpiący', None, None), ('silny', 'silny', None, None), ('słabi', 'słaby', None, None), ('głuchi', 'głuchy', None, None), ('slepi', 'ślepy', None, None)], 'sentences': []}, {'id': 'v14b', 'title': 'Zdrowie 2', 'icon': 'Z', 'track': 'jezyk', 'words': [('kùlawi', 'kulawy', None, None), ('niemi', 'niemy', None, None), ('szalony', 'szalony', None, None), ('trëcëzna', 'trucizna', None, 'rodzaj żeński'), ('smierc', 'śmierć', None, 'rodzaj żeński'), ('trup', 'trup', None, 'rodzaj męski'), ('ùzdrowienié', 'uzdrowienie', None, 'rodzaj nijaki'), ('pòmòc', 'pomoc', None, 'rodzaj żeński'), ('zaraza', 'zaraza', None, 'rodzaj żeński'), ('blëzna', 'blizna', None, 'rodzaj żeński'), ('òdpòczink', 'odpoczynek', None, 'rodzaj męski'), ('dieta', 'dieta', None, 'rodzaj żeński'), ('masc', 'maść', None, 'rodzaj żeński'), ('kąpiel', 'kąpiel', None, 'rodzaj żeński'), ('leczenié', 'leczenie', None, 'rodzaj nijaki'), ('òddzel', 'szpital (oddział)', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v14c', 'title': 'Zdrowie 3', 'icon': 'Z', 'track': 'jezyk', 'words': [('pielãgniarka', 'pielęgniarka', None, 'rodzaj żeński'), ('tabletka', 'tabletka', None, 'rodzaj żeński'), ('zastrzik', 'zastrzyk', None, 'rodzaj męski'), ('termòmeter', 'termometr', None, 'rodzaj męski'), ('zãbòból', 'ząb (ból)', None, 'rodzaj męski'), ('grëpa', 'grypa', None, 'rodzaj żeński'), ('przezãbienié', 'przeziębienie', None, 'rodzaj nijaki'), ('alergiô', 'alergia', None, 'rodzaj żeński'), ('cukrzëca', 'cukrzyca', None, 'rodzaj żeński'), ('złamanié', 'złamanie', None, 'rodzaj nijaki'), ('òpatrunk', 'opatrunek', None, 'rodzaj męski'), ('òperacëjô', 'operacja', None, 'rodzaj żeński'), ('badanié', 'badanie', None, 'rodzaj nijaki'), ('wizita', 'wizyta', None, 'rodzaj żeński'), ('recepta', 'recepta', None, 'rodzaj żeński'), ('mdłòscë', 'mdłości', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v15a', 'title': 'Uczucia i charakter 1', 'icon': 'U', 'track': 'jezyk', 'words': [('rôdosc', 'radość', None, 'rodzaj żeński'), ('smùtk', 'smutek', None, 'rodzaj męski'), ('strach', 'strach', None, 'rodzaj męski'), ('gniew', 'gniew', None, 'rodzaj męski'), ('miłòsc', 'miłość', None, 'rodzaj żeński'), ('drëszba', 'przyjaźń', None, 'rodzaj żeński'), ('nienawiść', 'nienawiść', None, 'rodzaj żeński'), ('nadzeja', 'nadzieja', None, 'rodzaj żeński'), ('marzenié', 'marzenie', None, 'rodzaj nijaki'), ('szczescé', 'szczęście', None, 'rodzaj nijaki'), ('wstid', 'wstyd', None, 'rodzaj męski'), ('zdzëwienié', 'zdziwienie', None, 'rodzaj nijaki'), ('cekawòsc', 'ciekawość', None, 'rodzaj żeński'), ('cerpliwòsc', 'cierpliwość', None, 'rodzaj żeński'), ('szczirny', 'szczery', None, None), ('miłi', 'miły', None, None)], 'sentences': []}, {'id': 'v15b', 'title': 'Uczucia i charakter 2', 'icon': 'U', 'track': 'jezyk', 'words': [('grzeczny', 'grzeczny', None, None), ('głëpi', 'głupi', None, None), ('mądri', 'mądry', None, None), ('leniwi', 'leniwy', None, None), ('robòtny', 'pracowity', None, None), ('wesoły', 'wesoły', None, None), ('smùtny', 'smutny', None, None), ('zły', 'zły', None, None), ('szczescliwi', 'szczęśliwy', None, None), ('zakòchóny', 'zakochany', None, None), ('samòtny', 'samotny', None, None), ('spòkòjny', 'spokojny', None, None), ('dëmny', 'dumny', None, None), ('zazdrosny', 'zazdrosny', None, None), ('wdzãcznë', 'wdzięczny', None, None), ('òdważny', 'odważny', None, None)], 'sentences': []}, {'id': 'v15c', 'title': 'Uczucia i charakter 3', 'icon': 'U', 'track': 'jezyk', 'words': [('wiérny', 'wierny', None, None), ('skąpi', 'skąpy', None, None), ('hòjny', 'hojny', None, None), ('pòkòrny', 'pokorny', None, None), ('litòscywi', 'litościwy', None, None), ('òkrutny', 'okrutny', None, None), ('sprawiedlëwi', 'sprawiedliwy', None, None), ('ùczcëwi', 'uczciwy', None, None), ('pòbòżny', 'pobożny', None, None), ('szlachetny', 'szlachetny', None, None), ('litòsc', 'litość', None, 'rodzaj żeński'), ('żôl', 'żal', None, 'rodzaj męski'), ('tãsknota', 'tęsknota', None, 'rodzaj żeński'), ('zazdrosc', 'zazdrość', None, 'rodzaj żeński'), ('zemsta', 'zemsta', None, 'rodzaj żeński'), ('lós', 'los', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v15d', 'title': 'Uczucia i charakter 4', 'icon': 'U', 'track': 'jezyk', 'words': [('grzéch', 'grzech', None, 'rodzaj męski'), ('łaska', 'łaska', None, 'rodzaj żeński'), ('wiara', 'wiara', None, 'rodzaj żeński'), ('pòkòra', 'pokora', None, 'rodzaj żeński'), ('cnota', 'cnota', None, 'rodzaj żeński'), ('pëcha', 'pycha', None, 'rodzaj żeński'), ('prôwda', 'prawda', None, 'rodzaj żeński'), ('kłamstwò', 'kłamstwo', None, 'rodzaj nijaki'), ('wòlnota', 'wolność', None, 'rodzaj żeński'), ('niewòla', 'niewola', None, 'rodzaj żeński'), ('hònór', 'honor', None, 'rodzaj męski'), ('sława', 'sława', None, 'rodzaj żeński'), ('wòla', 'wola', None, 'rodzaj żeński'), ('rozëm', 'rozum', None, 'rodzaj męski'), ('pamiãc', 'pamięć', None, 'rodzaj żeński'), ('mësl', 'myśl', None, 'rodzaj żeński')], 'sentences': []}, {'id': 'v15e', 'title': 'Uczucia i charakter 5', 'icon': 'U', 'track': 'jezyk', 'words': [('sëmienié', 'sumienie', None, 'rodzaj nijaki'), ('złosc', 'złość', None, 'rodzaj żeński'), ('zdumienié', 'zdumienie', None, 'rodzaj nijaki'), ('tãsknic', 'tęsknić', None, None), ('wstidzëc sã', 'wstydzić się', None, None), ('ùsmiéch', 'uśmiech', None, 'rodzaj męski'), ('płacz', 'płacz', None, 'rodzaj męski'), ('smiéch', 'śmiech', None, 'rodzaj męski'), ('nuda', 'nuda', None, 'rodzaj żeński'), ('ùlga', 'ulga', None, 'rodzaj żeński'), ('niepòkòj', 'niepokój', None, 'rodzaj męski'), ('zadowòlenié', 'zadowolenie', None, 'rodzaj nijaki'), ('cekawi', 'ciekawy', None, None)], 'sentences': []}, {'id': 'v16a', 'title': 'Przymiotniki 1', 'icon': 'P', 'track': 'jezyk', 'words': [('wiôlgi', 'duży', None, None), ('dłudżi', 'długi', None, None), ('krótczi', 'krótki', None, None), ('wësoczi', 'wysoki', None, None), ('niskò', 'niski', None, None), ('szeroczi', 'szeroki', None, None), ('wąsczi', 'wąski', None, None), ('grëbi', 'gruby', None, None), ('chùdi', 'chudy', None, None), ('cężczi', 'ciężki', None, None), ('lekczi', 'lekki', None, None), ('szëbczi', 'szybki', None, None), ('twardi', 'twardy', None, None), ('miãkczi', 'miękki', None, None), ('mokri', 'mokry', None, None), ('suchi', 'suchy', None, None)], 'sentences': []}, {'id': 'v16b', 'title': 'Przymiotniki 2', 'icon': 'P', 'track': 'jezyk', 'words': [('czësti', 'czysty', None, None), ('brudny', 'brudny', None, None), ('pełny', 'pełny', None, None), ('pùsti', 'pusty', None, None), ('głosny', 'głośny', None, None), ('cichi', 'cichy', None, None), ('nowi', 'nowy', None, None), ('ładny', 'ładny', None, None), ('brzëdczi', 'brzydki', None, None), ('łatwi', 'łatwy', None, None), ('trudny', 'trudny', None, None), ('wôżny', 'ważny', None, None), ('mòżlëwi', 'możliwy', None, None), ('prawdzëwi', 'prawdziwy', None, None), ('fałszëwi', 'fałszywy', None, None), ('własny', 'własny', None, None)], 'sentences': []}, {'id': 'v16c', 'title': 'Przymiotniki 3', 'icon': 'P', 'track': 'jezyk', 'words': [('pòtãżny', 'potężny', None, None), ('słôwny', 'sławny', None, None), ('blëski', 'bliski', None, None), ('dalekò', 'daleki', None, None), ('pewny', 'pewny', None, None), ('gotowi', 'gotowy', None, None), ('pòdobny', 'podobny', None, None), ('jiny', 'inny', None, None), ('kòżdi', 'każdy', None, None), ('głãbòczi', 'głęboki', None, None), ('płëtczi', 'płytki', None, None), ('słodczi', 'słodki', None, None), ('gòrzczi', 'gorzki', None, None), ('kwasny', 'kwaśny', None, None), ('słony', 'słony', None, None), ('gòrący', 'gorący', None, None)], 'sentences': []}, {'id': 'v16d', 'title': 'Przymiotniki 4', 'icon': 'P', 'track': 'jezyk', 'words': [('zëmny', 'zimny', None, None), ('cepłi', 'ciepły', None, None), ('piãkny', 'piękny', None, None), ('rzadczi', 'rzadki', None, None), ('bògati', 'bogaty', None, None), ('ùbogi', 'ubogi', None, None), ('bezpieczny', 'bezpieczny', None, None), ('niebezpieczny', 'niebezpieczny', None, None), ('spòlny', 'wspólny', None, None), ('òsobny', 'osobny', None, None), ('òstatny', 'ostatni', None, None), ('nôstãpny', 'następny', None, None), ('dôwny', 'dawny', None, None), ('wiecznë', 'wieczny', None, None), ('smiertelny', 'śmiertelny', None, None), ('bòsczi', 'boski', None, None)], 'sentences': []}, {'id': 'v16e', 'title': 'Przymiotniki 5', 'icon': 'P', 'track': 'jezyk', 'words': [('ludzczi', 'ludzki', None, None), ('pòlsczi', 'polski', None, None), ('kaszëbsczi', 'kaszubski', None, None), ('niemiecczi', 'niemiecki', None, None), ('zemsczi', 'ziemski', None, None), ('jedyny', 'jedyny', None, None), ('òczewiscy', 'oczywisty', None, None), ('skrómny', 'skromny', None, None), ('pilny', 'pilny', None, None), ('drodżi', 'drogi', None, None), ('tani', 'tani', None, None), ('wesoło', 'wesoło', None, None), ('mòcny', 'mocny', None, None), ('cenczi', 'cienki', None, None), ('zdolny', 'zdolny', None, None), ('cekawsczi', 'ciekawski', None, None)], 'sentences': []}, {'id': 'v16f', 'title': 'Przymiotniki 6', 'icon': 'P', 'track': 'jezyk', 'words': [('sprëtny', 'sprytny', None, None), ('nudny', 'nudny', None, None), ('brzëdkò', 'brzydko', None, None), ('ładno', 'ładnie', None, None), ('sóm', 'sam', None, None)], 'sentences': []}, {'id': 'v17a', 'title': 'Czasowniki podstawowe 1', 'icon': 'C', 'track': 'jezyk', 'words': [('miec', 'mieć', None, None), ('robic', 'robić', None, None), ('jic', 'iść', None, None), ('jechac', 'jechać', None, None), ('przińc', 'przyjść', None, None), ('wińc', 'wyjść', None, None), ('wrócëc', 'wrócić', None, None), ('biec', 'biec', None, None), ('stac', 'stać', None, None), ('sedzec', 'siedzieć', None, None), ('leżec', 'leżeć', None, None), ('spac', 'spać', None, None), ('wstac', 'wstać', None, None), ('jesc', 'jeść', None, None), ('pic', 'pić', None, None), ('gotowac', 'gotować', None, None)], 'sentences': []}, {'id': 'v17b', 'title': 'Czasowniki podstawowe 2', 'icon': 'C', 'track': 'jezyk', 'words': [('mëc', 'myć', None, None), ('gadac', 'mówić', None, None), ('pòwiedzec', 'powiedzieć', None, None), ('pëtac', 'pytać', None, None), ('òdpòwiôdac', 'odpowiadać', None, None), ('słëszec', 'słyszeć', None, None), ('widzec', 'widzieć', None, None), ('patrzec', 'patrzeć', None, None), ('czëtac', 'czytać', None, None), ('pisac', 'pisać', None, None), ('ùczëc sã', 'uczyć się', None, None), ('rozmiec', 'rozumieć', None, None), ('wiedzec', 'wiedzieć', None, None), ('znac', 'znać', None, None), ('mëslec', 'myśleć', None, None), ('pamiãtac', 'pamiętać', None, None)], 'sentences': []}, {'id': 'v17c', 'title': 'Czasowniki podstawowe 3', 'icon': 'C', 'track': 'jezyk', 'words': [('zapòmòc', 'zapominać', None, None), ('chcec', 'chcieć', None, None), ('lëbic', 'lubić', None, None), ('kòchac', 'kochać', None, None), ('pòtrzebòwac', 'potrzebować', None, None), ('mòc', 'móc', None, None), ('mùsec', 'musieć', None, None), ('dawac', 'dawać', None, None), ('brac', 'brać', None, None), ('kùpòwac', 'kupować', None, None), ('sprzedawac', 'sprzedawać', None, None), ('płacëc', 'płacić', None, None), ('òtwiérac', 'otwierać', None, None), ('zamëkac', 'zamykać', None, None), ('zaczinac', 'zaczynać', None, None), ('kùńczëc', 'kończyć', None, None)], 'sentences': []}, {'id': 'v17d', 'title': 'Czasowniki podstawowe 4', 'icon': 'C', 'track': 'jezyk', 'words': [('grac', 'grać', None, None), ('spiewac', 'śpiewać', None, None), ('tuńczëc', 'tańczyć', None, None), ('płëwac', 'pływać', None, None), ('latac', 'latać', None, None), ('klasc', 'kłaść', None, None), ('szëkac', 'szukać', None, None), ('znajdowac', 'znajdować', None, None), ('czekac', 'czekać', None, None), ('pòmagac', 'pomagać', None, None), ('prosëc', 'prosić', None, None), ('przeprôszac', 'przepraszać', None, None), ('pòzwòlëc', 'pozwalać', None, None), ('próbòwac', 'próbować', None, None), ('zmieniac', 'zmieniać', None, None), ('nosëc', 'nosić', None, None)], 'sentences': []}, {'id': 'v17e', 'title': 'Czasowniki podstawowe 5', 'icon': 'C', 'track': 'jezyk', 'words': [('trzimac', 'trzymać', None, None), ('rzucac', 'rzucać', None, None), ('łapac', 'łapać', None, None), ('bic', 'bić', None, None), ('zabijac', 'zabijać', None, None), ('umiérac', 'umierać', None, None), ('żëc', 'żyć', None, None), ('mieszkac', 'mieszkać', None, None), ('spòtkac', 'spotykać', None, None), ('wësłac', 'wysyłać', None, None), ('dostawac', 'dostawać', None, None), ('pòkazywac', 'pokazywać', None, None), ('zaprôszac', 'zapraszać', None, None), ('òdwiedzac', 'odwiedzać', None, None), ('płakac', 'płakać', None, None), ('smiac sã', 'śmiać się', None, None)], 'sentences': []}, {'id': 'v17f', 'title': 'Czasowniki podstawowe 6', 'icon': 'C', 'track': 'jezyk', 'words': [('bòjec sã', 'bać się', None, None), ('cëszëc sã', 'cieszyć się', None, None), ('wierzëc', 'wierzyć', None, None), ('zgôdzac sã', 'zgadzać się', None, None), ('wëbiérac', 'wybierać', None, None), ('decydowac', 'decydować', None, None), ('liczëc', 'liczyć', None, None), ('rządzëc', 'rządzić', None, None), ('prowadzëc', 'prowadzić', None, None), ('pòddac sã', 'poddać się', None, None), ('zwëcãżac', 'zwyciężać', None, None), ('wòjowac', 'walczyć', None, None), ('brónic', 'bronić', None, None), ('atakòwac', 'atakować', None, None), ('niszczëc', 'niszczyć', None, None), ('budowac', 'budować', None, None)], 'sentences': []}, {'id': 'v17g', 'title': 'Czasowniki podstawowe 7', 'icon': 'C', 'track': 'jezyk', 'words': [('burzëc', 'burzyć', None, None), ('palëc', 'palić', None, None), ('gasëc', 'gasić', None, None), ('pòżądac', 'pragnąć', None, None), ('żałowac', 'żałować', None, None), ('ratowac', 'ratować', None, None), ('wëzwòlëc', 'wyzwalać', None, None), ('czcëc', 'czcić', None, None), ('mòdlëc sã', 'modlić się', None, None), ('przësãgac', 'przysięgać', None, None), ('òbiecywac', 'obiecywać', None, None), ('kłamac', 'kłamać', None, None), ('òskarżac', 'oskarżać', None, None), ('sądzëc', 'sądzić', None, None), ('karac', 'karać', None, None), ('dzãkòwac', 'dziękować', None, None)], 'sentences': []}, {'id': 'v17h', 'title': 'Czasowniki podstawowe 8', 'icon': 'C', 'track': 'jezyk', 'words': [('pòzdrôwiac', 'pozdrawiać', None, None), ('błògòsławic', 'błogosławić', None, None), ('chrzcëc', 'chrzcić', None, None), ('grzeszëc', 'grzeszyć', None, None), ('zbawiac', 'zbawiać', None, None), ('stwòrzëc', 'stworzyć', None, None), ('urodzëc sã', 'narodzić się', None, None), ('wskrzesëc', 'wskrzesić', None, None), ('błagac', 'błagać', None, None), ('dzëwòwac sã', 'dziwić się', None, None), ('wątpic', 'wątpić', None, None), ('sniic', 'śnić', None, None), ('zazdroscëc', 'zazdrościć', None, None), ('mylëc sã', 'mylić się', None, None)], 'sentences': []}, {'id': 'v18a', 'title': 'Czasowniki dnia codziennego 1', 'icon': 'C', 'track': 'jezyk', 'words': [('jeżdżëc', 'jeździć', None, None), ('wsiadac', 'wsiadać', None, None), ('wësiadac', 'wysiadać', None, None), ('skrãcac', 'skręcać', None, None), ('zatrzimòwac sã', 'zatrzymywać się', None, None), ('spòzniac sã', 'spóźniać się', None, None), ('spieszëc sã', 'spieszyć się', None, None), ('òdpòczëwac', 'odpoczywać', None, None), ('bawic sã', 'bawić się', None, None), ('naprawiac', 'naprawiać', None, None), ('ciąc', 'ciąć', None, None), ('smażëc', 'smażyć', None, None), ('mieszac', 'mieszać', None, None), ('nalewac', 'nalewać', None, None), ('sprzątac', 'sprzątać', None, None), ('prac', 'prać', None, None)], 'sentences': []}, {'id': 'v18b', 'title': 'Czasowniki dnia codziennego 2', 'icon': 'C', 'track': 'jezyk', 'words': [('golëc sã', 'golić się', None, None), ('czesac', 'czesać', None, None), ('kąpac sã', 'kąpać się', None, None), ('budzëc sã', 'budzić się', None, None), ('zasëpiac', 'zasypiać', None, None), ('ćwiczëc', 'ćwiczyć', None, None), ('ruszac', 'ruszać', None, None), ('ciągnąc', 'ciągnąć', None, None), ('pchac', 'pchać', None, None), ('pòdnosëc', 'podnosić', None, None), ('spadac', 'spadać', None, None), ('skòczëc', 'skakać', None, None), ('wspinac sã', 'wspinać się', None, None), ('ùkriwac', 'ukrywać', None, None), ('krasc', 'kraść', None, None), ('òddawac', 'oddawać', None, None)], 'sentences': []}, {'id': 'v18c', 'title': 'Czasowniki dnia codziennego 3', 'icon': 'C', 'track': 'jezyk', 'words': [('pòżëczac', 'pożyczać', None, None), ('wëdawac', 'wydawać', None, None), ('òszczãdzac', 'oszczędzać', None, None), ('òrac', 'orać', None, None), ('siac', 'siać', None, None), ('żąc', 'żąć', None, None), ('zbierac', 'zbierać', None, None), ('sadzëc', 'sadzić', None, None), ('pòdlewac', 'podlewać', None, None), ('pasc', 'paść', None, None), ('dojic', 'doić', None, None), ('strzëc', 'strzyc', None, None), ('tkac', 'tkać', None, None), ('prząsc', 'prząść', None, None), ('szëc', 'szyć', None, None), ('mlec', 'mleć', None, None)], 'sentences': []}, {'id': 'v18d', 'title': 'Czasowniki dnia codziennego 4', 'icon': 'C', 'track': 'jezyk', 'words': [('rzezbic', 'rzeźbić', None, None), ('malowac', 'malować', None, None), ('kùc', 'kuć', None, None), ('topic', 'topić', None, None), ('kòpac', 'kopać', None, None), ('wiązac', 'wiązać', None, None), ('rozwiązywac', 'rozwiązywać', None, None), ('òdmëkac', 'odmykać', None, None), ('siadac', 'siadać', None, None), ('krzëczec', 'krzyczeć', None, None), ('mlëczec', 'milczeć', None, None), ('szeptac', 'szeptać', None, None), ('wòłac', 'wołać', None, None), ('żegnac', 'żegnać', None, None), ('witac', 'witać', None, None), ('nazëwac', 'nazywać', None, None)], 'sentences': []}, {'id': 'v18e', 'title': 'Czasowniki dnia codziennego 5', 'icon': 'C', 'track': 'jezyk', 'words': [('òpòwiôdac', 'opowiadać', None, None), ('òpisëwac', 'opisywać', None, None), ('tłomaczëc', 'tłumaczyć', None, None), ('chwalëc', 'chwalić', None, None), ('ganic', 'ganić', None, None), ('wëbaczac', 'wybaczać', None, None), ('rozkazywac', 'rozkazywać', None, None), ('zabrôniac', 'zabraniać', None, None), ('dowòdzëc', 'dowodzić', None, None), ('żeglowac', 'żeglować', None, None), ('wiosłowac', 'wiosłować', None, None), ('brac ùdzel', 'brać udział', None, None), ('przëbëwac', 'przybywać', None, None), ('òdchòdzëc', 'odchodzić', None, None), ('wracac', 'wracać', None, None), ('ùkazywac sã', 'ukazywać się', None, None)], 'sentences': []}, {'id': 'v18f', 'title': 'Czasowniki dnia codziennego 6', 'icon': 'C', 'track': 'jezyk', 'words': [('ìstniec', 'istnieć', None, None), ('stawac sã', 'stawać się', None, None), ('wëdarzac sã', 'wydarzać się', None, None), ('wëdawac sã', 'wydawać się', None, None), ('zòstawac', 'pozostawać', None, None), ('pòrzucac', 'porzucać', None, None), ('słëchac', 'słuchać', None, None), ('dotikac', 'dotykać', None, None), ('czuc', 'czuć', None, None), ('wąchac', 'wąchać', None, None), ('smakòwac', 'smakować', None, None), ('mãczëc sã', 'męczyć się', None, None), ('cerpiec', 'cierpieć', None, None), ('rosc', 'rosnąć', None, None), ('rodzëc', 'rodzić', None, None), ('karmic', 'karmić', None, None)], 'sentences': []}, {'id': 'v18g', 'title': 'Czasowniki dnia codziennego 7', 'icon': 'C', 'track': 'jezyk', 'words': [('wëchòwiwac', 'wychowywać', None, None), ('wiercëc', 'wiercić', None, None), ('kréncëc', 'kręcić', None, None), ('drapac', 'drapać', None, None), ('gridz', 'gryźć', None, None), ('kòpnąc', 'kopnąć', None, None), ('ciosac', 'ciosać', None, None), ('strùgac', 'strugać', None, None), ('wbijac', 'wbijać', None, None), ('wkrãcac', 'wkręcać', None, None), ('dzwigac', 'dźwigać', None, None), ('ładowac', 'ładować', None, None)], 'sentences': []}, {'id': 'v19a', 'title': 'Słowa funkcyjne 1', 'icon': 'S', 'track': 'jezyk', 'words': [('tën', 'ten', None, None), ('tamten', 'tamten', None, None), ('tuwò', 'tutaj', None, None), ('tam', 'tam', None, None), ('stądë', 'stąd', None, None), ('gdze', 'gdzie', None, None), ('jak', 'jak', None, None), ('czemù', 'dlaczego', None, None), ('chtëri', 'który', None, None), ('ale', 'ale', None, None), ('abò', 'lub', None, None), ('bò', 'bo', None, None), ('eżlë', 'jeśli', None, None), ('że', 'że', None, None), ('tej', 'więc', None, None), ('téż', 'też', None, None)], 'sentences': []}, {'id': 'v19b', 'title': 'Słowa funkcyjne 2', 'icon': 'S', 'track': 'jezyk', 'words': [('le', 'tylko', None, None), ('trochã', 'trochę', None, None), ('nick', 'nic', None, None), ('cos', 'coś', None, None), ('ktos', 'ktoś', None, None), ('nikt', 'nikt', None, None), ('mòże', 'może', None, None), ('na pewno', 'na pewno', None, None), ('bez', 'bez', None, None), ('na', 'na', None, None), ('do', 'do', None, None), ('òd', 'od', None, None), ('dlô', 'dla', None, None), ('przez', 'przez', None, None), ('przed', 'przed', None, None), ('za', 'za', None, None)], 'sentences': []}, {'id': 'v19c', 'title': 'Słowa funkcyjne 3', 'icon': 'S', 'track': 'jezyk', 'words': [('nad', 'nad', None, None), ('pòd', 'pod', None, None), ('òbòk', 'obok', None, None), ('midzë', 'między', None, None), ('przeciw', 'przeciw', None, None), ('ò', 'o', None, None), ('ù', 'u', None, None), ('òkòło', 'około', None, None), ('prawie', 'prawie', None, None), ('nawetk', 'nawet', None, None), ('gdzes', 'gdzieś', None, None), ('nigde', 'nigdzie', None, None), ('wszãdze', 'wszędzie', None, None), ('barz', 'bardzo', None, None), ('tak', 'tak', None, None), ('czë', 'czy', None, None)], 'sentences': []}, {'id': 'v19d', 'title': 'Słowa funkcyjne 4', 'icon': 'S', 'track': 'jezyk', 'words': [('jednak', 'jednak', None, None), ('chòc', 'chociaż', None, None), ('gdë', 'gdy', None, None), ('dopòkù', 'dopóki', None, None), ('zanim', 'zanim', None, None), ('ani', 'ani', None, None), ('jak i', 'zarówno', None, None), ('a', 'a', None, None), ('i', 'i', None, None), ('òto', 'oto', None, None), ('òno', 'ono', None, None), ('wë', 'wy', None, None), ('mie', 'mnie', None, None), ('cebie', 'ciebie', None, None), ('jegò', 'jego', None, None), ('nas', 'nas', None, None)], 'sentences': []}, {'id': 'v19e', 'title': 'Słowa funkcyjne 5', 'icon': 'S', 'track': 'jezyk', 'words': [('was', 'was', None, None), ('jich', 'ich', None, None), ('sebie', 'siebie', None, None), ('twój', 'twój', None, None), ('wasz', 'wasz', None, None), ('swój', 'swój', None, None), ('czyj', 'czyj', None, None), ('wszelczi', 'wszelki', None, None), ('kilkakrotno', 'kilkakrotnie', None, None), ('niestetë', 'niestety', None, None), ('prosã', 'proszę', None, None), ('dzãkùjã', 'dziękuję', None, None), ('przeprôszóm', 'przepraszam', None, None), ('dobri dzéń', 'dzień dobry', None, None), ('dobrô nocë', 'dobranoc', None, None), ('do vidzeniô', 'do widzenia', None, None)], 'sentences': []}, {'id': 'v19f', 'title': 'Słowa funkcyjne 6', 'icon': 'S', 'track': 'jezyk', 'words': [('witôj', 'cześć', None, None), ('tak je', 'tak jest', None, None), ('nié ma', 'nie ma', None, None), ('bëło', 'było', None, None), ('bãdze', 'będzie', None, None)], 'sentences': []}, {'id': 'v20a', 'title': 'Kaszuby i ich świat 1', 'icon': 'K', 'track': 'jezyk', 'words': [('Kaszëbë', 'Kaszuby', None, 'rodzaj żeński'), ('Kaszëba', 'Kaszub', None, 'rodzaj męski'), ('Kaszëbka', 'Kaszubka', None, 'rodzaj żeński'), ('kaszëbizna', 'kaszubszczyzna', None, 'rodzaj żeński'), ('Gduńsk', 'Gdańsk', None, 'rodzaj męski'), ('Gdiniô', 'Gdynia', None, 'rodzaj żeński'), ('Kartuzë', 'Kartuzy', None, 'rodzaj żeński'), ('Kòscérzna', 'Kościerzyna', None, 'rodzaj żeński'), ('Wejrowò', 'Wejherowo', None, 'rodzaj nijaki'), ('Pùck', 'Puck', None, 'rodzaj męski'), ('Hél', 'Hel', None, 'rodzaj męski'), ('Chònice', 'Chojnice', None, 'rodzaj żeński'), ('Bëtowò', 'Bytów', None, 'rodzaj nijaki'), ('Lãbòrk', 'Lębork', None, 'rodzaj męski'), ('Słëpsk', 'Słupsk', None, 'rodzaj męski'), ('Pòmòrze', 'Pomorze', None, 'rodzaj nijaki')], 'sentences': []}, {'id': 'v20b', 'title': 'Kaszuby i ich świat 2', 'icon': 'K', 'track': 'jezyk', 'words': [('Wisła', 'Wisła', None, 'rodzaj żeński'), ('Kaszëbskô Szwajcariô', 'Szwajcaria Kaszubska', None, 'rodzaj żeński'), ('Wieżëca', 'Wieżyca', None, 'rodzaj żeński'), ('Pùckô Zôtoka', 'Zatoka Pucka', None, 'rodzaj żeński'), ('Helskô Półwëspa', 'Półwysep Helski', None, 'rodzaj żeński'), ('Jastarniô', 'Jastarnia', None, 'rodzaj żeński'), ('Kaszëbi', 'Kaszubi', None, 'rodzaj męski'), ('haft', 'haft', None, 'rodzaj męski'), ('kaszëbsczi haft', 'haft kaszubski', None, 'rodzaj męski'), ('ceramika', 'ceramika', None, 'rodzaj żeński'), ('gbùr', 'gbur', None, 'rodzaj męski'), ('kaszëbsczé', 'kaszubskie', None, None), ('Remùs', 'Remus', None, 'rodzaj męski'), ('Remùsowô', 'Remusowa', None, 'rodzaj żeński'), ('Żëcé i przigòdë Remùsa', 'Żëcé i przigòdë Remusa', None, 'rodzaj nijaki'), ('Jón Trepczik', 'Jan Trepczyk', None, 'rodzaj męski')], 'sentences': []}, {'id': 'v20c', 'title': 'Kaszuby i ich świat 3', 'icon': 'K', 'track': 'jezyk', 'words': [('Hieronim Derdowsczi', 'Hieronim Derdowski', None, 'rodzaj męski'), ('Aleksander Majkòwsczi', 'Aleksander Majkowski', None, 'rodzaj męski'), ('Florian Cenôwa', 'Florian Ceynowa', None, 'rodzaj męski'), ('Kaszëbskô Jednota', 'Kaszëbskô Jednota', None, 'rodzaj żeński'), ('Zrzeszenié Kaszëbskò-Pòmòrsczé', 'Zrzeszenie Kaszubsko-Pomorskie', None, 'rodzaj nijaki'), ('Dzéń Jednotë', 'Dzéń Jednotë', None, 'rodzaj męski'), ('kaszëbskô gôdka', 'kaszëbsczi gôdkù', None, 'rodzaj żeński'), ('gôdac pò kaszëbskù', 'gôdac pò kaszëbskù', None, None), ('kaszëbsczi jãzëk', 'kaszëbsczi jãzëk', None, 'rodzaj męski'), ('stolem', 'stolem', None, 'rodzaj męski'), ('Stolem', 'Stolem', None, 'rodzaj męski'), ('remùs', 'remus', None, None), ('zakôrmic', 'zôkôrmić', None, None), ('ùrzãdnik', 'ùrzãdnik', None, 'rodzaj męski')], 'sentences': []}]
# === /SŁOWNICTWO ===

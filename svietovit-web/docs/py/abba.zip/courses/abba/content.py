"""Treść kursu: aramejski biblijny i aramejski czasów Jezusa, dla Polaków, pismem syryjskim.

Słowo:     (forma pismem syryjskim bez samogłosek, transkrypcja, znaczenie, polskie skojarzenie, uwaga)
Litera:    (litera, transkrypcja, opis po polsku, nazwa)
Zdanie:    (lista słów w kolejności czytania, od prawej, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź, wyjaśnienie, dział)
           przed/temat/końcówka/po są w kolejności czytania (logicznej); aplikacja sama
           odwraca je do wyświetlenia od prawej do lewej.

Pismo syryjskie łączy litery. Kivy tego nie umie, więc tools/shape_syriac.py składa każde
słowo z góry (HarfBuzz) i zapisuje gotowe kształty w fonts/Syr.ttf i syriac_shapes.json.
Po zmianie treści uruchom: python tools/shape_syriac.py
"""

UNITS = [
    # --------------------------------------------------------------- alfabet
    {
        "id": "alef1", "title": "Alfabet I", "icon": "ܐ", "track": "pismo",
        "letters": [
            ("ܐ", "ʾ", "[ʔ] albo niema; na końcu słowa często -ā", "ʾālap"),
            ("ܒ", "b", "[b], po samogłosce [v]", "bēt"), ("ܓ", "g", "[ɡ], po samogłosce [ɣ]", "gāmal"),
            ("ܕ", "d", "[d], po samogłosce [ð]; kropka pod spodem", "dālat"),
            ("ܗ", "h", "[h]", "hē"), ("ܘ", "w", "[w]; też samogłoska [o] lub [u]", "waw"),
            ("ܙ", "z", "[z]", "zayn"), ("ܚ", "ḥ", "[ħ] (gardłowe ch)", "ḥēt"), ("ܛ", "ṭ", "[tˤ] („ciężkie” t)", "ṭēt"),
            ("ܝ", "j", "[j]; też samogłoska [i] lub [e]", "yod"), ("ܟ", "k", "[k], po samogłosce [x]", "kāp"),
        ],
    },
    {
        "id": "alef2", "title": "Alfabet II", "icon": "ܬ", "track": "pismo",
        "letters": [
            ("ܠ", "l", "[l]", "lāmad"), ("ܡ", "m", "[m]", "mīm"), ("ܢ", "n", "[n]", "nūn"),
            ("ܣ", "s", "[s]", "semkat"), ("ܥ", "ʿ", "[ʕ] (gardłowy dźwięk)", "ʿē"),
            ("ܦ", "p", "[p], po samogłosce [f]", "pē"), ("ܨ", "ṣ", "[sˤ] („ciężkie” s)", "ṣādē"),
            ("ܩ", "q", "[q] (głębokie k)", "qop"), ("ܪ", "r", "[r]; kropka nad literą (pod spodem byłoby d!)", "rēš"),
            ("ܫ", "š", "[ʃ] (sz)", "šīn"), ("ܬ", "t", "[t], po samogłosce [θ]", "taw"),
        ],
    },
    {
        "id": "alef3", "title": "Łączenie liter", "icon": "ܕ", "track": "pismo",
        "letters": [
            ("ܐ ", "ʾ", "ʾālap nie łączy się z następną literą", "ʾālap"),
            ("ܕ ", "d", "dālat nie łączy się z następną", "dālat"),
            ("ܗ ", "h", "hē nie łączy się z następną", "hē"),
            ("ܘ ", "w", "waw nie łączy się z następną", "waw"),
            ("ܙ ", "z", "zayn nie łączy się z następną", "zayn"),
            ("ܨ ", "ṣ", "ṣādē nie łączy się z następną", "ṣādē"),
            ("ܪ ", "r", "rēš nie łączy się z następną", "rēš"),
            ("ܬ ", "t", "taw nie łączy się z następną", "taw"),
        ],
    },
    {
        "id": 'alef4', "title": 'Samogłoski I: ܒ i ܡ', "icon": 'ܒܰ', "track": "pismo",
        "letters": [
            ('ܒܰ', 'ba', '[ba]: pthaha: znak nad literą = a', 'pthaha'),
            ('ܒܳ', 'bo', '[bo]: zqapha: znak nad literą = o', 'zqapha'),
            ('ܒܶ', 'be', '[be]: rbasa: znak nad literą = e', 'rbasa'),
            ('ܒܻ', 'bi', '[bi]: hbasa: znak pod literą = i', 'hbasa'),
            ('ܒܾ', 'bu', '[bu]: esasa: znak pod literą = u', 'esasa'),
            ('ܡܰ', 'ma', '[ma]: pthaha: znak nad literą = a', 'pthaha'),
            ('ܡܳ', 'mo', '[mo]: zqapha: znak nad literą = o', 'zqapha'),
            ('ܡܶ', 'me', '[me]: rbasa: znak nad literą = e', 'rbasa'),
            ('ܡܻ', 'mi', '[mi]: hbasa: znak pod literą = i', 'hbasa'),
            ('ܡܾ', 'mu', '[mu]: esasa: znak pod literą = u', 'esasa'),
        ],
    },
    {
        "id": 'alef5', "title": 'Samogłoski II: ܠ ܣ ܫ', "icon": 'ܠܳ', "track": "pismo",
        "letters": [
            ('ܠܰ', 'la', '[la]: pthaha: znak nad literą = a', 'pthaha'),
            ('ܠܳ', 'lo', '[lo]: zqapha: znak nad literą = o', 'zqapha'),
            ('ܠܶ', 'le', '[le]: rbasa: znak nad literą = e', 'rbasa'),
            ('ܠܻ', 'li', '[li]: hbasa: znak pod literą = i', 'hbasa'),
            ('ܠܾ', 'lu', '[lu]: esasa: znak pod literą = u', 'esasa'),
            ('ܣܰ', 'sa', '[sa]: pthaha: znak nad literą = a', 'pthaha'),
            ('ܣܳ', 'so', '[so]: zqapha: znak nad literą = o', 'zqapha'),
            ('ܣܶ', 'se', '[se]: rbasa: znak nad literą = e', 'rbasa'),
            ('ܣܻ', 'si', '[si]: hbasa: znak pod literą = i', 'hbasa'),
            ('ܣܾ', 'su', '[su]: esasa: znak pod literą = u', 'esasa'),
            ('ܫܰ', 'ša', '[ša]: pthaha: znak nad literą = a', 'pthaha'),
            ('ܫܳ', 'šo', '[šo]: zqapha: znak nad literą = o', 'zqapha'),
        ],
    },
    {
        "id": 'alef6', "title": 'Twarde i miękkie: ܒܓܕܟܦܬ', "icon": 'ܒ݂', "track": "pismo",
        "letters": [
            ('ܒ݁', 'b', '[b]: kropka nad literą (quššāyā) = twarda wymowa', 'quššāyā'),
            ('ܒ݂', 'ḇ', '[v]: kropka pod literą (rukkāḵā) = miękka wymowa', 'rukkāḵā'),
            ('ܓ݁', 'g', '[ɡ]: kropka nad literą (quššāyā) = twarda wymowa', 'quššāyā'),
            ('ܓ݂', 'ḡ', '[ɣ]: kropka pod literą (rukkāḵā) = miękka wymowa', 'rukkāḵā'),
            ('ܕ݁', 'd', '[d]: kropka nad literą (quššāyā) = twarda wymowa', 'quššāyā'),
            ('ܕ݂', 'ḏ', '[ð]: kropka pod literą (rukkāḵā) = miękka wymowa', 'rukkāḵā'),
            ('ܟ݁', 'k', '[k]: kropka nad literą (quššāyā) = twarda wymowa', 'quššāyā'),
            ('ܟ݂', 'ḵ', '[x]: kropka pod literą (rukkāḵā) = miękka wymowa', 'rukkāḵā'),
            ('ܦ݁', 'p', '[p]: kropka nad literą (quššāyā) = twarda wymowa', 'quššāyā'),
            ('ܦ݂', 'p̄', '[f]: kropka pod literą (rukkāḵā) = miękka wymowa', 'rukkāḵā'),
            ('ܬ݁', 't', '[t]: kropka nad literą (quššāyā) = twarda wymowa', 'quššāyā'),
            ('ܬ݂', 'ṯ', '[θ]: kropka pod literą (rukkāḵā) = miękka wymowa', 'rukkāḵā'),
        ],
    },
    # ---------------------------------------------------------------- język
    {
        "id": "slowa", "title": "Pierwsze słowa", "icon": "ܫܠܡ", "track": "jezyk", "requires": "alef2",
        "words": [
            ("ܫܠܡ", "šĕlām", "pokój; witaj", "szalom", "Ten sam rdzeń co hebrajskie szalom i arabskie salam."),
            ("ܐܒܐ", "ʾabbā", "tata; ojcze", "Abba; opat", "Słowo „opat” pochodzi właśnie od aramejskiego abba!"),
            ("ܐܡܐ", "ʾimmā", "mama", None, None),
            ("ܐܢܗ", "ʾănā", "ja", None, None),
            ("ܐܢܬ", "ʾant", "ty", None, None),
            ("ܗܘܐ", "hūʾ", "on", None, None),
            ("ܗܝܐ", "hīʾ", "ona", None, None),
            ("ܒܪ", "bar", "syn", "Bartłomiej; Barabasz", "Bartłomiej = syn Tolmaja, Barabasz = syn ojca (bar abbā)."),
            ("ܒܪܬ", "bĕrat", "córka", None, None),
            ("ܐܢܫ", "ʾĕnāš", "człowiek", None, "bar ʾĕnāš = syn człowieczy, czyli po prostu „człowiek”."),
            ("ܛܒ", "ṭāb", "dobry", None, None),
            ("ܠܐ", "lāʾ", "nie", None, None),
        ],
        "sentences": [
            (["ܐܢܗ", "ܒܪ"], "Jestem synem.", {}),
            (["ܗܘܐ", "ܛܒ"], "On jest dobry.", {"ܗܝܐ": "ܗܝܐ to „ona”. On: ܗܘܐ."}),
            (["ܗܝܐ", "ܒܪܬ"], "Ona jest córką.", {"ܒܪ": "Córka: ܒܪܬ. ܒܪ to „syn”."}),
            (["ܐܒܐ", "ܛܒ"], "Tata jest dobry.", {}),
            (["ܒܪ", "ܐܢܫ"], "Syn człowieczy.", {}),
        ],
    },
    {
        "id": "emfatyczny", "title": "Rodzajnik na końcu", "icon": "ܐ-", "track": "jezyk",
        "words": [
            ("ܡܠܟ", "melek", "król", None, "Ten sam rdzeń co hebrajskie melech."),
            ("ܡܠܟܐ", "malkā", "(ten) król", None, "Końcówka -ā = rodzajnik: „ten król”."),
            ("ܐܠܗ", "ʾĕlāh", "bóg", "Eloi", None),
            ("ܐܠܗܐ", "ʾĕlāhā", "Bóg (ten jedyny)", None, None),
            ("ܫܡܝܐ", "šĕmayyā", "niebiosa", None, None),
            ("ܐܪܥܐ", "ʾarʿā", "ziemia", None, None),
            ("ܠܚܡܐ", "laḥmā", "chleb", "Betlejem", "Betlejem po hebrajsku to „dom chleba” (bēt leḥem)."),
            ("ܥܠܡܐ", "ʿālmā", "świat; wiek", None, None),
            ("ܡܠܟܘܬܐ", "malkūtā", "królestwo", None, None),
            ("ܕܝ", "dī", "który; (czyj)", None, "ܕܝ łączy rzeczowniki jak polski dopełniacz: król (czego?) Babilonu."),
            ("ܒܒܠ", "bābel", "Babilon", "Babel", None),
            ("ܪܒ", "rab", "wielki; mistrz", "rabin", "Rabin = „mój mistrz”."),
        ],
        "sentences": [
            (["ܡܠܟܐ", "ܪܒ"], "Król jest wielki.", {"ܡܠܟ": "Konkretny król: z rodzajnikiem, ܡܠܟܐ."}),
            (["ܡܠܟܐ", "ܕܝ", "ܒܒܠ"], "Król Babilonu.", {}),
            (["ܡܠܟܘܬܐ", "ܕܝ", "ܫܡܝܐ"], "Królestwo niebios.", {}),
            (["ܠܚܡܐ", "ܛܒ"], "Chleb jest dobry.", {}),
        ],
    },
    {
        "id": "jezus", "title": "Słowa Jezusa", "icon": "ܛܠ", "track": "jezyk",
        "words": [
            ("ܛܠܝܬܐ", "ṭalyĕtā", "dziewczynko", "talitha", None),
            ("ܩܘܡܝ", "qūmī", "wstań (do kobiety)", "kum", "Wiele rękopisów Ewangelii ma κουμ (qūm), formę „męską”; inne κουμι (qūmī)."),
            ("ܐܠܗܝ", "ʾĕlāhī", "Boże mój", "Eloi", "-ī na końcu = „mój”: ʾĕlāh (bóg) → ʾĕlāhī (mój Boże)."),
            ("ܠܡܗ", "lĕmā", "dlaczego", "lama", None),
            ("ܫܒܩܬܢܝ", "šĕbaqtanī", "opuściłeś mnie", "sabachthani", None),
            ("ܡܪܢܐ", "māranā", "Panie nasz", "Marana", "Maranatha da się podzielić na dwa sposoby: māranā tā (Panie, przyjdź!) albo māran ʾătā (Pan przyszedł)."),
            ("ܬܐ", "tā", "przyjdź", "tha", None),
            ("ܪܒܘܢܝ", "rabbūnī", "mój Nauczycielu", "Rabbuni", None),
            ("ܟܝܦܐ", "kēpā", "skała", "Kefas", "Jezus nazwał Szymona Kefas, po grecku Petros: Piotr = skała."),
            ("ܬܐܘܡܐ", "tōmā", "bliźniak", "Tomasz", "Imię Tomasz to aramejskie „bliźniak”."),
            ("ܡܡܘܢܐ", "māmōnā", "bogactwo", "mammona", None),
            ("ܓܠܓܠܬܐ", "gulgaltā", "czaszka", "Golgota", None),
            ("ܛܒܝܬܐ", "ṭabyĕtā", "gazela", "Tabita", None),
        ],
        "sentences": [
            (["ܛܠܝܬܐ", "ܩܘܡܝ"], "Dziewczynko, wstań!", {}),
            (["ܐܠܗܝ", "ܐܠܗܝ", "ܠܡܗ", "ܫܒܩܬܢܝ"], "Boże mój, Boże mój, czemuś mnie opuścił?", {}),
            (["ܡܪܢܐ", "ܬܐ"], "Panie nasz, przyjdź!", {}),
        ],
    },
    {
        "id": "czas", "title": "Czasowniki", "icon": "ܟܬܒ", "track": "jezyk",
        "words": [
            ("ܐܡܪ", "ʾămar", "powiedział", None, None),
            ("ܟܬܒ", "kĕtab", "napisał", None, "Rdzeń k-t-b = pisać. Ten sam co w arabskim kitab (książka)."),
            ("ܐܙܠ", "ʾăzal", "poszedł", None, None),
            ("ܥܢܗ", "ʿānē", "odpowiada", None, None),
            ("ܘܐܡܪ", "wĕʾāmar", "i mówi; i rzekł", None, "ܘ na początku słowa = „i”. Pisze się je razem ze słowem."),
            ("ܕܢܝܐܠ", "dāniyyēʾl", "Daniel", "Daniel", "Imię znaczy „mój sędzia to Bóg”."),
        ],
        "sentences": [
            (["ܥܢܗ", "ܡܠܟܐ", "ܘܐܡܪ"], "Król odpowiedział i rzekł.", {}),
            (["ܕܢܝܐܠ", "ܐܡܪ"], "Daniel powiedział.", {}),
            (["ܡܠܟܐ", "ܟܬܒ"], "Król napisał.", {}),
        ],
    },
    # ---------------------------------------------------------------- teksty
    {
        "id": "daniel", "title": "Księga Daniela", "icon": "ܕܢ", "track": "teksty", "requires": "czas",
        "words": [
            ("ܠܗܘܐ", "lehĕwēʾ", "niech będzie", None, None),
            ("ܫܡܗ", "šĕmēh", "jego imię", None, None),
            ("ܡܒܪܟ", "mĕbārak", "błogosławione", None, None),
            ("ܡܢ", "min", "od", None, None),
            ("ܘܥܕ", "wĕʿad", "i aż do", None, None),
        ],
        "sentences": [
            (["ܠܗܘܐ", "ܫܡܗ", "ܕܝ", "ܐܠܗܐ", "ܡܒܪܟ"], "Niech będzie błogosławione imię Boga.", {}),
            (["ܡܢ", "ܥܠܡܐ", "ܘܥܕ", "ܥܠܡܐ"], "Od wieków na wieki.", {}),
        ],
    },
    {
        "id": "abun", "title": "Ojcze nasz (Peszitta)", "icon": "ܐܒ", "track": "teksty",
        "words": [
            ("ܐܒܘܢ", "ʾabūn", "Ojcze nasz", None, "Tak zaczyna się Ojcze nasz w syryjskiej Peszitcie."),
            ("ܕܒܫܡܝܐ", "dbašmayyā", "który jesteś w niebie", None, "d- = który, b- = w, šmayyā = niebiosa."),
            ("ܢܬܩܕܫ", "nitqaddaš", "niech się święci", None, None),
            ("ܫܡܟ", "šmāk", "imię Twoje", None, "-āk na końcu = „twój”."),
            ("ܬܐܬܐ", "tēʾtē", "niech przyjdzie", None, None),
            ("ܡܠܟܘܬܟ", "malkūtāk", "królestwo Twoje", None, None),
        ],
        "sentences": [
            (["ܐܒܘܢ", "ܕܒܫܡܝܐ"], "Ojcze nasz, który jesteś w niebie.", {}),
            (["ܢܬܩܕܫ", "ܫܡܟ"], "Święć się imię Twoje.", {}),
            (["ܬܐܬܐ", "ܡܠܟܘܬܟ"], "Przyjdź królestwo Twoje.", {}),
        ],
    },
    {
        "id": "kadisz", "title": "Kadisz", "icon": "ܩܕ", "track": "teksty",
        "words": [
            ("ܝܬܓܕܠ", "yitgaddal", "niech będzie wywyższone", None, None),
            ("ܘܝܬܩܕܫ", "wĕyitqaddaš", "i uświęcone", None, None),
            ("ܪܒܐ", "rabbā", "wielkie", None, None),
        ],
        "sentences": [
            (["ܝܬܓܕܠ", "ܘܝܬܩܕܫ", "ܫܡܗ", "ܪܒܐ"], "Niech będzie wywyższone i uświęcone Jego wielkie imię.", {}),
        ],
    },
]

TRACKS = {
    "pismo": "ܟܬܒܐ · PISMO",
    "jezyk": "ܠܫܢܐ · JĘZYK",
    "teksty": "ܟܬܒܝܐ · TEKSTY",
}

INSIGHTS = {
    "alef4": [
        {"title": "Samogłoski to znaczki",
         "text": "Zwykle piszesz same spółgłoski, ale w Biblii i podręcznikach dodaje się znaczki samogłosek. "
                 "W tradycji zachodniej (serto) są trzy nad literą i dwa pod nią: pthaha (a), zqapha (o), rbasa (e) "
                 "nad literą oraz hbasa (i) i esasa (u) pod nią. Ćwicz je na ܒ i ܡ.",
         "chain": []},
    ],
    "alef6": [
        {"title": "Sześć liter z dwiema wymowami",
         "text": "ܒ ܓ ܕ ܟ ܦ ܬ (po łacinie bgdkpt) mają dwa dźwięki: twardy po spółgłosce lub na początku, miękki po samogłosce. "
                 "Wymowę oznacza się kropką: nad literą (quššāyā) = twardy [b], pod literą (rukkāḵā) = miękki [v]. "
                 "W codziennym tekście kropek nie piszą, więc trzeba znać regułę.",
         "chain": []},
    ],
    "alef1": [
        {"title": "Od prawej do lewej",
         "text": "Pismo syryjskie czyta się od prawej. Zapisuje się w nim głównie spółgłoski: samogłoski "
                 "trzeba znać albo odczytać z transkrypcji. Tym pismem pisze się do dziś w Kościołach "
                 "syryjskich, a wyrosło z tego samego alfabetu aramejskiego co pismo hebrajskie.",
         "chain": []},
    ],
    "alef2": [
        {"title": "Dźwięki gardłowe i kropki",
         "text": "ܚ (ḥ) to gardłowe ch, ܥ (ʿ) to gardłowy dźwięk, którego polski nie ma. Uważaj na ܕ i ܪ: "
                 "różnią się tylko kropką, pod spodem to d, nad literą to r.",
         "chain": []},
    ],
    "alef3": [
        {"title": "Litery się łączą",
         "text": "Jak w piśmie odręcznym, litery syryjskie łączą się ze sobą i zmieniają kształt zależnie od "
                 "miejsca w słowie. Osiem liter nie łączy się z następną: po nich słowo ma „przerwę”. "
                 "Zobacz ܐܒܐ (Abba): ܐ na końcu nie łączy się dalej.",
         "chain": []},
    ],
    "slowa": [
        {"title": "Bez „jest”",
         "text": "Aramejski zwykle pomija „jest”: ܗܘܐ ܛܒ = on (jest) dobry. Tak jak w polskich nagłówkach: "
                 "„Tata – dobry”. A ܒܪ (bar) to syn: stąd Bartłomiej (syn Tolmaja) i Barabasz (syn ojca).",
         "chain": [
             ("On jest dobry.", ["ܗܘܐ", "ܛܒ"], "ܗܘܐ (on) + ܛܒ (dobry). Czytasz od prawej."),
             ("Syn człowieczy.", ["ܒܪ", "ܐܢܫ"], "ܒܪ (syn) + ܐܢܫ (człowiek)."),
         ]},
    ],
    "emfatyczny": [
        {"title": "Rodzajnik na końcu",
         "text": "Polski nie ma rodzajnika, a aramejski dokleja go na końcu słowa: -ā. ܡܠܟ (melek) to „król”, "
                 "a ܡܠܟܐ (malkā) to „ten król”. Dlatego tyle aramejskich słów kończy się na -a: Abba, "
                 "Golgota, Kefas (kēpā).",
         "chain": [
             ("Król jest wielki.", ["ܡܠܟܐ", "ܪܒ"], "Konkretny król: ܡܠܟܐ, potem ܪܒ (wielki)."),
             ("Królestwo niebios.", ["ܡܠܟܘܬܐ", "ܕܝ", "ܫܡܝܐ"], "ܕܝ łączy jak dopełniacz: królestwo (czego?) niebios."),
         ]},
    ],
    "jezus": [
        {"title": "Słowa, które zostały w Ewangelii",
         "text": "Ewangelie są po grecku, ale kilka zdań zostawiono po aramejsku, a polska Biblia je "
                 "przepisała: Talitha kum, Effatha, Eloi Eloi lema sabachthani, Abba, Maranatha. -ī na "
                 "końcu to „mój”: ʾĕlāhī = mój Boże, rabbūnī = mój Nauczycielu.",
         "chain": [
             ("Dziewczynko, wstań!", ["ܛܠܝܬܐ", "ܩܘܡܝ"], "ṭalyĕtā (dziewczynko) + qūmī (wstań)."),
             ("Boże mój, Boże mój, czemuś mnie opuścił?", ["ܐܠܗܝ", "ܐܠܗܝ", "ܠܡܗ", "ܫܒܩܬܢܝ"],
              "ʾĕlāhī dwa razy, potem lĕmā (dlaczego) i šĕbaqtanī."),
         ]},
    ],
    "czas": [
        {"title": "Trzy spółgłoski = jedno znaczenie",
         "text": "Słowa budują się z rdzeni z trzech spółgłosek. ܟ-ܬ-ܒ (k-t-b) to „pisać”: kĕtab (napisał). "
                 "To jak polskie „pis-” w pisać, napis, pisarz, tylko że samogłoski zmieniają się w środku.",
         "chain": [("Król odpowiedział i rzekł.", ["ܥܢܗ", "ܡܠܟܐ", "ܘܐܡܪ"],
                    "Typowe zdanie z Daniela: ܥܢܗ (odpowiada) + ܡܠܟܐ + ܘܐܡܪ (i mówi).")]},
    ],
    "daniel": [
        {"title": "Aramejski w Biblii",
         "text": "Część Księgi Daniela (2,4–7,28) i Ezdrasza jest po aramejsku, nie po hebrajsku. To język "
                 "imperium perskiego, wspólny język Bliskiego Wschodu przez tysiąc lat.",
         "chain": [("Niech będzie błogosławione imię Boga.", ["ܠܗܘܐ", "ܫܡܗ", "ܕܝ", "ܐܠܗܐ", "ܡܒܪܟ"],
                    "lehĕwēʾ (niech będzie) šĕmēh (jego imię) dī ʾĕlāhā (Boga) mĕbārak.")]},
    ],
    "abun": [
        {"title": "Ojcze nasz po syryjsku",
         "text": "Peszitta to Biblia w języku syryjskim, czyli aramejskim Kościołów Wschodu. Do dziś "
                 "czyta się ją w liturgii, i to właśnie tym pismem.",
         "chain": [("Ojcze nasz, który jesteś w niebie.", ["ܐܒܘܢ", "ܕܒܫܡܝܐ"], "ʾabūn (Ojcze nasz) + dbašmayyā.")]},
    ],
    "kadisz": [
        {"title": "Modlitwa po aramejsku",
         "text": "Kadisz to żydowska modlitwa odmawiana do dziś, i to po aramejsku. Zaczyna się słowami, "
                 "które przypominają „święć się imię Twoje”.",
         "chain": []},
    ],
}

ENDINGS_INSIGHT = {
    "title": "Końcówki doklejane",
    "text": "Aramejski dokleja do słów to, co polski mówi osobno: -ā = „ten”, -ī = „mój”, -āk = „twój”. "
            "Patrz na koniec słowa, czyli na jego lewą stronę.",
}

ENDINGS = [
    ("", "ܡܠܟ", "ܐ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], "ten król (malkā)", "Rodzajnik: -ā (ܐ).", "emfatyczny"),
    ("", "ܐܠܗ", "ܐ", "", ["ܐ", "ܝ", "ܟ", "ܢ"], "Bóg (ʾĕlāhā)", "Rodzajnik: -ā (ܐ).", "emfatyczny"),
    ("", "ܐܠܗ", "ܝ", "", ["ܐ", "ܝ", "ܟ", "ܢ"], "mój Boże (ʾĕlāhī)", "„Mój” = -ī (ܝ).", "jezus"),
    ("", "ܪܒܘܢ", "ܝ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], "mój Nauczycielu (rabbūnī)", "„Mój” = -ī (ܝ).", "jezus"),
    ("", "ܫܡ", "ܟ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], "imię twoje (šmāk)", "„Twój” = -āk (ܟ).", "abun"),
    ("", "ܡܠܟܘܬ", "ܟ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], "królestwo twoje (malkūtāk)", "„Twój” = -āk (ܟ).", "abun"),
]

CHATS = [
    {
        "id": "shalom", "title": "Pozdrowienie", "partner": "Jan", "avatar": "ܝ", "requires": "slowa",
        "turns": [
            {"bot": ["ܫܠܡ", "!"], "en": "Pokój! (Witaj!)",
             "options": [(["ܫܠܡ", "!"], True, None),
                         (["ܠܐ", "!"], False, "ܠܐ to „nie”. Odpowiedz pozdrowieniem: ܫܠܡ.")]},
            {"bot": ["ܐܢܬ", "ܒܪ", "?"], "en": "Ty jesteś synem?",
             "options": [(["ܐܢܗ", "ܒܪ"], True, None),
                         (["ܐܢܬ", "ܒܪ"], False, "ܐܢܬ to „ty”. O sobie: ܐܢܗ (ja)."),
                         (["ܗܘܐ", "ܒܪ"], False, "ܗܘܐ to „on”. O sobie: ܐܢܗ.")]},
            {"bot": ["ܐܒܐ", "ܛܒ", "?"], "en": "Tata jest dobry?",
             "build": (["ܐܒܐ", "ܛܒ"], "Tata jest dobry.")},
        ],
    },
    {
        "id": "kefas", "title": "Nad jeziorem", "partner": "Szymon Kefas", "avatar": "ܟ", "requires": "jezus",
        "turns": [
            {"bot": ["ܪܒܘܢܝ", "!"], "en": "Mój Nauczycielu!",
             "options": [(["ܫܠܡ"], True, None),
                         (["ܠܡܗ"], False, "ܠܡܗ to „dlaczego”. Przywitaj się: ܫܠܡ.")]},
            {"bot": ["ܡܪܢܐ", "ܬܐ"], "en": "Panie nasz, przyjdź!",
             "build": (["ܡܪܢܐ", "ܬܐ"], "Panie nasz, przyjdź!")},
        ],
    },
    {
        "id": "babel", "title": "Na dworze w Babilonie", "partner": "Daniel", "avatar": "ܕ", "requires": "czas",
        "turns": [
            {"bot": ["ܡܠܟܐ", "ܕܝ", "ܒܒܠ", "ܪܒ", "."], "en": "Król Babilonu jest wielki.",
             "options": [(["ܐܠܗܐ", "ܪܒ"], True, None),
                         (["ܐܠܗ", "ܪܒ"], False, "Mówiąc o jedynym Bogu, użyj formy z rodzajnikiem: ܐܠܗܐ.")]},
            {"bot": ["ܡܠܟܐ", "ܟܬܒ", "?"], "en": "Czy król napisał?",
             "build": (["ܡܠܟܐ", "ܟܬܒ"], "Król napisał.")},
        ],
    },
]

# Słowa tylko z rozmów: forma → (transkrypcja, znaczenie)
CHAT_EXTRA = {}
PUNCT = set(".,!?:;")


# ---------------------------------------------------------------------------
# Gramatyka. PITFALLS: typowe trudności uczących się, (tytuł, opis).
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------
PITFALLS = [
    ('Pismo od prawej, bez samogłosek', 'Tekst czyta się od prawej do lewej, a litery oznaczają głównie spółgłoski. Samogłoski trzeba znać albo odczytać ze znaczków nad i pod literami.'),
    ('Litery zmieniają kształt', 'Większość liter łączy się z sąsiednimi i wygląda inaczej na początku, w środku i na końcu słowa. Kilka liter nie łączy się w lewo.'),
    ('Spółgłoski gardłowe i emfatyczne', 'ܥ (ʿajin) i ܚ (ḥet) wymawia się w gardle, a ܛ, ܨ, ܩ są „cięższe” niż zwykłe t, s, k. W polskim nie ma odpowiedników.'),
    ('Końcowe -ā zamiast rodzajnika', 'Rzeczownik w zwykłej formie kończy się na -ā (malkā = król, ten król). To dawny rodzajnik doklejony na końcu.'),
    ('Rdzeń trzech spółgłosek', 'Słowa buduje się z trzyliterowego rdzenia i wzoru samogłosek: K-T-B daje kĕtab (napisał), kātēb (piszący), kĕtābā (księga).'),
]

PARADIGM_LABELS = {
}

PARADIGMS = [
]

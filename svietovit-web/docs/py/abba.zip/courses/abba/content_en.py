"""[en — wygenerowane przez tools/i18n.py, nie edytuj] Treść kursu: aramejski biblijny i aramejski czasów Jezusa, dla Polaków, pismem syryjskim.

Słowo:     (forma pismem syryjskim bez samogłosek, transkrypcja, znaczenie, polskie skojarzenie, uwaga)
Litera:    (litera, transkrypcja, opis po polsku, nazwa)
Zdanie:    (lista słów w kolejności czytania, od prawej, tłumaczenie, {pułapka: wyjaśnienie})
Końcówka:  (przed, temat, końcówka, po, [opcje], podpowiedź, wyjaśnienie, dział)
           przed/temat/końcówka/po są w kolejności czytania (logicznej); aplikacja sama
           odwraca je do wyświetlenia od prawej do lewej.

Pismo syryjskie łączy litery. Kivy tego nie umie, więc tools/shape_syriac.py składa każde
słowo z góry (HarfBuzz) i zapisuje gotowe kształty w fonts/Syr.ttf i syriac_shapes.json.
Po zmianie treści uruchom: python tools/shape_syriac.py
"""

UNITS = [
    # --------------------------------------------------------------- alfabet
    {
        "id": "alef1", "title": 'Alphabet I', "icon": "ܐ", "track": "pismo",
        "letters": [
            ("ܐ", "ʾ", '[ʔ] or silent; at the end of a word often -ā', "ʾālap"),
            ("ܒ", "b", '[b], after a vowel [v]', "bēt"), ("ܓ", "g", '[ɡ], after a vowel [ɣ]', "gāmal"),
            ("ܕ", "d", '[d], after a vowel [ð]; dot underneath', "dālat"),
            ("ܗ", "h", '[h]', "hē"), ("ܘ", "w", '[w]; also the vowel [o] or [u]', "waw"),
            ("ܙ", "z", '[z]', "zayn"), ("ܚ", "ḥ", '[ħ] (throaty h)', "ḥēt"), ("ܛ", "ṭ", '[tˤ] (“heavy” t)', "ṭēt"),
            ("ܝ", "j", '[j]; also the vowel [i] or [e]', "yod"), ("ܟ", "k", '[k], after a vowel [x]', "kāp"),
        ],
    },
    {
        "id": "alef2", "title": 'Alphabet II', "icon": "ܬ", "track": "pismo",
        "letters": [
            ("ܠ", "l", '[l]', "lāmad"), ("ܡ", "m", '[m]', "mīm"), ("ܢ", "n", '[n]', "nūn"),
            ("ܣ", "s", '[s]', "semkat"), ("ܥ", "ʿ", '[ʕ] (throat sound)', "ʿē"),
            ("ܦ", "p", '[p], after a vowel [f]', "pē"), ("ܨ", "ṣ", '[sˤ] (“heavy” s)', "ṣādē"),
            ("ܩ", "q", '[q] (deep k)', "qop"), ("ܪ", "r", '[r]; dot above (a dot below would make it d!)', "rēš"),
            ("ܫ", "š", '[ʃ] (sh)', "šīn"), ("ܬ", "t", '[t], after a vowel [θ]', "taw"),
        ],
    },
    {
        "id": "alef3", "title": 'Joining letters', "icon": "ܕ", "track": "pismo",
        "letters": [
            ("ܐ ", "ʾ", 'ʾālap does not join the next letter', "ʾālap"),
            ("ܕ ", "d", 'dālat does not join the next letter', "dālat"),
            ("ܗ ", "h", 'hē does not join the next letter', "hē"),
            ("ܘ ", "w", 'waw does not join the next letter', "waw"),
            ("ܙ ", "z", 'zayn does not join the next letter', "zayn"),
            ("ܨ ", "ṣ", 'ṣādē does not join the next letter', "ṣādē"),
            ("ܪ ", "r", 'rēš does not join the next letter', "rēš"),
            ("ܬ ", "t", 'taw does not join the next letter', "taw"),
        ],
    },
    {
        "id": 'alef4', "title": 'Vowels I: ܒ and ܡ', "icon": 'ܒܰ', "track": "pismo",
        "letters": [
            ('ܒܰ', 'ba', '[ba]: pthaha: mark above the letter = a', 'pthaha'),
            ('ܒܳ', 'bo', '[bo]: zqapha: mark above the letter = o', 'zqapha'),
            ('ܒܶ', 'be', '[be]: rbasa: mark above the letter = e', 'rbasa'),
            ('ܒܻ', 'bi', '[bi]: hbasa: mark below the letter = i', 'hbasa'),
            ('ܒܾ', 'bu', '[bu]: esasa: mark below the letter = u', 'esasa'),
            ('ܡܰ', 'ma', '[ma]: pthaha: mark above the letter = a', 'pthaha'),
            ('ܡܳ', 'mo', '[mo]: zqapha: mark above the letter = o', 'zqapha'),
            ('ܡܶ', 'me', '[me]: rbasa: mark above the letter = e', 'rbasa'),
            ('ܡܻ', 'mi', '[mi]: hbasa: mark below the letter = i', 'hbasa'),
            ('ܡܾ', 'mu', '[mu]: esasa: mark below the letter = u', 'esasa'),
        ],
    },
    {
        "id": 'alef5', "title": 'Vowels II: ܠ ܣ ܫ', "icon": 'ܠܳ', "track": "pismo",
        "letters": [
            ('ܠܰ', 'la', '[la]: pthaha: mark above the letter = a', 'pthaha'),
            ('ܠܳ', 'lo', '[lo]: zqapha: mark above the letter = o', 'zqapha'),
            ('ܠܶ', 'le', '[le]: rbasa: mark above the letter = e', 'rbasa'),
            ('ܠܻ', 'li', '[li]: hbasa: mark below the letter = i', 'hbasa'),
            ('ܠܾ', 'lu', '[lu]: esasa: mark below the letter = u', 'esasa'),
            ('ܣܰ', 'sa', '[sa]: pthaha: mark above the letter = a', 'pthaha'),
            ('ܣܳ', 'so', '[so]: zqapha: mark above the letter = o', 'zqapha'),
            ('ܣܶ', 'se', '[se]: rbasa: mark above the letter = e', 'rbasa'),
            ('ܣܻ', 'si', '[si]: hbasa: mark below the letter = i', 'hbasa'),
            ('ܣܾ', 'su', '[su]: esasa: mark below the letter = u', 'esasa'),
            ('ܫܰ', 'ša', '[ša]: pthaha: mark above the letter = a', 'pthaha'),
            ('ܫܳ', 'šo', '[šo]: zqapha: mark above the letter = o', 'zqapha'),
        ],
    },
    {
        "id": 'alef6', "title": 'Hard and soft: ܒܓܕܟܦܬ', "icon": 'ܒ݂', "track": "pismo",
        "letters": [
            ('ܒ݁', 'b', '[b]: a dot above the letter (quššāyā) = hard pronunciation', 'quššāyā'),
            ('ܒ݂', 'ḇ', '[v]: a dot below the letter (rukkāḵā) = soft pronunciation', 'rukkāḵā'),
            ('ܓ݁', 'g', '[ɡ]: a dot above the letter (quššāyā) = hard pronunciation', 'quššāyā'),
            ('ܓ݂', 'ḡ', '[ɣ]: a dot below the letter (rukkāḵā) = soft pronunciation', 'rukkāḵā'),
            ('ܕ݁', 'd', '[d]: a dot above the letter (quššāyā) = hard pronunciation', 'quššāyā'),
            ('ܕ݂', 'ḏ', '[ð]: a dot below the letter (rukkāḵā) = soft pronunciation', 'rukkāḵā'),
            ('ܟ݁', 'k', '[k]: a dot above the letter (quššāyā) = hard pronunciation', 'quššāyā'),
            ('ܟ݂', 'ḵ', '[x]: a dot below the letter (rukkāḵā) = soft pronunciation', 'rukkāḵā'),
            ('ܦ݁', 'p', '[p]: a dot above the letter (quššāyā) = hard pronunciation', 'quššāyā'),
            ('ܦ݂', 'p̄', '[f]: a dot below the letter (rukkāḵā) = soft pronunciation', 'rukkāḵā'),
            ('ܬ݁', 't', '[t]: a dot above the letter (quššāyā) = hard pronunciation', 'quššāyā'),
            ('ܬ݂', 'ṯ', '[θ]: a dot below the letter (rukkāḵā) = soft pronunciation', 'rukkāḵā'),
        ],
    },
    # ---------------------------------------------------------------- język
    {
        "id": "slowa", "title": 'First words', "icon": "ܫܠܡ", "track": "jezyk", "requires": "alef2",
        "words": [
            ("ܫܠܡ", "šĕlām", 'peace; hello', 'shalom', 'The same root as Hebrew shalom and Arabic salaam.'),
            ("ܐܒܐ", "ʾabbā", 'dad; father', 'Abba; abbot', 'The word “abbot” comes from Aramaic abba!'),
            ("ܐܡܐ", "ʾimmā", 'mum', None, None),
            ("ܐܢܗ", "ʾănā", 'I', None, None),
            ("ܐܢܬ", "ʾant", 'you', None, None),
            ("ܗܘܐ", "hūʾ", 'he', None, None),
            ("ܗܝܐ", "hīʾ", 'she', None, None),
            ("ܒܪ", "bar", 'son', 'Bartholomew; Barabbas', 'Bartholomew = son of Tolmai, Barabbas = son of the father (bar abbā).'),
            ("ܒܪܬ", "bĕrat", 'daughter', None, None),
            ("ܐܢܫ", "ʾĕnāš", 'human being', None, 'bar ʾĕnāš = son of man, which simply means “a human being”.'),
            ("ܛܒ", "ṭāb", 'good', None, None),
            ("ܠܐ", "lāʾ", 'no; not', None, None),
        ],
        "sentences": [
            (["ܐܢܗ", "ܒܪ"], 'I am a son.', {}),
            (["ܗܘܐ", "ܛܒ"], 'He is good.', {"ܗܝܐ": 'ܗܝܐ means “she”. He: ܗܘܐ.'}),
            (["ܗܝܐ", "ܒܪܬ"], 'She is a daughter.', {"ܒܪ": 'Daughter: ܒܪܬ. ܒܪ means “son”.'}),
            (["ܐܒܐ", "ܛܒ"], 'Dad is good.', {}),
            (["ܒܪ", "ܐܢܫ"], 'The Son of Man.', {}),
        ],
    },
    {
        "id": "emfatyczny", "title": 'The article at the end', "icon": "ܐ-", "track": "jezyk",
        "words": [
            ("ܡܠܟ", "melek", 'king', None, 'The same root as Hebrew melech.'),
            ("ܡܠܟܐ", "malkā", '(the) king', None, 'The ending -ā is the article: “the king”.'),
            ("ܐܠܗ", "ʾĕlāh", 'god', 'Eloi', None),
            ("ܐܠܗܐ", "ʾĕlāhā", 'God (the one God)', None, None),
            ("ܫܡܝܐ", "šĕmayyā", 'heaven(s)', None, None),
            ("ܐܪܥܐ", "ʾarʿā", 'earth', None, None),
            ("ܠܚܡܐ", "laḥmā", 'bread', 'Bethlehem', 'Bethlehem is Hebrew for “house of bread” (bēt leḥem).'),
            ("ܥܠܡܐ", "ʿālmā", 'world; age', None, None),
            ("ܡܠܟܘܬܐ", "malkūtā", 'kingdom', None, None),
            ("ܕܝ", "dī", 'who; which; of', None, 'ܕܝ links nouns like English “of”: king of Babylon.'),
            ("ܒܒܠ", "bābel", 'Babylon', 'Babel', None),
            ("ܪܒ", "rab", 'great; master', 'rabbi', 'Rabbi = “my master”.'),
        ],
        "sentences": [
            (["ܡܠܟܐ", "ܪܒ"], 'The king is great.', {"ܡܠܟ": 'A particular king: with the article, ܡܠܟܐ.'}),
            (["ܡܠܟܐ", "ܕܝ", "ܒܒܠ"], 'The king of Babylon.', {}),
            (["ܡܠܟܘܬܐ", "ܕܝ", "ܫܡܝܐ"], 'The kingdom of heaven.', {}),
            (["ܠܚܡܐ", "ܛܒ"], 'The bread is good.', {}),
        ],
    },
    {
        "id": "jezus", "title": 'Words of Jesus', "icon": "ܛܠ", "track": "jezyk",
        "words": [
            ("ܛܠܝܬܐ", "ṭalyĕtā", 'little girl', 'talitha', None),
            ("ܩܘܡܝ", "qūmī", 'get up (to a woman)', 'koum', 'Many Gospel manuscripts have κουμ (qūm), the “masculine” form; others κουμι (qūmī).'),
            ("ܐܠܗܝ", "ʾĕlāhī", 'my God', 'Eloi', '-ī at the end = “my”: ʾĕlāh (god) → ʾĕlāhī (my God).'),
            ("ܠܡܗ", "lĕmā", 'why', 'lama', None),
            ("ܫܒܩܬܢܝ", "šĕbaqtanī", 'you have forsaken me', 'sabachthani', None),
            ("ܡܪܢܐ", "māranā", 'our Lord', 'Marana', 'Maranatha can be split two ways: māranā tā (Our Lord, come!) or māran ʾătā (Our Lord has come).'),
            ("ܬܐ", "tā", 'come!', 'tha', None),
            ("ܪܒܘܢܝ", "rabbūnī", 'my Teacher', 'Rabboni', None),
            ("ܟܝܦܐ", "kēpā", 'rock', 'Cephas', 'Jesus called Simon Kēpā (Cephas), in Greek Petros: Peter = rock.'),
            ("ܬܐܘܡܐ", "tōmā", 'twin', 'Thomas', 'The name Thomas is Aramaic for “twin”.'),
            ("ܡܡܘܢܐ", "māmōnā", 'wealth', 'mammon', None),
            ("ܓܠܓܠܬܐ", "gulgaltā", 'skull', 'Golgotha', None),
            ("ܛܒܝܬܐ", "ṭabyĕtā", 'gazelle', 'Tabitha', None),
        ],
        "sentences": [
            (["ܛܠܝܬܐ", "ܩܘܡܝ"], 'Little girl, get up!', {}),
            (["ܐܠܗܝ", "ܐܠܗܝ", "ܠܡܗ", "ܫܒܩܬܢܝ"], 'My God, my God, why have you forsaken me?', {}),
            (["ܡܪܢܐ", "ܬܐ"], 'Our Lord, come!', {}),
        ],
    },
    {
        "id": "czas", "title": 'Verbs', "icon": "ܟܬܒ", "track": "jezyk",
        "words": [
            ("ܐܡܪ", "ʾămar", '(he) said', None, None),
            ("ܟܬܒ", "kĕtab", '(he) wrote', None, 'The root k-t-b = write. The same as in Arabic kitab (book).'),
            ("ܐܙܠ", "ʾăzal", '(he) went', None, None),
            ("ܥܢܗ", "ʿānē", 'answers', None, None),
            ("ܘܐܡܪ", "wĕʾāmar", 'and says; and said', None, 'ܘ at the start of a word = “and”. It is written together with the word.'),
            ("ܕܢܝܐܠ", "dāniyyēʾl", 'Daniel', 'Daniel', 'The name means “God is my judge”.'),
        ],
        "sentences": [
            (["ܥܢܗ", "ܡܠܟܐ", "ܘܐܡܪ"], 'The king answered and said.', {}),
            (["ܕܢܝܐܠ", "ܐܡܪ"], 'Daniel said.', {}),
            (["ܡܠܟܐ", "ܟܬܒ"], 'The king wrote.', {}),
        ],
    },
    # ---------------------------------------------------------------- teksty
    {
        "id": "daniel", "title": 'Book of Daniel', "icon": "ܕܢ", "track": "teksty", "requires": "czas",
        "words": [
            ("ܠܗܘܐ", "lehĕwēʾ", 'may (it) be', None, None),
            ("ܫܡܗ", "šĕmēh", 'his name', None, None),
            ("ܡܒܪܟ", "mĕbārak", 'blessed', None, None),
            ("ܡܢ", "min", 'from', None, None),
            ("ܘܥܕ", "wĕʿad", 'and up to', None, None),
        ],
        "sentences": [
            (["ܠܗܘܐ", "ܫܡܗ", "ܕܝ", "ܐܠܗܐ", "ܡܒܪܟ"], 'Blessed be the name of God.', {}),
            (["ܡܢ", "ܥܠܡܐ", "ܘܥܕ", "ܥܠܡܐ"], 'From age to age.', {}),
        ],
    },
    {
        "id": "abun", "title": 'Our Father (Peshitta)', "icon": "ܐܒ", "track": "teksty",
        "words": [
            ("ܐܒܘܢ", "ʾabūn", 'Our Father', None, "This is how the Lord's Prayer begins in the Syriac Peshitta."),
            ("ܕܒܫܡܝܐ", "dbašmayyā", 'who art in heaven', None, 'd- = who, b- = in, šmayyā = heaven.'),
            ("ܢܬܩܕܫ", "nitqaddaš", 'hallowed be', None, None),
            ("ܫܡܟ", "šmāk", 'thy name', None, '-āk at the end = “your”.'),
            ("ܬܐܬܐ", "tēʾtē", 'may (it) come', None, None),
            ("ܡܠܟܘܬܟ", "malkūtāk", 'thy kingdom', None, None),
        ],
        "sentences": [
            (["ܐܒܘܢ", "ܕܒܫܡܝܐ"], 'Our Father, who art in heaven.', {}),
            (["ܢܬܩܕܫ", "ܫܡܟ"], 'Hallowed be thy name.', {}),
            (["ܬܐܬܐ", "ܡܠܟܘܬܟ"], 'Thy kingdom come.', {}),
        ],
    },
    {
        "id": "kadisz", "title": 'Kaddish', "icon": "ܩܕ", "track": "teksty",
        "words": [
            ("ܝܬܓܕܠ", "yitgaddal", 'may (it) be exalted', None, None),
            ("ܘܝܬܩܕܫ", "wĕyitqaddaš", 'and hallowed', None, None),
            ("ܪܒܐ", "rabbā", 'great', None, None),
        ],
        "sentences": [
            (["ܝܬܓܕܠ", "ܘܝܬܩܕܫ", "ܫܡܗ", "ܪܒܐ"], 'Exalted and hallowed be His great name.', {}),
        ],
    },
]

TRACKS = {
    "pismo": 'ܟܬܒܐ · WRITING',
    "jezyk": 'ܠܫܢܐ · LANGUAGE',
    "teksty": 'ܟܬܒܝܐ · TEXTS',
}

INSIGHTS = {
    "alef4": [
        {"title": 'Vowels are little marks',
         "text": 'Usually you write only consonants, but in the Bible and in textbooks vowel marks are added. In the western tradition (Serto) there are three above the letter and two below it: pthaha (a), zqapha (o), rbasa (e) above, and hbasa (i) and esasa (u) below. Practise them on ܒ and ܡ.',
         "chain": []},
    ],
    "alef6": [
        {"title": 'Six letters with two pronunciations',
         "text": 'ܒ ܓ ܕ ܟ ܦ ܬ (in Latin letters bgdkpt) have two sounds: hard after a consonant or at the start, soft after a vowel. The pronunciation is marked with a dot: above the letter (quššāyā) = hard [b], below the letter (rukkāḵā) = soft [v]. In everyday text the dots are not written, so you have to know the rule.',
         "chain": []},
    ],
    "alef1": [
        {"title": 'Right to left',
         "text": 'Syriac script is read from the right. It writes mainly consonants: you have to know the vowels or read them from the transcription. The Syriac churches still write it today, and it grew from the same Aramaic alphabet as the Hebrew script.',
         "chain": []},
    ],
    "alef2": [
        {"title": 'Throat sounds and dots',
         "text": "ܚ (ḥ) is a throaty h, ܥ (ʿ) is a throat sound English doesn't have. Watch ܕ and ܪ: they differ only by a dot, below for d, above for r.",
         "chain": []},
    ],
    "alef3": [
        {"title": 'Letters join up',
         "text": "As in handwriting, Syriac letters join together and change shape depending on their place in the word. Eight letters never join the next one, so the word has a “gap” after them. Look at ܐܒܐ (Abba): the ܐ at the end doesn't join on.",
         "chain": []},
    ],
    "slowa": [
        {"title": 'No “is”',
         "text": 'Aramaic usually leaves out “is”: ܗܘܐ ܛܒ = he (is) good, like a headline: “Dad – good”. And ܒܪ (bar) means son: hence Bartholomew (son of Tolmai) and Barabbas (son of the father).',
         "chain": [
             ('He is good.', ["ܗܘܐ", "ܛܒ"], 'ܗܘܐ (he) + ܛܒ (good). Read from the right.'),
             ('The Son of Man.', ["ܒܪ", "ܐܢܫ"], 'ܒܪ (son) + ܐܢܫ (man).'),
         ]},
    ],
    "emfatyczny": [
        {"title": 'The article at the end',
         "text": "English puts “the” in front; Aramaic attaches it at the end of the word: -ā. ܡܠܟ (melek) is “king”, ܡܠܟܐ (malkā) is “the king”. That's why so many Aramaic words end in -a: Abba, Golgotha, Cephas (kēpā).",
         "chain": [
             ('The king is great.', ["ܡܠܟܐ", "ܪܒ"], 'A particular king: ܡܠܟܐ, then ܪܒ (great).'),
             ('The kingdom of heaven.', ["ܡܠܟܘܬܐ", "ܕܝ", "ܫܡܝܐ"], 'ܕܝ works like “of”: the kingdom of heaven.'),
         ]},
    ],
    "jezus": [
        {"title": 'Words kept in the Gospels',
         "text": 'The Gospels are in Greek, but a few sentences were left in Aramaic, and English Bibles keep them: Talitha koum, Ephphatha, Eloi Eloi lama sabachthani, Abba, Maranatha. -ī at the end means “my”: ʾĕlāhī = my God, rabbūnī = my Teacher.',
         "chain": [
             ('Little girl, get up!', ["ܛܠܝܬܐ", "ܩܘܡܝ"], 'ṭalyĕtā (little girl) + qūmī (get up).'),
             ('My God, my God, why have you forsaken me?', ["ܐܠܗܝ", "ܐܠܗܝ", "ܠܡܗ", "ܫܒܩܬܢܝ"],
              'ʾĕlāhī twice, then lĕmā (why) and šĕbaqtanī.'),
         ]},
    ],
    "czas": [
        {"title": 'Three consonants = one meaning',
         "text": 'Words are built from roots of three consonants. ܟ-ܬ-ܒ (k-t-b) means “write”: kĕtab (he wrote). Like English “sing, sang, song”, the vowels change inside while the consonants stay.',
         "chain": [('The king answered and said.', ["ܥܢܗ", "ܡܠܟܐ", "ܘܐܡܪ"],
                    'A typical sentence from Daniel: ܥܢܗ (answers) + ܡܠܟܐ + ܘܐܡܪ (and says).')]},
    ],
    "daniel": [
        {"title": 'Aramaic in the Bible',
         "text": 'Parts of the Book of Daniel (2:4–7:28) and of Ezra are in Aramaic, not Hebrew. It was the language of the Persian Empire, the common language of the Middle East for a thousand years.',
         "chain": [('Blessed be the name of God.', ["ܠܗܘܐ", "ܫܡܗ", "ܕܝ", "ܐܠܗܐ", "ܡܒܪܟ"],
                    'lehĕwēʾ (may be) šĕmēh (his name) dī ʾĕlāhā (of God) mĕbārak.')]},
    ],
    "abun": [
        {"title": 'Our Father in Syriac',
         "text": 'The Peshitta is the Bible in Syriac, the Aramaic of the Eastern churches. It is still read in the liturgy today, in this very script.',
         "chain": [('Our Father, who art in heaven.', ["ܐܒܘܢ", "ܕܒܫܡܝܐ"], 'ʾabūn (Our Father) + dbašmayyā.')]},
    ],
    "kadisz": [
        {"title": 'A prayer in Aramaic',
         "text": 'The Kaddish is a Jewish prayer still said today, in Aramaic. It begins with words that recall “hallowed be thy name”.',
         "chain": []},
    ],
}

ENDINGS_INSIGHT = {
    "title": 'Attached endings',
    "text": 'Aramaic attaches to words what English says separately: -ā = “the”, -ī = “my”, -āk = “your”. Look at the end of the word, which is its left side.',
}

ENDINGS = [
    ("", "ܡܠܟ", "ܐ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], 'the king (malkā)', 'Article: -ā (ܐ).', "emfatyczny"),
    ("", "ܐܠܗ", "ܐ", "", ["ܐ", "ܝ", "ܟ", "ܢ"], 'God (ʾĕlāhā)', 'Article: -ā (ܐ).', "emfatyczny"),
    ("", "ܐܠܗ", "ܝ", "", ["ܐ", "ܝ", "ܟ", "ܢ"], 'my God (ʾĕlāhī)', '“My” = -ī (ܝ).', "jezus"),
    ("", "ܪܒܘܢ", "ܝ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], 'my Teacher (rabbūnī)', '“My” = -ī (ܝ).', "jezus"),
    ("", "ܫܡ", "ܟ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], 'thy name (šmāk)', '“Your” = -āk (ܟ).', "abun"),
    ("", "ܡܠܟܘܬ", "ܟ", "", ["ܐ", "ܝ", "ܟ", "ܗ"], 'thy kingdom (malkūtāk)', '“Your” = -āk (ܟ).', "abun"),
]

CHATS = [
    {
        "id": "shalom", "title": 'Greeting', "partner": "Jan", "avatar": "ܝ", "requires": "slowa",
        "turns": [
            {"bot": ["ܫܠܡ", "!"], "en": 'Peace! (Hello!)',
             "options": [(["ܫܠܡ", "!"], True, None),
                         (["ܠܐ", "!"], False, 'ܠܐ means “no”. Reply with a greeting: ܫܠܡ.')]},
            {"bot": ["ܐܢܬ", "ܒܪ", "?"], "en": 'Are you a son?',
             "options": [(["ܐܢܗ", "ܒܪ"], True, None),
                         (["ܐܢܬ", "ܒܪ"], False, 'ܐܢܬ means “you”. About yourself: ܐܢܗ (I).'),
                         (["ܗܘܐ", "ܒܪ"], False, 'ܗܘܐ means “he”. About yourself: ܐܢܗ.')]},
            {"bot": ["ܐܒܐ", "ܛܒ", "?"], "en": 'Is Dad good?',
             "build": (["ܐܒܐ", "ܛܒ"], 'Dad is good.')},
        ],
    },
    {
        "id": "kefas", "title": 'By the lake', "partner": "Szymon Kefas", "avatar": "ܟ", "requires": "jezus",
        "turns": [
            {"bot": ["ܪܒܘܢܝ", "!"], "en": 'My Teacher!',
             "options": [(["ܫܠܡ"], True, None),
                         (["ܠܡܗ"], False, 'ܠܡܗ means “why”. Say hello: ܫܠܡ.')]},
            {"bot": ["ܡܪܢܐ", "ܬܐ"], "en": 'Our Lord, come!',
             "build": (["ܡܪܢܐ", "ܬܐ"], 'Our Lord, come!')},
        ],
    },
    {
        "id": "babel", "title": 'At the court of Babylon', "partner": "Daniel", "avatar": "ܕ", "requires": "czas",
        "turns": [
            {"bot": ["ܡܠܟܐ", "ܕܝ", "ܒܒܠ", "ܪܒ", "."], "en": 'The king of Babylon is great.',
             "options": [(["ܐܠܗܐ", "ܪܒ"], True, None),
                         (["ܐܠܗ", "ܪܒ"], False, 'Speaking of the one God, use the form with the article: ܐܠܗܐ.')]},
            {"bot": ["ܡܠܟܐ", "ܟܬܒ", "?"], "en": 'Did the king write?',
             "build": (["ܡܠܟܐ", "ܟܬܒ"], 'The king wrote.')},
        ],
    },
]

# Słowa tylko z rozmów: forma → (transkrypcja, znaczenie)
CHAT_EXTRA = {}
PUNCT = set(".,!?:;")


# ---------------------------------------------------------------------------
# Gramatyka.
# PARADIGMS: ("conj" | "decl" | "form", grupa, tytuł, klucz etykiet, formy rozdzielone „; ”, uwaga lub None)
# conj = koniugacje i czasy, decl = deklinacje, zaimki i liczebniki, form = imiesłowy, formy podstawowe, ćwiczenia celowane.
# Liczba form musi być równa liczbie etykiet. Uczeń przechodzi cały wzór: tabela, po kolei, na wyrywki.
# ---------------------------------------------------------------------------

PARADIGM_LABELS = {
}

PARADIGMS = [
]

# Więcej ćwiczeń celowanych w typowe trudności
PARADIGM_LABELS.update({
    't_m0': ['ܐ', 'ܒ', 'ܓ', 'ܕ', 'ܗ', 'ܘ', 'ܡ', 'ܫ'],
    't_m1': ['napisał', 'piszący', 'księga, pismo', 'pisarz'],
    't_m2': ['król', 'syn', 'dom', 'dzień', 'księga'],
})
PARADIGMS += [
    ('form', 'Typowe trudności', 'Litera: jaki dźwięk?', 't_m0', 'ʾ (zwarcie krtaniowe); b; g; d; h; w; m; š', 'Litery oznaczają spółgłoski; samogłoski trzeba znać lub odczytać ze znaczków.'),
    ('form', 'Typowe trudności', 'Rdzeń K-T-B (pisać)', 't_m1', 'kĕtab; kātēb; kĕtābā; kātōbā', 'Słowa buduje się z trzyliterowego rdzenia i wzoru samogłosek.'),
    ('form', 'Typowe trudności', 'Końcowe -ā zamiast rodzajnika', 't_m2', 'malkā; brā; baytā; yawmā; kĕtābā', 'Zwykła forma rzeczownika kończy się na -ā: to dawny rodzajnik.'),
]
